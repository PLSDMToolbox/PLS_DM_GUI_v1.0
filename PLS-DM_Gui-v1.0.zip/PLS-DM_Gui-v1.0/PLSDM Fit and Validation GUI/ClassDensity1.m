%
function [D_sorted, idx_sorted, D] = ClassDensity1(X, include_self)
% SORTED_PAIRWISE_DISTANCES Compute pairwise Euclidean distances and sort them
% -------------------------------------------------------------------------
% [D_sorted, idx_sorted, D] = ClassDensity1(X)
% [D_sorted, idx_sorted, D] =ClassDensity1(X, include_self)
%
% Inputs:
%   X            - data matrix (n x p), n samples, p variables
%   include_self - optional logical flag:
%                  true  -> keep self-distances (zeros on diagonal) when sorting
%                  false -> exclude self-distances by treating diagonal as Inf (default)
%
% Outputs:
%   D_sorted  - (n x n) matrix where each row i contains distances from sample i
%               to all samples sorted in ascending order
%   idx_sorted- (n x n) matrix with corresponding column indices: idx_sorted(i,k)
%               gives the original column index of the k-th nearest sample to i
%   D         - (n x n) full symmetric distance matrix (unsorted)
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 2
    include_self = false; % default: exclude self-distances when sorting
end

% Ensure numeric input
if ~isnumeric(X)
    error('Input X must be a numeric matrix.');
end

[n, p] = size(X);

% ------------------------
% 1) Compute squared norms for each row (n x 1)
% ------------------------
% Using the identity: ||x - y||^2 = ||x||^2 + ||y||^2 - 2 x*y'
sq_norms = sum(X.^2, 2);            % (n x 1)

% ------------------------
% 2) Build squared distance matrix in vectorized form
% ------------------------
% D2(i,j) = sq_norms(i) + sq_norms(j) - 2 * X(i,:) * X(j,:)'
D2 = bsxfun(@plus, sq_norms, sq_norms') - 2 * (X * X');  % (n x n)

% Numerical issues: tiny negative values may appear due to floating point -> clamp
D2(D2 < 0 & D2 > -1e-12) = 0;

% Final Euclidean distance matrix
D = sqrt(D2);

% ------------------------
% 3) Handle self-distances before sorting
% ------------------------
if ~include_self
    % set diagonal to Inf so self-distance is excluded from the ascending order
    D_no_self = D;
    D_no_self(1:n+1:end) = Inf;
else
    D_no_self = D; % keep zeros on diagonal
end

% ------------------------
% 4) Sort each row ascending and return both distances and indices
% ------------------------
[D_sorted, idx_sorted] = sort(D_no_self, 2, 'ascend');  % sort along rows

end
