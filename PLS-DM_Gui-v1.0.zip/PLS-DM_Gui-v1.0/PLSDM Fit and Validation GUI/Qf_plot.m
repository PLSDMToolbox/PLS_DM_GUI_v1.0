%
function hFig = Qf_plot(PLSDMmodel, opts)
%QF_PLOT  Visualize Q-residuals and probability-of-fit (f) distributions.
%
% SYNTAX:
%   hFig = Qf_plot(PLSDMmodel)
%   hFig = Qf_plot(PLSDMmodel, opts)
%
% EXAMPLE:
%   h = Qf_plot(PLSDMmodel);
%   h = Qf_plot(PLSDMmodel, struct('logQ',true,'title','Cross-validation Fold 3'));
% ---------- Validate ----------
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 1 || ~isstruct(PLSDMmodel) || ~isfield(PLSDMmodel,'FinalModel')
    error('Qf_plot:InvalidInput','PLSDMmodel.FinalModel is required.');
end
FM = PLSDMmodel.FinalModel;
need = {'Qresid','Qlimit','f_train','flimit'};
for k=1:numel(need)
    if ~isfield(FM,need{k}) || isempty(FM.(need{k}))
        error('Qf_plot:MissingField','Missing FinalModel.%s.',need{k});
    end
end
if nargin<2 || isempty(opts), opts = struct; end
if ~isfield(opts,'nbins'), opts.nbins = []; end
if ~isfield(opts,'logQ'),  opts.logQ  = false; end
if ~isfield(opts,'title'), opts.title = 'Q and f distributions'; end
if ~isfield(opts,'fmin'),  opts.fmin  = []; end

% ---------- Data ----------
Q = FM.Qresid; Qlimit = FM.Qlimit;
f = FM.f_train(:); flimit = FM.flimit;
if ~isvector(Q), if size(Q,1)<size(Q,2), Q=Q.'; end, Qs = sqrt(sum(Q.^2,2)); else, Qs=Q(:); end
N = min(numel(Qs), numel(f)); Qs = Qs(1:N); f = f(1:N);
mask = isfinite(Qs) & isfinite(f); Qs = Qs(mask); f = f(mask); N = numel(Qs);

if opts.logQ
    Qplot = log(1 + max(Qs,0)); Qthr = log(1 + max(Qlimit,0));
    q_xlab = 'log(1+Q residual)'; q_thr_lab = 'log(1+Q_\alpha)';
else
    Qplot = Qs; Qthr = Qlimit;
    q_xlab = 'Q residual (per sample)'; q_thr_lab = 'Q_\alpha';
end
%
kQ = choose_bins_legacy(Qplot, opts.nbins);
kF = choose_bins_legacy(f,     opts.nbins);
%
cBlue  = [0.27 0.50 0.70];
cGreen = [0.35 0.70 0.40];
cRed   = [0.85 0.30 0.30];
cLine  = [0.80 0.10 0.10];
fa     = 0.20; lw = 1.6; axfs = 11; labfs = 12; titfs = 14;

% ---------- Figure ----------
hFig = figure('Color','w','Name','Q and f distributions','Units','normalized','Position',[0.2 0.2 0.58 0.46]);
annotation(hFig,'textbox',[0.15 0.94 0.7 0.05],'String',opts.title,'HorizontalAlignment','center','VerticalAlignment','middle','FontWeight','bold','FontSize',15,'LineStyle','none');

subplot(1,2,1); hold on; box on; grid on; set(gca,'FontSize',axfs,'XMinorTick','on','YMinorTick','on');
[centQ, cntQ] = hist_counts_2010(Qplot, kQ);
bar(centQ, cntQ, 0.9, 'FaceColor', cBlue, 'EdgeColor','k');

yl = ylim; xL = xlim;
patch([xL(1) min(Qthr,xL(2)) min(Qthr,xL(2)) xL(1)], [0 0 yl(2) yl(2)], cGreen, 'FaceAlpha',fa, 'EdgeColor','none');
patch([min(Qthr,xL(2)) xL(2) xL(2) min(Qthr,xL(2))], [0 0 yl(2) yl(2)], cRed,   'FaceAlpha',fa, 'EdgeColor','none');

plot([Qthr Qthr], ylim, '--', 'LineWidth', lw, 'Color', cLine);
text(Qthr, yl(2)*0.95, sprintf('%s=%.3g', q_thr_lab, Qlimit), 'Color', cLine, 'HorizontalAlignment','center','VerticalAlignment','top','FontSize',10,'BackgroundColor',[1 1 1]);

xlabel(q_xlab, 'FontSize', labfs, 'FontWeight','bold');
ylabel('Frequency', 'FontSize', labfs, 'FontWeight','bold');    % <-- Y = Frequency
title('Q-residuals', 'FontSize', titfs, 'FontWeight','bold');

text(0.05,0.88, sprintf('N=%d  \\mu=%.3g  \\sigma=%.3g  acc=%.1f%%', N, mean(Qs), std(Qs), 100*mean(Qs<=Qlimit)), ...
    'Units','normalized','BackgroundColor',[1 1 1],'EdgeColor',[0.7 0.7 0.7],'FontSize',10);

subplot(1,2,2); hold on; box on; grid on; set(gca,'FontSize',axfs,'XMinorTick','on','YMinorTick','on');
[centF, cntF] = hist_counts_2010(f, kF);
bar(centF, cntF, 0.9, 'FaceColor', cGreen, 'EdgeColor','k');


xL = xlim;
if ~isempty(opts.fmin)
    xlim([opts.fmin, xL(2)]);
else
   
    xlim([max(0,min(0.2,0.5*flimit)), xL(2)]);
end
yl = ylim; xL = xlim;


patch([xL(1) min(flimit,xL(2)) min(flimit,xL(2)) xL(1)], [0 0 yl(2) yl(2)], cRed,   'FaceAlpha',fa, 'EdgeColor','none');
patch([min(flimit,xL(2)) xL(2) xL(2) min(flimit,xL(2))], [0 0 yl(2) yl(2)], cGreen, 'FaceAlpha',fa, 'EdgeColor','none');

plot([flimit flimit], ylim, '--', 'LineWidth', lw, 'Color', cLine);
text(flimit, yl(2)*0.95, sprintf('f_{\\alpha}=%.3g', flimit), 'Color', cLine, 'HorizontalAlignment','center','VerticalAlignment','top','FontSize',10,'BackgroundColor',[1 1 1]);

xlabel('Density (f)', 'FontSize', labfs, 'FontWeight','bold');  % <-- no "probability"
ylabel('Frequency',  'FontSize', labfs, 'FontWeight','bold');  % <-- Y = Frequency
title('f Density',   'FontSize', titfs, 'FontWeight','bold');  % <-- title sem "probability"

% stats (inside axes)
text(0.05,0.88, sprintf('\\mu=%.3g  \\sigma=%.3g  acc=%.1f%%', mean(f), std(f), 100*mean(f>=flimit)), ...
    'Units','normalized','BackgroundColor',[1 1 1],'EdgeColor',[0.7 0.7 0.7],'FontSize',10);

end

function k = choose_bins_legacy(x, kUser)
    x = x(isfinite(x));
    n = numel(x);
    if ~isempty(kUser), k = max(5,min(100,round(kUser))); return; end
    if n<=1, k=5; return; end
    iqrX = iqr_fast(x);
    h = 2*iqrX*(n^(-1/3));
    xr = max(x)-min(x);
    if isfinite(h) && h>0 && xr>0
        k = max(5, min(100, ceil(xr/h)));
    else
        k = max(5, min(100, round(1 + 3.322*log10(n))));
    end
end

function q = iqr_fast(x)
    x = sort(x(:)); n = numel(x);
    if n<4, q = max(eps, std(x)); return; end
    q1 = median(x(1:floor(n/2)));
    if mod(n,2)==0, q3 = median(x(floor(n/2)+1:end));
    else,           q3 = median(x(ceil(n/2)+1:end));
    end
    q = max(eps, q3-q1);
end

function [centers, counts] = hist_counts_2010(x, k)
    x = x(:);
    xmin = min(x); xmax = max(x);
    if ~isfinite(xmin) || ~isfinite(xmax) || xmin==xmax
        xmin = xmin - 0.5; xmax = xmax + 0.5;
    end
    edges  = linspace(xmin, xmax, k+1);   
    counts = histc(x, edges);             
    counts(end-1) = counts(end-1) + counts(end);
    counts(end)   = [];                   
    centers = (edges(1:end-1) + edges(2:end))/2;
end