%
function [results_struct, pareto_struct, best_model] = analyze_pls_dm_results(compliance, kappa_values, smooth_values)
% ANALYZE_PLS_DM_RESULTS - Analyze and visualize PLS-DM model results.
%
% INPUTS:
%   compliance     - 3D cell array of result structs (kappa x smooth x LV)
%   kappa_values   - Vector of kappa values (optional)
%   smooth_values  - Vector of smooth values (optional)
%
% OUTPUTS:
%   results_struct - Struct array with metrics for all models
%   pareto_struct  - Subset of models on the Pareto front
%   best_model     - Best model from Pareto front (highest efficiency)
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 2 || isempty(kappa_values)
    kappa_values = 1:6;
    smooth_values = 0.3:0.1:0.8;
end

[nK, nS, nLV] = size(compliance);
results_struct = [];
idx = 0;
caseType = '';  


for i = 1:nK
    for j = 1:nS
        for lv = 1:nLV
            res = compliance{i,j,lv};
            if isempty(res), continue; end
            
           
            if isfield(res, 'Gtrue') && any(res.Gtrue ~= 1)
                caseType = 'compliant';
            else
                caseType = 'rigorous';
            end
            
            idx = idx + 1;
            results_struct(idx).ModelNum    = idx;
            results_struct(idx).Kappa       = kappa_values(i);
            results_struct(idx).Smooth      = smooth_values(j);
            results_struct(idx).LV          = lv;
            results_struct(idx).CaseType    = caseType;
            results_struct(idx).Sensitivity = getfield_safe(res, 'sensitivity');
            results_struct(idx).Specificity = getfield_safe(res, 'specificity');
            results_struct(idx).Precision   = getfield_safe(res, 'precision');
            results_struct(idx).Accuracy    = getfield_safe(res, 'accuracy');
            results_struct(idx).F1Score     = getfield_safe(res, 'f1score');
            results_struct(idx).Efficiency  = getfield_safe(res, 'efficiency');
        end
    end
end
fprintf('\n=== ALL MODELS ===\n');
fprintf('Num | Kappa | Smooth | LV | Case      | Sens   | Spec   | Prec   | Acc    | F1     | Eff    \n');
fprintf('---------------------------------------------------------------------------------------------\n');
for i = 1:length(results_struct)
    r = results_struct(i);
    fprintf('%3d | %5d | %6.2f | %2d | %-9s | %.4f | %.4f | %.4f | %.4f | %.4f | %.4f\n', ...
        r.ModelNum, r.Kappa, r.Smooth, r.LV, r.CaseType, ...
        r.Sensitivity, r.Specificity, r.Precision, ...
        r.Accuracy, r.F1Score, r.Efficiency);
end

if strcmp(caseType, 'compliant')
    selected_idx = strcmp({results_struct.CaseType}, 'compliant');
    sens = [results_struct(selected_idx).Sensitivity];
    spec = [results_struct(selected_idx).Specificity];
    valid = ~isnan(sens) & ~isnan(spec);
    valid_idx = find(selected_idx);
    valid_idx = valid_idx(valid);
      
    ispareto = pareto_front(spec(valid), sens(valid));
    pareto_struct = results_struct(valid_idx(ispareto));
    
     effs = [pareto_struct.Efficiency];
    [~, best_idx] = max(effs);
    best_model = pareto_struct(best_idx);
    

    figure; hold on;
    all_spec = [results_struct(valid_idx).Specificity];
    all_sens = [results_struct(valid_idx).Sensitivity];
    all_nums = [results_struct(valid_idx).ModelNum];
    
    scatter(all_spec, all_sens, 50, 'b', 'filled');
    dx = 0.005 * range(all_spec);
    dy = 0.005 * range(all_sens);
    for k = 1:length(all_nums)
        text(all_spec(k)+dx, all_sens(k)+dy, sprintf('%d', all_nums(k)), ...
            'FontSize', 8, 'Color', [0.2 0.2 0.2]);
    end
    
  
    pareto_spec = [pareto_struct.Specificity];
    pareto_sens = [pareto_struct.Sensitivity];
    pareto_nums = [pareto_struct.ModelNum];
    
    scatter(pareto_spec, pareto_sens, 70, 'ro', 'LineWidth', 1.5);
    

    [sorted_spec, sort_idx] = sort(pareto_spec);
    sorted_sens = pareto_sens(sort_idx);
    plot(sorted_spec, sorted_sens, 'r-', 'LineWidth', 1.5);
    
    scatter(best_model.Specificity, best_model.Sensitivity, ...
        100, 'gs', 'filled');
    text(best_model.Specificity + dx, best_model.Sensitivity + dy, ...
        sprintf('%d', best_model.ModelNum), ...
        'FontSize', 9, 'Color', 'g', 'FontWeight', 'bold');
    
    xlabel('Specificity'); ylabel('Sensitivity');
    title('Pareto Front - PLS-DM (Compliant Case)');
    legend('All Valid Models', 'Pareto Front', 'Best Model (green square)', 'Location', 'best');
    grid on; box on;
    
else
    % RIGOROUS CASE - Only Sensitivity is available
    selected_idx = strcmp({results_struct.CaseType}, 'rigorous');
    valid_idx = find(selected_idx);
    sens = [results_struct(valid_idx).Sensitivity];
    valid = ~isnan(sens);
    valid_idx = valid_idx(valid);
    
    % In rigorous mode, use Sensitivity only
    all_sens = sens(valid);
    all_nums = [results_struct(valid_idx).ModelNum];
    
    % Pareto front = max sensitivity
    [max_sens, best_pos] = max(all_sens);
    pareto_struct = results_struct(valid_idx(all_sens == max_sens));
    best_model = results_struct(valid_idx(best_pos));
    
    % Plot: Sensitivity only
    figure; hold on;
    scatter(1:length(all_sens), all_sens, 50, 'b', 'filled');
    for k = 1:length(all_sens)
        text(k+0.1, all_sens(k), sprintf('%d', all_nums(k)), ...
            'FontSize', 8, 'Color', [0.2 0.2 0.2]);
    end
   
    scatter(best_pos, max_sens, 100, 'gs', 'filled');
    text(best_pos + 0.2, max_sens, sprintf('%d', all_nums(best_pos)), ...
        'FontSize', 9, 'Color', 'g', 'FontWeight', 'bold');
    
    xlabel('Model Index'); ylabel('Sensitivity');
    title('Rigorous Mode - Sensitivity per Model');
    legend('Valid Models', 'Best Model (green square)', 'Location', 'best');
    grid on; box on;
end

end

% 
function val = getfield_safe(s, f)
if isfield(s, f)
    val = s.(f);
    if isempty(val)
        val = NaN;
    end
else
    val = NaN;
end
end

%  Compute Pareto front 
function ispareto = pareto_front(x, y)
n = length(x);
ispareto = true(n,1);
for i = 1:n
    ispareto(i) = ~any((x > x(i) & y >= y(i)) | ...
        (x >= x(i) & y > y(i)));
end
end

