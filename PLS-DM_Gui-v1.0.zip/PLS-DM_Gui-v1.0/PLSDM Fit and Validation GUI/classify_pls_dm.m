%
function results = classify_pls_dm(Q, f, Qcrit, falpha, Gtrue)
%CLASSIFY_PLS_DM Classification and performance metrics for PLS-DM (One-Class Classification)
%
% This function classifies samples using the PLS-DM (Partial Least Squares
% Density Modeling) acceptance criteria:
%
%   Q_i / Qcrit <= 1     AND     -log(f_i) / -log(f_alpha) <= 1
%
%
% Where:
%   - Q is the residual variance (SPE)
%   - f is the potential function (PFM density)
%   - Qcrit is the critical Q threshold (e.g., from training set)
%   - f_alpha is the minimum acceptable density threshold
%
% Gtrue should contain:
%   1 = samples belonging to the class (target class)
%   2,3,... = samples not belonging to the class
%
% INPUTS:
%   Q       - vector (n x 1) of Q values
%   f       - vector (n x 1) of potential function values
%   Qcrit   - scalar, Q threshold
%   falpha  - scalar, f_alpha threshold
%   Gtrue   - vector (n x 1) of true class labels (1 = class, others = non-class)
%
% OUTPUT:
%   results - structure containing:
%       Gtrue          - original class labels (1, 2, ...)
%       Gtrue_bin      - binarized labels (1 = class, 0 = non-class)
%       Gpred_bin      - predicted class (1 = accepted, 0 = rejected)
%       Qnorm          - normalized Q values
%       logf_norm      - normalized -log(f) values
%       TP, TN, FP, FN - confusion matrix elements
%       sensitivity    - true positive rate (recall)
%       specificity    - true negative rate
%       precision      - positive predictive value
%       accuracy       - overall correct classification rate
%       f1score        - harmonic mean of precision and recall
%       efficiency     - geometric mean of sensitivity and specificity
%  Binarize true classes
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

Q = Q(:); f = f(:); Gtrue = Gtrue(:);
Gtrue_bin = (Gtrue == 1);

% Thresholds may be scalars or fold/sample-specific vectors.
if isscalar(Qcrit), Qcrit = repmat(Qcrit,numel(Q),1); else, Qcrit = Qcrit(:); end
if isscalar(falpha), falpha = repmat(falpha,numel(f),1); else, falpha = falpha(:); end
if numel(Qcrit) ~= numel(Q) || numel(falpha) ~= numel(f)
    error('Invalid threshold size.');
end

Qcrit(Qcrit<=0) = realmin('double');
f(f<=0) = realmin('double');
falpha(falpha<=0) = realmin('double');

Qnorm = Q ./ Qcrit;
logf_norm = -log(f) ./ max(abs(-log(falpha)),eps);

% Inclusive joint decision: Q <= Qcrit AND f >= falpha.
Gpred_bin = (Q <= Qcrit) & (f >= falpha);

%  Confusion matrix 
TP = sum(Gpred_bin == 1 & Gtrue_bin == 1);
FN = sum(Gpred_bin == 0 & Gtrue_bin == 1);

% Check if there are non-class samples
has_negatives = any(Gtrue_bin == 0);

if has_negatives
    % Normal full-case metrics
    TN = sum(Gpred_bin == 0 & Gtrue_bin == 0);
    FP = sum(Gpred_bin == 1 & Gtrue_bin == 0);
    
    sensitivity = TP / (TP + FN);
    specificity = TN / (TN + FP);
    precision   = TP / (TP + FP);
    accuracy    = (TP + TN) / length(Gtrue);
    f1score     = 2 * (precision * sensitivity) / (precision + sensitivity);
    efficiency  = sqrt(sensitivity * specificity);
else
    % Only class 1 present (no TN or FP)
    TN = 0; FP = 0;
    
    sensitivity = TP / (TP + FN);
    specificity = NaN;
    precision   = NaN;
    accuracy    = sensitivity; 
    f1score     = NaN;
    efficiency  = NaN;
end

%  Store results 
results.Gtrue       = Gtrue;
results.Gtrue_bin   = Gtrue_bin;
results.Gpred_bin   = Gpred_bin;

results.Qnorm       = Qnorm;
results.logf_norm   = logf_norm;

results.TP = TP; results.FP = FP;
results.TN = TN; results.FN = FN;

results.sensitivity = sensitivity;
results.specificity = specificity;
results.precision   = precision;
results.accuracy    = accuracy;
results.f1score     = f1score;
results.efficiency  = efficiency;
end
