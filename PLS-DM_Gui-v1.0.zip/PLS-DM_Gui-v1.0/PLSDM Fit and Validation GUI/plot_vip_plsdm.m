%
function hFig = plot_vip_plsdm(PLSDMmodel, varargin)
% 
% Plot active-class and other-class mean training signals with VIP overlay.
% ---------- Checks ----------
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

req = isfield(PLSDMmodel,'Xtrain') && isfield(PLSDMmodel,'ClassTrain') && ...
      isfield(PLSDMmodel,'FinalModel') && isfield(PLSDMmodel.FinalModel,'VIP') && ...
      isfield(PLSDMmodel,'var_label');
if ~req
    error('PLSDMmodel must contain Xtrain, ClassTrain, FinalModel.VIP, and var_label.');
end

X      = PLSDMmodel.Xtrain;
yclass = PLSDMmodel.ClassTrain(:);
classOriginal = yclass;
targetClass = 1;
if isfield(PLSDMmodel,'OriginalClassTrain') && ~isempty(PLSDMmodel.OriginalClassTrain)
    classOriginal = PLSDMmodel.OriginalClassTrain(:);
end
if isfield(PLSDMmodel,'TargetClass') && ~isempty(PLSDMmodel.TargetClass)
    targetClass = PLSDMmodel.TargetClass;
end
vip    = PLSDMmodel.FinalModel.VIP(:);
labels = PLSDMmodel.var_label(:);

[n,m] = size(X);
if length(vip) ~= m,    error('VIP length must equal size(Xtrain,2).'); end
if length(labels) ~= m, error('var_label length must equal size(Xtrain,2).'); end
if length(yclass) ~= n, error('ClassTrain length must equal size(Xtrain,1).'); end
if length(classOriginal) ~= n
    classOriginal = yclass;
    targetClass = 1;
end

% ---------- Options ----------
Cutoff        = 1.0;
PlotTitle     = 'Active-class and other-class mean signals with VIP overlay';
HighlightTopN = 0;
SaveAsFile    = '';
ParentAxes    = [];
for k = 1:2:length(varargin)
    switch lower(varargin{k})
        case 'cutoff',        Cutoff        = varargin{k+1};
        case 'title',         PlotTitle     = varargin{k+1};
        case 'highlighttopn', HighlightTopN = max(0, round(varargin{k+1}));
        case 'saveas',        SaveAsFile    = varargin{k+1};
        case 'parentaxes',    ParentAxes    = varargin{k+1};
    end
end

if isfield(PLSDMmodel,'OriginalClassTrain') && ~isempty(PLSDMmodel.OriginalClassTrain) && ...
        isfield(PLSDMmodel,'TargetClass') && ~isempty(PLSDMmodel.TargetClass)
    maskT = (classOriginal == targetClass);
else
    maskT = (yclass == 1);
end

if ~any(maskT), error('No samples found for the active target class.'); end
mean_target = mean(X(maskT, :), 1);

otherClasses = unique(classOriginal(:));
otherClasses = otherClasses(otherClasses ~= targetClass);
mean_other = {};
other_labels = {};
for ic = 1:length(otherClasses)
    maskC = (classOriginal == otherClasses(ic));
    if any(maskC)
        mean_other{end+1} = mean(X(maskC,:),1);
        other_labels{end+1} = ['Class ' num2str(otherClasses(ic)) ' mean'];
    end
end
hasOther = ~isempty(mean_other);


x = 1:m;


c_tar  = [0.12 0.36 0.80]; 
c_vip  = [0.00 0.60 0.30]; 
c_gray = [0.35 0.35 0.35]; 
lw_tar = 2.2;
lw_nt  = 1.6;
lw_vip = 1.7;
otherColors = [0.75 0.00 0.00;
               0.85 0.45 0.05;
               0.55 0.15 0.70;
               0.10 0.55 0.65;
               0.45 0.45 0.45;
               0.80 0.30 0.55];

if isempty(ParentAxes)
    hFig = figure('Color','w','Position',[80 80 1250 560]);
    [ax, hLeftMain, hVIP] = plotyy(x, mean_target, x, vip, 'plot', 'plot');
else
    if ~ishandle(ParentAxes) || ~strcmpi(get(ParentAxes,'Type'),'axes')
        error('ParentAxes must be a valid axes handle.');
    end
    hFig = ancestor(ParentAxes,'figure');
    [ax, hLeftMain, hVIP] = plotyy(ParentAxes,x,mean_target,x,vip,'plot','plot');
end
set(hLeftMain, 'Color', c_tar, 'LineWidth', lw_tar);      % target mean
set(hVIP,      'Color', c_vip, 'LineWidth', lw_vip);      % VIP (right axis)

hold(ax(1),'on');
hOther = [];
if hasOther
    for ic = 1:length(mean_other)
        cidx = mod(ic-1,size(otherColors,1))+1;
        hOther(ic) = plot(ax(1), x, mean_other{ic}, ...
            'Color', otherColors(cidx,:), 'LineWidth', lw_nt);
    end
end
try uistack(hLeftMain,'top'); catch, end


set(ax(1), 'FontName','Arial','FontSize',10, 'Box','off', 'Layer','top', 'XLim',[1 m]);
set(ax(2), 'FontName','Arial','FontSize',10, 'Box','off', 'Layer','top', 'XLim',[1 m]);
set(get(ax(1),'Ylabel'),'String','Mean signal', 'FontName','Arial','FontSize',12,'FontWeight','bold');
set(get(ax(2),'Ylabel'),'String','VIP score',            'FontName','Arial','FontSize',12,'FontWeight','bold');
xlabel(ax(1),'Variables','FontName','Arial','FontSize',11);
title(ax(1),PlotTitle, 'FontName','Arial','FontSize',14,'FontWeight','bold');
grid(ax(1),'on'); grid(ax(2),'on');

% ---------- VIP cutoff band 
if ~isempty(Cutoff) && isfinite(Cutoff)
    y2 = get(ax(2),'YLim');
    yTop = max(y2(2), max(vip)*1.05);
    set(ax(2),'YLim',[0 yTop]);
    hold(ax(2),'on');
    
    try
        patch([1 m m 1],[Cutoff Cutoff yTop yTop], c_vip, ...
              'Parent', ax(2), 'FaceAlpha', 0.08, 'EdgeColor','none');
    catch
       
    end
    plot(ax(2), [1 m], [Cutoff Cutoff], '--', 'Color', c_gray, 'LineWidth', 1.5);
end


if HighlightTopN > 0
    [~, ord] = sort(vip, 'descend');
    kN = min(HighlightTopN, m);
    idxTop = ord(1:kN);
    hold(ax(2),'on');
    plot(ax(2), idxTop, vip(idxTop), 'o', ...
        'MarkerFaceColor', c_vip, 'MarkerEdgeColor', 'w', 'MarkerSize', 5);
end


if m <= 40
    set(ax(1),'XTick',x,'XTickLabel',labels);
    set(ax(2),'XTick',x,'XTickLabel',[]);
    xticklabel_rotate_legacy(ax(1), 45);
else
    step = max(1, round(m/35));
    ticks = 1:step:m;
    set(ax(1),'XTick',ticks,'XTickLabel',labels(ticks));
    set(ax(2),'XTick',ticks,'XTickLabel',[]);
    xticklabel_rotate_legacy(ax(1), 45);
end

y1min = min(mean_target); 
y1max = max(mean_target);
if hasOther
    for ic = 1:length(mean_other)
        y1min = min([y1min, min(mean_other{ic})]);
        y1max = max([y1max, max(mean_other{ic})]);
    end
end
set(ax(1),'YLim',[min(0, y1min), y1max*1.08]);

y2 = get(ax(2),'YLim');
set(ax(2),'YLim',[0, max(y2(2), max(vip)*1.10)]);

legH = []; legS = {};
legH(end+1) = hLeftMain; 
if targetClass == 1 && ~(isfield(PLSDMmodel,'OriginalClassTrain') && ~isempty(PLSDMmodel.OriginalClassTrain))
    legS{end+1} = 'Target mean';
else
    legS{end+1} = ['Class ' num2str(targetClass) ' mean'];
end
if hasOther
    for ic = 1:length(hOther)
        legH(end+1) = hOther(ic);
        legS{end+1} = other_labels{ic};
    end
end
legH(end+1) = hVIP;        legS{end+1} = 'VIP';
if ~isempty(Cutoff) && isfinite(Cutoff)
    hCut = plot(ax(2), NaN, NaN, '--', 'Color', c_gray, 'LineWidth', 1.5);
    legH(end+1) = hCut; legS{end+1} = sprintf('VIP cutoff = %.2f', Cutoff);
end
legend(ax(1), legH, legS, 'Location','northeast', 'Box','off');

if isempty(ParentAxes)
    set(ax(1),'Units','normalized'); pos = get(ax(1),'Position'); pos(2)=pos(2)+0.04; set(ax(1),'Position',pos);
    set(ax(2),'Units','normalized'); pos2= get(ax(2),'Position'); pos2(2)=pos2(2)+0.04; set(ax(2),'Position',pos2);
end

if ~isempty(SaveAsFile)
    [~,~,ext] = fileparts(SaveAsFile);
    set(hFig,'PaperPositionMode','auto');
    switch lower(ext)
        case '.png', print(hFig,'-dpng','-r300',SaveAsFile);
        case '.pdf', print(hFig,'-dpdf',SaveAsFile);
        otherwise,   warning('Unsupported extension for SaveAs. Use .png or .pdf');
    end
end

end %  end main

% --------------------
function xticklabel_rotate_legacy(ax, angle_deg)

xt = get(ax,'XTick');
xl = get(ax,'XTickLabel');
if isempty(xl) || ischar(xl), return; end
set(ax,'XTickLabel',[]);
yl = get(ax,'YLim');
ypos = yl(1) - 0.03*(yl(2)-yl(1));
for i = 1:length(xt)
    if i <= length(xl)
        text('Parent', ax, 'Position', [xt(i) ypos 0], 'String', xl{i}, ...
            'Rotation', angle_deg, 'HorizontalAlignment','right', ...
            'VerticalAlignment','top', 'FontName','Arial','FontSize',9);
    end
end
end
