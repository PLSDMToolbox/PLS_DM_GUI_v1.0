%
function PLSmodel = pls_fit(X, y, maxLV, conflev, alpha, preprocessing)
% SYNTAX: PLSMODEL = pls_fit(X, y, maxLV, conflev, alpha, preprocessing)
% 
% Fits a PLS model with optional preprocessing and computes Q-residual
% statistics and potential-function densities for PLS-DM applications.
%
% Also computes Variable Importance in Projection (VIP) scores.
%
% Inputs:
%   X            - Training predictors (n x m)
%   y            - Training responses (n x 1)
%   maxLV        - Number of latent variables to extract
%   conflev      - Confidence level for Q and f limits (e.g., 0.95)
%   alpha        - Smoothing coefficient for PFM (e.g., 0.3-0.8)
%   preprocessing - 'raw' | 'centered' | 'scaled' | 'autoscaled'
%
% Output:
%   PLSmodel - Struct with all model parameters and thresholds
% Check inputs
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 6
    error('All 6 arguments must be provided.');
end
[n, m] = size(X);
y = y(:);  
% === Preprocessing ===
mu = mean(X, 1);                
sigma = std(X, 0, 1);
sigma(sigma == 0) = 1;          

switch lower(preprocessing)
    case 'raw'
        Xp = X;
        mu = zeros(1, m);
        sigma = ones(1, m);

    case 'centered'
        Xp = X - repmat(mu, n, 1);

    case 'scaled'
        Xp = X ./ repmat(sigma, n, 1);
        mu = zeros(1,m);

    case 'autoscaled'
        Xp = (X - repmat(mu, n, 1)) ./ repmat(sigma, n, 1);

    otherwise
        error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
end

% === NIPALS PLS ===
T = zeros(n, maxLV);
P = zeros(m, maxLV);
W = zeros(m, maxLV);
Qy = zeros(1, maxLV);
Xres = Xp;
yres = y;

for a = 1:maxLV
    u = yres;
    diff = 1;
    while diff > 1e-10
        w = (Xres' * u) / (u' * u);
        w = w / norm(w);
        t = Xres * w;
        q = (yres' * t) / (t' * t);
        u_new = yres * (q / (q^2));
        diff = norm(u_new - u);
        u = u_new;
    end
    p = (Xres' * t) / (t' * t);

    T(:, a) = t;
    P(:, a) = p;
    W(:, a) = w;
    Qy(a) = q;

    Xres = Xres - t * p';
    yres = yres - t * q;
end

% === Regression coefficients ===
B = W * ((P' * W) \ Qy');

% === Q-residuals ===
Xhat = T(:,1:maxLV) * P(:,1:maxLV)';
Xrec = Xp - Xhat;
Q = sum(Xrec.^2, 2);

% === Q-limit using Jackson and Mudholkar method ===
Qlimit = plsdm_original_qlimit(Xrec,conflev);

% === Potential Function (PFM) f estimation ===
[~,f_alpha,f_train] = plsdm_original_pfm(T(:,1:maxLV),T(:,1:maxLV),alpha,conflev);

% === VIP scores ( ===
% SSY_a = (t_a' * t_a) * (q_a^2); VIP_j = sqrt( m * sum_a SSY_a * (w_ja^2)/(w_a'w_a) / sum_a SSY_a )
SSY = zeros(maxLV,1);
for a = 1:maxLV
    ta = T(:,a);
    qa = Qy(a);
    SSY(a) = (ta' * ta) * (qa^2);
end
denSSY = sum(SSY);
if denSSY <= eps
    vip = NaN(m,1);
else
    vip = zeros(m,1);
    for j = 1:m
        s = 0;
        for a = 1:maxLV
            wa = W(:,a);
            wja = W(j,a);
            denom_w = wa' * wa;
            if denom_w <= eps, denom_w = eps; end
            s = s + SSY(a) * (wja^2) / denom_w;
        end
        vip(j) = sqrt( (m * s) / denSSY );
    end
end

% === Output struct ===
PLSmodel.Xmean = mu;
PLSmodel.Xstd = sigma;
PLSmodel.preprocessing = preprocessing;
PLSmodel.W = W;
PLSmodel.P = P;
PLSmodel.Qy = Qy;
PLSmodel.B = B;
PLSmodel.T = T;
PLSmodel.maxLV = maxLV;
PLSmodel.conflev = conflev;
PLSmodel.alpha = alpha;
PLSmodel.Qlimit = Qlimit;
PLSmodel.Qresid = Q;
PLSmodel.flimit = f_alpha;
PLSmodel.f_train = f_train;
PLSmodel.VIP = vip;      
% PLSmodel.QlimitO = QlimitO;
% PLSmodel.flimitO = f_alphaO;
end
