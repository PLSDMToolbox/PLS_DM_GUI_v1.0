%
function result = pls_predict(Xtest, PLSmodel, LV)
% SYNTAX: result = pls_predict(Xtest, PLSmodel, LV)
%
% Applies a previously trained PLS model to new test data and evaluates:
%   - Predicted y values
%   - Q residuals and threshold comparison
%   - Potential Function Method (f values) and threshold comparison
%
% Inputs:
%   Xtest     - Test data (n x m)
%   PLSmodel  - Struct from pls_fit
%   LV        - Number of latent variables to use
%
% Output (struct 'result'):
%   .y_pred   - Predicted y values
%   .Q        - Q residuals
%   .Qpass    - Q <= Qlimit
%   .f        - PFM density values
%   .fpass    - f >= flimit
%   .accepted - Logical AND of Qpass and fpass

% === Preprocess Xtest based on PLSmodel settings ===
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

[n_test, m] = size(Xtest);
mu = PLSmodel.Xmean;
sigma = PLSmodel.Xstd;

switch lower(PLSmodel.preprocessing)
    case 'raw'
        Xp = Xtest;

    case 'centered'
        Xp = Xtest - repmat(mu, n_test, 1);

    case 'scaled'
        Xp = Xtest ./ repmat(sigma, n_test, 1);

    case 'autoscaled'
        Xp = (Xtest - repmat(mu, n_test, 1)) ./ repmat(sigma, n_test, 1);

    otherwise
        error('Unknown preprocessing type in PLSmodel');
end

W = PLSmodel.W(:,1:LV);
P = PLSmodel.P(:,1:LV);
Qy = PLSmodel.Qy(1:LV);
Wcoeff = W / (P' * W);
Ttest = Xp * Wcoeff;
B = W * ((P' * W) \ Qy');
y_pred = Xp * B;

% Q-residuals and acceptance 
Xhat = Ttest * P';
Q = sum((Xp - Xhat).^2, 2);
Qpass = Q <= PLSmodel.Qlimit;

% Compute f values using original-compatible PFM
Ttrain = PLSmodel.T(:,1:LV);
f_test = plsdm_original_pfm(Ttrain,Ttest,PLSmodel.alpha,PLSmodel.conflev);
fpass = f_test >= PLSmodel.flimit;

%  Output 
result.y_pred = y_pred;
result.Q = Q;
result.Qpass = Qpass;
result.f = f_test;
result.fpass = fpass;
result.accepted = Qpass & fpass;

end
