%
function PLSDM_CV=plsdm_CV(Xtrain, ClassTrain, K, LV, conflev, alpha, kappa,preprocessing,var_label,status);
% PLSDM_CV - Train and evaluate a PLS-DM (Partial Least Squares - Density Modeling)
%
% Syntax:
%   PLSDMCV = plsdm_ft(Xtrain, ClassTrain, K, LV, conflev, alpha, kappa, preprocessing)
%
%             or
%   PLSDMmodel = plsdm_ft(Xtrain, ClassTrain)
%--------------------------------------------------------------------------
% Inputs:
%   Xtrain        - Data matrix (N x M) of predictor variables for the training set.
%                   N = number of samples, M = number of variables.
%
%   ClassTrain    - Column vector (N x 1) of class labels.
%                   Must contain 1 for target-class samples and values
%                   different from 1 for non-target samples.
%                   Any value different from 1 will be automatically converted to 2.
%
%   K             - Number of folds for K-fold cross-validation (positive integer).
%                   Default: 5.
%
%   LV            - Maximum number of latent variables (LVs) to be evaluated
%                   during cross-validation.
%                   Default: 10.
%
%   conflev       - Confidence level for computing the critical thresholds
%                   of Q-residuals and the potential function (0 < conflev < 1).
%                   Default: 0.95.
%
%   alpha         - Smoothing coefficient for the potential function (PFM),
%                   used to smooth the estimated densities.
%                    Default: 0.3.
%
%   kappa         - Number of nearest neighbors (kNN) used to estimate the
%                   class density, which is used as the response variable in PLS.
%                   Default: 1.
%
%   preprocessing - String specifying the type of data pre-processing:
%                       'raw'        -> no pre-processing
%                       'centered'   -> mean centering
%                       'scaled'     -> scaling by standard deviation
%                       'autoscaled' -> mean centering + scaling
%                       Default: 'raw'
%
%   var_label - label of varibles in X matrix i smust be a vector (1 x N)
%                        Default: absent
%   gama      - Significance level for outlier detection. Defalut 0.01
%   Status     - The status vector contains the classification result of each
%                sample according to the two-boundary outlier detection scheme.
%                Each element %  corresponds to one sample in the input data
%                and can take one of the following values:
%                                 1 - Regular sample,
%                                 2 - Extreme sample,
%                                 3 - Outlier sample,
%                                 0 - Not evaluated/non-target (implementation dependent)
% Outputs:
%   PLSDMmodel - Structure containing:
%       .model         - Model name ('PLS-DM model')
%       .Xtrain        - Original input data
%       .ClassTrain    - Class vector used for training
%       .K             - Number of folds used
%       .LV            - Maximum number of LVs evaluated
%       .conflev       - Confidence level used
%       .alpha         - Alpha coefficient used in PFM
%       .preprocessing - Applied pre-processing method
%       .kfoldmodel    - Structure with cross-validation results
%       .Compliance    - Classification results for each LV
%       .caseType      - 'compliant' or 'rigorous'
%       .TP_all, .FP_all, .TN_all, .FN_all - Vectors with counts per LV
%       .sen_all, .spec_all, .acc_all      - Sensitivity, specificity, accuracy per LV
%       .f1score_all, .precision_all, .eff_all - Additional performance metrics per LV
%       .LVopt         - Optimal number of LVs selected by the user
%       .FinalModel    - Final PLS-DM model trained with LVopt
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

PLSDM_CV.model='PLS-DM cv';

if nargin > 9
    [nX, ~] = size(Xtrain);
    nC      = numel(ClassTrain);
    nS      = numel(status);
    
    if nX ~= nC || nX ~= nS
        error('Inconsistent sizes: Xtrain (%d rows), ClassTrain (%d), status (%d).', ...
            nX, nC, nS);
    end
    % Ensure column vectors
    ClassTrain = ClassTrain(:);
    status     = status(:);
    % Find outliers (status == 3)
    idxRemoved = find(status == 3);
    idxKept    = setdiff((1:nX).', idxRemoved);
    % Remove outliers
    Xtrain   = Xtrain(idxKept, :);
    ClassTrain= ClassTrain(idxKept);
end

%--------------------------------------------------------------------------
[Nsam Nvar]=size(Xtrain);
max_class=max(ClassTrain);
Ctrain=ClassTrain;
%
if max_class>1
    nt_samples = find(ClassTrain ~= 1);
    Ctrain(nt_samples)=2;
    Xtrain2=Xtrain(nt_samples,:);
    Nsam2=size(Xtrain2,1);
end
%
t_samples=find(ClassTrain==1);
Xtrain1=Xtrain(t_samples,:);
Nsam1=size(Xtrain1,1);
%% -------------------------Check inputs-----------------------------------
if nargin < 3 || isempty(K)
    if Nsam1 > 19
        K = 5;
    else
        K =1;
    end
end

if nargin < 4 || isempty(LV)
    if Nsam > 10
        LV=10;
    else
        LV=Nsam-1;
    end
end

% The original PLS-DM assigns Venetian-blind groups before separating the
% target class from the complete training set.
targetFoldIndex = mod(t_samples-1,K)+1;

if nargin < 5 || isempty(conflev)
    conflev = 0.95;
end

if conflev <= 0 || conflev >= 1
    error('conflev must be between 0 and 1 (exclusive).');
end
%
if nargin < 6 || isempty(alpha)
    alpha = 0.3;
end
if nargin < 7 || isempty(kappa)
    kappa=1;
end
if nargin < 8 || isempty(preprocessing)
    preprocessing = 'raw';
end
if nargin < 9 || isempty(var_label)
    var_label=1:Nvar;
end
%
% if nargin < 11 || isempty(LVopt)
%     LVopt=1;
% end

%%-------------------------------------------------------------------------
PLSDM_CV.Xtrain=Xtrain;
PLSDM_CV.ClassTrain=ClassTrain;
PLSDM_CV.K=K;
PLSDMmodel.LV=LV;
PLSDM_CV.conflev=conflev;
PLSDM_CV.alpha=alpha;
PLSDM_CV.preprocessing=preprocessing;
PLSDM_CV.var_label=var_label;
%%
%=== Preprocessing ===
[n, m] = size(Xtrain1);
mu = mean(Xtrain1, 1);
sigma = std(Xtrain1, 0, 1);
sigma(sigma == 0) = 1;

switch lower(preprocessing)
    case 'raw'
        Xpt = Xtrain1;
        mu = zeros(1, m);
        sigma = ones(1, m);
        if  max_class>1
            Xpu=Xtrain2;
        end
    case 'centered'
        Xpt = Xtrain1 - repmat(mu, n, 1);
        if  max_class>1
            Xpu=Xtrain2- repmat(mu, Nsam2, 1);
        end
    case 'scaled'
        Xpt = (Xtrain1./ repmat(sigma, n, 1));
        if  max_class>1
            Xpu=(Xtrain2 ./ repmat(sigma, Nsam2, 1));
        end
    case 'autoscaled'
        Xpt = (Xtrain1 - repmat(mu, n, 1)) ./ repmat(sigma, n, 1);
        if  max_class>1
            Xpu=(Xtrain2 - repmat(mu, Nsam2, 1)) ./ repmat(sigma, Nsam2, 1);
        end
    otherwise
        error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
end

%% Class density by knn - Training global model
[D_sorted, idx_sorted, D] = ClassDensity1(Xpt,true);
dist1=D_sorted(:,2:Nsam1);
dist1=dist1(:,1:kappa);
ytrain=sum(dist1,2);
%-----------------------------------------------
if  max_class==1
    Modelpls_kfold = pls_kfold(Xtrain1,K, LV, conflev, alpha, preprocessing,kappa,[],targetFoldIndex);
end
%
if  max_class>1
    Modelpls_kfold = pls_kfold(Xtrain1, K, LV, conflev, alpha, preprocessing,kappa,Xtrain2,targetFoldIndex);
end

PLSDMmodel.kfoldmodel=Modelpls_kfold;

% Samples Compliance
for k=1:LV
    
    Qresid=Modelpls_kfold .Qresid;
    Fdensity_cv=Modelpls_kfold .f_cv;
    Qlim=Modelpls_kfold .Qlims_perLV;
    qlimit=mean(Qlim{k});
    flimits_perLV=Modelpls_kfold .flimits_perLV;
    flimit= mean(flimits_perLV{k});
    qlimit_target=Modelpls_kfold.Qlimit_cv(:,k);
    flimit_target=Modelpls_kfold.flimit_cv(:,k);
    if  max_class>1
        f_untarget_cv=Modelpls_kfold .f_untarget_cv;
        Q_untarget_cv=Modelpls_kfold .Q_untarget_cv;
        
    end
    %-----------------
    if  max_class == 1
        Qstat=[Qresid(:,k)];
        f_density=[Fdensity_cv(:,k)];
        qlimit=qlimit_target;
        flimit=flimit_target;
        Gtrue=ones(Nsam1,1);
    end
    %
    if  max_class> 1
        Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
        f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
        qlimit=[qlimit_target;Modelpls_kfold.Qlimit_untarget_cv(:,k)];
        flimit=[flimit_target;Modelpls_kfold.flimit_untarget_cv(:,k)];
        Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
    end
    %------------------
    results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
    Compliance{k}=results;
end
PLSDM_CV.Compliance=Compliance;
PLSDM_CV.kfoldmodel=Modelpls_kfold;
if isfield(Modelpls_kfold,'Qlims_perLV')
    PLSDM_CV.Qlims_perLV=Modelpls_kfold.Qlims_perLV;
end
if isfield(Modelpls_kfold,'flimits_perLV')
    PLSDM_CV.flimits_perLV=Modelpls_kfold.flimits_perLV;
end
if isfield(Modelpls_kfold,'Qlimit_cv')
    PLSDM_CV.Qlimit_cv=Modelpls_kfold.Qlimit_cv;
end
if isfield(Modelpls_kfold,'flimit_cv')
    PLSDM_CV.flimit_cv=Modelpls_kfold.flimit_cv;
end

caseType = '';  % Will be determined dynamically
% Extract results from each LV
% ----------------------
for lv = 1:LV
    res = Compliance{lv};
    % Determine case type
    if isfield(res, 'Gtrue') && any(res.Gtrue ~= 1)
        caseType = 'compliant';
    else
        caseType = 'rigorous';
    end
    %
    TP_all(lv)=res.TP;
    FP_all(lv)=res.FP;
    TN_all(lv)=res.TN;
    FN_all(lv)=res.FN;
    sen_all(lv)= res.sensitivity;
    spec_all(lv) = res.specificity;
    acc_all(lv)  = res.accuracy;
    f1score_all(lv)=res.f1score;
    precision_all(lv)=res.precision;
    eff_all(lv)=res.efficiency;
    
end

% ----------------------
PLSDM_CV.caseType=caseType;
PLSDM_CV.TP_all=TP_all;
PLSDM_CV.FP_all= FP_all;
PLSDM_CV.TN_all=TN_all;
PLSDM_CV.FN_all=FN_all;
PLSDM_CV.sen_all=sen_all;
PLSDM_CV.spec_all=spec_all;
PLSDM_CV. acc_all= acc_all;
PLSDM_CV.f1score_all=f1score_all;
PLSDM_CV.precision_all= precision_all;
PLSDM_CV.eff_all=eff_all;
%
sensitivities = sen_all;
specificities =  spec_all;
efficiencies =eff_all;
LVs = 1:length(sensitivities);
%%-------------------------------------------------------------------------
[LVs, ord] = sort(LVs(:).');
sensitivities = sensitivities(ord);
if exist('specificities','var') && numel(specificities)==numel(LVs), specificities = specificities(ord); end
if exist('efficiencies','var')  && numel(efficiencies)==numel(LVs),  efficiencies  = efficiencies(ord);  end

% switch lower(caseType)
%     case 'compliant'
%         
%         col.rmse = [0.635 0.078 0.184];
%         col.sen  = [0.85  0.33  0.10 ];
%         col.spe  = [0.00  0.45  0.74 ];
%         col.eff  = [0.47  0.67  0.19 ];
%         msz = 7; lw = 2;
%         
%         
%         [dummy,i_eff]  = max(efficiencies(:));
%         lv_eff  = LVs(i_eff);
%         
%         figure('Color','w');
%         
%         % --- plot : Sensitivity / Specificity / Efficiency
%         
%         hold on; box on; grid on;
%         p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.sen);
%         p2 = plot(LVs, specificities, '-s', 'Color', col.spe, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.spe);
%         p3 = plot(LVs, efficiencies,  '-d', 'Color', col.eff, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.eff);
%         set(gca,'FontSize',12,'XMinorTick','on','YMinorTick','on');
%         xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
%         ylabel('Cross-validated performance','FontWeight','bold');
%         title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
%         ylim([0 1]);
%         xlim([min(LVs) max(LVs)]);
%         set(gca,'XTick',unique(LVs));
%         leg = legend([p1 p2 p3], {'Sensitivity','Specificity','Efficiency'}, 'Location','Best');
%         set(leg,'Box','off');
%         
%     case 'rigorous'
%         col.rmse = [0.635 0.078 0.184];
%         col.sen  = [0.85  0.33  0.10 ];
%         msz = 7; lw = 2;
%         [dummy,i_sen ] = max(sensitivities(:));
%         lv_sen  = LVs(i_sen);
%         figure('Color','w');
%         % --- plot 2: Sensitivity
%         hold on; box on; grid on;
%         p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.sen);
%         set(gca,'FontSize',12,'XMinorTick','on','YMinorTick','on');
%         xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
%         ylabel('Cross-validated performance','FontWeight','bold');
%         title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
%         ylim([0 1]);
%         xlim([min(LVs) max(LVs)]);
%         set(gca,'XTick',unique(LVs));
%         leg = legend(p1, {'Sensitivity'}, 'Location','Best');
%         set(leg,'Box','off');
%         
%     otherwise
%         error('Invalid caseType. Must be ''compliant'' or ''rigorous''.');
% end

% =========================================================================
%     function h = vline2010(x, style, color, labelStr)
%         
%         if nargin < 2 || isempty(style), style = '--'; end
%         if nargin < 3 || isempty(color), color = [0 0 0]; end
%         if nargin < 4, labelStr = ''; end
%         ax = gca;
%         yl = get(ax,'YLim');
%         h  = line([x x], yl, 'LineStyle', style, 'Color', color, 'LineWidth', 1.2);
%         
%         if ~isempty(labelStr)
%             dy = 0.04*(yl(2)-yl(1));
%             text(x, yl(1)+dy, labelStr, 'HorizontalAlignment','center', ...
%                 'VerticalAlignment','bottom', 'Color', color, 'FontSize',10, 'FontWeight','bold');
%         end
%     end

 end
