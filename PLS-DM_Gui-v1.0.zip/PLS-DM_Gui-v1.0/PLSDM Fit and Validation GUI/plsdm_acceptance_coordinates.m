%
function [xplot,yplot,Qnorm,PFcoord,limit,accepted] = plsdm_acceptance_coordinates(Q,f,Qcrit,falpha)
% Fixed model-based coordinates for all acceptance plots and click reports.
% PFcoord = 1 + (log(falpha)-log(f))/max(abs(log(falpha)),1).
% Its boundary is 1; decreasing density increases PFcoord for any falpha>0.
% No coordinate depends on the other samples in the displayed set.
% Licensed under the PLS-DM Toolbox License; see LICENSE.txt in the toolbox root.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================
Q = Q(:); f = f(:);
n = numel(Q);
if numel(f) ~= n, error('Q and f must have the same length.'); end
if isscalar(Qcrit), Qcrit = repmat(Qcrit,n,1); else, Qcrit = Qcrit(:); end
if isscalar(falpha), falpha = repmat(falpha,n,1); else, falpha = falpha(:); end
if numel(Qcrit) ~= n || numel(falpha) ~= n
    error('Thresholds must be scalar or have one value per sample.');
end
valid = isfinite(Q) & Q >= 0 & isfinite(f) & f >= 0 & ...
    isfinite(Qcrit) & Qcrit >= 0 & isfinite(falpha) & falpha > 0;
accepted = valid & (Q <= Qcrit) & (f >= falpha);
Qnorm = Q ./ max(Qcrit,realmin('double'));
PFcoord = 1 + (log(max(falpha,realmin('double'))) - ...
    log(max(f,realmin('double')))) ./ max(abs(log(max(falpha,realmin('double')))),1);
c = 10;
xplot = log(1 + c*max(PFcoord,0));
yplot = log(1 + c*max(Qnorm,0));
limit = log(1+c);
end
