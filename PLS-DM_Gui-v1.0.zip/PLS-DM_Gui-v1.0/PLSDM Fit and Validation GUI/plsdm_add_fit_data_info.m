%
function [info,applied] = plsdm_add_fit_data_info(parent,classv,sampleCounts,currentInfo)
%
%PLSDM_ADD_FIT_DATA_INFO Optional display metadata for Fit & Validation.
% Keeps independent sample names for training, validation and unknown sets.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    if nargin < 4 || isempty(currentInfo), currentInfo = struct(); end
    classes = plsdm_unique_stable(classv(:));
    info = normalizeInfo(currentInfo,classes,sampleCounts);
    applied = false;
    nClass = numel(classes);
    rowH = 28;
    figH = 500 + rowH*nClass;
    f = figure('Name','Add data info','NumberTitle','off','MenuBar','none', ...
        'ToolBar','none','WindowStyle','modal','Resize','off', ...
        'Color',[0.95 0.95 0.95],'Position',centerOnParent(parent,620,figH), ...
        'CloseRequestFcn',@onCancel);

    uicontrol(f,'Style','text','String','Optional axis labels', ...
        'Position',[25 figH-60 560 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    uicontrol(f,'Style','text','String','X-axis label','Position',[25 figH-94 125 22], ...
        'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
    edX = uicontrol(f,'Style','edit','String',info.xLabel, ...
        'Position',[155 figH-96 430 26],'BackgroundColor','white','HorizontalAlignment','left');
    uicontrol(f,'Style','text','String','Y-axis label','Position',[25 figH-128 125 22], ...
        'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
    edY = uicontrol(f,'Style','edit','String',info.yLabel, ...
        'Position',[155 figH-130 430 26],'BackgroundColor','white','HorizontalAlignment','left');

    classTop = figH-170;
    uicontrol(f,'Style','text','String','Optional class names', ...
        'Position',[25 classTop 560 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    edClass = zeros(nClass,1);
    for k = 1:nClass
        y = classTop-32-(k-1)*rowH;
        uicontrol(f,'Style','text','String',sprintf('Class %g',classes(k)), ...
            'Position',[25 y 125 22],'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
        edClass(k) = uicontrol(f,'Style','edit','String',info.classNames{k}, ...
            'Position',[155 y-2 430 26],'BackgroundColor','white','HorizontalAlignment','left');
    end

    sampleTop = classTop-55-nClass*rowH;
    uicontrol(f,'Style','text','String','Optional sample names', ...
        'Position',[25 sampleTop 560 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    setLabels = {'Training','Validation','Unknown'};
    fieldNames = {'sampleNames','validationSampleNames','unknownSampleNames'};
    statusText = zeros(3,1);
    for k = 1:3
        y = sampleTop-38-(k-1)*55;
        uicontrol(f,'Style','text','String',[setLabels{k} ' (' num2str(sampleCounts(k)) ' samples)'], ...
            'Position',[25 y+3 150 22],'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
        statusText(k) = uicontrol(f,'Style','text','String',sampleStatus(info.(fieldNames{k}),sampleCounts(k)), ...
            'Position',[175 y+3 190 22],'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
        enableValue = 'on';
        if sampleCounts(k) < 1, enableValue = 'off'; end
        uicontrol(f,'Style','pushbutton','String','Import workspace...', ...
            'Position',[370 y 135 28],'Enable',enableValue,'Callback',{@onImportNames,k});
        uicontrol(f,'Style','pushbutton','String','Clear', ...
            'Position',[515 y 70 28],'Enable',enableValue,'Callback',{@onClearNames,k});
    end

    uicontrol(f,'Style','pushbutton','String','Apply','FontWeight','bold', ...
        'Position',[380 20 95 32],'Callback',@onApply);
    uicontrol(f,'Style','pushbutton','String','Cancel', ...
        'Position',[490 20 95 32],'Callback',@onCancel);
    uiwait(f);

    function onImportNames(h,ev,setIndex)
        vars = evalin('base','whos');
        keep = strcmp({vars.class},'cell') | strcmp({vars.class},'char') | ...
               strcmp({vars.class},'string') | strcmp({vars.class},'categorical');
        vars = vars(keep);
        if isempty(vars)
            errordlg('No compatible name variable is available in the workspace.','Sample names'); return;
        end
        [idx,ok] = listdlg('PromptString',['Select ' lower(setLabels{setIndex}) ' sample names:'], ...
            'SelectionMode','single','ListString',{vars.name},'ListSize',[330 220]);
        if ~ok, return; end
        candidate = evalin('base',vars(idx).name);
        [names,ok,msg] = normalizeNames(candidate,sampleCounts(setIndex));
        if ~ok, errordlg(msg,'Sample names'); return; end
        info.(fieldNames{setIndex}) = names;
        set(statusText(setIndex),'String',sampleStatus(names,sampleCounts(setIndex)));
    end

    function onClearNames(h,ev,setIndex)
        info.(fieldNames{setIndex}) = {};
        set(statusText(setIndex),'String',sampleStatus({},sampleCounts(setIndex)));
    end

    function onApply(h,ev)
        info.xLabel = strtrim(get(edX,'String'));
        info.yLabel = strtrim(get(edY,'String'));
        for j = 1:nClass
            value = strtrim(get(edClass(j),'String'));
            if isempty(value), value = sprintf('Class %g',classes(j)); end
            info.classNames{j} = value;
        end
        info.classValues = classes;
        applied = true; uiresume(f); delete(f);
    end
    function onCancel(h,ev), applied = false; uiresume(f); delete(f); end
end

function info = normalizeInfo(info,classes,counts)
    if ~isfield(info,'xLabel'), info.xLabel = ''; end
    if ~isfield(info,'yLabel'), info.yLabel = ''; end
    fields = {'sampleNames','validationSampleNames','unknownSampleNames'};
    for k = 1:3
        if ~isfield(info,fields{k}) || numel(info.(fields{k})) ~= counts(k), info.(fields{k}) = {}; end
    end
    if ~isfield(info,'classValues'), info.classValues = classes; end
    if ~isfield(info,'classNames'), info.classNames = {}; end
    oldValues = info.classValues(:); oldNames = info.classNames; names = cell(numel(classes),1);
    for k = 1:numel(classes)
        hit = find(oldValues == classes(k),1);
        if ~isempty(hit) && hit <= numel(oldNames) && ~isempty(oldNames{hit})
            names{k} = oldNames{hit};
        else
            names{k} = sprintf('Class %g',classes(k));
        end
    end
    info.classValues = classes; info.classNames = names;
end

function [names,ok,msg] = normalizeNames(value,nExpected)
    names = {}; ok = false; msg = '';
    if ischar(value), value = cellstr(value);
    elseif isa(value,'categorical') || isa(value,'string'), value = cellstr(value(:)); end
    if ~iscell(value), msg = 'The selected variable must contain sample names.'; return; end
    value = value(:);
    if numel(value) ~= nExpected
        msg = sprintf('Expected %d names, but the selected variable contains %d.',nExpected,numel(value)); return;
    end
    names = cell(nExpected,1);
    for k = 1:nExpected
        v = value{k};
        if iscell(v) && numel(v) == 1, v = v{1}; end
        if isa(v,'string'), v = char(v); end
        if isnumeric(v) && isscalar(v), v = num2str(v); end
        if ~ischar(v) || isempty(strtrim(v)), msg = sprintf('Sample name %d is empty or invalid.',k); return; end
        names{k} = strtrim(v);
    end
    ok = true;
end

function s = sampleStatus(names,n)
    if n < 1, s = 'Load this data set first.';
    elseif isempty(names), s = 'Not loaded (numeric labels).';
    else s = [num2str(numel(names)) ' names loaded.']; end
end

function pos = centerOnParent(parent,w,h)
    oldUnits = get(parent,'Units'); set(parent,'Units','pixels'); p = get(parent,'Position'); set(parent,'Units',oldUnits);
    pos = [p(1)+(p(3)-w)/2 p(2)+(p(4)-h)/2 w h];
end
