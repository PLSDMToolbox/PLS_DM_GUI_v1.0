%
function plsdm_custom_figure_menu(owner,guiName,plotNames,classNames,renderFcn)
%PLSDM_CUSTOM_FIGURE_MENU Build an editable multi-panel MATLAB FIG file.
% renderFcn(plotIndex,classIndex,axesHandle) draws one selected panel.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 5 || isempty(plotNames), return; end
if isempty(classNames), classNames = {'Active class'}; end

D.items = struct('plot',{},'class',{},'title',{});
D.owner = owner; D.renderFcn = renderFcn; D.guiName = guiName;
D.fig = figure('Name',[guiName ' - Custom figure'],'NumberTitle','off', ...
    'MenuBar','none','Toolbar','none','Resize','on','WindowStyle','normal', ...
    'Color',[0.94 0.95 0.98],'Units','pixels','Position',[180 100 790 540]);

uicontrol('Parent',D.fig,'Style','text','String','Plot type','Units','pixels', ...
    'Position',[25 495 330 22],'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',get(D.fig,'Color'));
D.popPlot = uicontrol('Parent',D.fig,'Style','popupmenu','String',plotNames, ...
    'Units','pixels','Position',[25 462 330 30],'BackgroundColor','w');
uicontrol('Parent',D.fig,'Style','text','String','Class/model','Units','pixels', ...
    'Position',[380 495 210 22],'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',get(D.fig,'Color'));
D.popClass = uicontrol('Parent',D.fig,'Style','popupmenu','String',classNames, ...
    'Units','pixels','Position',[380 462 210 30],'BackgroundColor','w');
uicontrol('Parent',D.fig,'Style','pushbutton','String','Add panel', ...
    'Units','pixels','Position',[615 462 145 30],'FontWeight','bold','Callback',@addPanel);

uicontrol('Parent',D.fig,'Style','text','String','Figure panels (the list order is the subplot order)', ...
    'Units','pixels','Position',[25 420 520 22],'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',get(D.fig,'Color'));
D.list = uicontrol('Parent',D.fig,'Style','listbox','String',{'No panels added.'}, ...
    'Units','pixels','Position',[25 180 565 240],'BackgroundColor','w','Max',1,'Min',0, ...
    'Callback',@selectPanel);
uicontrol('Parent',D.fig,'Style','pushbutton','String','Move up','Units','pixels', ...
    'Position',[615 370 145 30],'Callback',{@movePanel,-1});
uicontrol('Parent',D.fig,'Style','pushbutton','String','Move down','Units','pixels', ...
    'Position',[615 330 145 30],'Callback',{@movePanel,1});
uicontrol('Parent',D.fig,'Style','pushbutton','String','Duplicate','Units','pixels', ...
    'Position',[615 290 145 30],'Callback',@duplicatePanel);
uicontrol('Parent',D.fig,'Style','pushbutton','String','Remove','Units','pixels', ...
    'Position',[615 250 145 30],'Callback',@removePanel);
uicontrol('Parent',D.fig,'Style','pushbutton','String','Clear','Units','pixels', ...
    'Position',[615 210 145 30],'Callback',@clearPanels);

uicontrol('Parent',D.fig,'Style','text','String','Selected panel title','Units','pixels', ...
    'Position',[25 145 170 22],'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',get(D.fig,'Color'));
D.edTitle = uicontrol('Parent',D.fig,'Style','edit','String','', ...
    'Units','pixels','Position',[195 142 395 28],'BackgroundColor','w','Callback',@editTitle);
uicontrol('Parent',D.fig,'Style','text','String','Columns','Units','pixels', ...
    'Position',[615 145 65 22],'HorizontalAlignment','left','BackgroundColor',get(D.fig,'Color'));
D.popCols = uicontrol('Parent',D.fig,'Style','popupmenu','String',{'Automatic','1','2','3','4'}, ...
    'Units','pixels','Position',[680 142 80 28],'BackgroundColor','w');

uicontrol('Parent',D.fig,'Style','text','String','Overall figure title','Units','pixels', ...
    'Position',[25 105 170 22],'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',get(D.fig,'Color'));
D.edOverall = uicontrol('Parent',D.fig,'Style','edit','String',[guiName ' - Custom figure'], ...
    'Units','pixels','Position',[195 102 565 28],'BackgroundColor','w');
uicontrol('Parent',D.fig,'Style','pushbutton','String','Generate','Units','pixels', ...
    'Position',[355 40 125 38],'FontWeight','bold','Callback',{@generateFigure,false});
uicontrol('Parent',D.fig,'Style','pushbutton','String','Generate and save .fig', ...
    'Units','pixels','Position',[490 40 170 38],'FontWeight','bold','Callback',{@generateFigure,true});
uicontrol('Parent',D.fig,'Style','pushbutton','String','Cancel','Units','pixels', ...
    'Position',[670 40 90 38],'Callback',@(s,e)close(D.fig));
set(findall(D.fig,'Type','uicontrol'),'Units','normalized');
guidata(D.fig,D);

    function addPanel(src,ev)
        d=guidata(D.fig); p=get(d.popPlot,'Value'); c=get(d.popClass,'Value');
        pn=getStringAt(d.popPlot,p); cn=getStringAt(d.popClass,c);
        it.plot=p; it.class=c; it.title=[pn ' - ' cn]; d.items(end+1)=it;
        guidata(D.fig,d); refreshList(length(d.items));
    end
    function selectPanel(src,ev)
        d=guidata(D.fig); if isempty(d.items), return; end
        i=min(get(d.list,'Value'),length(d.items)); set(d.edTitle,'String',d.items(i).title);
    end
    function editTitle(src,ev)
        d=guidata(D.fig); if isempty(d.items), return; end
        i=min(get(d.list,'Value'),length(d.items)); d.items(i).title=get(d.edTitle,'String');
        guidata(D.fig,d); refreshList(i);
    end
    function movePanel(src,ev,delta)
        d=guidata(D.fig); if isempty(d.items), return; end
        i=min(get(d.list,'Value'),length(d.items)); j=i+delta;
        if j<1 || j>length(d.items), return; end
        tmp=d.items(i); d.items(i)=d.items(j); d.items(j)=tmp; guidata(D.fig,d); refreshList(j);
    end
    function duplicatePanel(src,ev)
        d=guidata(D.fig); if isempty(d.items), return; end
        i=min(get(d.list,'Value'),length(d.items)); d.items(end+1)=d.items(i);
        guidata(D.fig,d); refreshList(length(d.items));
    end
    function removePanel(src,ev)
        d=guidata(D.fig); if isempty(d.items), return; end
        i=min(get(d.list,'Value'),length(d.items)); d.items(i)=[]; guidata(D.fig,d); refreshList(max(1,i-1));
    end
    function clearPanels(src,ev)
        d=guidata(D.fig); d.items=struct('plot',{},'class',{},'title',{}); guidata(D.fig,d); refreshList(1);
    end
    function refreshList(sel)
        d=guidata(D.fig); if isempty(d.items)
            set(d.list,'String',{'No panels added.'},'Value',1); set(d.edTitle,'String',''); return;
        end
        s=cell(length(d.items),1); for k=1:length(d.items), s{k}=sprintf('%d. %s',k,d.items(k).title); end
        sel=max(1,min(sel,length(s))); set(d.list,'String',s,'Value',sel); set(d.edTitle,'String',d.items(sel).title);
    end
    function generateFigure(src,ev,doSave)
        d=guidata(D.fig); if isempty(d.items), errordlg('Add at least one panel.','Custom figure'); return; end
        n=length(d.items); cv=get(d.popCols,'Value');
        if cv==1, nc=ceil(sqrt(n)); else nc=cv-1; end; nr=ceil(n/nc);
        fw=min(1800,max(760,480*nc)); fh=min(1100,max(520,360*nr));
        out=figure('Color','w','Name',get(d.edOverall,'String'),'NumberTitle','off', ...
            'MenuBar','figure','Toolbar','figure','Resize','on','WindowStyle','normal', ...
            'DockControls','on','Units','pixels','Position',[60 50 fw fh]);
        for k=1:n
            ax=subplot(nr,nc,k,'Parent',out);
            set(ax,'Units','normalized','HandleVisibility','on','HitTest','on');
            try
                d.renderFcn(d.items(k).plot,d.items(k).class,ax);
                title(ax,d.items(k).title,'Interpreter','none','FontWeight','bold');
            catch ME
                cla(ax); axis(ax,'off'); text(0.5,0.5,['Unavailable: ' ME.message], ...
                    'Parent',ax,'HorizontalAlignment','center','Interpreter','none');
                title(ax,d.items(k).title,'Interpreter','none');
            end
        end
        addOverallTitle(out,get(d.edOverall,'String'));
        try, plotedit(out,'on'); catch, end
        if doSave
            [fn,pn]=uiputfile('*.fig','Save custom MATLAB figure');
            if ~isequal(fn,0), file=fullfile(pn,fn); if exist('savefig','file')==2, savefig(out,file); else hgsave(out,file); end; end
        end
    end
end

function s=getStringAt(h,i)
v=get(h,'String'); if iscell(v), s=v{i}; else s=v(i,:); end
end
function addOverallTitle(f,s)
if isempty(s), return; end
annotation(f,'textbox',[0.05 0.955 0.90 0.035],'String',s,'LineStyle','none', ...
    'HorizontalAlignment','center','FontWeight','bold','Interpreter','none');
end
