%
function plsdm_gui_fit_validation()

% PLSDM_GUI_FIT_VALIDATION
%
% Expected command-line routines:
%   Classical CV:    CVmodel    = plsdm_CV(Xtrain,ClassTrain,K,LVmax,conflev,alpha,kappa,preprocessing,var_label,status)
%   Classical final: PLSDMmodel = plsdm_ft(Xtrain,ClassTrain,K,LVopt,conflev,alpha,kappa,preprocessing,var_label,status)
%   Robust CV:       CVmodel    = rplsdm_CV(Xtrain,ClassTrain,K,LVmax,conflev,alpha,kappa,preprocessing,var_label,gama,status)
%   Robust final:    PLSDMmodel = rplsdm_ft(Xtrain,ClassTrain,K,LVopt,conflev,alpha,kappa,preprocessing,var_label,gama,status)
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    if exist('plsdm_exclude_samples_dialog','file') ~= 2
        moduleRoot = fileparts(fileparts(mfilename('fullpath')));
        sharedGuiFolder = fullfile(moduleRoot,'PLSDM optimization GUI');
        if exist(sharedGuiFolder,'dir') == 7, addpath(sharedGuiFolder); end
    end
%
    thisDir = fileparts(mfilename('fullpath'));
    addpath(fullfile(thisDir,'..','PLSDM optimization GUI'));
    GUI_VERSION = 'PLS-DM Toolbox GUI v1.0-A8';
    scr = get(0,'ScreenSize');
    figW = min(1400, scr(3)-80);
    figH = min(820,  scr(4)-100);

    fig = figure('Name',['PLS-DM Toolbox - Fit & Validation - ' GUI_VERSION], ...
                 'NumberTitle','off', ...
                 'MenuBar','none', ...
                 'Toolbar','none', ...
                 'Color',[0.94 0.95 0.98], ...
                 'Units','pixels', ...
                 'Position',[40 40 figW figH]);

    S = struct();
    S.Xtrain = [];
    S.ClassTrain = [];
    S.status = [];
    S.var_label = [];
    S.CVmodel = [];
    S.CVmodelAll = [];
    S.PLSDMmodel = [];
    S.PLSDMmodelAll = [];
    S.Xval = [];
    S.ClassVal = [];
    S.Xunk = [];
    S.XtrainAll = []; S.ClassTrainAll = []; S.statusAll = [];
    S.XvalAll = []; S.ClassValAll = []; S.XunkAll = [];
    S.includeTrain = []; S.includeVal = []; S.includeUnk = [];
    S.trainOriginalRows = []; S.valOriginalRows = []; S.unkOriginalRows = [];
    S.trainNamesAll = {}; S.valNamesAll = {}; S.unkNamesAll = {};
    S.PLSDMvalidation = [];
    S.PLSDMpred = [];
    S.TargetClasses = [];
    S.TargetClass = [];
    S.ActiveModelIndex = 1;
    S.SelectedLVByClass = [];
    S.CVParamsByClass = [];
    S.ModellingType = 'Compliant';
    S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}}, ...
        'sampleNames',{{}},'validationSampleNames',{{}},'unknownSampleNames',{{}});

    % -----------------------------
    % Visual 
    % -----------------------------
    themeDark  = [0.18 0.32 0.62];
    themeLight = [0.94 0.95 0.98];

    S.pnlHeader = uipanel('Parent',fig, ...
                        'Units','normalized','Position',[0.01 0.88 0.98 0.10], ...
                        'BackgroundColor',themeDark, ...
                        'BorderType','none');

    uicontrol('Parent',S.pnlHeader,'Style','text','String','PLS-DM fit and validation', ...
              'Units','normalized','Position',[0.025 0.45 0.60 0.42], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[1 1 1], ...
              'HorizontalAlignment','left','FontSize',17,'FontWeight','bold');

    uicontrol('Parent',S.pnlHeader,'Style','text', ...
              'String','Run cross-validation, fit the final PLS-DM model and validate known or unknown samples', ...
              'Units','normalized','Position',[0.025 0.12 0.86 0.26], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[0.88 0.92 0.98], ...
              'HorizontalAlignment','left','FontSize',10);

    uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Help', ...
              'Units','normalized','Position',[0.90 0.35 0.08 0.45], ...
              'FontWeight','bold', ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Open detailed help for the Fit & Validation module.', ...
              'Callback',@onHelpFitValidation);
    S.btnDataInfo = uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Add data info...', ...
              'Units','normalized','Position',[0.745 0.35 0.14 0.45], ...
              'FontWeight','bold','BackgroundColor',[1 1 1],'ForegroundColor',themeDark, ...
              'Enable','off','Callback',@onDataInfo);

    % ================================================================
    % LEFT PANEL - CONTROLS
    % ================================================================
    S.pnlCtrl = uipanel('Parent',fig,'Title','Fit & validation settings', ...
                        'Units','normalized','Position',[0.01 0.02 0.23 0.84], ...
                        'BackgroundColor',[0.94 0.95 0.98], ...
                        'FontWeight','bold');
    S.btnExclude = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Exclude...', ...
              'Units','normalized','Position',[0.68 0.90 0.25 0.045], ...
              'FontWeight','bold','Enable','off','Callback',@onExcludeSamples);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data source', ...
              'Units','normalized','Position',[0.05 0.95 0.35 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'HorizontalAlignment','left','FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Import workspace', ...
              'Units','normalized','Position',[0.05 0.90 0.28 0.045], ...
              'Callback',@onImportWorkspace);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Load PLSDMmodel', ...
              'Units','normalized','Position',[0.36 0.90 0.29 0.045], ...
              'Callback',@onLoadModel);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Model type', ...
              'Units','normalized','Position',[0.05 0.855 0.30 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupMode = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Classical PLS','Robust PLS'}, ...
              'Units','normalized','Position',[0.05 0.815 0.40 0.045], ...
              'BackgroundColor',[1 1 1]);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Target class', ...
              'Units','normalized','Position',[0.50 0.855 0.30 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupTargetClass = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'import data'}, ...
              'Units','normalized','Position',[0.50 0.815 0.22 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'Callback',@onTargetSelectionChanged);

    S.chkAllClasses = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','All', ...
              'Units','normalized','Position',[0.74 0.815 0.16 0.045], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'TooltipString','Fit one one-class model for each class found in ClassTrain.', ...
              'Callback',@onTargetSelectionChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','K-fold CV', ...
              'Units','normalized','Position',[0.05 0.755 0.20 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.edKcv = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','5', ...
              'Units','normalized','Position',[0.25 0.752 0.15 0.04], ...
              'BackgroundColor',[1 1 1]);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Max LV', ...
              'Units','normalized','Position',[0.48 0.755 0.18 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.edMaxLV = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','10', ...
              'Units','normalized','Position',[0.66 0.752 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'Callback',@onUpdateLVMenu);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','LV selected at Fit', ...
              'Units','normalized','Position',[0.05 0.705 0.30 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left', ...
              'Visible','off');
    S.popupLVopt = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',make_lv_strings(10), ...
              'Units','normalized','Position',[0.36 0.695 0.23 0.045], ...
              'BackgroundColor',[1 1 1], 'Visible','off', ...
              'Callback',@onLVSelectionChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Fit opens LV selector', ...
              'Units','normalized','Position',[0.62 0.695 0.28 0.045], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'HorizontalAlignment','left', 'Visible','off');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Modelling type', ...
              'Units','normalized','Position',[0.05 0.705 0.30 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.popupModellingType = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Compliant','Rigorous'}, ...
              'Units','normalized','Position',[0.36 0.695 0.37 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'Callback',@onModellingTypeChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Conf. lev. (1-alpha)', ...
              'Units','normalized','Position',[0.05 0.645 0.45 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.edConf = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','0.95', ...
              'Units','normalized','Position',[0.55 0.642 0.18 0.04], ...
              'BackgroundColor',[1 1 1]);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Preprocessing', ...
              'Units','normalized','Position',[0.05 0.595 0.35 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left', ...
              'Visible','off');
    S.popupPrepro = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Raw','Center','Scale','Autoscale'}, ...
              'Units','normalized','Position',[0.36 0.585 0.54 0.045], ...
              'BackgroundColor',[1 1 1], 'Visible','off');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Smoothing coefficient (alpha)', ...
              'Units','normalized','Position',[0.05 0.525 0.50 0.035], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left', ...
              'Visible','off');
    S.edAlpha = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','0.3', ...
              'Units','normalized','Position',[0.05 0.485 0.35 0.04], ...
              'BackgroundColor',[1 1 1], 'Visible','off');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Kappa', ...
              'Units','normalized','Position',[0.50 0.525 0.28 0.035], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left', ...
              'Visible','off');
    S.edKappa = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','1', ...
              'Units','normalized','Position',[0.50 0.485 0.35 0.04], ...
              'BackgroundColor',[1 1 1], 'Visible','off');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Gamma level outlier detection', ...
              'Units','normalized','Position',[0.05 0.595 0.62 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.edGamma = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','0.01', ...
              'Units','normalized','Position',[0.72 0.592 0.18 0.04], ...
              'BackgroundColor',[1 1 1]);

    btn_w = 0.40;
    btn_h = 0.055;

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Run CV', ...
              'Units','normalized','Position',[0.05 0.525 btn_w btn_h], ...
              'FontWeight','bold','Callback',@onRunCV);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Fit final model', ...
              'Units','normalized','Position',[0.50 0.525 btn_w btn_h], ...
              'FontWeight','bold','Callback',@onFitFinalModel);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Restore defaults', ...
              'Units','normalized','Position',[0.05 0.460 btn_w btn_h], ...
              'Callback',@onRestoreDefaults);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Performance vs LV', ...
              'Units','normalized','Position',[0.50 0.460 btn_w btn_h], ...
              'Callback',@onOpenPerformanceFigure);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Classification report', ...
              'Units','normalized','Position',[0.05 0.395 btn_w btn_h], ...
              'Callback',@onOpenClassificationReport);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','CV diagnostics', ...
              'Units','normalized','Position',[0.50 0.395 btn_w btn_h], ...
              'Callback',@onOpenCVDiagnostics);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export model', ...
              'Units','normalized','Position',[0.05 0.330 btn_w btn_h], ...
              'Callback',@onExportModel);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','VIP scores', ...
              'Units','normalized','Position',[0.50 0.330 btn_w btn_h], ...
              'Callback',@onShowVIPScores);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Q/f plot', ...
              'Units','normalized','Position',[0.05 0.265 btn_w btn_h], ...
              'Callback',@onShowQfPlot);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','See data', ...
              'Units','normalized','Position',[0.50 0.265 btn_w btn_h], ...
              'Callback',@onSeeData);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Outliers status', ...
              'Units','normalized','Position',[0.05 0.200 0.40 btn_h], ...
              'Callback',@onExportOutliersStatus);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Figures of merit', ...
              'Units','normalized','Position',[0.50 0.200 0.40 btn_h], ...
              'TooltipString','Show Training, CV, and available Known-prediction figures of merit.', ...
              'Callback',@onShowFOMs);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data / run summary', ...
              'Units','normalized','Position',[0.05 0.145 0.45 0.03], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.txtSummary = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'Units','normalized','Position',[0.05 0.03 0.85 0.110], ...
              'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
              'String',{'No training data loaded.'});

    % ================================================================
    % RIGHT PANEL - VIEW
    % ================================================================
    S.pnlView = uipanel('Parent',fig,'Title','Fit & validation results', ...
                        'Units','normalized','Position',[0.25 0.02 0.46 0.84], ...
                        'BackgroundColor',[0.94 0.95 0.98], ...
                        'FontWeight','bold');

    uicontrol('Parent',S.pnlView,'Style','text','String','Active class/model', ...
              'Units','normalized','Position',[0.08 0.925 0.18 0.035], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.popupModelView = uicontrol('Parent',S.pnlView,'Style','popupmenu', ...
              'String',{'current'}, ...
              'Units','normalized','Position',[0.27 0.918 0.18 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'Callback',@onModelViewChanged);

    uicontrol('Parent',S.pnlView,'Style','text','String','Acceptance plot', ...
              'Units','normalized','Position',[0.49 0.925 0.16 0.035], ...
              'BackgroundColor',[0.94 0.95 0.98], 'HorizontalAlignment','left');
    S.popupAcceptanceMode = uicontrol('Parent',S.pnlView,'Style','popupmenu', ...
              'String',{'Training','CV fold-wise','CV mean'}, ...
              'Units','normalized','Position',[0.64 0.918 0.14 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'Callback',@onAcceptanceControlsChanged);
    S.chkPlotLabels = uicontrol('Parent',S.pnlView,'Style','checkbox', ...
              'String','Labels', ...
              'Units','normalized','Position',[0.80 0.918 0.10 0.045], ...
              'BackgroundColor',[0.94 0.95 0.98], ...
              'Callback',@onAcceptanceControlsChanged);

    uicontrol('Parent',S.pnlView,'Style','pushbutton','String','Custom figure...', ...
              'Units','normalized','Position',[0.79 0.865 0.17 0.045], ...
              'FontWeight','bold','Callback',@onCustomFigure);

    S.axPerf = [];

    S.pnlAcceptance = uipanel('Parent',S.pnlView,'Title','Acceptance area', ...
                        'Units','normalized','Position',[0.06 0.34 0.88 0.50], ...
                        'BackgroundColor',[0.94 0.95 0.98]);

    S.axAcceptance = axes('Parent',S.pnlAcceptance,'Units','normalized','Position',[0.07 0.20 0.80 0.72]);
    title(S.axAcceptance,'Acceptance area'); box(S.axAcceptance,'on'); grid(S.axAcceptance,'on');

    uicontrol('Parent',S.pnlAcceptance,'Style','pushbutton','String','Export', ...
              'Units','normalized','Position',[0.84 0.035 0.12 0.08], ...
              'Callback',@onExportAcceptanceFigure);

    S.pnlModel = uipanel('Parent',S.pnlView,'Title','Final model and CV summary', ...
                        'Units','normalized','Position',[0.06 0.04 0.88 0.28], ...
                        'BackgroundColor',[0.94 0.95 0.98]);

    S.txtModel = uicontrol('Parent',S.pnlModel,'Style','listbox', ...
              'Units','normalized','Position',[0.03 0.08 0.94 0.86], ...
              'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
              'String',{'No final model available.'});

    S.txtMetrics = S.txtModel;
    S.axConfTrain = [];
    S.axConfCV = [];

    % ================================================================
    % PREDICTION PANEL
    % ================================================================
    S.pnlPrediction = uipanel('Parent',fig,'Title','Prediction', ...
                        'Units','normalized','Position',[0.72 0.02 0.27 0.84], ...
                        'BackgroundColor',[0.94 0.95 0.98], ...
                        'FontWeight','bold');

    % ---------------------------------------------------------------
    % Known-class prediction / external validation
    % ---------------------------------------------------------------
    S.pnlKnownPrediction = uipanel('Parent',S.pnlPrediction,'Title','Known-class samples', ...
                        'Units','normalized','Position',[0.05 0.47 0.90 0.50], ...
                        'BackgroundColor',[0.94 0.95 0.98], ...
                        'FontWeight','bold');

    %
    pred_btn_y = 0.88;
    pred_btn_h = 0.08;
    pred_btn_w = 0.28;

    uicontrol('Parent',S.pnlKnownPrediction,'Style','pushbutton','String','Import', ...
              'Units','normalized','Position',[0.06 pred_btn_y pred_btn_w pred_btn_h], ...
              'Callback',@onImportValidationData);

    uicontrol('Parent',S.pnlKnownPrediction,'Style','pushbutton','String','Run', ...
              'Units','normalized','Position',[0.36 pred_btn_y pred_btn_w pred_btn_h], ...
              'FontWeight','bold','Callback',@onRunKnownValidation);

    uicontrol('Parent',S.pnlKnownPrediction,'Style','pushbutton','String','Export', ...
              'Units','normalized','Position',[0.66 pred_btn_y pred_btn_w pred_btn_h], ...
              'Callback',@onExportKnownValidationResults);

    uicontrol('Parent',S.pnlKnownPrediction,'Style','pushbutton','String','Report', ...
              'Units','normalized','Position',[0.06 0.78 0.27 0.075], ...
              'Callback',@onOpenClassificationReport);
    uicontrol('Parent',S.pnlKnownPrediction,'Style','pushbutton','String','Acceptance', ...
              'Units','normalized','Position',[0.36 0.78 0.27 0.075], ...
              'Callback',@onPlotKnownPredictionAcceptance);

    S.txtKnownPrediction = uicontrol('Parent',S.pnlKnownPrediction,'Style','listbox', ...
              'Units','normalized','Position',[0.06 0.06 0.88 0.69], ...
              'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
              'String',{'Fit or load a final model first.'});

    S.pnlPredConfusion = [];
    S.axValConf = [];

    % ---------------------------------------------------------------
    % Unknown-sample prediction
    % ---------------------------------------------------------------
    S.pnlUnknownPrediction = uipanel('Parent',S.pnlPrediction,'Title','Unknown samples', ...
                        'Units','normalized','Position',[0.05 0.03 0.90 0.41], ...
                        'BackgroundColor',[0.94 0.95 0.98], ...
                        'FontWeight','bold');

    % 
    pred_btn_y = 0.82;
    pred_btn_h = 0.10;
    pred_btn_w = 0.28;

    uicontrol('Parent',S.pnlUnknownPrediction,'Style','pushbutton','String','Import', ...
              'Units','normalized','Position',[0.06 pred_btn_y pred_btn_w pred_btn_h], ...
              'Callback',@onImportUnknownData);

    uicontrol('Parent',S.pnlUnknownPrediction,'Style','pushbutton','String','Run', ...
              'Units','normalized','Position',[0.36 pred_btn_y pred_btn_w pred_btn_h], ...
              'FontWeight','bold','Callback',@onRunUnknownPrediction);

    uicontrol('Parent',S.pnlUnknownPrediction,'Style','pushbutton','String','Export', ...
              'Units','normalized','Position',[0.66 pred_btn_y pred_btn_w pred_btn_h], ...
              'Callback',@onExportUnknownPredictionResults);

    uicontrol('Parent',S.pnlUnknownPrediction,'Style','pushbutton','String','Acceptance', ...
              'Units','normalized','Position',[0.06 0.72 0.34 0.085], ...
              'Callback',@onPlotUnknownPredictionAcceptance);
    uicontrol('Parent',S.pnlUnknownPrediction,'Style','pushbutton','String','Report', ...
              'Units','normalized','Position',[0.43 0.72 0.34 0.085], ...
              'Callback',@onOpenClassificationReport);

    S.txtUnknownPrediction = uicontrol('Parent',S.pnlUnknownPrediction,'Style','listbox', ...
              'Units','normalized','Position',[0.06 0.07 0.88 0.61], ...
              'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
              'String',{'Fit or load a final model first.'});

    applyFitValidationTooltips(fig,S);

    guidata(fig,S);
    refreshSummary(fig,{});
    clearView(fig);

    % ================================================================
    % CALLBACKS
    % ================================================================
    function onImportWorkspace(hObj,ev)
        S = guidata(hObj);
        [ok, names, vals] = plsdm_select_workspace_vars('Import training data', ...
            {'Xtrain','ClassTrain','x-axis / variable labels'}, ...
            {'Xtrain','ClassTrain','var_label'}, {false,false,true});
        if ~ok, return; end
        try
            Xtrain = vals{1};
            ClassTrain = vals{2};
            if size(ClassTrain,1)==1
                ClassTrain = ClassTrain';
            end
            if size(Xtrain,1) ~= length(ClassTrain)
                error('Xtrain rows and ClassTrain length are inconsistent.');
            end
            status = zeros(size(ClassTrain));

            if isempty(vals{3})
                var_label = 1:size(Xtrain,2);
            else
                var_label = vals{3};
                var_label = var_label(:)';
                if numel(var_label) ~= size(Xtrain,2)
                    error('x-axis length must match the number of columns in Xtrain.');
                end
            end

            S.Xtrain = Xtrain;
            S.ClassTrain = ClassTrain(:);
            S.status = status(:);
            S.XtrainAll = Xtrain;
            S.ClassTrainAll = ClassTrain(:);
            S.statusAll = status(:);
            S.includeTrain = true(size(Xtrain,1),1);
            S.trainOriginalRows = (1:size(Xtrain,1))';
            S.trainNamesAll = arrayfun(@(i)sprintf('Sample %d',i),(1:size(Xtrain,1))','UniformOutput',false);
            S.var_label = var_label;
            S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}}, ...
                'sampleNames',{{}},'validationSampleNames',{{}},'unknownSampleNames',{{}});
            set(S.btnDataInfo,'Enable','on','String','Add data info...');
            set(S.btnExclude,'Enable','on');
            guidata(hObj,S);
            updateTargetClassMenu(hObj);
            refreshSummary(hObj,{['Training data imported: ' names{1} ', ' names{2}]});
        catch ME
            errordlg(['Import error: ' ME.message],'Import');
        end
    end

    function onDataInfo(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain), errordlg('Load training data first.','Add data info'); return; end
        sampleCounts = [size(S.Xtrain,1) size(S.Xval,1) size(S.Xunk,1)];
        [info,applied] = plsdm_add_fit_data_info(fig,S.ClassTrain,sampleCounts,S.dataInfo);
        if ~applied, return; end
        S.dataInfo = info;
        if ~isempty(info.sampleNames), S.trainNamesAll(S.includeTrain) = info.sampleNames(:); end
        if ~isempty(info.validationSampleNames), S.valNamesAll(S.includeVal) = info.validationSampleNames(:); end
        if ~isempty(info.unknownSampleNames), S.unkNamesAll(S.includeUnk) = info.unknownSampleNames(:); end
        set(S.btnDataInfo,'String','Edit data info...'); guidata(fig,S);
        refreshSummary(fig,{'Display information updated.'});
    end

    function onExcludeSamples(hObj,ev)
        S = guidata(hObj);
        datasets = struct('key',{},'label',{},'X',{},'classDisplay',{}, ...
            'sampleNames',{},'originalRows',{},'included',{},'outlierStatus',{});
        if ~isempty(S.XtrainAll)
            d.key = 'train'; d.label = 'Training'; d.X = S.XtrainAll;
            d.classDisplay = num2cell(S.ClassTrainAll(:)); d.sampleNames = S.trainNamesAll(:);
            d.originalRows = S.trainOriginalRows(:); d.included = S.includeTrain(:);
            d.outlierStatus = S.statusAll(:);
            datasets(end+1) = d;
        end
        if ~isempty(S.XvalAll)
            d.key = 'known'; d.label = 'Known prediction / validation'; d.X = S.XvalAll;
            d.classDisplay = num2cell(S.ClassValAll(:)); d.sampleNames = S.valNamesAll(:);
            d.originalRows = S.valOriginalRows(:); d.included = S.includeVal(:);
            d.outlierStatus = zeros(size(S.XvalAll,1),1);
            datasets(end+1) = d;
        end
        if ~isempty(S.XunkAll)
            d.key = 'unknown'; d.label = 'Unknown prediction'; d.X = S.XunkAll;
            d.classDisplay = repmat({'Unknown'},size(S.XunkAll,1),1); d.sampleNames = S.unkNamesAll(:);
            d.originalRows = S.unkOriginalRows(:); d.included = S.includeUnk(:);
            d.outlierStatus = zeros(size(S.XunkAll,1),1);
            datasets(end+1) = d;
        end
        if isempty(datasets)
            errordlg('Load at least one dataset before editing sample inclusion.','Exclude samples'); return;
        end
        oldTrain = S.includeTrain; oldVal = S.includeVal; oldUnk = S.includeUnk;
        oldStatus = S.statusAll;
        [applied,datasets] = plsdm_fit_exclude_samples_dialog(fig,datasets);
        if ~applied, return; end
        trainChanged = false; valChanged = false; unkChanged = false;
        for kk = 1:numel(datasets)
            switch datasets(kk).key
                case 'train'
                    S.includeTrain = datasets(kk).included;
                    S.statusAll = datasets(kk).outlierStatus(:);
                    trainChanged = ~isequal(oldTrain,S.includeTrain) || ~isequal(oldStatus,S.statusAll);
                    S.Xtrain = S.XtrainAll(S.includeTrain,:);
                    S.ClassTrain = S.ClassTrainAll(S.includeTrain);
                    S.status = S.statusAll(S.includeTrain);
                    S.dataInfo.sampleNames = S.trainNamesAll(S.includeTrain);
                case 'known'
                    S.includeVal = datasets(kk).included;
                    valChanged = ~isequal(oldVal,S.includeVal);
                    S.Xval = S.XvalAll(S.includeVal,:);
                    S.ClassVal = S.ClassValAll(S.includeVal);
                    S.dataInfo.validationSampleNames = S.valNamesAll(S.includeVal);
                case 'unknown'
                    S.includeUnk = datasets(kk).included;
                    unkChanged = ~isequal(oldUnk,S.includeUnk);
                    S.Xunk = S.XunkAll(S.includeUnk,:);
                    S.dataInfo.unknownSampleNames = S.unkNamesAll(S.includeUnk);
            end
        end
        if trainChanged
            S.CVmodel = []; S.CVmodelAll = []; S.PLSDMmodel = []; S.PLSDMmodelAll = [];
            S.PLSDMvalidation = []; S.PLSDMpred = [];
        else
            if valChanged, S.PLSDMvalidation = []; end
            if unkChanged, S.PLSDMpred = []; end
        end
        guidata(hObj,S);
        updateTargetClassMenu(hObj);
        updatePlotsAndText(hObj);
        if trainChanged
            msgbox('Training sample selection updated. Refit the model and rerun validation to visualize the updated results.', ...
                'Sample selection updated');
        elseif valChanged || unkChanged
            msgbox('Prediction sample selection updated. Rerun validation or prediction to visualize the updated results.', ...
                'Sample selection updated');
        end
    end

    function onLoadModel(hObj,ev)
        S = guidata(hObj);
        choice = questdlg('How do you want to load a saved PLSDMmodel?', ...
                          'Load PLSDMmodel', ...
                          'Workspace variable','MAT-file','Cancel','Workspace variable');
        if isempty(choice) || strcmp(choice,'Cancel')
            return;
        end
        try
            if strcmp(choice,'Workspace variable')
                [ok, names, vals] = plsdm_select_workspace_vars('Load PLSDMmodel', ...
                    {'PLSDMmodel'}, {'PLSDMmodel'}, {false});
                if ~ok, return; end
                PLSDMmodel = vals{1};
            else
                [file,path] = uigetfile('*.mat','Select MAT-file containing PLSDMmodel');
                if isequal(file,0), return; end
                loaded = load(fullfile(path,file));
                if isfield(loaded,'PLSDMmodel')
                    PLSDMmodel = loaded.PLSDMmodel;
                else
                    fn = fieldnames(loaded);
                    PLSDMmodel = loaded.(fn{1});
                end
            end
            if ~isstruct(PLSDMmodel)
                error('Loaded object is not a structure.');
            end
            S.PLSDMmodel = PLSDMmodel;
            if isfield(PLSDMmodel,'AllClassesModels')
                S.PLSDMmodelAll = PLSDMmodel.AllClassesModels;
            else
                S.PLSDMmodelAll = [];
            end
            S.CVmodel = [];
            S.CVmodelAll = [];
            if isfield(PLSDMmodel,'Xtrain'), S.Xtrain = PLSDMmodel.Xtrain; end
            if isfield(PLSDMmodel,'OriginalClassTrain')
                S.ClassTrain = PLSDMmodel.OriginalClassTrain;
            elseif isfield(PLSDMmodel,'ClassTrain')
                S.ClassTrain = PLSDMmodel.ClassTrain;
            end
            if isfield(PLSDMmodel,'var_label') && ~isempty(PLSDMmodel.var_label)
                S.var_label = PLSDMmodel.var_label;
            elseif ~isempty(S.Xtrain)
                S.var_label = 1:size(S.Xtrain,2);
            end
            if isempty(S.status) && ~isempty(S.ClassTrain), S.status = zeros(size(S.ClassTrain)); end
            if ~isempty(S.Xtrain) && ~isempty(S.ClassTrain)
                S.XtrainAll = S.Xtrain; S.ClassTrainAll = S.ClassTrain(:); S.statusAll = S.status(:);
                S.includeTrain = true(size(S.Xtrain,1),1); S.trainOriginalRows = (1:size(S.Xtrain,1))';
                S.trainNamesAll = arrayfun(@(i)sprintf('Sample %d',i),(1:size(S.Xtrain,1))','UniformOutput',false);
                S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}}, ...
                    'sampleNames',{{}},'validationSampleNames',{{}},'unknownSampleNames',{{}});
                set(S.btnDataInfo,'Enable','on','String','Add data info...');
                set(S.btnExclude,'Enable','on');
            end
            if isfield(PLSDMmodel,'sen_all') && ~isempty(PLSDMmodel.sen_all)
                lvLoad = get(S.popupLVopt,'Value');
                if isfield(PLSDMmodel,'LVopt') && ~isempty(PLSDMmodel.LVopt)
                    lvLoad = PLSDMmodel.LVopt;
                    if numel(lvLoad) > 1, lvLoad = lvLoad(end); end
                end
                set(S.popupLVopt,'String',make_lv_strings(length(PLSDMmodel.sen_all)),'Value',max(1,min(lvLoad,length(PLSDMmodel.sen_all))));
            end
            guidata(hObj,S);
            updateTargetClassMenu(hObj);
            updateModelViewMenu(hObj);
            S = guidata(hObj);
            if isfield(PLSDMmodel,'TargetClass') && ~isempty(S.TargetClasses)
                idxTarget = find(S.TargetClasses == PLSDMmodel.TargetClass,1);
                if ~isempty(idxTarget)
                    set(S.popupTargetClass,'Value',idxTarget);
                    S.TargetClass = PLSDMmodel.TargetClass;
                    guidata(hObj,S);
                end
            end
            updatePlotsAndText(hObj);
            refreshSummary(hObj,{'Saved PLSDMmodel loaded successfully.'});
        catch ME
            errordlg(['Load error: ' ME.message],'Load PLSDMmodel');
        end
    end

    function updateTargetClassMenu(hObj)
        S = guidata(hObj);
        if isempty(S.ClassTrain)
            S.TargetClasses = [];
            S.TargetClass = [];
            if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
                set(S.popupTargetClass,'String',{'import data'},'Value',1);
            end
            guidata(hObj,S);
            return;
        end
        classes = unique(S.ClassTrain(:));
        S.TargetClasses = classes(:);
        oldTarget = [];
        if isfield(S,'TargetClass')
            oldTarget = S.TargetClass;
        end
        val = 1;
        if ~isempty(oldTarget)
            oldIdx = find(S.TargetClasses == oldTarget,1);
            if ~isempty(oldIdx)
                val = oldIdx;
            end
        end
        labels = cell(numel(S.TargetClasses),1);
        for ii = 1:numel(S.TargetClasses)
            labels{ii} = num2str(S.TargetClasses(ii));
        end
        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            set(S.popupTargetClass,'String',labels,'Value',val);
        end
        S.TargetClass = S.TargetClasses(val);
        guidata(hObj,S);
    end

    function targetClasses = getTargetClassesForRun(S)
        targetClasses = [];
        if isempty(S.ClassTrain)
            return;
        end
        classes = unique(S.ClassTrain(:));
        if isfield(S,'chkAllClasses') && ishandle(S.chkAllClasses) && get(S.chkAllClasses,'Value')
            targetClasses = classes(:);
            return;
        end
        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass) && ~isempty(classes)
            idx = get(S.popupTargetClass,'Value');
            idx = max(1,min(idx,numel(classes)));
            targetClasses = classes(idx);
        else
            targetClasses = classes(1);
        end
    end

    function targetClass = getModelTargetClass(S)
        targetClass = [];
        if isfield(S,'PLSDMmodel') && ~isempty(S.PLSDMmodel) && isfield(S.PLSDMmodel,'TargetClass')
            targetClass = S.PLSDMmodel.TargetClass;
        elseif isfield(S,'TargetClass') && ~isempty(S.TargetClass)
            targetClass = S.TargetClass;
        elseif ~isempty(S.ClassTrain)
            classes = unique(S.ClassTrain(:));
            targetClass = classes(1);
        else
            targetClass = 1;
        end
    end

    function onTargetSelectionChanged(hObj,ev)
        S = guidata(hObj);
        if ~isempty(S.TargetClasses) && isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            idx = get(S.popupTargetClass,'Value');
            idx = max(1,min(idx,numel(S.TargetClasses)));
            S.TargetClass = S.TargetClasses(idx);
            guidata(hObj,S);
        end
        refreshSummary(hObj,{});
    end

    function onRestoreDefaults(hObj,ev)
        S = guidata(hObj);
        set(S.edKcv,'String','5');
        set(S.edMaxLV,'String','10');
        set(S.popupLVopt,'String',make_lv_strings(10),'Value',1);
        set(S.edConf,'String','0.95');
        set(S.popupPrepro,'Value',1);
        set(S.edAlpha,'String','0.3');
        set(S.edKappa,'String','1');
        set(S.edGamma,'String','0.01');
        set(S.popupMode,'Value',1);
        if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
            set(S.popupModellingType,'Value',1);
        end
        S.ModellingType = 'Compliant';
        guidata(hObj,S);
        refreshSummary(hObj,{'Defaults restored.'});
        updatePlotsAndText(hObj);
    end

    function onModellingTypeChanged(hObj,ev)
        S = guidata(hObj);
        S.ModellingType = getSelectedModellingType(S);
        guidata(hObj,S);
        refreshSummary(hObj,{});
    end

    function modellingType = getSelectedModellingType(S)
        modellingType = 'Compliant';
        if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
            vals = get(S.popupModellingType,'String');
            idx = get(S.popupModellingType,'Value');
            if ischar(vals)
                modellingType = vals;
            elseif idx >= 1 && idx <= numel(vals)
                modellingType = vals{idx};
            end
        elseif isfield(S,'ModellingType') && ~isempty(S.ModellingType)
            modellingType = S.ModellingType;
        end
    end

    function [Xmodel,ClassOne,statusModel,targetInfo] = prepare_gui_modelling_data(S,targetClass,modellingType)
        if nargin < 3 || isempty(modellingType)
            modellingType = 'Compliant';
        end
        ClassTrain = S.ClassTrain(:);
        statusFull = S.status(:);
        if isempty(statusFull)
            statusFull = zeros(size(ClassTrain));
        end
        if numel(statusFull) ~= numel(ClassTrain)
            error('Outliers status length must match ClassTrain length.');
        end
        switch lower(modellingType)
            case 'rigorous'
                idxTarget = find(ClassTrain == targetClass);
                if isempty(idxTarget)
                    error('Selected target class was not found in ClassTrain.');
                end
                Xmodel = S.Xtrain(idxTarget,:);
                ClassOne = ones(numel(idxTarget),1);
                statusModel = statusFull(idxTarget);
                classes = unique(ClassTrain);
                targetInfo = struct();
                targetInfo.targetClass = targetClass;
                targetInfo.originalClasses = classes(:);
                targetInfo.originalClassTrain = ClassTrain;
                targetInfo.nTarget = numel(idxTarget);
                targetInfo.nNonTarget = 0;
                targetInfo.modellingType = 'Rigorous';
                targetInfo.trainingRows = idxTarget(:);
            otherwise
                [ClassOne,targetInfo] = plsdm_prepare_oneclass_labels(ClassTrain,targetClass);
                Xmodel = S.Xtrain;
                statusModel = statusFull;
                targetInfo.modellingType = 'Compliant';
                targetInfo.trainingRows = (1:numel(ClassTrain))';
        end
    end

    function onExportOutliersStatus(hObj,ev)
        S = guidata(hObj);
        M = [];
        if isfield(S,'PLSDMmodel') && ~isempty(S.PLSDMmodel)
            M = S.PLSDMmodel;
        end
        if isempty(M) || ~isfield(M,'samples_status') || isempty(M.samples_status)
            warndlg('Run a robust final model before exporting outliers status.','Outliers status');
            return;
        end
        out_status = M.samples_status(:);
        assignin('base','out_status',out_status);
        msgbox('Outliers status exported to workspace as out_status.','Outliers status');
    end

    function onShowFOMs(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            warndlg('Fit the final model before generating the figures-of-merit report.','Figures of merit');
            return;
        end
        if isempty(S.CVmodel)
            warndlg('Run cross-validation before generating the figures-of-merit report.','Figures of merit');
            return;
        end
        finalModels = {S.PLSDMmodel};
        cvModels = {S.CVmodel};
        if ~isempty(S.PLSDMmodelAll)
            finalModels = S.PLSDMmodelAll;
        end
        if ~isempty(S.CVmodelAll)
            cvModels = S.CVmodelAll;
        end
        lines = {'PLS-DM Figures of Merit'; ' '};
        for ii = 1:length(finalModels)
            Mfit = finalModels{ii};
            Mcv = cvModels{min(ii,length(cvModels))};
            lv = getFinalLVForModel(S,Mfit,ii);
            targetClass = ii;
            if isfield(Mfit,'TargetClass') && ~isempty(Mfit.TargetClass)
                targetClass = Mfit.TargetClass;
            end
            lines{end+1} = ['Target class: ' num2str(targetClass)];
            lines{end+1} = ['LV used in final model: ' num2str(lv)];
            if isfield(Mfit,'Cresults') && isfield(Mfit.Cresults,'Gtrue') && ...
                    isfield(Mfit.Cresults,'Gpred_bin')
                lines = appendFOMSection(lines,'Training',Mfit.Cresults.Gtrue,Mfit.Cresults.Gpred_bin);
            else
                lines{end+1} = 'Training: results unavailable.';
            end
            if isfield(Mcv,'Compliance') && numel(Mcv.Compliance) >= lv && ...
                    ~isempty(Mcv.Compliance{lv}) && isfield(Mcv.Compliance{lv},'Gtrue') && ...
                    isfield(Mcv.Compliance{lv},'Gpred_bin')
                C = Mcv.Compliance{lv};
                lines = appendFOMSection(lines,'Cross-validation',C.Gtrue,C.Gpred_bin);
            else
                lines{end+1} = 'Cross-validation: results unavailable at the final LV.';
            end
            if ~isempty(S.PLSDMvalidation) && ~isempty(S.Xval) && ~isempty(S.ClassVal)
                try
                    [knownTruth,tmpInfo] = plsdm_prepare_oneclass_labels(S.ClassVal,targetClass); %#ok<NASGU>
                    knownResult = enrich_known_validation_result(struct(),S.Xval,knownTruth,Mfit);
                    if isfield(knownResult,'CVresults') && ...
                            isfield(knownResult.CVresults,'Gtrue') && ...
                            isfield(knownResult.CVresults,'Gpred_bin')
                        lines = appendFOMSection(lines,'Known prediction', ...
                            knownResult.CVresults.Gtrue,knownResult.CVresults.Gpred_bin);
                    else
                        lines{end+1} = 'Known prediction: results unavailable.';
                    end
                catch
                    lines{end+1} = 'Known prediction: results unavailable.';
                end
            else
                lines{end+1} = 'Known prediction: not run.';
            end
            lines{end+1} = ' ';
        end
        if numel(finalModels) > 1 && ~isempty(S.PLSDMvalidation) && ...
                ~isempty(S.Xval) && ~isempty(S.ClassVal)
            lines = appendKnownMulticlassFOMSummary(lines,S,finalModels);
        end
        fReport = figure('Name','PLS-DM Figures of Merit','NumberTitle','off', ...
            'MenuBar','none','Toolbar','none','Color',[0.94 0.95 0.98], ...
            'Units','pixels','Position',[180 100 610 570]);
        uicontrol('Parent',fReport,'Style','listbox','Units','normalized', ...
            'Position',[0.04 0.04 0.92 0.92],'String',lines,'Max',2,'Min',0, ...
            'BackgroundColor',[1 1 1],'FontName','FixedWidth','FontSize',10, ...
            'HorizontalAlignment','left');
    end

    function lv = getFinalLVForModel(S,M,modelIndex)
        lv = get(S.popupLVopt,'Value');
        if isfield(M,'SelectedLVForClass') && ~isempty(M.SelectedLVForClass)
            lv = M.SelectedLVForClass;
        elseif isfield(S,'SelectedLVByClass') && numel(S.SelectedLVByClass) >= modelIndex
            lv = S.SelectedLVByClass(modelIndex);
        elseif isfield(M,'LVopt') && ~isempty(M.LVopt)
            lv = M.LVopt;
            if numel(lv) > 1, lv = lv(end); end
        end
        lv = max(1,round(lv));
    end

    function lines = appendFOMSection(lines,titleText,Gtrue,Gpred)
        truth = Gtrue(:) == 1;
        accepted = Gpred(:) == 1;
        n = min(length(truth),length(accepted));
        truth = truth(1:n);
        accepted = accepted(1:n);
        TP = sum(truth & accepted);
        FN = sum(truth & ~accepted);
        TN = sum(~truth & ~accepted);
        FP = sum(~truth & accepted);
        sensitivity = safeRatio(TP,TP+FN);
        specificity = safeRatio(TN,TN+FP);
        fnr = safeRatio(FN,TP+FN);
        fpr = safeRatio(FP,TN+FP);
        efficiency = NaN;
        if isfinite(sensitivity) && isfinite(specificity)
            efficiency = sqrt(sensitivity*specificity);
        end
        precision = safeRatio(TP,TP+FP);
        accuracy = safeRatio(TP+TN,n);
        f1 = safeRatio(2*precision*sensitivity,precision+sensitivity);
        lines{end+1} = [titleText ' (n = ' num2str(n) ')'];
        lines{end+1} = sprintf('  Accepted: %d (%.2f%%)',sum(accepted),100*safeRatio(sum(accepted),n));
        lines{end+1} = sprintf('  Rejected: %d (%.2f%%)',sum(~accepted),100*safeRatio(sum(~accepted),n));
        lines{end+1} = ['  Sensitivity: ' formatFOM(sensitivity)];
        lines{end+1} = ['  Specificity: ' formatFOM(specificity)];
        lines{end+1} = ['  Efficiency: ' formatFOM(efficiency)];
        lines{end+1} = ['  Precision: ' formatFOM(precision)];
        lines{end+1} = ['  Accuracy: ' formatFOM(accuracy)];
        lines{end+1} = ['  F1 score: ' formatFOM(f1)];
        lines{end+1} = ['  False negative rate: ' formatFOM(fnr)];
        lines{end+1} = ['  False positive rate: ' formatFOM(fpr)];
        lines{end+1} = sprintf('  TP: %d | FN: %d | TN: %d | FP: %d',TP,FN,TN,FP);
    end

    function lines = appendKnownMulticlassFOMSummary(lines,S,models)
        n = size(S.Xval,1);
        nModels = numel(models);
        accepted = false(n,nModels);
        classes = zeros(1,nModels);
        macro = nan(nModels,6);
        for jj = 1:nModels
            if isfield(models{jj},'TargetClass') && ~isempty(models{jj}.TargetClass)
                classes(jj) = models{jj}.TargetClass;
            else
                classes(jj) = jj;
            end
            [truthOne,tmpInfo] = plsdm_prepare_oneclass_labels(S.ClassVal,classes(jj)); %#ok<NASGU>
            result = enrich_known_validation_result(struct(),S.Xval,truthOne,models{jj});
            if ~isfield(result,'CVresults') || ~isfield(result.CVresults,'Gpred_bin'), continue; end
            pred = result.CVresults.Gpred_bin(:) == 1;
            accepted(:,jj) = pred(1:n);
            truth = truthOne(:) == 1;
            TP=sum(truth & pred); FN=sum(truth & ~pred); TN=sum(~truth & ~pred); FP=sum(~truth & pred);
            sen=safeRatio(TP,TP+FN); spec=safeRatio(TN,TN+FP); prec=safeRatio(TP,TP+FP);
            acc=safeRatio(TP+TN,n); f1=safeRatio(2*prec*sen,prec+sen);
            eff=NaN; if isfinite(sen) && isfinite(spec), eff=sqrt(sen*spec); end
            macro(jj,:)=[sen spec eff prec acc f1];
        end
        correct=false(n,1); unassigned=false(n,1); ambiguous=false(n,1); wrong=false(n,1);
        for rr=1:n
            ids=find(accepted(rr,:)); actual=S.ClassVal(rr);
            if isempty(ids), unassigned(rr)=true;
            elseif numel(ids)>1, ambiguous(rr)=true;
            elseif classes(ids)==actual, correct(rr)=true;
            else, wrong(rr)=true;
            end
        end
        lines{end+1}='Known prediction - multiclass summary';
        lines{end+1}=sprintf('  Correct single-class assignments: %d/%d (%.2f%%)',sum(correct),n,100*safeRatio(sum(correct),n));
        lines{end+1}=sprintf('  Wrong single-class assignments: %d',sum(wrong));
        lines{end+1}=sprintf('  Rejected by all classes: %d',sum(unassigned));
        lines{end+1}=sprintf('  Ambiguous (accepted by multiple classes): %d',sum(ambiguous));
        labels={'Sensitivity','Specificity','Efficiency','Precision','Accuracy','F1 score'};
        for kk=1:numel(labels)
            values=macro(:,kk); values=values(isfinite(values));
            if isempty(values), value=NaN; else, value=mean(values); end
            lines{end+1}=['  Macro ' labels{kk} ': ' formatFOM(value)];
        end
        lines{end+1}=' ';
    end

    function value = safeRatio(num,den)
        if den > 0
            value = num/den;
        else
            value = NaN;
        end
    end

    function txt = formatFOM(value)
        if isfinite(value)
            txt = sprintf('%.4f (%.2f%%)',value,100*value);
        else
            txt = 'N/A (no non-target samples)';
        end
    end

    function onUpdateLVMenu(hObj,ev)
        S = guidata(hObj);
        try
            LVmax = parsePositiveInteger(get(S.edMaxLV,'String'),'Max LV');
            oldVal = get(S.popupLVopt,'Value');
            set(S.popupLVopt,'String',make_lv_strings(LVmax),'Value',max(1,min(oldVal,LVmax)));
        catch ME
            errordlg(ME.message,'LV list');
        end
    end

    function onRunCV(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain) || isempty(S.ClassTrain)
            errordlg('Import Xtrain and ClassTrain before running CV.','Cross-validation');
            return;
        end

        try
            K = parsePositiveInteger(get(S.edKcv,'String'),'K-fold CV');
            LVmax = parsePositiveInteger(get(S.edMaxLV,'String'),'Max LV');
            conflev = parseProbability(get(S.edConf,'String'),'Confidence');
            gama = parseProbability(get(S.edGamma,'String'),'Robust gamma');
            if isempty(S.var_label)
                S.var_label = 1:size(S.Xtrain,2);
            end
            if isempty(S.status)
                S.status = zeros(size(S.ClassTrain));
            end
        catch ME
            errordlg(ME.message,'Invalid settings');
            return;
        end

        set(S.txtModel,'String',{'Running cross-validation...'});
        drawnow;

        try
            modeVal = get(S.popupMode,'Value');
            modellingType = getSelectedModellingType(S);
            targetClasses = getTargetClassesForRun(S);
            if isempty(targetClasses)
                error('No target class is available. Import ClassTrain first.');
            end
            [okParams,cvParams] = selectCVParamsForRun(S,targetClasses);
            if ~okParams
                return;
            end
            CVmodelAll = cell(numel(targetClasses),1);
            for it = 1:numel(targetClasses)
                alpha = cvParams(it).alpha;
                kappa = cvParams(it).kappa;
                preprocessing = cvParams(it).preprocessing;
                [Xmodel,ClassOne,statusModel,targetInfo] = prepare_gui_modelling_data(S,targetClasses(it),modellingType);
                if modeVal == 1
                    CVtmp = call_classical_cv(Xmodel, ClassOne, K, LVmax, conflev, alpha, kappa, preprocessing, S.var_label, statusModel);
                else
                    CVtmp = call_robust_cv(Xmodel, ClassOne, K, LVmax, conflev, alpha, kappa, preprocessing, S.var_label, gama, statusModel);
                end
                CVtmp.TargetClass = targetClasses(it);
                CVtmp.TargetInfo = targetInfo;
                CVtmp.OriginalClassTrain = S.ClassTrain;
                CVtmp.ClassTrain = ClassOne;
                CVtmp.ModellingType = modellingType;
                CVtmp.TrainingRows = targetInfo.trainingRows;
                CVtmp.GUI_CV_alpha = alpha;
                CVtmp.GUI_CV_kappa = kappa;
                CVtmp.GUI_CV_preprocessing = preprocessing;
                CVtmp.GUIVersion = GUI_VERSION;
                CVmodelAll{it} = CVtmp;
            end
            CVmodel = CVmodelAll{1};
            if numel(targetClasses) > 1
                CVmodel.AllClassesModels = CVmodelAll;
                CVmodel.AllTargetClasses = targetClasses(:);
            end
        catch ME
            errordlg(['Cross-validation failed: ' ME.message],'Cross-validation');
            return;
        end

        S.CVmodel = CVmodel;
        if numel(targetClasses) > 1
            S.CVmodelAll = CVmodelAll;
        else
            S.CVmodelAll = [];
        end
        S.PLSDMmodel = [];
        S.PLSDMmodelAll = [];
        S.CVParamsByClass = cvParams;
        S.TargetClass = targetClasses(1);
        if isfield(CVmodel,'sen_all') && ~isempty(CVmodel.sen_all)
            set(S.popupLVopt,'String',make_lv_strings(length(CVmodel.sen_all)),'Value',1);
        else
            set(S.popupLVopt,'String',make_lv_strings(LVmax),'Value',1);
        end
        guidata(hObj,S);
        updateModelViewMenu(hObj);
        updatePlotsAndText(hObj);
        refreshSummary(hObj,{'Cross-validation completed successfully.'});
    end

    function onFitFinalModel(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain) || isempty(S.ClassTrain)
            errordlg('Import Xtrain and ClassTrain before fitting the final model.','Fit final model');
            return;
        end
        if isempty(S.CVmodel)
            answer = questdlg('No CV result is currently stored. Fit final model anyway using the selected LV?', ...
                              'Fit final model', 'Yes','No','No');
            if isempty(answer) || strcmp(answer,'No')
                return;
            end
        end

        try
            K = parsePositiveInteger(get(S.edKcv,'String'),'K-fold CV');
            conflev = parseProbability(get(S.edConf,'String'),'Confidence');
            gama = parseProbability(get(S.edGamma,'String'),'Robust gamma');
            if isempty(S.var_label)
                S.var_label = 1:size(S.Xtrain,2);
            end
            if isempty(S.status)
                S.status = zeros(size(S.ClassTrain));
            end
        catch ME
            errordlg(ME.message,'Invalid settings');
            return;
        end

        try
            modeVal = get(S.popupMode,'Value');
            modellingType = getSelectedModellingType(S);
            targetClasses = getTargetClassesForRun(S);
            if isempty(targetClasses)
                error('No target class is available. Import ClassTrain first.');
            end
            [okFit,fitParams] = selectFinalParamsForFit(S,targetClasses);
            if ~okFit
                return;
            end
            lvByClass = reshape([fitParams.LV],[],1);
            S.SelectedLVByClass = lvByClass;
            set(S.txtModel,'String',build_fit_progress_lines(S,targetClasses,fitParams));
            guidata(hObj,S);
            drawnow;
            PLSDMmodelAll = cell(numel(targetClasses),1);
            for it = 1:numel(targetClasses)
                LVopt = lvByClass(it);
                alpha = fitParams(it).alpha;
                kappa = fitParams(it).kappa;
                preprocessing = fitParams(it).preprocessing;
                [Xmodel,ClassOne,statusModel,targetInfo] = prepare_gui_modelling_data(S,targetClasses(it),modellingType);
                if modeVal == 1
                    PLStmp = call_classical_fit(Xmodel, ClassOne, K, LVopt, conflev, alpha, kappa, preprocessing, S.var_label, statusModel);
                else
                    PLStmp = call_robust_fit(Xmodel, ClassOne, K, LVopt, conflev, alpha, kappa, preprocessing, S.var_label, gama, statusModel);
                end
                PLStmp.TargetClass = targetClasses(it);
                PLStmp.TargetInfo = targetInfo;
                PLStmp.OriginalClassTrain = S.ClassTrain;
                PLStmp.ClassTrain = ClassOne;
                PLStmp.ModellingType = modellingType;
                PLStmp.TrainingRows = targetInfo.trainingRows;
                PLStmp.SelectedLVForClass = LVopt;
                PLStmp.GUI_CV_alpha = alpha;
                PLStmp.GUI_CV_kappa = kappa;
                PLStmp.GUI_CV_preprocessing = preprocessing;
                PLStmp.GUI_Fit_alpha = alpha;
                PLStmp.GUI_Fit_kappa = kappa;
                PLStmp.GUIVersion = GUI_VERSION;
                PLSDMmodelAll{it} = PLStmp;
            end
            PLSDMmodel = PLSDMmodelAll{1};
            if numel(targetClasses) > 1
                PLSDMmodel.AllClassesModels = PLSDMmodelAll;
                PLSDMmodel.AllTargetClasses = targetClasses(:);
                PLSDMmodel.SelectedLVByClass = lvByClass(:);
            end
        catch ME
            errordlg(['Final model fitting failed: ' ME.message],'Fit final model');
            return;
        end

        if ~isfield(PLSDMmodel,'var_label') || isempty(PLSDMmodel.var_label)
            PLSDMmodel.var_label = S.var_label;
        end
        S.PLSDMmodel = PLSDMmodel;
        if numel(targetClasses) > 1
            S.PLSDMmodelAll = PLSDMmodelAll;
        else
            S.PLSDMmodelAll = [];
        end
        % A newly fitted model invalidates prediction results from any
        % previously fitted model.
        S.PLSDMvalidation = [];
        S.PLSDMpred = [];
        S.TargetClass = targetClasses(1);
        guidata(hObj,S);
        updateModelViewMenu(hObj);
        updatePlotsAndText(hObj);
        refreshSummary(hObj,{'Final model fitted successfully.'});
    end

    function lines = build_fit_progress_lines(S,targetClasses,fitParams)
        lines = {'Fitting final model(s) with selected parameters...'; ' '};
        for ii = 1:length(targetClasses)
            className = plsdm_data_info_class_name(S.dataInfo,targetClasses(ii));
            lines{end+1} = [className ': ' preprocessing_display_name(fitParams(ii).preprocessing) ', LV ' num2str(fitParams(ii).LV) ...
                ', smoothing ' num2str(fitParams(ii).alpha) ', kappa ' num2str(fitParams(ii).kappa)];
        end
    end

    function [ok,fitParams] = selectFinalParamsForFit(S,targetClasses)
        ok = false;
        nClass = length(targetClasses);
        fitParams = repmat(struct('TargetClass',[],'LV',1,'alpha',[],'kappa',[], ...
            'preprocessing',''),nClass,1);
        maxLvByClass = zeros(nClass,1);
        defaultLv = ones(nClass,1);
        for ii = 1:nClass
            Mtmp = [];
            if nClass > 1 && isfield(S,'CVmodelAll') && numel(S.CVmodelAll) >= ii
                Mtmp = S.CVmodelAll{ii};
            elseif isfield(S,'CVmodel') && ~isempty(S.CVmodel)
                Mtmp = S.CVmodel;
            elseif isfield(S,'PLSDMmodelAll') && numel(S.PLSDMmodelAll) >= ii
                Mtmp = S.PLSDMmodelAll{ii};
            elseif isfield(S,'PLSDMmodel') && ~isempty(S.PLSDMmodel)
                Mtmp = S.PLSDMmodel;
            end
            maxLvByClass(ii) = getMaxLVFromModelOrSettings(Mtmp,S);
            defaultLv(ii) = getDefaultLVForClass(S,Mtmp,targetClasses(ii),ii,maxLvByClass(ii));
        end

        scr = get(0,'ScreenSize');
        rowH0 = 36;
        figH = min(max(246,146+nClass*rowH0),640);
        rowH = min(rowH0,max(24,(figH-176)/max(1,nClass)));
        figW = 620;
        pos = [scr(3)/2-figW/2 scr(4)/2-figH/2 figW figH];
        dlg = figure('Name','Set final fit parameters', ...
                     'NumberTitle','off', ...
                     'MenuBar','none', ...
                     'Toolbar','none', ...
                     'WindowStyle','modal', ...
                     'Resize','off', ...
                     'Color',[0.94 0.95 0.98], ...
                     'Position',pos);
        uicontrol('Parent',dlg,'Style','text', ...
            'String','Define preprocessing, LV, smoothing coefficient and kappa for the final model(s).', ...
            'Units','pixels','Position',[20 figH-55 figW-40 30], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Class', ...
            'Units','pixels','Position',[28 figH-86 80 20],'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Preprocessing', ...
            'Units','pixels','Position',[115 figH-86 140 20],'BackgroundColor',[0.94 0.95 0.98],'FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','LV', ...
            'Units','pixels','Position',[265 figH-86 55 20],'BackgroundColor',[0.94 0.95 0.98],'FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Smoothing (alpha)', ...
            'Units','pixels','Position',[330 figH-86 100 20],'BackgroundColor',[0.94 0.95 0.98],'FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Kappa', ...
            'Units','pixels','Position',[455 figH-86 80 20],'BackgroundColor',[0.94 0.95 0.98],'FontWeight','bold');
        popPre = zeros(nClass,1);
        pop = zeros(nClass,1);
        edAlpha = zeros(nClass,1);
        edKappa = zeros(nClass,1);
        y0 = figH-126;
        for ii = 1:nClass
            y = y0-(ii-1)*rowH;
            defaults = getCVParamsForClass(S,targetClasses(ii));
            preproList = get(S.popupPrepro,'String');
            preIdx = find_string_index(preproList,defaults.preprocessing);
            uicontrol('Parent',dlg,'Style','text', ...
                'String',plsdm_data_info_class_name(S.dataInfo,targetClasses(ii)), ...
                'Units','pixels','Position',[28 y 80 24], ...
                'BackgroundColor',[0.94 0.95 0.98], ...
                'HorizontalAlignment','left');
            popPre(ii) = uicontrol('Parent',dlg,'Style','popupmenu', ...
                'String',preproList,'Value',preIdx, ...
                'Units','pixels','Position',[115 y 140 24],'BackgroundColor',[1 1 1]);
            pop(ii) = uicontrol('Parent',dlg,'Style','popupmenu', ...
                'String',make_lv_strings(maxLvByClass(ii)), ...
                'Value',defaultLv(ii), ...
                'Units','pixels','Position',[265 y 55 24], ...
                'BackgroundColor',[1 1 1]);
            edAlpha(ii) = uicontrol('Parent',dlg,'Style','edit','String',num2str(defaults.alpha), ...
                'Units','pixels','Position',[330 y 95 24],'BackgroundColor',[1 1 1]);
            edKappa(ii) = uicontrol('Parent',dlg,'Style','edit','String',num2str(defaults.kappa), ...
                'Units','pixels','Position',[455 y 95 24],'BackgroundColor',[1 1 1]);
        end
        uicontrol('Parent',dlg,'Style','pushbutton','String','OK', ...
            'Units','pixels','Position',[figW-190 20 75 28], ...
            'FontWeight','bold','Callback',@onLVDialogOK);
        uicontrol('Parent',dlg,'Style','pushbutton','String','Cancel', ...
            'Units','pixels','Position',[figW-105 20 75 28], ...
            'Callback',@onLVDialogCancel);
        setappdata(dlg,'ok',false);
        uiwait(dlg);
        if ishandle(dlg)
            ok = getappdata(dlg,'ok');
            delete(dlg);
        end

        function onLVDialogOK(h,ev)
            try
                for jj = 1:nClass
                    fitParams(jj).TargetClass = targetClasses(jj);
                    fitParams(jj).LV = get(pop(jj),'Value');
                    pList = get(popPre(jj),'String');
                    fitParams(jj).preprocessing = preprocessing_internal_name(pList{get(popPre(jj),'Value')});
                    fitParams(jj).alpha = parseScalarNumber(get(edAlpha(jj),'String'),'Smoothing coefficient');
                    fitParams(jj).kappa = parsePositiveInteger(get(edKappa(jj),'String'),'Kappa');
                end
                setappdata(dlg,'ok',true);
                uiresume(dlg);
            catch ME
                errordlg(ME.message,'Invalid fit parameters');
            end
        end
        function onLVDialogCancel(h,ev)
            setappdata(dlg,'ok',false);
            uiresume(dlg);
        end
    end

    function [ok,paramsByClass] = selectCVParamsForRun(S,targetClasses)
        ok = false;
        nClass = length(targetClasses);
        paramsByClass = repmat(struct('TargetClass',[],'alpha',[],'kappa',[],'preprocessing',''),nClass,1);
        preproList = get(S.popupPrepro,'String');
        defaultPre = preproList{get(S.popupPrepro,'Value')};
        defaultAlpha = parseScalarNumber(get(S.edAlpha,'String'),'Smoothing coefficient');
        defaultKappa = parsePositiveInteger(get(S.edKappa,'String'),'Kappa');

        scr = get(0,'ScreenSize');
        rowH0 = 36;
        figH = min(max(246,146+nClass*rowH0),640);
        rowH = min(rowH0,max(24,(figH-176)/max(1,nClass)));
        figW = 620;
        pos = [scr(3)/2-figW/2 scr(4)/2-figH/2 figW figH];
        dlg = figure('Name','Set CV parameters', ...
                     'NumberTitle','off','MenuBar','none','Toolbar','none', ...
                     'WindowStyle','modal','Resize','off', ...
                     'Color',[0.94 0.95 0.98], ...
                     'Position',pos);
        uicontrol('Parent',dlg,'Style','text', ...
            'String','Define preprocessing, smoothing coefficient and kappa for the CV model(s).', ...
            'Units','pixels','Position',[20 figH-55 figW-40 30], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Class', ...
            'Units','pixels','Position',[28 figH-86 80 20], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Preprocessing', ...
            'Units','pixels','Position',[130 figH-86 150 20], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Smoothing (alpha)', ...
            'Units','pixels','Position',[320 figH-86 100 20], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');
        uicontrol('Parent',dlg,'Style','text','String','Kappa', ...
            'Units','pixels','Position',[455 figH-86 80 20], ...
            'BackgroundColor',[0.94 0.95 0.98], ...
            'HorizontalAlignment','left','FontWeight','bold');

        popPre = zeros(nClass,1);
        edAlpha = zeros(nClass,1);
        edKappa = zeros(nClass,1);
        y0 = figH-126;
        for ii = 1:nClass
            y = y0 - (ii-1)*rowH;
            defaults = getCVParamsForClass(S,targetClasses(ii));
            if isempty(defaults.preprocessing), defaults.preprocessing = defaultPre; end
            if isempty(defaults.alpha), defaults.alpha = defaultAlpha; end
            if isempty(defaults.kappa), defaults.kappa = defaultKappa; end
            preIdx = find_string_index(preproList,defaults.preprocessing);
            uicontrol('Parent',dlg,'Style','text','String',plsdm_data_info_class_name(S.dataInfo,targetClasses(ii)), ...
                'Units','pixels','Position',[28 y 80 24], ...
                'BackgroundColor',[0.94 0.95 0.98], ...
                'HorizontalAlignment','left');
            popPre(ii) = uicontrol('Parent',dlg,'Style','popupmenu','String',preproList, ...
                'Value',preIdx,'Units','pixels','Position',[130 y 160 24], ...
                'BackgroundColor',[1 1 1]);
            edAlpha(ii) = uicontrol('Parent',dlg,'Style','edit','String',num2str(defaults.alpha), ...
                'Units','pixels','Position',[320 y 95 24], ...
                'BackgroundColor',[1 1 1]);
            edKappa(ii) = uicontrol('Parent',dlg,'Style','edit','String',num2str(defaults.kappa), ...
                'Units','pixels','Position',[455 y 95 24], ...
                'BackgroundColor',[1 1 1]);
        end

        uicontrol('Parent',dlg,'Style','pushbutton','String','OK', ...
            'Units','pixels','Position',[figW-190 20 75 28], ...
            'FontWeight','bold','Callback',@onCVParamsOK);
        uicontrol('Parent',dlg,'Style','pushbutton','String','Cancel', ...
            'Units','pixels','Position',[figW-105 20 75 28], ...
            'Callback',@onCVParamsCancel);
        setappdata(dlg,'ok',false);
        uiwait(dlg);
        if ishandle(dlg)
            ok = getappdata(dlg,'ok');
            delete(dlg);
        end

        function onCVParamsOK(h,ev)
            try
                for jj = 1:nClass
                    pList = get(popPre(jj),'String');
                    paramsByClass(jj).TargetClass = targetClasses(jj);
                    paramsByClass(jj).preprocessing = preprocessing_internal_name(pList{get(popPre(jj),'Value')});
                    paramsByClass(jj).alpha = parseScalarNumber(get(edAlpha(jj),'String'),'Smoothing coefficient');
                    paramsByClass(jj).kappa = parsePositiveInteger(get(edKappa(jj),'String'),'Kappa');
                end
                setappdata(dlg,'ok',true);
                uiresume(dlg);
            catch ME
                errordlg(ME.message,'Invalid CV parameters');
            end
        end
        function onCVParamsCancel(h,ev)
            setappdata(dlg,'ok',false);
            uiresume(dlg);
        end
    end

    function params = getCVParamsForClass(S,targetClass)
        params.TargetClass = targetClass;
        params.alpha = [];
        params.kappa = [];
        params.preprocessing = '';
        if isfield(S,'CVParamsByClass') && ~isempty(S.CVParamsByClass)
            for ii = 1:length(S.CVParamsByClass)
                if isfield(S.CVParamsByClass(ii),'TargetClass') && S.CVParamsByClass(ii).TargetClass == targetClass
                    params = S.CVParamsByClass(ii);
                    return;
                end
            end
        end
        preproList = get(S.popupPrepro,'String');
        params.preprocessing = preprocessing_internal_name(preproList{get(S.popupPrepro,'Value')});
        params.alpha = parseScalarNumber(get(S.edAlpha,'String'),'Smoothing coefficient');
        params.kappa = parsePositiveInteger(get(S.edKappa,'String'),'Kappa');
    end

    function idx = find_string_index(list,value)
        value = preprocessing_display_name(value);
        idx = 1;
        for ii = 1:length(list)
            if strcmpi(list{ii},value)
                idx = ii;
                return;
            end
        end
    end

    function name = preprocessing_internal_name(label)
        switch lower(label)
            case 'raw', name='raw'; case 'center', name='centered'; case 'scale', name='scaled';
            case 'autoscale', name='autoscaled'; otherwise, name=label;
        end
    end

    function label = preprocessing_display_name(name)
        switch lower(name)
            case 'raw', label='Raw'; case {'center','centered'}, label='Center';
            case {'scale','scaled'}, label='Scale'; case {'autoscale','autoscaled'}, label='Autoscale';
            otherwise, label=name;
        end
    end

    function maxLV = getMaxLVFromModelOrSettings(M,S)
        maxLV = 1;
        if ~isempty(M) && isstruct(M) && isfield(M,'sen_all') && ~isempty(M.sen_all)
            maxLV = length(M.sen_all);
        elseif ~isempty(M) && isstruct(M) && isfield(M,'LV') && ~isempty(M.LV)
            maxLV = M.LV;
            if numel(maxLV) > 1, maxLV = max(maxLV(:)); end
        else
            try
                maxLV = parsePositiveInteger(get(S.edMaxLV,'String'),'Max LV');
            catch
                maxLV = 10;
            end
        end
        maxLV = max(1,round(maxLV));
    end

    function lv = getDefaultLVForClass(S,M,targetClass,idx,maxLV)
        lv = min(maxLV,max(1,get(S.popupLVopt,'Value')));
        if isfield(S,'SelectedLVByClass') && ~isempty(S.SelectedLVByClass) && numel(S.SelectedLVByClass) >= idx
            lv = S.SelectedLVByClass(idx);
        elseif ~isempty(M) && isstruct(M)
            if isfield(M,'LVopt') && ~isempty(M.LVopt)
                lv = M.LVopt;
                if numel(lv) > 1, lv = lv(end); end
            elseif strcmpi(getSelectedModellingType(S),'Rigorous') && ...
                    isfield(M,'sen_all') && ~isempty(M.sen_all) && any(isfinite(M.sen_all))
                expected = str2double(get(S.edConf,'String'));
                if isnan(expected), expected = 0.95; end
                distance = abs(M.sen_all(:)-expected);
                distance(~isfinite(distance)) = Inf;
                [dummy,lv] = min(distance); 
            elseif isfield(M,'eff_all') && ~isempty(M.eff_all) && any(isfinite(M.eff_all))
                [dummy,lv] = max(M.eff_all(:));
            elseif isfield(M,'sen_all') && ~isempty(M.sen_all)
                [dummy,lv] = max(M.sen_all(:));
            end
        end
        lv = max(1,min(maxLV,round(lv)));
    end

    function onLVSelectionChanged(hObj,ev)
        S = guidata(hObj);
        if ~isempty(S.CVmodel) || ~isempty(S.PLSDMmodel)
            updateModelText(hObj);
            refreshSummary(hObj,{});
            plotAcceptanceInGui(hObj);
        end
    end

    function updateModelViewMenu(hObj)
        S = guidata(hObj);
        labels = {'current'};
        nmodels = 0;
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
            nmodels = length(S.PLSDMmodelAll);
        elseif isfield(S,'CVmodelAll') && ~isempty(S.CVmodelAll)
            nmodels = length(S.CVmodelAll);
        end
        if nmodels > 0
            labels = cell(nmodels,1);
            for ii = 1:nmodels
                tgt = [];
                if ~isempty(S.PLSDMmodelAll) && isfield(S.PLSDMmodelAll{ii},'TargetClass')
                    tgt = S.PLSDMmodelAll{ii}.TargetClass;
                elseif ~isempty(S.CVmodelAll) && isfield(S.CVmodelAll{ii},'TargetClass')
                    tgt = S.CVmodelAll{ii}.TargetClass;
                end
                if isempty(tgt)
                    labels{ii} = ['Model ' num2str(ii)];
                else
                    labels{ii} = ['Class ' num2str(tgt)];
                end
            end
        elseif ~isempty(S.PLSDMmodel) && isfield(S.PLSDMmodel,'TargetClass')
            labels = {['Class ' num2str(S.PLSDMmodel.TargetClass)]};
        elseif ~isempty(S.CVmodel) && isfield(S.CVmodel,'TargetClass')
            labels = {['Class ' num2str(S.CVmodel.TargetClass)]};
        end
        if isfield(S,'popupModelView') && ishandle(S.popupModelView)
            set(S.popupModelView,'String',labels,'Value',max(1,min(S.ActiveModelIndex,length(labels))));
        end
        guidata(hObj,S);
    end

    function onModelViewChanged(hObj,ev)
        S = guidata(hObj);
        idx = get(S.popupModelView,'Value');
        S.ActiveModelIndex = idx;
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
            idx = max(1,min(idx,length(S.PLSDMmodelAll)));
            S.PLSDMmodel = S.PLSDMmodelAll{idx};
            if isfield(S.PLSDMmodel,'TargetClass'), S.TargetClass = S.PLSDMmodel.TargetClass; end
        end
        if isfield(S,'CVmodelAll') && ~isempty(S.CVmodelAll)
            idx = max(1,min(idx,length(S.CVmodelAll)));
            S.CVmodel = S.CVmodelAll{idx};
            if isempty(S.PLSDMmodel) && isfield(S.CVmodel,'TargetClass'), S.TargetClass = S.CVmodel.TargetClass; end
        end
        if isfield(S,'PLSDMvalidation') && ~isempty(S.PLSDMvalidation) && ...
                isfield(S.PLSDMvalidation,'AllClassesResults')
            allResults = S.PLSDMvalidation.AllClassesResults;
            allTargets = S.PLSDMvalidation.AllTargetClasses;
            resultIdx = max(1,min(idx,length(allResults)));
            selectedResult = allResults{resultIdx};
            selectedResult.AllClassesResults = allResults;
            selectedResult.AllTargetClasses = allTargets;
            selectedResult.ActiveModelIndex = resultIdx;
            S.PLSDMvalidation = selectedResult;
        end
        if isfield(S,'PLSDMpred') && ~isempty(S.PLSDMpred) && ...
                isfield(S.PLSDMpred,'AllClassesResults')
            allResults = S.PLSDMpred.AllClassesResults;
            allTargets = S.PLSDMpred.AllTargetClasses;
            resultIdx = max(1,min(idx,length(allResults)));
            selectedResult = allResults{resultIdx};
            selectedResult.AllClassesResults = allResults;
            selectedResult.AllTargetClasses = allTargets;
            selectedResult.ActiveModelIndex = resultIdx;
            S.PLSDMpred = selectedResult;
        end
        guidata(hObj,S);
        updatePlotsAndText(hObj);
        refreshSummary(hObj,{});
    end

    function onAcceptanceControlsChanged(hObj,ev)
        plotAcceptanceInGui(hObj);
    end

    function onExportModel(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            errordlg('No PLSDMmodel available.','Export');
            return;
        end
        assignin('base','PLSDMmodel',S.PLSDMmodel);
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
            assignin('base','PLSDMmodelAll',S.PLSDMmodelAll);
            msgbox('PLSDMmodel and PLSDMmodelAll exported to workspace.','Export');
        else
            msgbox('PLSDMmodel exported to workspace.','Export');
        end
    end

    function onExportCVFigure(hObj,ev)
        onOpenPerformanceFigure(hObj,ev);
    end

    function onOpenPerformanceFigure(hObj,ev)
        S = guidata(hObj);
        if isempty(S.CVmodel) && isempty(S.PLSDMmodel)
            errordlg('No CV performance result available.','Performance vs LV');
            return;
        end
        f = figure('Color','w','Name','PLS-DM performance vs LVs','NumberTitle','off');
        ax = axes('Parent',f);
        plotCVPerformance(ax,getCVModelForPlot(S));
    end

    function onCustomFigure(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel) && isempty(S.CVmodel)
            errordlg('Run CV, fit, or load a model before creating a custom figure.','Custom figure');
            return;
        end
        classNames=get(S.popupModelView,'String'); if ~iscell(classNames), classNames=cellstr(classNames); end
        plots={ ...
            'Training acceptance area'; 'CV fold-wise acceptance area'; 'CV mean acceptance area'; ...
            'Performance versus LVs'; 'CV limit variation'; 'CV performance by fold'; ...
            'VIP mean profiles'; 'VIP scores'; 'Q-residual distribution'; 'f-density distribution'; ...
            'Training data profiles by class'; 'Known validation samples'; ...
            'Training + known validation projection'; 'Known prediction acceptance'; 'Unknown samples'; ...
            'Training + unknown projection'; 'Unknown prediction acceptance'};
        plsdm_custom_figure_menu(hObj,'PLS-DM Fit and Validation',plots,classNames,@renderCustomFitPanel);
    end

    function renderCustomFitPanel(plotIndex,classIndex,ax)
        S0=guidata(fig); oldClass=get(S0.popupModelView,'Value'); oldMode=get(S0.popupAcceptanceMode,'Value');
        cleanup=onCleanup(@()restoreCustomFitState(oldClass,oldMode));
        set(S0.popupModelView,'Value',max(1,min(classIndex,length(get(S0.popupModelView,'String')))));
        onModelViewChanged(fig,[]); S=guidata(fig);
        switch plotIndex
            case {1,2,3}
                set(S.popupAcceptanceMode,'Value',plotIndex); plotAcceptanceInGui(fig); S=guidata(fig); copy_axes_content(S.axAcceptance,ax);
            case 4
                plotCVPerformance(ax,getCVModelForPlot(S));
            case 5
                captureCustomExternal(ax,@()plotExternalCVDiagnostics(S),'PLS-DM CV limit variation','');
            case 6
                captureCustomExternal(ax,@()plotExternalCVDiagnostics(S),'PLS-DM CV performance by fold','');
            case {7,8}
                onShowVIPScores(fig,[],ax);
            case 9
                captureCustomExternal(ax,@()onShowQfPlot(fig,[]),'Q and f distributions','Q-residuals');
            case 10
                captureCustomExternal(ax,@()onShowQfPlot(fig,[]),'Q and f distributions','f Density');
            case 11
                plotCustomFitTrainingData(ax,S);
            case 12
                captureCustomExternal(ax,@()plotKnownValidationFigures(fig),'PLS-DM validation samples','');
            case 13
                captureCustomExternal(ax,@()plotKnownValidationFigures(fig),'PLS-DM training + validation projection','');
            case 14
                captureCustomExternal(ax,@()onPlotKnownPredictionAcceptance(fig,[]),'PLS-DM known prediction acceptance','');
            case 15
                captureCustomExternal(ax,@()plotUnknownPredictionFigures(fig),'PLS-DM unknown samples','');
            case 16
                captureCustomExternal(ax,@()plotUnknownPredictionFigures(fig),'PLS-DM training + unknown projection','');
            case 17
                captureCustomExternal(ax,@()onPlotUnknownPredictionAcceptance(fig,[]),'PLS-DM unknown prediction acceptance','');
        end
    end

    function restoreCustomFitState(oldClass,oldMode)
        if ~ishandle(fig), return; end
        S=guidata(fig); set(S.popupModelView,'Value',oldClass); onModelViewChanged(fig,[]);
        S=guidata(fig); set(S.popupAcceptanceMode,'Value',oldMode); plotAcceptanceInGui(fig);
    end

    function captureCustomExternal(dst,action,figureName,axesTitle)
        before=findall(0,'Type','figure'); oldVis=get(0,'DefaultFigureVisible');
        set(0,'DefaultFigureVisible','off'); visCleanup=onCleanup(@()set(0,'DefaultFigureVisible',oldVis));
        action(); after=findall(0,'Type','figure'); made=setdiff(after,before);
        if isempty(made), error('Required result is unavailable.'); end
        chosen=[];
        for ii=1:length(made)
            nm=get(made(ii),'Name'); if isempty(figureName) || ~isempty(strfind(lower(nm),lower(figureName))), chosen=made(ii); break; end
        end
        if isempty(chosen), chosen=made(1); end
        axs=findall(chosen,'Type','axes'); axs=flipud(axs(:)); src=[];
        for ii=1:length(axs)
            if strcmpi(get(axs(ii),'Tag'),'legend'), continue; end
            tt=get(get(axs(ii),'Title'),'String');
            if isempty(axesTitle) || ~isempty(strfind(lower(localTitleText(tt)),lower(axesTitle))), src=axs(ii); break; end
        end
        if isempty(src), close(made); error('Plot axes were not found.'); end
        copy_axes_content(src,dst); close(made);
    end

    function s=localTitleText(v)
        if iscell(v), s=''; for kk=1:length(v), s=[s ' ' v{kk}]; end; else s=v; end
        if isempty(s), s=''; end
    end

    function plotCustomFitTrainingData(ax,S)
        X=S.Xtrain; C=S.ClassTrain(:); classes=unique(C); cols=local_class_colors(length(classes)); hold(ax,'on');
        for ii=1:length(classes)
            idx=find(C==classes(ii)); pale=.72*[1 1 1]+.28*cols(ii,:);
            for jj=1:length(idx), plot(ax,1:size(X,2),X(idx(jj),:),'-','Color',pale,'LineWidth',.5); end
            plot(ax,1:size(X,2),mean(X(idx,:),1),'-','Color',cols(ii,:),'LineWidth',2.2);
        end
        box(ax,'on'); grid(ax,'on'); xlabel(ax,'Variable index'); ylabel(ax,'Signal');
    end

    function onOpenClassificationReport(hObj,ev)
        S = guidata(hObj);
        hasModel = ~isempty(S.PLSDMmodel) || ~isempty(S.CVmodel) || ...
            (isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)) || ...
            (isfield(S,'CVmodelAll') && ~isempty(S.CVmodelAll));
        if ~hasModel
            errordlg('Run or load a fitted/CV model before opening the classification report.','Classification report');
            return;
        end
        f = figure('Name','PLS-DM - Classification report','NumberTitle','off', ...
            'MenuBar','none','Toolbar','none','Color',[0.94 0.95 0.98], ...
            'Units','normalized','Position',[0.06 0.08 0.88 0.82]);
        uicontrol('Parent',f,'Style','text','String','Dataset', ...
            'Units','normalized','Position',[0.025 0.935 0.08 0.035], ...
            'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left','FontWeight','bold');
        popup = uicontrol('Parent',f,'Style','popupmenu', ...
            'String',{'Training','Cross-validation','Known prediction','Unknown prediction'}, ...
            'Value',1,'Units','normalized','Position',[0.105 0.935 0.25 0.045], ...
            'BackgroundColor','w');
        note = uicontrol('Parent',f,'Style','text','String','', ...
            'Units','normalized','Position',[0.38 0.925 0.59 0.055], ...
            'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left');
        sampleTable = uitable('Parent',f,'Units','normalized','Position',[0.025 0.31 0.95 0.60], ...
            'Data',cell(0,1),'ColumnName',{'Sample'},'RowName',[]);
        uicontrol('Parent',f,'Style','text','String','Summary', ...
            'Units','normalized','Position',[0.025 0.255 0.20 0.035], ...
            'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left','FontWeight','bold');
        summaryTable = uitable('Parent',f,'Units','normalized','Position',[0.025 0.04 0.48 0.21], ...
            'Data',cell(0,2),'ColumnName',{'Status','Count'},'RowName',[]);
        uicontrol('Parent',f,'Style','text', ...
            'String',{'Green = Accepted';'Red = Rejected';'Each class column shows the independent decision of its PLS-DM model.'}, ...
            'Units','normalized','Position',[0.55 0.08 0.42 0.14], ...
            'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left');
        R.mainFigure = ancestor(hObj,'figure');
        R.popup = popup; R.sampleTable = sampleTable; R.summaryTable = summaryTable; R.note = note;
        guidata(f,R);
        set(popup,'Callback',@refreshClassificationReport);
        refreshClassificationReport(popup,[]);
    end

    function refreshClassificationReport(hObj,ev)
        reportFig = get(hObj,'Parent');
        R = guidata(reportFig);
        if isempty(R.mainFigure) || ~ishandle(R.mainFigure), return; end
        S = guidata(R.mainFigure);
        datasetValue = get(R.popup,'Value');
        [data,columnNames,statusValues,message] = buildClassificationReportData(S,datasetValue);
        set(R.sampleTable,'Data',data,'ColumnName',columnNames);
        set(R.note,'String',message);
        if isempty(statusValues)
            summaryData = cell(0,2);
        else
            labels = unique(statusValues);
            summaryData = cell(numel(labels),2);
            for ii = 1:numel(labels)
                summaryData(ii,:) = {labels{ii},sum(strcmp(statusValues,labels{ii}))};
            end
        end
        set(R.summaryTable,'Data',summaryData);
    end

    function [data,columnNames,statusValues,message] = buildClassificationReportData(S,datasetValue)
        data = cell(0,1); columnNames = {'Sample'}; statusValues = {}; message = '';
        actual = []; names = {}; models = {}; accepted = []; classes = [];
        if datasetValue == 1
            actual = S.ClassTrain(:); names = local_report_sample_names(S,'sampleNames',numel(actual),'Sample');
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll), models = S.PLSDMmodelAll; elseif ~isempty(S.PLSDMmodel), models = {S.PLSDMmodel}; end
            [accepted,classes] = local_training_cv_acceptance(S,models,'train');
            message = 'Final-model decisions for training samples.';
        elseif datasetValue == 2
            actual = S.ClassTrain(:); names = local_report_sample_names(S,'sampleNames',numel(actual),'Sample');
            if isfield(S,'CVmodelAll') && ~isempty(S.CVmodelAll), models = S.CVmodelAll; elseif ~isempty(S.CVmodel), models = {S.CVmodel}; end
            [accepted,classes] = local_training_cv_acceptance(S,models,'cv');
            message = 'Cross-validation decisions assembled by original sample.';
        elseif datasetValue == 3
            if isempty(S.Xval) || isempty(S.ClassVal)
                message = 'Import and run known-class prediction to populate this table.'; return;
            end
            actual = S.ClassVal(:); names = local_report_sample_names(S,'validationSampleNames',numel(actual),'Known');
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll), models = S.PLSDMmodelAll; elseif ~isempty(S.PLSDMmodel), models = {S.PLSDMmodel}; end
            [accepted,classes] = computeAllClassAcceptedMatrix(S.Xval,models);
            message = 'Independent class-model decisions for known prediction samples.';
        else
            if isempty(S.Xunk)
                message = 'Import and run unknown prediction to populate this table.'; return;
            end
            names = local_report_sample_names(S,'unknownSampleNames',size(S.Xunk,1),'Unknown');
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll), models = S.PLSDMmodelAll; elseif ~isempty(S.PLSDMmodel), models = {S.PLSDMmodel}; end
            [accepted,classes] = computeAllClassAcceptedMatrix(S.Xunk,models);
            message = 'Independent class-model decisions for unknown samples; no actual class is available.';
        end
        if isempty(models) || isempty(accepted)
            message = 'The selected dataset does not have sample-level decisions available.'; return;
        end
        n = size(accepted,1); includeActual = datasetValue ~= 4;
        columnNames = {'Sample'};
        if includeActual, columnNames{end+1} = 'Actual class'; end
        for jj = 1:numel(classes)
            columnNames{end+1} = ['Class ' plsdm_data_info_class_name(S.dataInfo,classes(jj))];
        end
        columnNames{end+1} = 'Status';
        data = cell(n,numel(columnNames)); statusValues = cell(n,1);
        for ii = 1:n
            col = 1; data{ii,col} = names{ii}; col = col+1;
            if includeActual
                data{ii,col} = plsdm_data_info_class_name(S.dataInfo,actual(ii)); col = col+1;
            end
            for jj = 1:numel(classes)
                if accepted(ii,jj)
                    data{ii,col} = '<html><font color="#008000">Accepted</font></html>';
                else
                    data{ii,col} = '<html><font color="#C00000">Rejected</font></html>';
                end
                col = col+1;
            end
            statusValues{ii} = local_classification_status(accepted(ii,:),classes,actual,ii,includeActual,S);
            data{ii,col} = statusValues{ii};
        end
    end

    function [accepted,classes] = local_training_cv_acceptance(S,models,modeName)
        accepted = []; classes = [];
        if isempty(models), return; end
        n = numel(S.ClassTrain); accepted = false(n,numel(models)); classes = zeros(1,numel(models));
        for jj = 1:numel(models)
            M = models{jj};
            if isfield(M,'TargetClass') && ~isempty(M.TargetClass), classes(jj)=M.TargetClass; else, classes(jj)=jj; end
            a = getModelAcceptedByOriginalSample(M,S,modeName,jj);
            if numel(a) == n, accepted(:,jj) = a(:) == 1; end
        end
    end

    function names = local_report_sample_names(S,fieldName,n,prefix)
        names = {};
        if isfield(S,'dataInfo') && isfield(S.dataInfo,fieldName) && numel(S.dataInfo.(fieldName)) >= n
            names = S.dataInfo.(fieldName)(1:n);
        elseif isfield(S,fieldName) && numel(S.(fieldName)) >= n
            names = S.(fieldName)(1:n);
        end
        if isempty(names), names = arrayfun(@(i)sprintf('%s %d',prefix,i),(1:n)','UniformOutput',false); end
        names = names(:);
    end

    function status = local_classification_status(row,classes,actual,idx,hasActual,S)
        ids = find(row);
        if ~hasActual
            if isempty(ids), status='Rejected by all classes';
            elseif numel(ids)==1, status=['Assigned to Class ' plsdm_data_info_class_name(S.dataInfo,classes(ids))];
            else, status=['Ambiguous - accepted by Classes ' local_report_class_list(S,classes(ids))]; end
            return;
        end
        trueClass = actual(idx); correct = find(classes == trueClass,1);
        if numel(classes) == 1
            isTarget = ~isempty(correct);
            if isTarget && row(1), status='Correctly accepted';
            elseif isTarget && ~row(1), status='Incorrectly rejected';
            elseif ~isTarget && row(1), status='Incorrectly accepted';
            else, status='Correctly rejected'; end
            return;
        end
        if isempty(ids), status='Rejected by all classes';
        elseif numel(ids)==1 && ~isempty(correct) && ids==correct, status='Correct';
        elseif numel(ids)==1, status=['Misclassified as Class ' plsdm_data_info_class_name(S.dataInfo,classes(ids))];
        elseif ~isempty(correct) && any(ids==correct), status=['Ambiguous - incorrect Class(es) also accepted: ' local_report_class_list(S,classes(ids(ids~=correct)))];
        else, status=['Misclassified/Ambiguous - accepted by Classes ' local_report_class_list(S,classes(ids))]; end
    end

    function textValue = local_report_class_list(S,values)
        textValue = '';
        for ii = 1:numel(values)
            if ii > 1, textValue = [textValue ', ']; end
            textValue = [textValue plsdm_data_info_class_name(S.dataInfo,values(ii))];
        end
    end


    function onOpenConfusionMatrices(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel) && isempty(S.CVmodel)
            errordlg('No fitted/CV model available.','Confusion matrices');
            return;
        end
        plotExternalConfusionMatrices(S);
    end

    function onOpenCVDiagnostics(hObj,ev)
        S = guidata(hObj);
        if isempty(S.CVmodel)
            errordlg('Run CV before opening CV diagnostics.','CV diagnostics');
            return;
        end
        plotExternalCVDiagnostics(S);
    end

    % ================================================================
    function onShowVIPScores(hObj,ev,parentAxes)
        if nargin < 3, parentAxes = []; end
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            errordlg('Run Fit final model before displaying VIP scores.','VIP scores');
            return;
        end
        if exist('plot_vip_plsdm','file') ~= 2
            errordlg('Function plot_vip_plsdm.m was not found on the MATLAB path.','VIP scores');
            return;
        end
        try
            PLSDMmodel = S.PLSDMmodel;
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
                idx = 1;
                if isfield(S,'ActiveModelIndex') && ~isempty(S.ActiveModelIndex)
                    idx = S.ActiveModelIndex;
                end
                idx = max(1,min(idx,length(S.PLSDMmodelAll)));
                PLSDMmodel = S.PLSDMmodelAll{idx};
            end
            if (~isfield(PLSDMmodel,'var_label') || isempty(PLSDMmodel.var_label)) && ~isempty(S.var_label)
                PLSDMmodel.var_label = S.var_label;
            end
            vipTitle = 'Active class mean, other classes mean and VIP scores';
            if isfield(PLSDMmodel,'TargetClass') && ~isempty(PLSDMmodel.TargetClass)
                vipTitle = [plsdm_data_info_class_name(S.dataInfo,PLSDMmodel.TargetClass) ': mean spectra and VIP scores'];
            end
            vipFigure = plot_vip_plsdm(PLSDMmodel,'title',vipTitle,'ParentAxes',parentAxes);
            if ~isempty(S.dataInfo.xLabel)
                if isempty(parentAxes)
                    vipAxes = findall(vipFigure,'Type','axes');
                else
                    vipAxes = parentAxes;
                end
                for iax = 1:length(vipAxes)
                    set(get(vipAxes(iax),'XLabel'),'String','');
                end
                for iax = 1:length(vipAxes)
                    if ~strcmpi(get(vipAxes(iax),'Tag'),'legend') && ...
                            strcmpi(get(vipAxes(iax),'YAxisLocation'),'left')
                        xlabel(vipAxes(iax),S.dataInfo.xLabel,'FontWeight','bold');
                        break;
                    end
                end
            end
        catch ME
            errordlg(['Unable to display VIP scores: ' ME.message],'VIP scores');
        end
    end

    function onShowQfPlot(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            errordlg('Run Fit final model before displaying the Q/f plot.','Q/f plot');
            return;
        end
        if exist('Qf_plot','file') ~= 2
            errordlg('Function Qf_plot.m was not found on the MATLAB path.','Q/f plot');
            return;
        end
        try
            Qf_plot(S.PLSDMmodel);
        catch ME
            errordlg(['Unable to display Q/f plot: ' ME.message],'Q/f plot');
        end
    end

    function onSeeData(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain) || isempty(S.ClassTrain)
            errordlg('Import Xtrain and ClassTrain before plotting data.','See data');
            return;
        end
        try
            X = S.Xtrain;
            C = S.ClassTrain(:);
            classes = unique(C);
            p = size(X,2);
            xaxis = 1:p;
            if ~isempty(S.var_label) && numel(S.var_label) == p && isnumeric(S.var_label)
                xaxis = S.var_label(:).';
            end
            cols = local_class_colors(length(classes));
            f = figure('Color','w','Name','Training data by class','NumberTitle','off');
            ax = axes('Parent',f); hold(ax,'on'); box(ax,'on'); grid(ax,'on');
            set(ax,'FontName','Arial','FontSize',11,'LineWidth',1.2);
            hMean = zeros(length(classes),1);
            leg = cell(length(classes),1);
            for ii = 1:length(classes)
                idx = find(C == classes(ii));
                col = cols(ii,:);
                pale = 0.72*[1 1 1] + 0.28*col;
                for jj = 1:length(idx)
                    plot(ax,xaxis,X(idx(jj),:),'-','Color',pale,'LineWidth',0.6);
                end
                mu = mean(X(idx,:),1);
                hMean(ii) = plot(ax,xaxis,mu,'-','Color',col,'LineWidth',2.6);
                leg{ii} = [plsdm_data_info_class_name(S.dataInfo,classes(ii)) ' mean'];
            end
            xLabelText = 'Variable index'; yLabelText = 'Signal';
            if ~isempty(S.dataInfo.xLabel), xLabelText = S.dataInfo.xLabel; end
            if ~isempty(S.dataInfo.yLabel), yLabelText = S.dataInfo.yLabel; end
            xlabel(ax,xLabelText,'FontWeight','bold');
            ylabel(ax,yLabelText,'FontWeight','bold');
            title(ax,'Training data profiles by class','FontWeight','bold');
            legend(ax,hMean,leg,'Location','EastOutside');
            axis(ax,'tight');
            hold(ax,'off');
        catch ME
            errordlg(['Unable to plot training data: ' ME.message],'See data');
        end
    end

    function cols = local_class_colors(n)
        base = [0.10 0.45 0.80;
                0.85 0.15 0.20;
                0.10 0.60 0.20;
                0.95 0.70 0.10;
                0.55 0.25 0.75;
                0.10 0.65 0.65;
                0.80 0.35 0.10;
                0.35 0.35 0.35];
        cols = zeros(n,3);
        for ii = 1:n
            cols(ii,:) = base(mod(ii-1,size(base,1))+1,:);
        end
    end

    function names = getDataInfoSetNames(S,fieldName,nExpected)
        names = {};
        if isfield(S,'dataInfo') && isfield(S.dataInfo,fieldName)
            candidate = S.dataInfo.(fieldName);
            if iscell(candidate) && numel(candidate) == nExpected
                names = candidate(:);
            end
        end
    end

    % ================================================================

    function onImportValidationData(hObj,ev)
        S = guidata(hObj);
        [ok, names, vals] = plsdm_select_workspace_vars('Import known-class validation data', ...
            {'Xval','ClassVal'}, {'Xval','ClassVal'}, {false,false});
        if ~ok, return; end
        try
            Xval = vals{1};
            ClassVal = vals{2};
            if size(ClassVal,1)==1
                ClassVal = ClassVal';
            end
            if size(Xval,1) ~= length(ClassVal)
                error('Xval rows and ClassVal length are inconsistent.');
            end
            S.Xval = Xval;
            S.ClassVal = ClassVal(:);
            S.XvalAll = Xval; S.ClassValAll = ClassVal(:);
            S.includeVal = true(size(Xval,1),1); S.valOriginalRows = (1:size(Xval,1))';
            S.valNamesAll = arrayfun(@(i)sprintf('Sample %d',i),(1:size(Xval,1))','UniformOutput',false);
            S.dataInfo.validationSampleNames = {};
            set(S.btnExclude,'Enable','on');
            guidata(hObj,S);
            updatePredictionText(hObj,{'Known-class validation data imported.'});
        catch ME
            errordlg(['Import error: ' ME.message],'Import validation data');
        end
    end

    function onImportUnknownData(hObj,ev)
        S = guidata(hObj);
        [ok, names, vals] = plsdm_select_workspace_vars('Import unknown samples', ...
            {'Xunknown'}, {'Xunk'}, {false});
        if ~ok, return; end
        try
            Xunk = vals{1};
            S.Xunk = Xunk;
            S.XunkAll = Xunk; S.includeUnk = true(size(Xunk,1),1);
            S.unkOriginalRows = (1:size(Xunk,1))';
            S.unkNamesAll = arrayfun(@(i)sprintf('Unknown %d',i),(1:size(Xunk,1))','UniformOutput',false);
            S.dataInfo.unknownSampleNames = {};
            set(S.btnExclude,'Enable','on');
            guidata(hObj,S);
            updatePredictionText(hObj,{'Unknown samples imported.'});
        catch ME
            errordlg(['Import error: ' ME.message],'Import unknown samples');
        end
    end

    function onRunKnownValidation(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            errordlg('Fit or load a final PLSDMmodel before validation.','Known-class validation');
            return;
        end
        if isempty(S.Xval) || isempty(S.ClassVal)
            errordlg('Import Xval and ClassVal first.','Known-class validation');
            return;
        end
        try
            models = {S.PLSDMmodel};
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
                models = S.PLSDMmodelAll;
            end
            allResults = cell(numel(models),1);
            allTargets = zeros(numel(models),1);
            for jj = 1:numel(models)
                Mj = models{jj};
                targetClass = jj;
                if isfield(Mj,'TargetClass') && ~isempty(Mj.TargetClass)
                    targetClass = Mj.TargetClass;
                end
                [ClassValOne,targetInfoVal] = plsdm_prepare_oneclass_labels(S.ClassVal,targetClass);
                resultJ = [];
                evalc('resultJ = plsdm_val(S.Xval, ClassValOne, Mj);');
                resultJ = enrich_known_validation_result(resultJ, S.Xval, ClassValOne, Mj);
                resultJ.OriginalClassVal = S.ClassVal(:);
                resultJ.TargetClass = targetClass;
                resultJ.TargetInfoValidation = targetInfoVal;
                allResults{jj} = resultJ;
                allTargets(jj) = targetClass;
            end
            activeIdx = max(1,min(S.ActiveModelIndex,numel(allResults)));
            PLSDMvalidation = allResults{activeIdx};
            PLSDMvalidation.AllClassesResults = allResults;
            PLSDMvalidation.AllTargetClasses = allTargets;
            PLSDMvalidation.ActiveModelIndex = activeIdx;
        catch ME
            errordlg(['Known-class validation failed: ' ME.message],'Known-class validation');
            return;
        end
        S.PLSDMvalidation = PLSDMvalidation;
        guidata(hObj,S);
        updatePredictionText(hObj,{'Known-class validation completed.'});
    end

    function onRunUnknownPrediction(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel)
            errordlg('Fit or load a final PLSDMmodel before prediction.','Unknown prediction');
            return;
        end
        if isempty(S.Xunk)
            errordlg('Import Xunknown first.','Unknown prediction');
            return;
        end
        try
            models = {S.PLSDMmodel};
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
                models = S.PLSDMmodelAll;
            end
            allResults = cell(numel(models),1);
            allTargets = zeros(numel(models),1);
            for jj = 1:numel(models)
                Mj = models{jj};
                targetClass = jj;
                if isfield(Mj,'TargetClass') && ~isempty(Mj.TargetClass)
                    targetClass = Mj.TargetClass;
                end
                resultJ = [];
                evalc('resultJ = plsdm_predict_unknown(S.Xunk, Mj);');
                resultJ.TargetClass = targetClass;
                allResults{jj} = resultJ;
                allTargets(jj) = targetClass;
            end
            activeIdx = max(1,min(S.ActiveModelIndex,numel(allResults)));
            PLSDMpred = allResults{activeIdx};
            PLSDMpred.AllClassesResults = allResults;
            PLSDMpred.AllTargetClasses = allTargets;
            PLSDMpred.ActiveModelIndex = activeIdx;
        catch ME
            errordlg(['Unknown prediction failed: ' ME.message],'Unknown prediction');
            return;
        end
        S.PLSDMpred = PLSDMpred;
        guidata(hObj,S);
        updatePredictionText(hObj,{'Unknown prediction completed.'});
    end

    function plotKnownValidationFigures(hObj)
        S = guidata(hObj);
        if isempty(S.PLSDMvalidation) || isempty(S.PLSDMmodel), return; end
        showLabels = isfield(S,'chkPlotLabels') && ishandle(S.chkPlotLabels) && get(S.chkPlotLabels,'Value') == 1;
        V = S.PLSDMvalidation;
        validationNames = getDataInfoSetNames(S,'validationSampleNames',size(S.Xval,1));
        if ~isfield(V,'PVresult'), return; end
        targetTxt = '';
        if isfield(V,'TargetClass'), targetTxt = [' | class ' num2str(V.TargetClass)]; end
        f1 = figure('Color','w','Name','PLS-DM validation samples','NumberTitle','off');
        ax1 = axes('Parent',f1);
        plsdm_plot_acceptance_area(ax1,V.PVresult.Q,V.PVresult.f,S.PLSDMmodel.FinalModel.Qlimit,S.PLSDMmodel.FinalModel.flimit,V.ClassVal, ...
            ['Validation samples only' targetTxt],showLabels,validationNames);
        f2 = figure('Color','w','Name','PLS-DM training + validation projection','NumberTitle','off');
        ax2 = axes('Parent',f2);
        plsdm_plot_acceptance_projection(ax2,S.PLSDMmodel,V.PVresult.Q,V.PVresult.f,V.ClassVal, ...
            ['Training + validation projection' targetTxt],showLabels,validationNames);
    end

    function onPlotKnownPredictionConfusion(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMvalidation) || ~isfield(S.PLSDMvalidation,'CVresults')
            errordlg('Run known-class validation first.','Known-class confusion');
            return;
        end
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll) && ~isempty(S.ClassVal)
            plotKnownAllClassConfusion(S);
            return;
        end
        C = S.PLSDMvalidation.CVresults;
        if isfield(C,'TP') && isfield(C,'FP') && isfield(C,'TN') && isfield(C,'FN')
            f = figure('Color','w','Name','Known-class prediction confusion','NumberTitle','off');
            ax = axes('Parent',f);
            plotConfusionColorMap(ax,C.TP,C.FP,C.TN,C.FN,'Known-class prediction');
        else
            errordlg('Known-class confusion values are unavailable.','Known-class confusion');
        end
    end

    function plotKnownAllClassConfusion(S)
        models = S.PLSDMmodelAll;
        nM = length(models);
        classes = zeros(nM,1);
        for jj = 1:nM
            if isfield(models{jj},'TargetClass'), classes(jj) = models{jj}.TargetClass; else classes(jj)=jj; end
        end
        n = length(S.ClassVal);
        acc = false(n,nM);
        for jj = 1:nM
            Mj = models{jj};
            [ClassValOne,tmp] = plsdm_prepare_oneclass_labels(S.ClassVal,classes(jj));
            Vj = enrich_known_validation_result(struct(),S.Xval,ClassValOne,Mj);
            if isfield(Vj,'CVresults') && isfield(Vj.CVresults,'Gpred_bin')
                acc(:,jj) = Vj.CVresults.Gpred_bin(:) == 1;
            end
        end
        trueClasses = unique(S.ClassVal(:));
        mat = zeros(length(trueClasses),nM+2);
        rowLabels = cell(1,length(trueClasses));
        colLabels = cell(1,nM+2);
        for ii=1:length(trueClasses), rowLabels{ii}=num2str(trueClasses(ii)); end
        for jj=1:nM, colLabels{jj}=num2str(classes(jj)); end
        colLabels{nM+1}='Not assigned'; colLabels{nM+2}='Ambiguous';
        for ii=1:n
            r = find(trueClasses == S.ClassVal(ii));
            nacc = sum(acc(ii,:));
            if nacc == 0
                c = nM+1;
            elseif nacc > 1
                c = nM+2;
            else
                c = find(acc(ii,:));
            end
            mat(r,c)=mat(r,c)+1;
        end
        f = figure('Color','w','Name','Known-class prediction all-class confusion','NumberTitle','off');
        ax = axes('Parent',f);
        plotMatrixHeatmapNoColorbar(ax,mat,rowLabels,colLabels,'Known-class prediction confusion');
    end

    function onPlotKnownPredictionAcceptance(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMvalidation) || isempty(S.PLSDMmodel) || ~isfield(S.PLSDMvalidation,'PVresult')
            errordlg('Run known-class validation first.','Known-class acceptance');
            return;
        end
        showLabels = get(S.chkPlotLabels,'Value') == 1;
        V = S.PLSDMvalidation;
        validationNames = getDataInfoSetNames(S,'validationSampleNames',size(S.Xval,1));
        targetTxt = '';
        if isfield(S.PLSDMmodel,'TargetClass'), targetTxt = [' | class ' num2str(S.PLSDMmodel.TargetClass)]; end
        f = figure('Color','w','Name','PLS-DM known prediction acceptance','NumberTitle','off');
        ax = axes('Parent',f);
        plsdm_plot_prediction_acceptance_like_training(ax,S.PLSDMmodel,V.PVresult.Q,V.PVresult.f,V.ClassVal, ...
            ['Known prediction samples' targetTxt],showLabels,validationNames,'known_only');
        installExternalPredictionClick(f,ax,S.PLSDMmodel,S.Xval,'Known prediction',S.ClassVal,validationNames,S.dataInfo,S.var_label);
    end

    function onPlotUnknownPredictionAcceptance(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMpred) || isempty(S.PLSDMmodel)
            errordlg('Run unknown prediction first.','Unknown acceptance');
            return;
        end
        P = S.PLSDMpred;
        unknownNames = getDataInfoSetNames(S,'unknownSampleNames',size(S.Xunk,1));
        showLabels = get(S.chkPlotLabels,'Value') == 1;
        f = figure('Color','w','Name','PLS-DM unknown prediction acceptance','NumberTitle','off');
        ax = axes('Parent',f);
        plsdm_plot_prediction_acceptance_like_training(ax,S.PLSDMmodel,P.Q,P.f,[], ...
            'Unknown prediction acceptance',showLabels,unknownNames,'unknown');
        installExternalPredictionClick(f,ax,S.PLSDMmodel,S.Xunk,'Unknown prediction',[],unknownNames,S.dataInfo,S.var_label);
    end

    function installExternalPredictionClick(figH,ax,PLSDMmodel,Xnew,labelText,Gnew,sampleNames,dataInfo,varLabel)
        if nargin < 6, Gnew = []; end
        if nargin < 7, sampleNames = {}; end
        if nargin < 8, dataInfo = struct(); end
        if nargin < 9, varLabel = []; end
        try
            D.PLSDMmodel = PLSDMmodel;
            D.Xnew = Xnew;
            D.Gnew = Gnew;
            D.ax = ax;
            D.labelText = labelText;
            D.sampleNames = sampleNames;
            D.dataInfo = dataInfo;
            D.varLabel = varLabel;
            P = getappdata(ax,'plsdm_prediction_click_points');
            if ~isempty(P)
                D.xplot = P.xplot;
                D.yplot = P.yplot;
                if isfield(P,'Q'), D.Q = P.Q; else D.Q = []; end
                if isfield(P,'f'), D.f = P.f; else D.f = []; end
                if isfield(P,'accepted'), D.accepted = P.accepted; else D.accepted = []; end
            else
                D.xplot = [];
                D.yplot = [];
                D.Q = [];
                D.f = [];
                D.accepted = [];
            end
            setappdata(figH,'plsdm_gui_prediction_clickdata',D);
            set(figH,'WindowButtonDownFcn',@onExternalPredictionClick);
        catch
        end
    end

    function onExternalPredictionClick(figH,ev)
        try
            D = getappdata(figH,'plsdm_gui_prediction_clickdata');
            if isempty(D) || isempty(D.Xnew), return; end
            ax = get(figH,'CurrentAxes');
            if isempty(ax) || ~ishandle(ax), return; end
            cp = get(ax,'CurrentPoint');
            bestD = Inf; bestIdx = [];
            if isfield(D,'xplot') && ~isempty(D.xplot) && length(D.xplot) == size(D.Xnew,1)
                dist = (D.xplot(:)-cp(1,1)).^2 + (D.yplot(:)-cp(1,2)).^2;
                [bestD,bestIdx] = min(dist);
            else
                kids = findobj(ax,'Type','line');
                for kk = 1:length(kids)
                    x = get(kids(kk),'XData'); y = get(kids(kk),'YData');
                    if length(x) == size(D.Xnew,1)
                        dist = (x(:)-cp(1,1)).^2 + (y(:)-cp(1,2)).^2;
                        [dmin,idx] = min(dist);
                        if dmin < bestD, bestD = dmin; bestIdx = idx; end
                    end
                end
            end
            if isempty(bestIdx) || ~isfinite(bestD), return; end
            Xtrain = D.PLSDMmodel.Xtrain;
            targetRows = find(D.PLSDMmodel.ClassTrain == 1);
            if isempty(targetRows), return; end
            mu = mean(Xtrain(targetRows,:),1); sd = std(Xtrain(targetRows,:),0,1);
            lambda = 1:size(Xtrain,2);
            if isnumeric(D.varLabel) && numel(D.varLabel) == size(Xtrain,2), lambda = D.varLabel(:)'; end
            sampleName = num2str(bestIdx);
            if iscell(D.sampleNames) && bestIdx <= numel(D.sampleNames), sampleName = D.sampleNames{bestIdx}; end
            xLabelText = 'Variable index'; yLabelText = 'Signal';
            if isfield(D.dataInfo,'xLabel') && ~isempty(D.dataInfo.xLabel), xLabelText = D.dataInfo.xLabel; end
            if isfield(D.dataInfo,'yLabel') && ~isempty(D.dataInfo.yLabel), yLabelText = D.dataInfo.yLabel; end
            f = figure('Color','w','Name',[D.labelText ' - ' sampleName],'NumberTitle','off', ...
                'Position',[90 120 1220 500]);
            ax1 = subplot(1,2,1,'Parent',f); hold(ax1,'on'); box(ax1,'on'); grid(ax1,'on');
            set(ax1,'LineWidth',1.2,'FontName','Arial','FontSize',11,'XMinorTick','on','YMinorTick','on');
            [hM,hB] = plotMeanSdBand(ax1,lambda,mu,sd);
            hS = plot(ax1,lambda,D.Xnew(bestIdx,:),'-','Color',[0.10 0.25 0.90],'LineWidth',2.2);
            ttl = [D.labelText ' - ' sampleName];
            if isfield(D,'Q') && ~isempty(D.Q) && length(D.Q) >= bestIdx
                ttl = [ttl ' | Q=' num2str(D.Q(bestIdx),4)];
            end
            if isfield(D,'f') && ~isempty(D.f) && length(D.f) >= bestIdx
                ttl = [ttl ' | PF=' num2str(D.f(bestIdx),4)];
            end
            if isfield(D,'accepted') && ~isempty(D.accepted) && length(D.accepted) >= bestIdx
                if D.accepted(bestIdx), dec = 'Accepted'; else dec = 'Rejected'; end
                ttl = [ttl ' | ' dec];
            end
            printPredictionCommandReport(D,bestIdx);
            title(ax1,ttl,'Interpreter','none');
            xlabel(ax1,xLabelText,'FontWeight','bold'); ylabel(ax1,yLabelText,'FontWeight','bold');
            legend(ax1,[hM hB hS],{'Target mean','Target mean +/- SD',sampleName},'Location','Best');
            xlim(ax1,[min(lambda) max(lambda)]); axis(ax1,'tight');

            ax2 = subplot(1,2,2,'Parent',f); hold(ax2,'on'); box(ax2,'on'); grid(ax2,'on');
            set(ax2,'LineWidth',1.2,'FontName','Arial','FontSize',11,'XMinorTick','on','YMinorTick','on');
            [okR,muR,sdR,Rrow] = computeGuiResidualReport(D.PLSDMmodel,Xtrain,D.Xnew(bestIdx,:));
            if okR
                [hRm,hRb] = plotMeanSdBand(ax2,lambda,muR,sdR);
                hRx = plot(ax2,lambda,Rrow,'-','Color',[0.10 0.25 0.90],'LineWidth',2.2);
                legend(ax2,[hRm hRb hRx],{'Calibration residual mean','Mean +/- SD',[sampleName ' residual']},'Location','Best');
                title(ax2,'Residual profile','Interpreter','none');
            else
                text(0.5,0.5,'Residual report unavailable','Parent',ax2, ...
                    'Units','normalized','HorizontalAlignment','center');
                title(ax2,'Residuals unavailable','Interpreter','none');
            end
            xlabel(ax2,xLabelText,'FontWeight','bold'); ylabel(ax2,[yLabelText ' residual'],'FontWeight','bold');
            xlim(ax2,[min(lambda) max(lambda)]); axis(ax2,'tight');
            hold(ax1,'off'); hold(ax2,'off');
        catch
        end
    end

    function printPredictionCommandReport(D,idx)
        clc;
        fprintf('PLS-DM prediction sample report\n');
        fprintf('-------------------------------\n');
        fprintf('Prediction set: %s\n',D.labelText);
        fprintf('Sample index: %d\n',idx);
        if isfield(D,'sampleNames') && iscell(D.sampleNames) && idx <= numel(D.sampleNames)
            fprintf('Sample name: %s\n',D.sampleNames{idx});
        end
        targetClass = 1;
        if isfield(D.PLSDMmodel,'TargetClass') && ~isempty(D.PLSDMmodel.TargetClass)
            targetClass = D.PLSDMmodel.TargetClass;
        end
        targetClassText = num2str(targetClass);
        if isfield(D,'dataInfo'), targetClassText = plsdm_data_info_class_name(D.dataInfo,targetClass); end
        fprintf('Active target class: %s\n',targetClassText);
        knownClass = [];
        if isfield(D,'Gnew') && ~isempty(D.Gnew) && idx <= numel(D.Gnew)
            knownClass = D.Gnew(idx);
            knownClassText = num2str(knownClass);
            if isfield(D,'dataInfo'), knownClassText = plsdm_data_info_class_name(D.dataInfo,knownClass); end
            fprintf('Correct/known class: %s\n',knownClassText);
        else
            fprintf('Correct/known class: unknown\n');
        end
        accepted = [];
        if isfield(D,'accepted') && ~isempty(D.accepted) && idx <= length(D.accepted)
            accepted = D.accepted(idx) ~= 0;
            if accepted, fprintf('Decision: accepted\n'); else fprintf('Decision: rejected\n'); end
        end
        if ~isempty(knownClass) && ~isempty(accepted)
            isTarget = (knownClass == targetClass);
            if isTarget && accepted
                st = 'TP';
            elseif isTarget && ~accepted
                st = 'FN';
            elseif ~isTarget && accepted
                st = 'FP';
            else
                st = 'TN';
            end
            fprintf('Classification status: %s\n',st);
        end
        if isfield(D,'Q') && idx <= length(D.Q), fprintf('Q residual: %.6g\n',D.Q(idx)); end
        if isfield(D,'f') && idx <= length(D.f), fprintf('PF density: %.6g\n',D.f(idx)); end
    end

    function plsdm_plot_prediction_acceptance_like_training(ax,PLSDMmodel,Qnew,fnew,Gnew,titleStr,showLabels,labels,plotMode)
        if nargin < 6 || isempty(titleStr), titleStr = 'Prediction acceptance'; end
        if nargin < 7 || isempty(showLabels), showLabels = false; end
        if nargin < 8, labels = {}; end
        if nargin < 9 || isempty(plotMode), plotMode = 'known'; end

        Qnew = Qnew(:);
        fnew = fnew(:);
        nNew = length(Qnew);
        if nNew < 1
            cla(ax); title(ax,''); return;
        end

        Qtrain = [];
        ftrain = [];
        Gtrain = [];
        if strcmpi(plotMode,'known_with_train') && isfield(PLSDMmodel,'acp_train_q') && isfield(PLSDMmodel,'acp_train_pf')
            Qtrain = PLSDMmodel.acp_train_q(:);
            ftrain = PLSDMmodel.acp_train_pf(:);
            if isfield(PLSDMmodel,'ClassTrain') && length(PLSDMmodel.ClassTrain) == length(Qtrain)
                Gtrain = PLSDMmodel.ClassTrain(:);
            else
                Gtrain = ones(length(Qtrain),1);
            end
        end

        Qlim = [];
        flim = [];
        if isfield(PLSDMmodel,'acp_train_Qlimit') && ~isempty(PLSDMmodel.acp_train_Qlimit)
            Qlim = PLSDMmodel.acp_train_Qlimit(1);
        elseif isfield(PLSDMmodel,'FinalModel') && isfield(PLSDMmodel.FinalModel,'Qlimit')
            Qlim = PLSDMmodel.FinalModel.Qlimit(1);
        end
        if isfield(PLSDMmodel,'acp_train_flimit') && ~isempty(PLSDMmodel.acp_train_flimit)
            flim = PLSDMmodel.acp_train_flimit(1);
        elseif isfield(PLSDMmodel,'FinalModel') && isfield(PLSDMmodel.FinalModel,'flimit')
            flim = PLSDMmodel.FinalModel.flimit(1);
        end
        if isempty(Qlim), Qlim = 1; end
        if isempty(flim), flim = 1e-12; end

        Qall = [Qtrain; Qnew];
        fall = [ftrain; fnew];
        [xall,yall,Qnorm,logf_norm,acc_x,acc_y] = local_prediction_acceptance_coords(Qall,fall,Qlim,flim);
        accepted = (Qall <= Qlim) & (fall >= flim);
        nTrain = length(Qtrain);
        xTrain = xall(1:nTrain); yTrain = yall(1:nTrain); accTrain = accepted(1:nTrain);
        xNew = xall(nTrain+1:end); yNew = yall(nTrain+1:end); accNew = accepted(nTrain+1:end);

        colTP = [0.10 0.60 0.20];
        colFP = [0.95 0.70 0.10];
        colFN = [0.20 0.45 0.80];
        colTN = [0.85 0.15 0.20];
        lwAx = 1.4; lwLine = 2.2; lwPts = 1.2;
        fsLbl = 12; fsLeg = 12;

        cla(ax);
        axes(ax);
        hold(ax,'on'); box(ax,'on'); grid(ax,'on');
        set(ax,'LineWidth',lwAx,'FontSize',fsLbl,'FontName','Arial', ...
            'XMinorTick','on','YMinorTick','on');

        x_rect = [0 acc_x acc_x 0 0];
        y_rect = [0 0 acc_y acc_y 0];
        hArea = plot(ax,x_rect,y_rect,'-','Color',[0.00 0.50 0.00],'LineWidth',lwLine);
        fill(x_rect,y_rect,[0.85 0.97 0.85],'FaceAlpha',0.25,'EdgeColor','none','Parent',ax);

        if strcmpi(plotMode,'known') || strcmpi(plotMode,'known_only') || strcmpi(plotMode,'known_with_train')
            if isempty(Gnew)
                Gnew = ones(nNew,1);
            else
                Gnew = Gnew(:);
                if length(Gnew) ~= nNew, Gnew = ones(nNew,1); end
            end
            if strcmpi(plotMode,'known_with_train') && ~isempty(xTrain) && length(Gtrain) == length(xTrain)
                local_prediction_plot_group(ax,xTrain,yTrain,find(accTrain & Gtrain == 1),'o',colTP,9,lwPts);
                local_prediction_plot_group(ax,xTrain,yTrain,find(accTrain & Gtrain ~= 1),'d',colFP,9,lwPts);
                local_prediction_plot_group(ax,xTrain,yTrain,find(~accTrain & Gtrain == 1),'s',colFN,9,lwPts);
                local_prediction_plot_group(ax,xTrain,yTrain,find(~accTrain & Gtrain ~= 1),'^',colTN,9,lwPts);
            end

            local_prediction_plot_group(ax,xNew,yNew,find(accNew & Gnew == 1),'o',colTP,9,lwPts);
            local_prediction_plot_group(ax,xNew,yNew,find(accNew & Gnew ~= 1),'d',colFP,9,lwPts);
            local_prediction_plot_group(ax,xNew,yNew,find(~accNew & Gnew == 1),'s',colFN,9,lwPts);
            local_prediction_plot_group(ax,xNew,yNew,find(~accNew & Gnew ~= 1),'^',colTN,9,lwPts);

            hTP = plot(ax,NaN,NaN,'o','MarkerFaceColor',colTP,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            hFP = plot(ax,NaN,NaN,'d','MarkerFaceColor',colFP,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            hFN = plot(ax,NaN,NaN,'s','MarkerFaceColor',colFN,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            hTN = plot(ax,NaN,NaN,'^','MarkerFaceColor',colTN,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            leg = legend([hArea hTP hFP hFN hTN], ...
                {'Acceptance boundary','True Positive (TP)','False Positive (FP)', ...
                'False Negative (FN)','True Negative (TN)'}, ...
                'Location','EastOutside');
        else
            local_prediction_plot_group(ax,xNew,yNew,find(accNew),'o',colTP,9,lwPts);
            local_prediction_plot_group(ax,xNew,yNew,find(~accNew),'s',colTN,9,lwPts);
            hAcc = plot(ax,NaN,NaN,'o','MarkerFaceColor',colTP,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            hRej = plot(ax,NaN,NaN,'s','MarkerFaceColor',colTN,'MarkerEdgeColor',[0 0 0],'MarkerSize',9,'LineWidth',lwPts,'Visible','off');
            leg = legend([hArea hAcc hRej],{'Acceptance boundary','Accepted','Rejected'},'Location','EastOutside');
        end
        set(leg,'FontSize',fsLeg,'Box','off');

        xlabel(ax,'Log-scaled PF','FontSize',fsLbl,'FontWeight','bold');
        ylabel(ax,'Log-scaled Q residual','FontSize',fsLbl,'FontWeight','bold');
        title(ax,'');

        if strcmpi(plotMode,'known_with_train')
            xfinite = [xNew(isfinite(xNew)); acc_x; local_axis_reference_value(xTrain)];
            yfinite = [yNew(isfinite(yNew)); acc_y; local_axis_reference_value(yTrain)];
        elseif strcmpi(plotMode,'known') || strcmpi(plotMode,'known_only')
            xfinite = [xNew(isfinite(xNew)); acc_x];
            yfinite = [yNew(isfinite(yNew)); acc_y];
        else
            xfinite = [xNew(isfinite(xNew)); acc_x];
            yfinite = [yNew(isfinite(yNew)); acc_y];
        end
        if isempty(xfinite)
            xmax = acc_x;
        else
            xmax = max([xfinite(:); acc_x]);
        end
        if isempty(yfinite)
            ymax = acc_y;
        else
            ymax = max([yfinite(:); acc_y]);
        end
        if isempty(xmax) || ~isfinite(xmax) || xmax <= 0, xmax = 1; end
        if isempty(ymax) || ~isfinite(ymax) || ymax <= 0, ymax = 1; end
        xlim(ax,[0 xmax + 0.15*xmax]);
        ylim(ax,[0 ymax + 0.15*ymax]);
        axis(ax,'square');

        if showLabels
            for ii = 1:nNew
                if isempty(labels)
                    lab = num2str(ii);
                elseif iscell(labels)
                    if ii <= numel(labels), lab = labels{ii}; else, lab = num2str(ii); end
                else
                    if ii <= numel(labels), lab = num2str(labels(ii)); else, lab = num2str(ii); end
                end
                text(xNew(ii),yNew(ii),[' ' lab],'Parent',ax,'FontSize',8,'Color',[0.10 0.10 0.10]);
            end
        end

        P.xplot = xNew(:);
        P.yplot = yNew(:);
        P.Q = Qnew(:);
        P.f = fnew(:);
        P.accepted = accNew(:);
        setappdata(ax,'plsdm_prediction_click_points',P);
        hold(ax,'off');
    end

    function [xplot,yplot,Qnorm,logf_norm,acc_x,acc_y] = local_prediction_acceptance_coords(Q,f,Qcrit,falpha)
        [xplot,yplot,Qnorm,logf_norm,acc_x] = ...
            plsdm_acceptance_coordinates(Q,f,Qcrit,falpha);
        acc_y = acc_x;
    end

    function local_prediction_plot_group(ax,x,y,idx,markerSymbol,faceColor,ms,lw)
        if isempty(idx), return; end
        plot(ax,x(idx),y(idx),markerSymbol,'MarkerFaceColor',faceColor, ...
            'MarkerEdgeColor',[0 0 0],'MarkerSize',ms,'LineWidth',lw);
    end

    function v = local_axis_reference_value(x)
        x = x(:);
        x = x(isfinite(x));
        if isempty(x)
            v = [];
            return;
        end
        x = sort(x);
        idx = ceil(0.95*length(x));
        if idx < 1, idx = 1; end
        if idx > length(x), idx = length(x); end
        v = x(idx);
    end

    function plotUnknownPredictionFigures(hObj)
        S = guidata(hObj);
        if isempty(S.PLSDMpred) || isempty(S.PLSDMmodel), return; end
        showLabels = isfield(S,'chkPlotLabels') && ishandle(S.chkPlotLabels) && get(S.chkPlotLabels,'Value') == 1;
        P = S.PLSDMpred;
        unknownNames = getDataInfoSetNames(S,'unknownSampleNames',size(S.Xunk,1));
        targetTxt = '';
        if isfield(S.PLSDMmodel,'TargetClass'), targetTxt = [' | class ' num2str(S.PLSDMmodel.TargetClass)]; end
        f1 = figure('Color','w','Name','PLS-DM unknown samples','NumberTitle','off');
        ax1 = axes('Parent',f1);
        plsdm_plot_acceptance_area(ax1,P.Q,P.f,P.Qcrit,P.f_alpha,[], ...
            ['Unknown samples only' targetTxt],showLabels,unknownNames);
        f2 = figure('Color','w','Name','PLS-DM training + unknown projection','NumberTitle','off');
        ax2 = axes('Parent',f2);
        plsdm_plot_acceptance_projection(ax2,S.PLSDMmodel,P.Q,P.f,[], ...
            ['Training + unknown projection' targetTxt],showLabels,unknownNames);
    end

    function onExportKnownValidationResults(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMvalidation)
            errordlg('No known-class validation result available.','Export known validation');
            return;
        end
        assignin('base','PLSDMvalidation',S.PLSDMvalidation);
        if isfield(S.PLSDMvalidation,'AllClassesResults') && ...
                length(S.PLSDMvalidation.AllClassesResults) > 1
            assignin('base','PLSDMvalidationAll',S.PLSDMvalidation.AllClassesResults);
            msgbox(['Known-class validation exported as PLSDMvalidation ' ...
                    '(active class) and PLSDMvalidationAll (all class models).'], ...
                   'Export known validation');
        else
            msgbox('Known-class validation result exported to workspace as PLSDMvalidation.','Export known validation');
        end
    end

    function onExportUnknownPredictionResults(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMpred)
            errordlg('No unknown prediction result available.','Export unknown prediction');
            return;
        end
        assignin('base','PLSDMpred',S.PLSDMpred);
        if isfield(S.PLSDMpred,'AllClassesResults') && ...
                length(S.PLSDMpred.AllClassesResults) > 1
            assignin('base','PLSDMpredAll',S.PLSDMpred.AllClassesResults);
            msgbox(['Unknown prediction exported as PLSDMpred ' ...
                    '(active class) and PLSDMpredAll (all class models).'], ...
                   'Export unknown prediction');
        else
            msgbox('Unknown prediction result exported to workspace as PLSDMpred.','Export unknown prediction');
        end
    end
    % ================================================================
    % HELP AND TOOLTIPS
    % ================================================================
    function applyFitValidationTooltips(figHandle,S)
       
        set(S.popupMode,'TooltipString','Choose Classical PLS-DM or Robust PLS-DM. Robust mode uses robust routines when available.');
        if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
            set(S.popupModellingType,'TooltipString','Compliant uses target and non-target classes; Rigorous uses only the active target class.');
        end
        set(S.edKcv,'TooltipString','Number of folds used in cross-validation, e.g. 5 or 10.');
        set(S.edMaxLV,'TooltipString','Maximum number of latent variables evaluated during cross-validation.');
        set(S.popupLVopt,'TooltipString','Latent variable selected for the final model fit. Update after running CV if needed.');
        set(S.edConf,'TooltipString','Confidence level (1-alpha) for PLS-DM thresholds, usually 0.95.');
        set(S.popupPrepro,'TooltipString','Preprocessing used by the PLS-DM fit and cross-validation routines.');
        set(S.edAlpha,'TooltipString','Smoothing coefficient alpha used in the density estimation step.');
        set(S.edKappa,'TooltipString','Kappa value: number of nearest neighbors used in the potential function method.');
        set(S.edGamma,'TooltipString','Gamma level for robust outlier detection.');
        set(S.txtSummary,'TooltipString','Summary of imported training data, CV status and final model status.');
        set(S.txtMetrics,'TooltipString','Metrics for the currently selected number of latent variables.');
        set(S.txtModel,'TooltipString','Summary of the final fitted PLS-DM model.');
        set(S.txtKnownPrediction,'TooltipString','Status and metrics for known-class validation samples.');
        set(S.txtUnknownPrediction,'TooltipString','Status and accepted/rejected summary for unknown samples.');

        set_by_string(figHandle,'Import workspace','Import Xtrain, ClassTrain and optional x-axis variables from the MATLAB workspace.');
        set_by_string(figHandle,'Load PLSDMmodel','Load a previously fitted PLSDMmodel from workspace or MAT-file.');
        set_by_string(figHandle,'Update LV list','Update the LV selection menu according to the Max LV value.');
        set_by_string(figHandle,'Run CV','Run cross-validation using plsdm_CV or rplsdm_CV.');
        set_by_string(figHandle,'Fit final model','Fit the final PLS-DM model using the selected LV.');
        set_by_string(figHandle,'Restore defaults','Restore default fitting and validation settings.');
        set_by_string(figHandle,'Performance vs LV','Open the CV performance plot in a standalone MATLAB figure.');
        set_by_string(figHandle,'Classification report','Open the sample-by-sample classification report for Training, Cross-validation, Known prediction and Unknown prediction.');
        set_by_string(figHandle,'CV diagnostics','Open CV limit variation and fold performance diagnostics.');
        set_by_string(figHandle,'Export model','Export PLSDMmodel to the MATLAB workspace.');
        set_by_string(figHandle,'Outliers status','Export PLSDMmodel.samples_status to workspace as out_status after robust final modelling.');
        set_by_string(figHandle,'VIP scores','Display VIP scores using plot_vip_plsdm.m.');
        set_by_string(figHandle,'Q/f plot','Display the Q/f diagnostic plot using Qf_plot.m.');
        set_by_string(figHandle,'Import','Import validation or unknown samples for prediction.');
        set_by_string(figHandle,'Run','Run known-class validation or unknown prediction.');
        set_by_string(figHandle,'Export','Export validation or prediction results to the MATLAB workspace.');
    end

    function set_by_string(figHandle,label,tip)
        h = findall(figHandle,'Style','pushbutton','String',label);
        for ii = 1:length(h)
            try
                set(h(ii),'TooltipString',tip);
            catch
            end
        end
    end

    function applyModernVisualTheme(figHandle,S)
        theme.bg       = [0.955 0.965 0.975];
        theme.panel    = [0.995 0.995 1.000];
        theme.header   = [0.075 0.145 0.220];
        theme.primary  = [0.070 0.300 0.500];
        theme.accent   = [0.060 0.500 0.420];
        theme.secondary= [0.860 0.900 0.935];
        theme.text     = [0.110 0.130 0.155];
        theme.muted    = [0.340 0.380 0.430];
        theme.border   = [0.720 0.760 0.810];
        theme.white    = [1 1 1];

        try, set(figHandle,'Color',theme.bg); catch, end

        panels = findobj(figHandle,'Type','uipanel');
        for ii = 1:length(panels)
            try
                set(panels(ii),'BackgroundColor',theme.panel, ...
                    'ForegroundColor',theme.text, ...
                    'HighlightColor',theme.border, ...
                    'ShadowColor',[0.88 0.90 0.93], ...
                    'FontName','Arial','FontWeight','bold');
            catch
            end
        end

        if isfield(S,'pnlHeader') && ishandle(S.pnlHeader)
            set(S.pnlHeader,'BackgroundColor',theme.header);
            kids = get(S.pnlHeader,'Children');
            for ii = 1:length(kids)
                try
                    set(kids(ii),'BackgroundColor',theme.header, ...
                        'ForegroundColor',[0.94 0.97 1.00], ...
                        'FontName','Arial');
                catch
                end
            end
        end

        txt = findobj(figHandle,'Style','text');
        for ii = 1:length(txt)
            try
                par = get(txt(ii),'Parent');
                bg = theme.panel;
                fg = theme.text;
                if isequal(par,S.pnlHeader), bg = theme.header; fg = [0.94 0.97 1.00]; end
                set(txt(ii),'BackgroundColor',bg,'ForegroundColor',fg,'FontName','Arial');
            catch
            end
        end

        edits = findobj(figHandle,'Style','edit');
        for ii = 1:length(edits)
            try
                set(edits(ii),'BackgroundColor',theme.white,'ForegroundColor',theme.text,'FontName','Arial');
            catch
            end
        end
        lists = findobj(figHandle,'Style','listbox');
        for ii = 1:length(lists)
            try
                set(lists(ii),'BackgroundColor',theme.white,'ForegroundColor',theme.text,'FontName','Arial');
            catch
            end
        end
        pops = findobj(figHandle,'Style','popupmenu');
        for ii = 1:length(pops)
            try
                set(pops(ii),'BackgroundColor',theme.white,'ForegroundColor',theme.text,'FontName','Arial');
            catch
            end
        end
        chks = findobj(figHandle,'Style','checkbox');
        for ii = 1:length(chks)
            try
                set(chks(ii),'BackgroundColor',theme.panel,'ForegroundColor',theme.text,'FontName','Arial');
            catch
            end
        end

        btns = findobj(figHandle,'Style','pushbutton');
        for ii = 1:length(btns)
            try
                label = get(btns(ii),'String');
                bg = theme.secondary;
                fg = theme.text;
                fw = 'normal';
                if strcmp(label,'Run CV') || strcmp(label,'Fit final model')
                    bg = theme.primary; fg = theme.white; fw = 'bold';
                elseif strcmp(label,'Run') || strcmp(label,'Acceptance') || strcmp(label,'See data')
                    bg = theme.accent; fg = theme.white; fw = 'bold';
                elseif strcmp(label,'Restore defaults')
                    bg = [0.925 0.935 0.950]; fg = theme.muted;
                end
                set(btns(ii),'BackgroundColor',bg,'ForegroundColor',fg, ...
                    'FontName','Arial','FontWeight',fw);
            catch
            end
        end

        if isfield(S,'axAcceptance') && ~isempty(S.axAcceptance) && ishandle(S.axAcceptance)
            try
                set(S.axAcceptance,'Color',theme.white,'XColor',theme.text,'YColor',theme.text, ...
                    'FontName','Arial','LineWidth',1.0);
            catch
            end
        end
    end

    function onHelpFitValidation(hObj,ev)
        f = figure('Name','PLS-DM Fit & Validation - Help', ...
                   'NumberTitle','off', ...
                   'MenuBar','none', ...
                   'Toolbar','none', ...
                   'Color',[1 1 1], ...
                   'Units','normalized', ...
                   'Position',[0.15 0.08 0.70 0.82]);

%         uicontrol('Parent',f,'Style','text', ...
%                   'String','PLS-DM Fit & Validation - Help', ...
%                   'Units','normalized', ...
%                   'Position',[0.02 0.94 0.96 0.04], ...
%                   'BackgroundColor',[1 1 1], ...
%                   'ForegroundColor',[0.18 0.32 0.62], ...
%                   'FontName','Arial', ...
%                   'FontSize',14, ...
%                   'FontWeight','bold', ...
%                   'HorizontalAlignment','left');

        txt = uicontrol('Parent',f,'Style','edit', ...
                  'Units','normalized', ...
                  'Position',[0.02 0.02 0.96 0.91], ...
                  'Max',2,'Min',0, ...
                  'HorizontalAlignment','left', ...
                  'FontName','Courier New', ...
                  'FontSize',10, ...
                  'BackgroundColor',[1 1 1]);

        helpText = {
' '
'PURPOSE OF THIS MODULE'
'This module is used after data preparation, sample partition and model optimization.'
'It performs cross-validation, fits the final PLS-DM model, and applies the final model to known-class or unknown samples.'
' '
'GENERAL WORKFLOW'
'1. Import Xtrain and ClassTrain from the MATLAB workspace.'
'2. Choose model type: Classical PLS or Robust PLS.'
'3. Define K-fold CV, Max LV, modelling type, confidence level, preprocessing, alpha and kappa.'
'4. Click Run CV.'
'5. Inspect Performance vs LV and CV diagnostics if needed.'
'6. Click Fit final model.'
'7. In the LV selector window, choose one LV for each active class.'
'   The selector opens with LV = 1 for all classes; change only what you want.'
'8. Inspect the acceptance area, final model summary and sample status table.'
'9. Optionally import known-class validation data or unknown samples.'
'10. Export the model, outliers status and prediction/validation results as needed.'
' '
'INPUT VARIABLES'
'Xtrain'
'  Matrix with training samples in rows and variables in columns.'
' '
'ClassTrain'
'  Class vector for the training samples.'
'  ClassTrain must have the same number of rows as Xtrain.'
'  The target class is selected in the Target class menu.'
'  In All mode, one one-class model is fitted for each class.'
' '
'Outliers status'
'  Load the optional status vector from the Exclude samples window.'
'  Status codes are 0 = not assigned, 1 = regular, 2 = extreme and 3 = outlier.'
' '
'x-axis variable label (optional)'
'  Optional vector used as var_label.'
'  This is useful for wavelength, wavenumber or variable labels in VIP and diagnostic plots.'
'  Its length must match the number of columns in Xtrain.'
' '
'MODEL TYPE'
'Classical PLS'
'  Uses the standard PLS-DM routines:'
'    plsdm_CV.m for cross-validation'
'    plsdm_ft.m for final model fitting'
' '
'Robust PLS'
'  Uses the robust routines when selected:'
'    rplsdm_CV.m for cross-validation'
'    rplsdm_ft.m for final model fitting'
'  Robust gamma is used only in this mode.'
'  The robust training acceptance area uses two limits: regular and outlier.'
' '
'MODELLING TYPE'
'Compliant'
'  Uses target samples and the remaining classes as non-target information.'
' '
'Rigorous'
'  Uses only the active target-class samples to build each one-class model.'
'  Other classes are not used during CV or final fitting.'
' '
'TARGET CLASS AND ALL MODE'
'Target class'
'  Selects which class is treated as the one-class target.'
' '
'All'
'  Fits one independent one-class model for each class in ClassTrain.'
'  CV, final LV selection, VIP and acceptance plots follow the active class selector.'
' '
'CROSS-VALIDATION SETTINGS'
'K-fold CV'
'  Number of folds used during cross-validation.'
'  Common values: 5 or 10.'
'  Avoid very high K when the number of samples is small.'
' '
'Max LV'
'  Maximum number of latent variables evaluated during CV.'
'  Should be compatible with the number of samples and variables.'
'  Using too many LVs can lead to overfitting.'
' '
'Final LV selection'
'  Clicking Fit final model opens a separate selector window.'
'  When All is enabled, the window shows one LV dropdown per class.'
'  Each dropdown starts at LV = 1 so the user explicitly chooses the final LV.'
' '
'Confidence'
'  Confidence level used to define PLS-DM acceptance thresholds.'
'  Typical value: 0.95.'
' '
'PREPROCESSING'
'Available options:'
'  Raw       - no preprocessing'
'  Center    - variable means are subtracted'
'  Scale     - scaled variables, depending on toolbox convention'
'  Autoscale - centered and variance-scaled variables'
' '
'Important: the preprocessing chosen here must be consistent with the optimization and final application workflow.'
' '
'Smoothing coefficient AND KAPPA'
'Smoothing coefficient'
'  Controls smoothing in the density estimation step.'
'  Lower values may generate sharper/local acceptance regions.'
'  Higher values may generate smoother/global acceptance regions.'
' '
'Kappa'
'  Number of nearest neighbors used in the potential function method.'
'  Small kappa values emphasize local density.'
'  Larger kappa values produce smoother density estimates.'
' '
'Robust gamma'
'  Parameter used in robust PLS-DM routines.'
'  It is ignored by classical routines.'
' '
'FIGURE BUTTONS'
'Performance vs LV'
'  Opens model performance as a function of LV in an external MATLAB figure.'
'In compliant mode, sensitivity, specificity and efficiency may be displayed when available.'
'In rigorous mode, compare CV sensitivity with the expected value 1-alpha.'
'The automatic reference LV minimizes |SENS-(1-alpha)|; it does not maximize sensitivity.'
'Ties use the lowest LV. Final LV selection remains an explicit user decision.'
' '
'CV diagnostics'
'  Opens CV fold-to-fold limit variation and CV performance by fold.'
' '
'Classification report'
'  Opens one MATLAB 2010-compatible table window for Training, Cross-validation, Known prediction and Unknown prediction.'
'  Each row is one sample. Every class has an Accepted (green) or Rejected (red) column, followed by Status.'
'  Known datasets include Actual class; Unknown prediction omits it. A status-count summary appears below.'
' '
'See data'
'  Displays class-colored sample profiles and mean class profiles.'
' '
'ACCEPTANCE AREA'
'The embedded acceptance area follows the active class/model selector.'
'Training'
'  Shows final-model training samples.'
'  Robust PLS shows only target samples with regular, extreme and outlier status.'
' '
'CV fold-wise'
'  Shows fold-wise CV results.'
' '
'CV mean'
'  Shows mean CV diagnostics when available.'
' '
'Export'
'  Opens the selected acceptance area outside the GUI.'
'  The exported acceptance plot is interactive: click a sample to print a report in the Command Window.'
'  The report clears the Command Window first and includes class/status and Q/PF metrics.'
' '
'FINAL MODEL SUMMARY'
'After fitting the final model, this panel reports information such as:'
'  Model type'
'  Preprocessing'
'  K-fold setting'
'  LV used in final model'
'  Confidence level'
'  Alpha'
'  Q limit'
'  f limit'
'  CV summary by LV'
'  sample-level status table'
' '
'KNOWN-CLASS VALIDATION'
'Use this section when you have external samples with known class labels.'
'Required variables:'
'  Xval'
'  ClassVal'
' '
'Steps:'
'1. Fit or load a final PLSDMmodel.'
'2. Import Xval and ClassVal.'
'3. Click Run.'
'4. In All mode, Run evaluates the validation set independently with every fitted class model.'
'5. Use the active class/model selector to inspect each result and the sample-by-sample Classification report.'
'6. Export PLSDMvalidation if needed. In All mode, PLSDMvalidationAll contains every class result.'
' '
'UNKNOWN-SAMPLE PREDICTION'
'Use this section when samples have no known class label.'
'Required variable:'
'  Xunk'
' '
'Steps:'
'1. Fit or load a final PLSDMmodel.'
'2. Import Xunknown.'
'3. Click Run.'
'4. In All mode, Run projects the unknown samples independently into every fitted class model.'
'5. Inspect the Classification report with one Accepted/Rejected column per class and the consolidated Status.'
'6. Export PLSDMpred if needed. In All mode, PLSDMpredAll contains every class result.'
' '
'EXPORTS'
'Export model'
'  Sends PLSDMmodel to the MATLAB workspace.'
' '
'Performance vs LV'
'  Opens the CV performance plot in a standalone figure for saving or editing.'
' '
'Outliers status'
'  Exports PLSDMmodel.samples_status to the workspace as out_status.'
'  Run a robust final model first.'
' '
'Figures of merit'
'  Opens a report for Training, Cross-validation and, when already run, Known prediction.'
'  The CV values are read at exactly the LV selected for the final model.'
'  In All mode, one section is generated for every fitted one-class model.'
'  Each section reports evaluated, accepted and rejected samples, sensitivity,'
'  sensitivity, specificity, efficiency, precision, accuracy, F1 score,'
'  false-negative/false-positive rates and TP/FN/TN/FP counts.'
'  When non-target samples are present, it also reports specificity, efficiency,'
'  false-positive rate and TN/FP counts.'
'  In rigorous target-only modelling, metrics requiring non-target samples are N/A.'
'  In multiclass mode, Known prediction also includes per-class results and a macro/global summary.'
'  Unknown prediction is excluded because its true classes are unavailable.'
'  Fit the final model and retain the corresponding CV result before pressing Figures of merit.'
' '
'Known-class export'
'  Sends the active result as PLSDMvalidation. In All mode, it also sends all results as PLSDMvalidationAll.'
' '
'Unknown export'
'  Sends the active result as PLSDMpred. In All mode, it also sends all results as PLSDMpredAll.'
' '
'Acceptance buttons in Prediction'
'  Known-class acceptance opens an external interactive plot for known validation samples.'
'  Unknown acceptance opens an external interactive plot for unknown samples.'
'  Clicking a sample prints a Command Window report and opens spectra/residual diagnostics.'
' '
'VIP SCORES'
'Shows the active-class mean spectrum, the mean spectrum of each other class, and active-class VIP scores.'
'In All mode, use the active class/model selector before clicking VIP scores.'
' '
'Q/f PLOT'
'The Q/f plot button calls Qf_plot.m.'
'This provides an acceptance/diagnostic view based on Q residual and f-density information.'
'The final model must be available before using this option.'
' '
'BUTTON-BY-BUTTON REFERENCE'
' '
'Help'
'  Opens this complete reference. It does not change data, settings, CV or fitted models.'
' '
'Import workspace'
'  Selects Xtrain, ClassTrain and optional x-axis/variable labels.'
'  A successful new import clears incompatible CV, final-model and prediction results.'
' '
'Exclude'
'  Opens one non-destructive selection window for every dataset currently loaded.'
'  For Training, Load outlier status imports a 0/1/2/3 status vector from the workspace.'
'  Samples with status 3 are unchecked automatically and the status remains visible in the table.'
'  Training and known-validation datasets allow exclusion of individual samples or complete numeric classes.'
'  Unknown samples display Class = Unknown and class-level controls are disabled.'
'  Changing Training invalidates CV, fitted models and predictions; refit and rerun validation.'
'  Changing known or unknown prediction data invalidates only the corresponding result; rerun that operation.'
'  Original row identifies the sample position in its source matrix.'
' '
'Load PLSDMmodel'
'  Selects an existing fitted model from the MATLAB workspace and restores compatible GUI information.'
'  Use only models whose variable definition matches future validation/prediction matrices.'
' '
'Run CV'
'  Requires training data. It validates K, Max LV, confidence and model settings, opens the per-class parameter dialog when needed, and calculates CV.'
'  OK starts CV with the displayed parameters. Cancel returns without replacing the stored CV result.'
' '
'Fit final model'
'  Requires training data and preferably a completed CV. It opens the final-LV selector.'
'  Choose one LV for each target model; OK fits and stores the model, while Cancel preserves the previous model.'
'  Fitting a new final model clears validation and unknown-prediction results produced by the previous model.'
' '
'Restore defaults'
'  Restores default interface settings. It does not import data and should be used before a new parameter setup.'
' '
'Performance vs LV'
'  Requires CV and opens sensitivity and, when available, specificity/efficiency versus LV for the active model.'
' '
'Classification report'
'  Opens sample-level decisions for Training, Cross-validation, Known prediction or Unknown prediction.'
'  Multiclass reports show one column per class model. One-class reports distinguish target and non-target outcomes in Status.'
'  It does not refit or revalidate the model.'
' '
'CV diagnostics'
'  Requires CV and opens fold limit variation and fold performance at the selected/final LV.'
' '
'Export model'
'  Requires a fitted final model and exports PLSDMmodel; All mode also preserves the collection of class models.'
' '
'VIP scores'
'  Requires a final model and opens VIP plus class mean profiles for the Active class/model.'
' '
'Q/f plot'
'  Requires a final model and opens its Q residual versus density diagnostic.'
' '
'See data'
'  Requires training data and opens all profiles and class means without fitting a model.'
' '
'Outliers status'
'  Requires a robust final model containing samples_status and exports it as out_status.'
' '
'Figures of merit'
'  Requires both CV and the final fit. It reports Training and CV at the exact final LV for each fitted target model.'
'  If Known prediction has been run, its metrics are appended automatically, including multiclass summaries when applicable.'
'  Unknown prediction has no figures of merit because reference classes are unavailable.'
'  It never recalculates the model and does not duplicate the sample-by-sample Classification report.'
' '
'Acceptance plot Export'
'  Opens the currently selected Training, CV fold-wise or CV mean acceptance view as an interactive standalone figure.'
' '
'Known-class Import / Run / Export / Report / Acceptance'
'  Import selects Xval and ClassVal. Run applies the final model and stores PLSDMvalidation.'
'  Export sends PLSDMvalidation to the workspace. Report opens sample-level Accepted/Rejected decisions and Status.'
'  Acceptance opens an interactive Q/f acceptance plot for known samples.'
' '
'Unknown Import / Run / Export / Report / Acceptance'
'  Import selects Xunk/Xunknown. Run applies the final model without requiring labels and stores PLSDMpred.'
'  Export sends PLSDMpred to the workspace. Report opens class decisions without Actual class. Acceptance opens the interactive plot.'
' '
'Active class/model and acceptance-view menus'
'  Active class/model changes which one-class model drives plots, VIP and reports in All mode.'
'  The acceptance menu switches among Training, CV fold-wise and CV mean without recalculating results.'
' '
'COMMON ERRORS'
'1. Xtrain rows and ClassTrain length are inconsistent.'
'   Check that each sample has one class label.'
' '
'2. No CV result is stored.'
'   You can still fit a model manually, but CV is recommended before final fitting.'
' '
'3. VIP or Q/f functions not found.'
'   Ensure plot_vip_plsdm.m and Qf_plot.m are on the MATLAB path.'
' '
'4. Validation rows and class length are inconsistent.'
'   Check Xval and ClassVal dimensions.'
' '
'5. Unknown prediction failed.'
'   Check that Xunk has the same number of variables as Xtrain.'
' '
'RECOMMENDATIONS'
'- Use the sample partition module to define Xtrain and validation/test sets.'
'- Use the optimization module before choosing alpha, kappa and LV.'
'- Prefer simpler models when performance is similar.'
'- Always evaluate the final model with external known-class validation when possible.'
'- Keep preprocessing consistent across optimization, fitting, validation and prediction.'
' '
'MATLAB WORKSPACE NAMING CONVENTIONS'
'Training:'
'  Xtrain, ClassTrain'
'Known validation:'
'  Xval, ClassVal'
'Unknown prediction:'
'  Xunk'
'Final model:'
'  PLSDMmodel'
'Validation result:'
'  PLSDMvalidation'
'Unknown prediction result:'
'  PLSDMpred'
' '
% 'END OF HELP'
        };

        set(txt,'String',helpText);
    end

   
    % ================================================================
    function clearView(hObj)
        S = guidata(hObj);
        if isfield(S,'axAcceptance') && ~isempty(S.axAcceptance) && ishandle(S.axAcceptance)
            cla(S.axAcceptance); title(S.axAcceptance,'Acceptance area'); grid(S.axAcceptance,'on'); box(S.axAcceptance,'on');
        end
        set(S.txtModel,'String',{'Run CV, select LV, then fit final model.'});
        if isfield(S,'txtKnownPrediction') && ~isempty(S.txtKnownPrediction) && ishandle(S.txtKnownPrediction)
            set(S.txtKnownPrediction,'String',{'Fit or load a final model first.'});
        end
        if isfield(S,'txtUnknownPrediction') && ~isempty(S.txtUnknownPrediction) && ishandle(S.txtUnknownPrediction)
            set(S.txtUnknownPrediction,'String',{'Fit or load a final model first.'});
        end
        if isfield(S,'axValConf') && ~isempty(S.axValConf) && ishandle(S.axValConf)
            resetSingleConfusionAxis(S.axValConf,'Known-class validation');
        end
    end
    function refreshSummary(hObj,msg)
        S = guidata(hObj);
        txt = {};
        if ~isempty(S.Xtrain)
            txt{end+1} = ['Samples: ' num2str(size(S.Xtrain,1))];
            txt{end+1} = ['Variables: ' num2str(size(S.Xtrain,2))];
            if ~isempty(S.var_label) && numel(S.var_label) == size(S.Xtrain,2)
                txt{end+1} = 'x-axis: loaded';
            else
                txt{end+1} = 'x-axis: default index';
            end
            classes = unique(S.ClassTrain(:));
            classLine = 'Classes: ';
            for ii = 1:numel(classes)
                if ii > 1, classLine = [classLine ', ']; end %#ok<AGROW>
                classLine = [classLine num2str(classes(ii)) ' (n=' num2str(sum(S.ClassTrain == classes(ii))) ')']; %#ok<AGROW>
            end
            txt{end+1} = classLine;
            modellingType = getSelectedModellingType(S);
            txt{end+1} = ['Modelling type: ' modellingType];
            targetClasses = getTargetClassesForRun(S);
            if numel(targetClasses) > 1
                txt{end+1} = ['Target mode: all classes (' num2str(numel(targetClasses)) ' models)'];
            elseif ~isempty(targetClasses)
                txt{end+1} = ['Target class: ' num2str(targetClasses(1))];
                txt{end+1} = ['Target n: ' num2str(sum(S.ClassTrain == targetClasses(1)))];
                if strcmpi(modellingType,'Rigorous')
                    txt{end+1} = 'Non-target n used: 0';
                else
                    txt{end+1} = ['Non-target n: ' num2str(sum(S.ClassTrain ~= targetClasses(1)))];
                end
            end
        else
            txt{end+1} = 'No training data loaded.';
        end
        if ~isempty(S.CVmodel)
            txt{end+1} = 'CV status: completed';
            if isfield(S.CVmodel,'caseType'), txt{end+1} = ['Case type: ' S.CVmodel.caseType]; end
        end
        if ~isempty(S.PLSDMmodel)
            txt{end+1} = 'Final model: fitted';
            if isfield(S.PLSDMmodel,'ModellingType'), txt{end+1} = ['Model fitted as: ' S.PLSDMmodel.ModellingType]; end
            if isfield(S.PLSDMmodel,'LVopt'), txt{end+1} = ['LV selected: ' num2str(S.PLSDMmodel.LVopt)]; end
            if isfield(S.PLSDMmodel,'preprocessing'), txt{end+1} = ['Preprocessing: ' preprocessing_display_name(S.PLSDMmodel.preprocessing)]; end
        elseif ~isempty(S.CVmodel)
            txt{end+1} = ['LV selected: ' num2str(get(S.popupLVopt,'Value'))];
        end
        if nargin >= 2 && ~isempty(msg)
            txt = [txt(:); {' '}; msg(:)];
        end
        set(S.txtSummary,'String',txt);
    end

    function updatePlotsAndText(hObj)
        S = guidata(hObj);
        if isempty(S.PLSDMmodel) && isempty(S.CVmodel)
            clearView(hObj);
            return;
        end
        plotAcceptanceInGui(hObj);
        updateModelText(hObj);
        updatePredictionText(hObj,{});
    end

    function plotAcceptanceInGui(hObj)
        S = guidata(hObj);
        if ~isfield(S,'axAcceptance') || isempty(S.axAcceptance) || ~ishandle(S.axAcceptance)
            return;
        end
        modeList = get(S.popupAcceptanceMode,'String');
        modeVal = get(S.popupAcceptanceMode,'Value');
        mode = modeList{modeVal};
        showLabels = get(S.chkPlotLabels,'Value') == 1;
        [ok,Q,f,Qlim,flim,Gtrue,titleStr] = getAcceptanceDataForPlot(S,mode);
        if ~ok
            cla(S.axAcceptance);
            title(S.axAcceptance,'Acceptance area unavailable');
            return;
        end
        Mplot = getActiveModelForAcceptance(S);
        sampleLabels = getAcceptanceSampleLabels(S,Mplot,mode,Gtrue,numel(Q));
        if strcmpi(mode,'Training') && isRobustOutlierModel(Mplot)
            robustData = plsdm_plot_robust_training_acceptance_gui(S.axAcceptance,Q,f,Qlim,flim,Gtrue, ...
                Mplot.FinalModel.QlimitO,Mplot.FinalModel.flimitO,showLabels,sampleLabels);
            compactAcceptanceLegend(S.axAcceptance);
            installRobustAcceptanceClick(S,Q,f,Qlim,flim,Gtrue,robustData,'Training');
            return;
        end
        markerSpec = getAcceptanceMarkerSpec(S,mode,Q,Gtrue);
        plsdm_plot_acceptance_area(S.axAcceptance,Q,f,Qlim,flim,Gtrue,titleStr,showLabels,sampleLabels,markerSpec);
        compactAcceptanceLegend(S.axAcceptance);
        installAcceptanceClick(S,Q,f,Qlim,flim,Gtrue,titleStr,mode,markerSpec);
    end

    function compactAcceptanceLegend(ax)
        if isempty(ax) || ~ishandle(ax), return; end
        figOwner = ancestor(ax,'figure');
        leg = findall(figOwner,'Type','Legend');
        if isempty(leg), leg = findall(figOwner,'Tag','legend'); end
        for ii = 1:length(leg)
            try, set(leg(ii),'FontSize',7,'Box','off'); catch, end
        end
        % Keep a larger plotting region while retaining a dedicated strip
        % for the compact legend on the right.
        set(ax,'Units','normalized','Position',[0.07 0.20 0.80 0.72]);
    end

    function M = getActiveModelForAcceptance(S)
        M = [];
        if ~isempty(S.PLSDMmodel)
            M = S.PLSDMmodel;
        elseif ~isempty(S.CVmodel)
            M = S.CVmodel;
        end
    end

    function labels = getAcceptanceSampleLabels(S,M,mode,Gtrue,nPlot)
        labels = {};
        if isempty(M) || ~isstruct(M) || ~isfield(S,'dataInfo') || ...
                ~isfield(S.dataInfo,'sampleNames') || isempty(S.dataInfo.sampleNames)
            return;
        end
        allNames = S.dataInfo.sampleNames(:);
        if ~isfield(M,'ClassTrain') || isempty(M.ClassTrain)
            return;
        end
        classOne = M.ClassTrain(:);
        rows = (1:numel(classOne))';
        if isfield(M,'TrainingRows') && numel(M.TrainingRows) == numel(classOne)
            rows = M.TrainingRows(:);
        end
        if any(rows < 1) || any(rows > numel(allNames))
            return;
        end
        baseNames = allNames(rows);
        if strcmpi(mode,'Training') && nPlot == numel(baseNames)
            labels = baseNames;
            return;
        end
        targetNames = baseNames(classOne == 1);
        nonTargetNames = baseNames(classOne ~= 1);
        Gtrue = Gtrue(:);
        if numel(Gtrue) ~= nPlot || isempty(targetNames)
            return;
        end
        labels = cell(nPlot,1);
        iTarget = 0;
        iNonTarget = 0;
        for kk = 1:nPlot
            if Gtrue(kk) == 1
                iTarget = iTarget + 1;
                labels{kk} = targetNames{1 + mod(iTarget-1,numel(targetNames))};
            elseif ~isempty(nonTargetNames)
                iNonTarget = iNonTarget + 1;
                labels{kk} = nonTargetNames{1 + mod(iNonTarget-1,numel(nonTargetNames))};
            else
                labels{kk} = num2str(kk);
            end
        end
    end

    function tf = isRobustOutlierModel(M)
        tf = false;
        if isempty(M) || ~isstruct(M) || ~isfield(M,'FinalModel') || ~isstruct(M.FinalModel)
            return;
        end
        tf = isfield(M.FinalModel,'QlimitO') && ~isempty(M.FinalModel.QlimitO) && ...
             isfield(M.FinalModel,'flimitO') && ~isempty(M.FinalModel.flimitO);
    end

    function markerSpec = getAcceptanceMarkerSpec(S,mode,Q,Gtrue)
        markerSpec = struct();
        markerSpec.UseCVScaling = false;
        markerSpec.UseFoldShade = false;
        markerSpec.FoldIndex = ones(numel(Q),1);
        markerSpec.NFolds = 1;
        if strcmpi(mode,'CV fold-wise') || strcmpi(mode,'CV mean') || strcmpi(mode,'CV')
            markerSpec.UseCVScaling = true;
        end
        if ~strcmpi(mode,'CV fold-wise')
            return;
        end
        Mlocal = [];
        if ~isempty(S.PLSDMmodel)
            Mlocal = S.PLSDMmodel;
        elseif ~isempty(S.CVmodel)
            Mlocal = S.CVmodel;
        end
        Klocal = 1;
        if ~isempty(Mlocal) && isfield(Mlocal,'K') && ~isempty(Mlocal.K), Klocal = Mlocal.K; end
        markerSpec.NFolds = Klocal;
        markerSpec.UseFoldShade = true;
        Gtrue = Gtrue(:);
        idxT = find(Gtrue == 1);
        idxN = find(Gtrue ~= 1);
        foldIndex = ones(numel(Q),1);
        for ii = 1:length(idxT)
            foldIndex(idxT(ii)) = mod(ii-1,Klocal)+1;
        end
        if ~isempty(Mlocal) && isfield(Mlocal,'ClassTrain')
            nUnt = length(find(Mlocal.ClassTrain(:) ~= 1));
        else
            nUnt = 0;
        end
        if nUnt > 0 && length(idxN) == nUnt*Klocal
            for kk = 1:Klocal
                for jj = 1:nUnt
                    foldIndex(idxN((kk-1)*nUnt+jj)) = kk;
                end
            end
        else
            for ii = 1:length(idxN)
                foldIndex(idxN(ii)) = mod(ii-1,Klocal)+1;
            end
        end
        markerSpec.FoldIndex = foldIndex;
    end

    function R = plsdm_plot_robust_training_acceptance_gui(ax,Q,f,Qcrit,f_alpha,Gtrue,Qo,fo,showLabels,labels)
        if nargin < 9 || isempty(showLabels), showLabels = false; end
        if nargin < 10, labels = {}; end
        c = 10;
        floor_f = 1e-12;
        Q = Q(:); f = f(:); Gtrue = Gtrue(:);
        nPlot = numel(Q);
        R = struct();
        if nPlot < 1
            cla(ax); title(ax,''); return;
        end
        if numel(f) ~= nPlot, f = f(1:min(numel(f),nPlot)); f(end+1:nPlot,1) = floor_f; end
        if numel(Gtrue) ~= nPlot, Gtrue = ones(nPlot,1); end

        f((~isfinite(f)) | f <= 0) = floor_f;
        Qcrit_v = expand_limit_for_gui(Qcrit,nPlot,realmin);
        falpha_v = expand_limit_for_gui(f_alpha,nPlot,floor_f);
        Qo_v = expand_limit_for_gui(Qo,nPlot,realmin);
        fo_v = expand_limit_for_gui(fo,nPlot,floor_f);
        Qcrit_v((~isfinite(Qcrit_v)) | Qcrit_v <= 0) = realmin;
        falpha_v((~isfinite(falpha_v)) | falpha_v <= 0) = floor_f;
        badQo = (~isfinite(Qo_v)) | Qo_v <= 0;
        Qo_v(badQo) = Qcrit_v(badQo);
        badFo = (~isfinite(fo_v)) | fo_v <= 0;
        fo_v(badFo) = falpha_v(badFo);

        [xplot,yplot,Qnorm,logf_norm,inner_limit_x,inner_accept] = ...
            plsdm_acceptance_coordinates(Q,f,Qcrit_v,falpha_v);
        [~,~,Qo_norm_lim_v,L_o_norm_v] = ...
            plsdm_acceptance_coordinates(Qo_v,fo_v,Qcrit_v,falpha_v);
        Qo_norm_lim = max(max(Qo_norm_lim_v),1);
        L_o_norm = max(max(L_o_norm_v),1);
        inner_limit_y = inner_limit_x;
        outer_limit_x = log(1 + c*max(L_o_norm,0));
        outer_limit_y = log(1 + c*max(Qo_norm_lim,0));

        isTarget = (Gtrue == 1);
        status = plsdm_training_status(Q,f,Qcrit_v,falpha_v,Qo_v,fo_v,Gtrue);

        cla(ax);
        axes(ax);
        hold(ax,'on'); box(ax,'on'); grid(ax,'on');
        set(ax,'LineWidth',1.4,'FontSize',12,'FontName','Arial', ...
            'XMinorTick','on','YMinorTick','on');

        x_rect_in = [0 inner_limit_x inner_limit_x 0 0];
        y_rect_in = [0 0 inner_limit_y inner_limit_y 0];
        x_rect_out = [0 outer_limit_x outer_limit_x 0 0];
        y_rect_out = [0 0 outer_limit_y outer_limit_y 0];
        fill(x_rect_out,y_rect_out,[1.00 0.90 0.90],'FaceAlpha',0.20,'EdgeColor','none','Parent',ax);
        fill(x_rect_in,y_rect_in,[0.85 0.97 0.85],'FaceAlpha',0.30,'EdgeColor','none','Parent',ax);
        hInner = plot(ax,x_rect_in,y_rect_in,'-','Color',[0.00 0.50 0.00],'LineWidth',2.2);
        hOuter = plot(ax,x_rect_out,y_rect_out,'-','Color',[0.85 0.00 0.00],'LineWidth',2.2);

        colReg = [0.10 0.60 0.20];
        colExt = [0.95 0.70 0.10];
        colOut = [0.85 0.15 0.20];
        idxReg = find(status == 1);
        idxExt = find(status == 2);
        idxOut = find(status == 3);
        hReg = local_plot_or_dummy(ax,xplot,yplot,idxReg,'o',colReg,9,1.2);
        hExt = local_plot_or_dummy(ax,xplot,yplot,idxExt,'d',colExt,9,1.2);
        hOut = local_plot_or_dummy(ax,xplot,yplot,idxOut,'s',colOut,9,1.2);

        leg = legend([hInner hOuter hReg hExt hOut], ...
            {'Regular limit','Outlier limit','Regular target','Extreme target','Outlier target'}, ...
            'Location','EastOutside');
        set(leg,'FontSize',10,'Box','off');
        xlabel(ax,'Log-scaled PF','FontSize',11,'FontWeight','bold');
        ylabel(ax,'Log-scaled Q residual','FontSize',11,'FontWeight','bold');
        title(ax,'');

        if showLabels
            idxT = find(isTarget);
            for ii = 1:length(idxT)
                jj = idxT(ii);
                labelText = num2str(jj);
                if iscell(labels) && jj <= numel(labels) && ~isempty(labels{jj})
                    labelText = labels{jj};
                end
                text('Parent',ax,'Position',[xplot(jj) yplot(jj) 0], ...
                    'String',labelText,'FontSize',8, ...
                    'VerticalAlignment','bottom','HorizontalAlignment','left');
            end
        end

        xmax = max([xplot(isfinite(xplot) & isTarget); inner_limit_x; outer_limit_x]);
        ymax = max([yplot(isfinite(yplot) & isTarget); inner_limit_y; outer_limit_y]);
        if isempty(xmax) || ~isfinite(xmax) || xmax <= 0, xmax = outer_limit_x; end
        if isempty(ymax) || ~isfinite(ymax) || ymax <= 0, ymax = outer_limit_y; end
        xlim(ax,[0 xmax + 0.15*xmax]);
        ylim(ax,[0 ymax + 0.15*ymax]);
        hold(ax,'off');

        R.xplot = xplot;
        R.yplot = yplot;
        R.xplot(~isTarget) = NaN;
        R.yplot(~isTarget) = NaN;
        R.Qnorm = Qnorm;
        R.logf_norm = logf_norm;
        R.accepted = inner_accept;
        R.status = status;
        R.Qo = Qo_v;
        R.fo = fo_v;
    end

    function h = local_plot_or_dummy(ax,x,y,idx,markerSymbol,faceColor,ms,lw)
        if isempty(idx)
            h = plot(ax,NaN,NaN,markerSymbol,'MarkerFaceColor',faceColor, ...
                'MarkerEdgeColor',[0 0 0],'MarkerSize',ms,'LineWidth',lw,'Visible','off');
        else
            h = plot(ax,x(idx),y(idx),markerSymbol,'MarkerFaceColor',faceColor, ...
                'MarkerEdgeColor',[0 0 0],'MarkerSize',ms,'LineWidth',lw);
        end
    end

    function installAcceptanceClick(S,Q,f,Qlim,flim,Gtrue,titleStr,mode,markerSpec)
        if ~isfield(S,'axAcceptance') || isempty(S.axAcceptance) || ~ishandle(S.axAcceptance)
            return;
        end
        installAcceptanceClickOnAxes(S.axAcceptance,S,Q,f,Qlim,flim,Gtrue,titleStr,mode,markerSpec);
    end

    function installAcceptanceClickOnAxes(axHandle,S,Q,f,Qlim,flim,Gtrue,titleStr,mode,markerSpec)
        if isempty(axHandle) || ~ishandle(axHandle)
            return;
        end
        [xplot,yplot,Qnorm,logf_norm] = computeAcceptanceGuiCoordinates(Q,f,Qlim,flim,markerSpec);
        D = struct();
        D.Q = Q(:);
        D.f = f(:);
        D.Qlim = expand_limit_for_gui(Qlim,length(D.Q),realmin);
        D.flim = expand_limit_for_gui(flim,length(D.Q),1e-12);
        D.Gtrue = Gtrue(:);
        if numel(D.Gtrue) ~= numel(D.Q)
            D.Gtrue = ones(numel(D.Q),1);
        end
        D.xplot = xplot;
        D.yplot = yplot;
        D.Qnorm = Qnorm;
        D.logf_norm = logf_norm;
        D.accepted = (D.Q <= D.Qlim) & (D.f >= D.flim);
        D.titleStr = titleStr;
        D.mode = mode;
        D.Xtrain = [];
        D.Model = [];
        D.SampleIndex = (1:numel(D.Q))';
        D.FoldIndex = ones(numel(D.Q),1);
        D.DataInfo = S.dataInfo;
        D.VarLabel = S.var_label;
        if isfield(S,'Xtrain') && ~isempty(S.Xtrain)
            D.Xtrain = S.Xtrain;
        end
        if isfield(S,'ClassTrain') && ~isempty(S.ClassTrain)
            D.ClassTrain = S.ClassTrain(:);
        else
            D.ClassTrain = [];
        end
        Klocal = 1;
        Mlocal = [];
        if ~isempty(S.PLSDMmodel)
            Mlocal = S.PLSDMmodel;
        elseif ~isempty(S.CVmodel)
            Mlocal = S.CVmodel;
        end
        if ~isempty(Mlocal) && isfield(Mlocal,'K') && ~isempty(Mlocal.K)
            Klocal = Mlocal.K;
        end
        D.Model = Mlocal;
        D.SampleLabels = getAcceptanceSampleLabels(S,Mlocal,mode,D.Gtrue,numel(D.Q));
        if ~isempty(Mlocal) && isfield(Mlocal,'TrainingRows') && numel(Mlocal.TrainingRows) == numel(D.Q)
            D.SampleIndex = Mlocal.TrainingRows(:);
        end
        if strcmpi(mode,'CV mean') && ~isempty(D.ClassTrain)
            nt = length(find(D.ClassTrain == 1));
            nonTargetIdx = find(D.ClassTrain ~= 1);
            if length(D.Q) == length(D.ClassTrain)
                D.SampleIndex = (1:length(D.ClassTrain))';
            elseif length(D.Q) == nt + length(nonTargetIdx)
                D.SampleIndex = [find(D.ClassTrain == 1); nonTargetIdx];
            end
        elseif strcmpi(mode,'Training') && ~isempty(D.ClassTrain) && length(D.Q) == length(D.ClassTrain)
            D.SampleIndex = (1:length(D.ClassTrain))';
        elseif strcmpi(mode,'CV fold-wise') && ~isempty(D.ClassTrain)
            idxT = find(D.Gtrue == 1);
            idxN = find(D.Gtrue ~= 1);
            targetRows = find(D.ClassTrain == 1);
            nonTargetRows = find(D.ClassTrain ~= 1);
            for ii = 1:length(idxT)
                if ii <= length(targetRows)
                    D.SampleIndex(idxT(ii)) = targetRows(ii);
                end
                D.FoldIndex(idxT(ii)) = mod(ii-1,Klocal)+1;
            end
            nUnt = length(nonTargetRows);
            if nUnt > 0 && length(idxN) == nUnt*Klocal
                for kk = 1:Klocal
                    for jj = 1:nUnt
                        pos = idxN((kk-1)*nUnt+jj);
                        D.SampleIndex(pos) = nonTargetRows(jj);
                        D.FoldIndex(pos) = kk;
                    end
                end
            else
                for ii = 1:length(idxN)
                    if ii <= length(nonTargetRows)
                        D.SampleIndex(idxN(ii)) = nonTargetRows(ii);
                    end
                    D.FoldIndex(idxN(ii)) = mod(ii-1,Klocal)+1;
                end
            end
        end
        setappdata(axHandle,'plsdm_gui_acceptance_clickdata',D);
        set(axHandle,'ButtonDownFcn',@onGuiAcceptanceClick,'HitTest','on');
        figExt = ancestor(axHandle,'figure');
        if ~isempty(figExt) && ishandle(figExt)
            set(figExt,'WindowButtonDownFcn','');
        end
        kids = findobj(axHandle);
        for ii = 1:length(kids)
            try
                set(kids(ii),'ButtonDownFcn',@onGuiAcceptanceClick,'HitTest','on');
            catch
            end
        end
    end

    function installRobustAcceptanceClick(S,Q,f,Qlim,flim,Gtrue,R,mode)
        if ~isfield(S,'axAcceptance') || isempty(S.axAcceptance) || ~ishandle(S.axAcceptance)
            return;
        end
        installRobustAcceptanceClickOnAxes(S.axAcceptance,S,Q,f,Qlim,flim,Gtrue,R,mode);
    end

    function installRobustAcceptanceClickOnAxes(axHandle,S,Q,f,Qlim,flim,Gtrue,R,mode)
        if isempty(axHandle) || ~ishandle(axHandle)
            return;
        end
        D = struct();
        D.Q = Q(:);
        D.f = f(:);
        D.Qlim = expand_limit_for_gui(Qlim,length(D.Q),realmin);
        D.flim = expand_limit_for_gui(flim,length(D.Q),1e-12);
        D.Gtrue = Gtrue(:);
        if numel(D.Gtrue) ~= numel(D.Q)
            D.Gtrue = ones(numel(D.Q),1);
        end
        D.xplot = R.xplot;
        D.yplot = R.yplot;
        D.Qnorm = R.Qnorm;
        D.logf_norm = R.logf_norm;
        D.accepted = R.accepted;
        D.RobustStatus = R.status;
        D.Qouter = R.Qo;
        D.fouter = R.fo;
        D.titleStr = 'Robust training outlier area';
        D.mode = mode;
        D.Xtrain = [];
        D.Model = [];
        D.SampleIndex = (1:numel(D.Q))';
        D.FoldIndex = ones(numel(D.Q),1);
        D.DataInfo = S.dataInfo;
        D.VarLabel = S.var_label;
        if isfield(S,'Xtrain') && ~isempty(S.Xtrain)
            D.Xtrain = S.Xtrain;
        end
        if isfield(S,'ClassTrain') && ~isempty(S.ClassTrain)
            D.ClassTrain = S.ClassTrain(:);
        else
            D.ClassTrain = [];
        end
        Mlocal = getActiveModelForAcceptance(S);
        D.Model = Mlocal;
        D.SampleLabels = getAcceptanceSampleLabels(S,Mlocal,mode,D.Gtrue,numel(D.Q));
        if ~isempty(Mlocal) && isfield(Mlocal,'TrainingRows') && numel(Mlocal.TrainingRows) == numel(D.Q)
            D.SampleIndex = Mlocal.TrainingRows(:);
        end
        if ~isempty(D.ClassTrain) && length(D.Q) == length(D.ClassTrain)
            D.SampleIndex = (1:length(D.ClassTrain))';
        end
        setappdata(axHandle,'plsdm_gui_acceptance_clickdata',D);
        set(axHandle,'ButtonDownFcn',@onGuiAcceptanceClick,'HitTest','on');
        figExt = ancestor(axHandle,'figure');
        if ~isempty(figExt) && ishandle(figExt)
            set(figExt,'WindowButtonDownFcn','');
        end
        kids = findobj(axHandle);
        for ii = 1:length(kids)
            try
                set(kids(ii),'ButtonDownFcn',@onGuiAcceptanceClick,'HitTest','on');
            catch
            end
        end
    end

    function [xplot,yplot,Qnorm,logf_norm] = computeAcceptanceGuiCoordinates(Q,f,Qcrit,falpha,markerSpec)
        [xplot,yplot,Qnorm,logf_norm] = ...
            plsdm_acceptance_coordinates(Q,f,Qcrit,falpha);
    end

    function v = expand_limit_for_gui(v,n,fallback)
        if isempty(v)
            v = repmat(fallback,n,1);
        elseif numel(v) == 1
            v = repmat(v,n,1);
        else
            v = v(:);
            if numel(v) ~= n
                v = repmat(v(1),n,1);
            end
        end
    end

    function onGuiAcceptanceClick(src,ev)
        ax = ancestor(src,'axes');
        if isempty(ax)
            fig0 = ancestor(src,'figure');
            if ~isempty(fig0) && ishandle(fig0)
                ax = get(fig0,'CurrentAxes');
            end
            if isempty(ax) || ~ishandle(ax)
                return;
            end
        end
        D = getappdata(ax,'plsdm_gui_acceptance_clickdata');
        if isempty(D) || isempty(D.xplot)
            return;
        end
        cp = get(ax,'CurrentPoint');
        px = cp(1,1);
        py = cp(1,2);
        xlimv = get(ax,'XLim');
        ylimv = get(ax,'YLim');
        xr = xlimv(2)-xlimv(1);
        yr = ylimv(2)-ylimv(1);
        if xr <= 0, xr = 1; end
        if yr <= 0, yr = 1; end
        dist = ((D.xplot-px)./xr).^2 + ((D.yplot-py)./yr).^2;
        dist(~isfinite(dist)) = inf;
        [dmin,idx] = min(dist);
        if isempty(idx) || dmin > 0.02
            return;
        end
        lastClick = getappdata(ax,'plsdm_gui_acceptance_last_click');
        nowClick = now;
        if ~isempty(lastClick) && numel(lastClick) >= 2 && ...
                lastClick(1) == idx && (nowClick - lastClick(2))*86400 < 0.35
            return;
        end
        setappdata(ax,'plsdm_gui_acceptance_last_click',[idx nowClick]);
        showAcceptanceClickReport(ax,D,idx);
    end

    function showAcceptanceClickReport(ax,D,idx)
        fig = ancestor(ax,'figure');
        S = guidata(fig);
        sampleIndex = idx;
        if isfield(D,'SampleIndex') && idx <= length(D.SampleIndex)
            sampleIndex = D.SampleIndex(idx);
        end
        sampleName = num2str(sampleIndex);
        if isfield(D,'SampleLabels') && iscell(D.SampleLabels) && idx <= numel(D.SampleLabels) && ~isempty(D.SampleLabels{idx})
            sampleName = D.SampleLabels{idx};
        elseif isfield(D,'DataInfo')
            sampleName = plsdm_data_info_sample_name(D.DataInfo,sampleIndex);
        end
        if D.Gtrue(idx) == 1
            trueClassText = 'target';
        else
            trueClassText = 'non-target';
        end
        if D.accepted(idx)
            decisionText = 'accepted';
        else
            decisionText = 'rejected';
        end
        correctClassText = 'unknown';
        if isfield(D,'ClassTrain') && ~isempty(D.ClassTrain) && sampleIndex >= 1 && sampleIndex <= length(D.ClassTrain)
            if isfield(D,'DataInfo')
                correctClassText = plsdm_data_info_class_name(D.DataInfo,D.ClassTrain(sampleIndex));
            else
                correctClassText = num2str(D.ClassTrain(sampleIndex));
            end
        end
        classStatusText = get_binary_status_text(D.Gtrue(idx) == 1,D.accepted(idx));
        robustStatusText = '';
        if isfield(D,'RobustStatus') && idx <= length(D.RobustStatus)
            if D.RobustStatus(idx) == 1
                robustStatusText = 'regular';
                decisionText = 'regular';
            elseif D.RobustStatus(idx) == 2
                robustStatusText = 'extreme';
                decisionText = 'extreme';
            elseif D.RobustStatus(idx) == 3
                robustStatusText = 'outlier';
                decisionText = 'outlier';
            elseif D.RobustStatus(idx) == 0
                robustStatusText = 'not evaluated';
            end
        end
        lines = {};
        canUpdateGuiList = ~isempty(S) && isstruct(S) && isfield(S,'txtModel') && ishandle(S.txtModel);
        if canUpdateGuiList
            lines = get(S.txtModel,'String');
            if ischar(lines), lines = cellstr(lines); end
        end
        clickLines = {};
        clickLines{end+1} = ' ';
        clickLines{end+1} = 'Clicked acceptance sample';
        clickLines{end+1} = ['Displayed point: ' num2str(idx)];
        clickLines{end+1} = ['Original sample index: ' num2str(sampleIndex)];
        clickLines{end+1} = ['Sample name: ' sampleName];
        clickLines{end+1} = ['Area: ' D.mode];
        if isfield(D,'FoldIndex') && idx <= length(D.FoldIndex)
            clickLines{end+1} = ['CV fold: ' num2str(D.FoldIndex(idx))];
        end
        clickLines{end+1} = ['Correct class: ' correctClassText];
        clickLines{end+1} = ['True group: ' trueClassText];
        clickLines{end+1} = ['Decision: ' decisionText];
        clickLines{end+1} = ['Classification status: ' classStatusText];
        if ~isempty(robustStatusText)
            clickLines{end+1} = ['Robust outlier status: ' robustStatusText];
        end
        clickLines{end+1} = ['Q residual: ' num2str(D.Q(idx),6)];
        clickLines{end+1} = ['Q limit: ' num2str(D.Qlim(idx),6)];
        if isfield(D,'Qouter') && idx <= length(D.Qouter)
            clickLines{end+1} = ['Outer Q limit: ' num2str(D.Qouter(idx),6)];
        end
        clickLines{end+1} = ['PF density: ' num2str(D.f(idx),6)];
        clickLines{end+1} = ['PF limit: ' num2str(D.flim(idx),6)];
        if isfield(D,'fouter') && idx <= length(D.fouter)
            clickLines{end+1} = ['Outer PF limit: ' num2str(D.fouter(idx),6)];
        end
        printAcceptanceCommandReport(D,idx,sampleIndex,sampleName,trueClassText,decisionText,robustStatusText,correctClassText,classStatusText);
        if canUpdateGuiList
            set(S.txtModel,'String',[clickLines(:); {' '}; lines(:)]);
        end
        plotGuiClickedSample(D,idx,trueClassText,decisionText);
    end

    function st = get_binary_status_text(isTarget,accepted)
        if isTarget && accepted
            st = 'TP';
        elseif isTarget && ~accepted
            st = 'FN';
        elseif ~isTarget && accepted
            st = 'FP';
        else
            st = 'TN';
        end
    end

    function printAcceptanceCommandReport(D,idx,sampleIndex,sampleName,trueClassText,decisionText,robustStatusText,correctClassText,classStatusText)
        clc;
        fprintf('PLS-DM acceptance sample report\n');
        fprintf('--------------------------------\n');
        fprintf('Displayed point: %d\n',idx);
        fprintf('Original sample index: %d\n',sampleIndex);
        fprintf('Sample name: %s\n',sampleName);
        if isfield(D,'mode'), fprintf('Area: %s\n',D.mode); end
        if isfield(D,'FoldIndex') && idx <= length(D.FoldIndex)
            fprintf('CV fold: %d\n',D.FoldIndex(idx));
        end
        fprintf('Correct/original class: %s\n',correctClassText);
        fprintf('Class/group: %s\n',trueClassText);
        fprintf('Status: %s\n',decisionText);
        fprintf('Classification status: %s\n',classStatusText);
        if ~isempty(robustStatusText)
            fprintf('Robust outlier status: %s\n',robustStatusText);
        end
        if isfield(D,'Q') && idx <= length(D.Q), fprintf('Q residual: %.6g\n',D.Q(idx)); end
        if isfield(D,'Qlim') && idx <= length(D.Qlim), fprintf('Q limit: %.6g\n',D.Qlim(idx)); end
        if isfield(D,'Qouter') && idx <= length(D.Qouter), fprintf('Outer Q limit: %.6g\n',D.Qouter(idx)); end
        if isfield(D,'f') && idx <= length(D.f), fprintf('PF density: %.6g\n',D.f(idx)); end
        if isfield(D,'flim') && idx <= length(D.flim), fprintf('PF limit: %.6g\n',D.flim(idx)); end
        if isfield(D,'fouter') && idx <= length(D.fouter), fprintf('Outer PF limit: %.6g\n',D.fouter(idx)); end
        if isfield(D,'Qnorm') && idx <= length(D.Qnorm), fprintf('Normalized Q: %.6g\n',D.Qnorm(idx)); end
        if isfield(D,'logf_norm') && idx <= length(D.logf_norm), fprintf('Normalized PF coordinate: %.6g\n',D.logf_norm(idx)); end
    end

    function plotGuiClickedSample(D,idx,trueClassText,decisionText)
        if ~isfield(D,'Xtrain') || isempty(D.Xtrain)
            return;
        end
        if ~isfield(D,'SampleIndex') || idx > length(D.SampleIndex)
            return;
        end
        row = D.SampleIndex(idx);
        Xtrain = D.Xtrain;
        if row < 1 || row > size(Xtrain,1)
            return;
        end
        if isfield(D,'ClassTrain') && ~isempty(D.ClassTrain) && length(D.ClassTrain) == size(Xtrain,1)
            targetValue = 1;
            if isfield(D,'Model') && isstruct(D.Model) && isfield(D.Model,'TargetClass')
                targetValue = D.Model.TargetClass;
            end
            targetRows = find(D.ClassTrain == targetValue);
        else
            targetRows = 1:size(Xtrain,1);
        end
        if isempty(targetRows)
            return;
        end
        lambda = 1:size(Xtrain,2);
        if isfield(D,'VarLabel') && isnumeric(D.VarLabel) && numel(D.VarLabel) == size(Xtrain,2)
            lambda = D.VarLabel(:)';
        end
        sampleName = num2str(row);
        xLabelText = 'Variable index'; yLabelText = 'Intensity';
        if isfield(D,'DataInfo')
            sampleName = plsdm_data_info_sample_name(D.DataInfo,row);
            if ~isempty(D.DataInfo.xLabel), xLabelText = D.DataInfo.xLabel; end
            if ~isempty(D.DataInfo.yLabel), yLabelText = D.DataInfo.yLabel; end
        end
        targetMean = mean(Xtrain(targetRows,:),1);
        targetSd = std(Xtrain(targetRows,:),0,1);
        sampleRow = Xtrain(row,:);
        colSamp = [0.10 0.25 0.90];
        lwSamp = 2.4;
        figS = figure('Name',['GUI - spectra and residuals: ' sampleName], ...
            'NumberTitle','off','Color','w','Position',[80 120 1240 480]);
        ax1 = subplot(1,2,1,'Parent',figS); hold(ax1,'on'); box(ax1,'on'); grid(ax1,'on');
        set(ax1,'LineWidth',1.2,'FontName','Arial','FontSize',12,'XMinorTick','on','YMinorTick','on');
        [hMean,hBand] = plotMeanSdBand(ax1,lambda,targetMean,targetSd);
        hSample = plot(ax1,lambda,sampleRow,'-','Color',colSamp,'LineWidth',lwSamp);
        legend(ax1,[hMean hBand hSample],{'Target mean','Target mean \pm SD',sampleName},'Location','best');
        xlabel(ax1,xLabelText,'FontWeight','bold');
        ylabel(ax1,yLabelText,'FontWeight','bold');
        title(ax1,'TRAIN/CV spectra (target mean \pm SD + clicked sample)','Interpreter','tex');
        xlim(ax1,[min(lambda) max(lambda)]); axis(ax1,'tight');

        ax2 = subplot(1,2,2,'Parent',figS); hold(ax2,'on'); box(ax2,'on'); grid(ax2,'on');
        set(ax2,'LineWidth',1.2,'FontName','Arial','FontSize',12,'XMinorTick','on','YMinorTick','on');
        [okR,muR,sdR,Rrow,A] = computeGuiResidualReport(D.Model,Xtrain,sampleRow);
        if okR
            [hRm,hRb] = plotMeanSdBand(ax2,lambda,muR,sdR);
            hRx = plot(ax2,lambda,Rrow,'-','Color',colSamp,'LineWidth',lwSamp);
            legend(ax2,[hRm hRb hRx],{'Calibration residual mean','Mean \pm SD',sampleName},'Location','best');
            title(ax2,sprintf('TRAIN/CV residuals (A = %d) + clicked sample',A),'Interpreter','tex');
        else
            text(0.5,0.5,'Residual report unavailable','Parent',ax2, ...
                'Units','normalized','HorizontalAlignment','center');
            title(ax2,'Residuals unavailable','Interpreter','tex');
        end
        xlabel(ax2,xLabelText,'FontWeight','bold');
        ylabel(ax2,[yLabelText ' residual'],'Interpreter','none','FontWeight','bold');
        xlim(ax2,[min(lambda) max(lambda)]); axis(ax2,'tight');
        hold(ax1,'off'); hold(ax2,'off');
    end

    function [hMean,hBand] = plotMeanSdBand(ax,x,mu,sd)
        x = x(:)';
        mu = mu(:)';
        sd = sd(:)';
        upperBand = mu + sd;
        lowerBand = mu - sd;

        hBand = fill([x fliplr(x)],[upperBand fliplr(lowerBand)], ...
            [0.78 0.93 0.80],'FaceAlpha',0.35,'EdgeColor','none', ...
            'Parent',ax);
        plot(ax,x,upperBand,':','Color',[0.20 0.55 0.25], ...
            'LineWidth',1.1,'HandleVisibility','off');
        plot(ax,x,lowerBand,':','Color',[0.20 0.55 0.25], ...
            'LineWidth',1.1,'HandleVisibility','off');
        hMean = plot(ax,x,mu,'-','Color',[0.00 0.45 0.20], ...
            'LineWidth',2.2);
    end

    function [ok,muR,sdR,Rrow,A] = computeGuiResidualReport(M,Xtrain,sampleRow)
        ok = false; muR = []; sdR = []; Rrow = []; A = 1;
        if isempty(M) || ~isfield(M,'FinalModel')
            return;
        end
        FM = M.FinalModel;
        req = {'Xmean','Xstd','preprocessing','W','P'};
        for rr = 1:length(req)
            if ~isfield(FM,req{rr})
                return;
            end
        end
        if isfield(M,'LVopt') && ~isempty(M.LVopt)
            A = M.LVopt;
            if numel(A)>1, A = A(end); end
        end
        A = max(1,floor(A));
        W = FM.W; P = FM.P; p = size(Xtrain,2);
        [pW,aW] = size(W); [pP,aP] = size(P);
        if pW ~= p && aW == p, W = W.'; [pW,aW] = size(W); end
        if pP ~= p && aP == p, P = P.'; [pP,aP] = size(P); end
        A = min([A,aW,aP]);
        Xmean = FM.Xmean(:).';
        Xstd = FM.Xstd(:).';
        [okTrain,Rtrain] = localGuiComputeResiduals(Xtrain,W,P,Xmean,Xstd,FM.preprocessing,A);
        [okRow,RrowMat] = localGuiComputeResiduals(sampleRow,W,P,Xmean,Xstd,FM.preprocessing,A);
        if okTrain && okRow
            muR = mean(Rtrain,1);
            sdR = std(Rtrain,0,1);
            Rrow = RrowMat(1,:);
            ok = true;
        end
    end

    function [ok,R] = localGuiComputeResiduals(X,W,P,Xmean,Xstd,preprocessing,A)
        ok = false; R = [];
        try
            Xp = X;
            prep = lower(preprocessing);
            if strcmp(prep,'center') || strcmp(prep,'centered') || strcmp(prep,'autoscale')
                Xp = bsxfun(@minus,Xp,Xmean);
            end
            if strcmp(prep,'scale') || strcmp(prep,'scaled') || strcmp(prep,'autoscale')
                Xstd(abs(Xstd) <= eps) = 1;
                Xp = bsxfun(@rdivide,Xp,Xstd);
            end
            What = W(:,1:A);
            Phat = P(:,1:A);
            T = Xp*What;
            Xhatp = T*Phat';
            if strcmp(prep,'scale') || strcmp(prep,'scaled') || strcmp(prep,'autoscale')
                Xhatp = bsxfun(@times,Xhatp,Xstd);
            end
            if strcmp(prep,'center') || strcmp(prep,'centered') || strcmp(prep,'autoscale')
                Xhat = bsxfun(@plus,Xhatp,Xmean);
            else
                Xhat = Xhatp;
            end
            R = X - Xhat;
            ok = true;
        catch
            ok = false; R = [];
        end
    end

    function m = localGuiNanMean(x)
        x = x(:);
        x = x(isfinite(x));
        if isempty(x)
            m = NaN;
        else
            m = mean(x);
        end
        if ~isfinite(m) || abs(m) <= eps
            m = 1;
        end
    end

    function [ok,Q,f,Qlim,flim,Gtrue,titleStr] = getAcceptanceDataForPlot(S,mode)
        ok = false; Q=[]; f=[]; Qlim=[]; flim=[]; Gtrue=[]; titleStr='Acceptance area';
        M = [];
        if ~isempty(S.PLSDMmodel)
            M = S.PLSDMmodel;
        elseif ~isempty(S.CVmodel)
            M = S.CVmodel;
        end
        if isempty(M), return; end
        tgt = '';
        if strcmpi(mode,'Training') && isfield(M,'acp_train_q')
            Q = M.acp_train_q;
            f = M.acp_train_pf;
            Qlim = M.acp_train_Qlimit;
            flim = M.acp_train_flimit;
            if isfield(M,'ClassTrain'), Gtrue = M.ClassTrain; end
            titleStr = 'Acceptance Area - Training set';
            ok = true;
            return;
        end
        lv = getSelectedLVForConfusion(S);
        if isfield(M,'acp_cv_q') && (strcmpi(mode,'CV') || strcmpi(mode,'CV fold-wise') || strcmpi(mode,'CV mean'))
            Q = M.acp_cv_q;
            f = M.acp_cv_pf;
            Qlim = M.acp_cv_qlimitcv;
            flim = M.acp_cv_flimitcv;
            if isfield(M,'Compliance') && numel(M.Compliance) >= lv && isfield(M.Compliance{lv},'Gtrue')
                Gtrue = M.Compliance{lv}.Gtrue;
            end
            if strcmpi(mode,'CV mean')
                [Q,f,Qlim,flim,Gtrue] = aggregate_cv_mean_for_gui(Q,f,Qlim,flim,Gtrue,M);
                titleStr = 'Acceptance Area - Cross-validation mean';
            else
                titleStr = 'Acceptance Area - Cross-validation fold-wise';
            end
            ok = true;
            return;
        end
        if isfield(M,'Compliance') && numel(M.Compliance) >= lv && isfield(M.Compliance{lv},'Q')
            C = M.Compliance{lv};
            Q = C.Q; f = C.f; Qlim = C.Qcrit; flim = C.falpha; Gtrue = C.Gtrue;
            if strcmpi(mode,'CV mean')
                [Q,f,Qlim,flim,Gtrue] = aggregate_cv_mean_for_gui(Q,f,Qlim,flim,Gtrue,M);
                titleStr = 'Acceptance Area - Cross-validation mean';
            else
                titleStr = 'Acceptance Area - Cross-validation fold-wise';
            end
            ok = true;
        end
    end

    function [Qm,fm,Qlimm,flimm,Gm] = aggregate_cv_mean_for_gui(Q,f,Qlim,flim,Gtrue,M)
        Q = Q(:); f = f(:); Qlim = Qlim(:); flim = flim(:); Gtrue = Gtrue(:);
        Qm = Q; fm = f; Qlimm = Qlim; flimm = flim; Gm = Gtrue;
        if isempty(Gtrue) || ~isfield(M,'ClassTrain') || ~isfield(M,'K')
            return;
        end
        idxT = find(Gtrue == 1);
        idxN = find(Gtrue ~= 1);
        ClassTrain = M.ClassTrain(:);
        nUnt = length(find(ClassTrain ~= 1));
        K = M.K;
        if isempty(K) || K < 1 || nUnt < 1 || length(idxN) ~= nUnt*K
            return;
        end
        nt = length(idxT);
        Qm = zeros(nt+nUnt,1);
        fm = zeros(nt+nUnt,1);
        Qlimm = zeros(nt+nUnt,1);
        flimm = zeros(nt+nUnt,1);
        Gm = [ones(nt,1); 2*ones(nUnt,1)];
        for i = 1:nt
            ii = idxT(i);
            Qm(i) = Q(ii); fm(i) = f(ii); Qlimm(i) = Qlim(ii); flimm(i) = flim(ii);
        end
        for j = 1:nUnt
            ids = zeros(K,1);
            for kk = 1:K
                ids(kk) = idxN((kk-1)*nUnt+j);
            end
            row = nt+j;
            Qm(row) = mean(Q(ids));
            fm(row) = mean(f(ids));
            Qlimm(row) = mean(Qlim(ids));
            flimm(row) = mean(flim(ids));
        end
    end

    function onExportAcceptanceFigure(hObj,ev)
        S = guidata(hObj);
        modeList = get(S.popupAcceptanceMode,'String');
        mode = modeList{get(S.popupAcceptanceMode,'Value')};
        showLabels = get(S.chkPlotLabels,'Value') == 1;
        if isempty(S.PLSDMmodel) && isempty(S.CVmodel)
            errordlg('No acceptance plot available.','Export acceptance');
            return;
        end
        ffig = figure('Color','w','Name',['PLS-DM acceptance - ' mode],'NumberTitle','off');
        ax = axes('Parent',ffig);
        [ok,Q,fv,Qlim,flim,Gtrue,titleStr] = getAcceptanceDataForPlot(S,mode);
        if ok
            Mplot = getActiveModelForAcceptance(S);
            sampleLabels = getAcceptanceSampleLabels(S,Mplot,mode,Gtrue,numel(Q));
            if strcmpi(mode,'Training') && isRobustOutlierModel(Mplot)
                robustData = plsdm_plot_robust_training_acceptance_gui(ax,Q,fv,Qlim,flim,Gtrue, ...
                    Mplot.FinalModel.QlimitO,Mplot.FinalModel.flimitO,showLabels,sampleLabels);
                installRobustAcceptanceClickOnAxes(ax,S,Q,fv,Qlim,flim,Gtrue,robustData,mode);
            else
                markerSpec = getAcceptanceMarkerSpec(S,mode,Q,Gtrue);
                plsdm_plot_acceptance_area(ax,Q,fv,Qlim,flim,Gtrue,titleStr,showLabels,sampleLabels,markerSpec);
                installAcceptanceClickOnAxes(ax,S,Q,fv,Qlim,flim,Gtrue,titleStr,mode,markerSpec);
            end
        else
            title(ax,'Unavailable');
        end
    end

    function plotExternalCVDiagnostics(S)
        M = getCVModelForPlot(S);
        if isempty(M)
            return;
        end
        f1 = figure('Color','w','Name','PLS-DM CV limit variation','NumberTitle','off', ...
            'Position',[150 110 820 560]);
        ax1 = axes('Parent',f1);
        hold(ax1,'on'); box(ax1,'on'); grid(ax1,'on');
        set(ax1,'LineWidth',1.2,'FontName','Arial','FontSize',12, ...
            'XMinorTick','on','YMinorTick','on');
        lv = getSelectedLVForConfusion(S);
        qv = getCVLimitVectorForGUI(M,lv,'Q');
        fv = getCVLimitVectorForGUI(M,lv,'F');
        if isempty(qv) && isempty(fv) && isfield(S,'PLSDMmodel') && ~isempty(S.PLSDMmodel)
            qv = getCVLimitVectorForGUI(S.PLSDMmodel,lv,'Q');
            fv = getCVLimitVectorForGUI(S.PLSDMmodel,lv,'F');
            if ~isempty(qv) || ~isempty(fv)
                M = S.PLSDMmodel;
            end
        end
        Klim = max([length(qv(:)) length(fv(:)) 1]);
        if ~isempty(qv)
            qn = qv(:)./localGuiNanMean(qv(:));
            plot(ax1,1:length(qn),qn,'-o','Color',[0.10 0.35 0.85], ...
                'MarkerFaceColor',[0.10 0.35 0.85],'MarkerEdgeColor',[0 0 0], ...
                'LineWidth',2.0,'MarkerSize',8);
        end
        if ~isempty(fv)
            fn = fv(:)./localGuiNanMean(fv(:));
            plot(ax1,1:length(fn),fn,'-s','Color',[0.80 0.25 0.10], ...
                'MarkerFaceColor',[0.80 0.25 0.10],'MarkerEdgeColor',[0 0 0], ...
                'LineWidth',2.0,'MarkerSize',8);
        end
        if isempty(qv) && isempty(fv)
            text(0.5,0.5,'Fold-wise CV limits unavailable for this saved model.', ...
                'Parent',ax1,'Units','normalized','HorizontalAlignment','center', ...
                'FontSize',11,'Color',[0.35 0.35 0.35]);
        end
        yvals = get(ax1,'YLim');
        allY = [1];
        if exist('qn','var'), allY = [allY; qn(:)]; end
        if exist('fn','var'), allY = [allY; fn(:)]; end
        allY = allY(isfinite(allY));
        if ~isempty(allY)
            ymin = min(allY); ymax = max(allY); yr = ymax-ymin; if yr <= 0, yr = 0.2; end
            ylim(ax1,[max(0,ymin-0.20*yr) ymax+0.20*yr]);
        else
            ylim(ax1,yvals);
        end
        if Klim == 1, xlim(ax1,[0.5 1.5]); else xlim(ax1,[1 Klim]); end
        axes(ax1);
        xlabel('CV fold','FontWeight','bold');
        ylabel('Limit / mean limit','FontWeight','bold');
        title('Fold-to-fold limit variation','FontWeight','bold');
        lg = legend({'Q limit','PF limit'},'Location','Best');
        set(lg,'Box','off','FontSize',10);

        f2 = figure('Color','w','Name','PLS-DM CV performance by fold','NumberTitle','off', ...
            'Position',[190 130 820 560]);
        ax2 = axes('Parent',f2);
        plotCVFoldPerformance(ax2,M,lv);
    end

    function v = getCVLimitVectorForGUI(M,lv,whichLimit)
        v = [];
        if strcmpi(whichLimit,'Q')
            fieldName = 'Qlims_perLV';
            scalarName = 'acp_cv_qlimitcv';
        else
            fieldName = 'flimits_perLV';
            scalarName = 'acp_cv_flimitcv';
        end
        if isfield(M,fieldName)
            tmp = M.(fieldName);
            if iscell(tmp) && numel(tmp) >= lv
                v = tmp{lv};
                return;
            elseif ~iscell(tmp) && size(tmp,2) >= lv
                v = tmp(:,lv);
                return;
            end
        end
        if isfield(M,'kfoldmodel') && isfield(M.kfoldmodel,fieldName)
            tmp = M.kfoldmodel.(fieldName);
            if iscell(tmp) && numel(tmp) >= lv
                v = tmp{lv};
                return;
            elseif ~iscell(tmp) && size(tmp,2) >= lv
                v = tmp(:,lv);
                return;
            end
        end
        if isfield(M,scalarName)
            tmp = M.(scalarName);
            if numel(tmp) > 1
                v = tmp(:);
            end
        end
    end

    function plotCVFoldPerformance(ax,M,lv)
        axes(ax); cla; hold on; box on; grid on;
        set(ax,'LineWidth',1.2,'FontName','Arial','FontSize',12, ...
            'XMinorTick','on','YMinorTick','on');
        if isempty(M)
            axes(ax); title('CV fold performance unavailable');
            hold off; return;
        end
        if nargin < 3 || isempty(lv)
            lv = 1;
            if isfield(M,'LVopt') && ~isempty(M.LVopt), lv = M.LVopt; if numel(lv)>1, lv = lv(end); end; end
        end
        accepted = [];
        Gtrue = [];
        if isfield(M,'acp_cv_q') && isfield(M,'acp_cv_pf') && isfield(M,'acp_cv_qlimitcv') && isfield(M,'acp_cv_flimitcv')
            Q = M.acp_cv_q(:);
            f = M.acp_cv_pf(:);
            Qlim = M.acp_cv_qlimitcv(:);
            flim = M.acp_cv_flimitcv(:);
            if isfield(M,'Compliance') && ~isempty(M.Compliance) && numel(M.Compliance) >= lv && isfield(M.Compliance{lv},'Gtrue')
                Gtrue = M.Compliance{lv}.Gtrue(:);
            elseif isfield(M,'ClassTrain')
                Gtrue = M.ClassTrain(:);
            else
                Gtrue = ones(size(Q));
            end
            if numel(Qlim)==1, Qlim = repmat(Qlim,numel(Q),1); end
            if numel(flim)==1, flim = repmat(flim,numel(Q),1); end
            n = min([numel(Q) numel(f) numel(Qlim) numel(flim) numel(Gtrue)]);
            Q = Q(1:n); f = f(1:n); Qlim = Qlim(1:n); flim = flim(1:n); Gtrue = Gtrue(1:n);
            accepted = (Q <= Qlim) & (f >= flim);
        elseif isfield(M,'Compliance') && numel(M.Compliance) >= lv && ~isempty(M.Compliance{lv}) && ...
                isfield(M.Compliance{lv},'Gtrue') && isfield(M.Compliance{lv},'Gpred_bin')
            Gtrue = M.Compliance{lv}.Gtrue(:);
            accepted = M.Compliance{lv}.Gpred_bin(:) == 1;
        else
            text(0.5,0.5,'Fold-wise CV performance unavailable for this saved model.', ...
                'Parent',ax,'Units','normalized','HorizontalAlignment','center', ...
                'FontSize',11,'Color',[0.35 0.35 0.35]);
            title('Performance by fold','FontWeight','bold');
            hold off; return;
        end
        n = min(numel(accepted),numel(Gtrue));
        accepted = accepted(1:n);
        Gtrue = Gtrue(1:n);
        K = 1;
        if isfield(M,'K') && ~isempty(M.K), K = M.K; end
        foldIndex = ones(n,1);
        idxT = find(Gtrue == 1);
        idxN = find(Gtrue ~= 1);
        for ii = 1:length(idxT)
            foldIndex(idxT(ii)) = mod(ii-1,K)+1;
        end
        if isfield(M,'ClassTrain')
            nUnt = length(find(M.ClassTrain(:) ~= 1));
        else
            nUnt = 0;
        end
        if nUnt > 0 && length(idxN) == nUnt*K
            for kk = 1:K
                for jj = 1:nUnt
                    foldIndex(idxN((kk-1)*nUnt+jj)) = kk;
                end
            end
        else
            for ii = 1:length(idxN)
                foldIndex(idxN(ii)) = mod(ii-1,K)+1;
            end
        end
        sen = nan(K,1); spe = nan(K,1); eff = nan(K,1);
        for kk = 1:K
            ids = find(foldIndex == kk);
            gt = Gtrue(ids); ac = accepted(ids);
            TP = sum(ac & (gt==1)); FN = sum((~ac) & (gt==1));
            TN = sum((~ac) & (gt~=1)); FP = sum(ac & (gt~=1));
            if TP+FN > 0, sen(kk)=TP/(TP+FN); end
            if TN+FP > 0, spe(kk)=TN/(TN+FP); end
            if isfinite(sen(kk)) && isfinite(spe(kk)), eff(kk)=sqrt(sen(kk)*spe(kk)); end
        end
        folds = (1:K)';
        plot(ax,folds,sen,'-o','Color',[0.10 0.60 0.20], ...
            'MarkerFaceColor',[0.10 0.60 0.20],'MarkerEdgeColor',[0 0 0], ...
            'LineWidth',2.0,'MarkerSize',8);
        caseType = 'rigorous';
        if isfield(M,'caseType') && ~isempty(M.caseType), caseType = M.caseType; end
        if strcmpi(caseType,'compliant')
            plot(ax,folds,spe,'-s','Color',[0.85 0.15 0.20], ...
                'MarkerFaceColor',[0.85 0.15 0.20],'MarkerEdgeColor',[0 0 0], ...
                'LineWidth',2.0,'MarkerSize',8);
            plot(ax,folds,eff,'-d','Color',[0.20 0.45 0.80], ...
                'MarkerFaceColor',[0.20 0.45 0.80],'MarkerEdgeColor',[0 0 0], ...
                'LineWidth',2.0,'MarkerSize',8);
            axes(ax); lg = legend({'Sensitivity','Specificity','Efficiency'},'Location','Best');
        else
            axes(ax); lg = legend({'Sensitivity'},'Location','Best');
        end
        set(lg,'Box','off','FontSize',10);
        axes(ax);
        xlabel('CV fold','FontWeight','bold');
        ylabel('Metric value','FontWeight','bold');
        title('Performance by fold','FontWeight','bold');
        ylim([0 1.05]);
        if K == 1, xlim([0.5 1.5]); else xlim([1 K]); end
        hold off;
    end

    function plotExternalConfusionMatrices(S)
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
            models = S.PLSDMmodelAll;
            classes = zeros(numel(models),1);
            for ii = 1:numel(models)
                if isfield(models{ii},'TargetClass')
                    classes(ii) = models{ii}.TargetClass;
                else
                    classes(ii) = ii;
                end
            end
            if ~isempty(S.PLSDMmodel)
                plotMulticlassConfusionFigure(S,models,classes,'Training all-class confusion','train');
            end
            if ~isempty(S.CVmodelAll)
                plotMulticlassConfusionFigure(S,S.CVmodelAll,classes,'CV k-fold all-class confusion','cv_foldwise');
                plotMulticlassConfusionFigure(S,S.CVmodelAll,classes,'CV mean all-class confusion','cv');
            end
        else
            lv = getSelectedLVForConfusion(S);
            [TPtr,FPtr,TNtr,FNtr,okTR] = extract_final_confusion_values(S.PLSDMmodel,lv);
            if okTR
                f1 = figure('Color','w','Name','Training confusion matrix','NumberTitle','off');
                ax1 = axes('Parent',f1);
                plotConfusionColorMap(ax1,TPtr,FPtr,TNtr,FNtr,['Training - LV = ' num2str(lv)]);
            end
            [TPcv,FPcv,TNcv,FNcv,okCV] = extract_confusion_from_model(S.CVmodel,lv);
            if okCV
                f2 = figure('Color','w','Name','CV k-fold confusion matrix','NumberTitle','off');
                ax2 = axes('Parent',f2);
                plotConfusionColorMap(ax2,TPcv,FPcv,TNcv,FNcv,['CV k-fold - LV = ' num2str(lv)]);
            end
            [TPm,FPm,TNm,FNm,okM] = extract_cv_mean_confusion(S,lv);
            if okM
                f3 = figure('Color','w','Name','CV mean confusion matrix','NumberTitle','off');
                ax3 = axes('Parent',f3);
                plotConfusionColorMap(ax3,TPm,FPm,TNm,FNm,['CV mean - LV = ' num2str(lv)]);
            end
        end
    end

    function plotMulticlassConfusionFigure(S,models,classes,figName,modeName)
        Ctrue = S.ClassTrain(:);
        [mat,rowLabels,colLabels] = compute_allclass_confusion(S,models,classes,modeName);
        f = figure('Color','w','Name',figName,'NumberTitle','off');
        ax = axes('Parent',f);
        plotMatrixHeatmapNoColorbar(ax,mat,rowLabels,colLabels,figName);
        if isempty(Ctrue) %#ok<BDLGI>
        end
    end

    function [mat,rowLabels,colLabels] = compute_allclass_confusion(S,models,classes,modeName)
        if strcmpi(modeName,'cv_foldwise')
            [mat,rowLabels,colLabels] = compute_allclass_confusion_foldwise(S,models,classes);
            return;
        end
        trueClasses = unique(S.ClassTrain(:));
        nC = length(trueClasses);
        nM = length(models);
        mat = zeros(nC,nM+2);
        rowLabels = cell(1,nC);
        colLabels = cell(1,nM+2);
        for i = 1:nC
            rowLabels{i} = num2str(trueClasses(i));
        end
        for j = 1:nM
            colLabels{j} = num2str(classes(j));
        end
        colLabels{nM+1} = 'Not assigned';
        colLabels{nM+2} = 'Ambiguous';
        acc = false(length(S.ClassTrain),nM);
        for j = 1:nM
            M = models{j};
            accj = getModelAcceptedByOriginalSample(M,S,modeName,j);
            if length(accj) == length(S.ClassTrain)
                acc(:,j) = accj(:) == 1;
            end
        end
        for i = 1:length(S.ClassTrain)
            r = find(trueClasses == S.ClassTrain(i));
            nacc = sum(acc(i,:));
            if nacc == 0
                cidx = nM+1;
            elseif nacc > 1
                cidx = nM+2;
            else
                cidx = find(acc(i,:));
            end
            mat(r,cidx) = mat(r,cidx)+1;
        end
    end

    function [mat,rowLabels,colLabels] = compute_allclass_confusion_foldwise(S,models,classes)
        trueClasses = unique(S.ClassTrain(:));
        nC = length(trueClasses);
        nM = length(models);
        mat = zeros(nC,nM+2);
        rowLabels = cell(1,nC);
        colLabels = cell(1,nM+2);
        for i = 1:nC
            rowLabels{i} = num2str(trueClasses(i));
        end
        for j = 1:nM
            colLabels{j} = num2str(classes(j));
        end
        colLabels{nM+1} = 'Not assigned';
        colLabels{nM+2} = 'Ambiguous';

        K = get_allclass_cv_K(models);
        if K < 1, K = 1; end
        n = length(S.ClassTrain);
        acc = false(n,K,nM);
        for j = 1:nM
            accj = getModelAcceptedByOriginalSampleFoldwise(models{j},S,j,K);
            if size(accj,1) == n
                Kj = min(K,size(accj,2));
                acc(:,1:Kj,j) = accj(:,1:Kj) == 1;
            end
        end

        for kk = 1:K
            for i = 1:n
                r = find(trueClasses == S.ClassTrain(i));
                nacc = sum(acc(i,kk,:));
                if nacc == 0
                    cidx = nM+1;
                elseif nacc > 1
                    cidx = nM+2;
                else
                    cidx = find(reshape(acc(i,kk,:),1,nM));
                end
                mat(r,cidx) = mat(r,cidx)+1;
            end
        end
    end

    function K = get_allclass_cv_K(models)
        K = 1;
        for jj = 1:length(models)
            M = models{jj};
            if isfield(M,'K') && ~isempty(M.K)
                K = max(K,round(M.K));
            end
        end
    end

    function accFold = getModelAcceptedByOriginalSampleFoldwise(M,S,modelIndex,K)
        n = length(S.ClassTrain);
        accFold = false(n,K);
        if isempty(M) || ~isstruct(M)
            accFold = [];
            return;
        end
        lv = 1;
        if isfield(S,'SelectedLVByClass') && numel(S.SelectedLVByClass) >= modelIndex
            lv = S.SelectedLVByClass(modelIndex);
        elseif isfield(M,'LVopt') && ~isempty(M.LVopt)
            lv = M.LVopt; if numel(lv)>1, lv = lv(end); end
        else
            lv = get(S.popupLVopt,'Value');
        end
        if ~isfield(M,'Compliance') || numel(M.Compliance) < lv || isempty(M.Compliance{lv}) || ...
                ~isfield(M.Compliance{lv},'Gpred_bin') || ~isfield(M.Compliance{lv},'Gtrue')
            accFold = [];
            return;
        end
        pred = M.Compliance{lv}.Gpred_bin(:) == 1;
        gtrue = M.Compliance{lv}.Gtrue(:);
        if length(pred) == n
            accFold = repmat(pred(:),1,K);
            return;
        end

        classOne = [];
        if isfield(M,'ClassTrain') && length(M.ClassTrain) == n
            classOne = M.ClassTrain(:);
        elseif isfield(M,'TargetClass')
            classOne = double(S.ClassTrain(:) == M.TargetClass);
            classOne(classOne == 0) = 2;
        end
        if isempty(classOne)
            accFold = [];
            return;
        end

        targetRows = find(classOne == 1);
        nonRows = find(classOne ~= 1);
        idxT = find(gtrue == 1);
        idxN = find(gtrue ~= 1);

        for ii = 1:min(length(idxT),length(targetRows))
            accFold(targetRows(ii),:) = pred(idxT(ii));
        end

        nUnt = length(nonRows);
        if nUnt > 0 && ~isempty(idxN)
            if mod(length(idxN),nUnt) == 0
                Klocal = length(idxN)/nUnt;
                Kuse = min(K,Klocal);
                for jj = 1:nUnt
                    ids = idxN(jj:nUnt:length(idxN));
                    for kk = 1:Kuse
                        accFold(nonRows(jj),kk) = pred(ids(kk));
                    end
                    if Kuse < K
                        accFold(nonRows(jj),Kuse+1:K) = accFold(nonRows(jj),Kuse);
                    end
                end
            else
                for jj = 1:min(nUnt,length(idxN))
                    accFold(nonRows(jj),:) = pred(idxN(jj));
                end
            end
        end
    end

    function plotMatrixHeatmapNoColorbar(ax,mat,rowLabels,colLabels,ttl)
        axes(ax); cla(ax);
        imagesc(mat,'Parent',ax);
        colormap(plsdm_blue_colormap(64));
        maxv = max(mat(:));
        if isempty(maxv) || ~isfinite(maxv) || maxv <= 0, maxv = 1; end
        set(ax,'CLim',[0 maxv]);
        title(ax,ttl,'FontWeight','bold');
        set(ax,'XTick',1:length(colLabels),'XTickLabel',colLabels, ...
            'YTick',1:length(rowLabels),'YTickLabel',rowLabels, ...
            'FontName','Arial','FontSize',9);
        xlabel(ax,'Predicted class','FontWeight','bold');
        ylabel(ax,'True class','FontWeight','bold');
        for ii = 1:size(mat,1)
            for jj = 1:size(mat,2)
                if mat(ii,jj) > 0.55*maxv
                    tcol = [1 1 1];
                else
                    tcol = [0.05 0.05 0.05];
                end
                text(jj,ii,num2str(mat(ii,jj)),'Parent',ax, ...
                    'HorizontalAlignment','center','Color',tcol,'FontWeight','bold');
            end
        end
        axis(ax,'tight'); box(ax,'on');
    end

    function [TP,FP,TN,FN,ok] = extract_cv_mean_confusion(S,lv)
        TP = 0; FP = 0; TN = 0; FN = 0; ok = false;
        if isempty(S.CVmodel) || isempty(S.ClassTrain)
            return;
        end
        acc = getModelAcceptedByOriginalSample(S.CVmodel,S,'cv',1);
        if length(acc) ~= length(S.ClassTrain)
            return;
        end
        M = S.CVmodel;
        if isfield(M,'TargetClass')
            isTarget = S.ClassTrain(:) == M.TargetClass;
        elseif isfield(M,'ClassTrain') && length(M.ClassTrain) == length(S.ClassTrain)
            isTarget = M.ClassTrain(:) == 1;
        else
            isTarget = S.ClassTrain(:) == 1;
        end
        acc = acc(:) == 1;
        TP = sum(acc & isTarget);
        FN = sum((~acc) & isTarget);
        FP = sum(acc & (~isTarget));
        TN = sum((~acc) & (~isTarget));
        ok = true;
    end

    function updatePredictionText(hObj,msg)
        S = guidata(hObj);
        knownTxt = {};
        unkTxt   = {};

        if isempty(S.PLSDMmodel)
            knownTxt{end+1} = 'Fit or load a final model first.';
            unkTxt{end+1}   = 'Fit or load a final model first.';
        else
            if isfield(S.PLSDMmodel,'LVopt')
                knownTxt{end+1} = ['Final model available | LV: ' num2str(S.PLSDMmodel.LVopt)];
                unkTxt{end+1}   = ['Final model available | LV: ' num2str(S.PLSDMmodel.LVopt)];
            else
                knownTxt{end+1} = 'Final model available.';
                unkTxt{end+1}   = 'Final model available.';
            end
        end

        if isempty(S.Xval)
            knownTxt{end+1} = 'Xval/ClassVal: not imported';
        else
            knownTxt{end+1} = ['Known-class samples: ' num2str(size(S.Xval,1))];
        end
        if ~isempty(S.PLSDMvalidation)
            knownTxt{end+1} = 'Validation: completed';
            if isfield(S.PLSDMvalidation,'CVresults')
                C = S.PLSDMvalidation.CVresults;
                if isfield(C,'sensitivity'), knownTxt{end+1} = ['SEN: ' num2str(C.sensitivity,4)]; end
                if isfield(C,'specificity'), knownTxt{end+1} = ['SPC: ' num2str(C.specificity,4)]; end
                if isfield(C,'efficiency'),  knownTxt{end+1} = ['EFF: ' num2str(C.efficiency,4)];  end
            end
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll) && length(S.PLSDMmodelAll) > 1
                knownTxt = appendKnownAllClassPredictionTable(knownTxt,S);
            else
                knownTxt = appendKnownPredictionTable(knownTxt,S);
            end
        end

        if isempty(S.Xunk)
            unkTxt{end+1} = 'Xunknown: not imported';
        else
            unkTxt{end+1} = ['Unknown samples: ' num2str(size(S.Xunk,1))];
        end
        if ~isempty(S.PLSDMpred)
            unkTxt{end+1} = 'Prediction: completed';
            if isfield(S.PLSDMpred,'counts')
                unkTxt{end+1} = ['Accepted: ' num2str(S.PLSDMpred.counts.accepted)];
                unkTxt{end+1} = ['Rejected: ' num2str(S.PLSDMpred.counts.rejected)];
            end
            if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll) && length(S.PLSDMmodelAll) > 1
                unkTxt = appendUnknownAllClassPredictionTable(unkTxt,S);
            else
                unkTxt = appendUnknownPredictionTable(unkTxt,S);
            end
        end

        if nargin >= 2 && ~isempty(msg)
            knownTxt = [knownTxt(:); {' '}; msg(:)];
            unkTxt   = [unkTxt(:);   {' '}; msg(:)];
        end

        if isfield(S,'txtKnownPrediction') && ~isempty(S.txtKnownPrediction) && ishandle(S.txtKnownPrediction)
            set(S.txtKnownPrediction,'String',knownTxt);
        end
        if isfield(S,'txtUnknownPrediction') && ~isempty(S.txtUnknownPrediction) && ishandle(S.txtUnknownPrediction)
            set(S.txtUnknownPrediction,'String',unkTxt);
        end
    end

    function txt = appendKnownPredictionTable(txt,S)
        if isempty(S.PLSDMvalidation) || ~isfield(S.PLSDMvalidation,'CVresults') || ...
                ~isfield(S.PLSDMvalidation.CVresults,'Gpred_bin')
            return;
        end
        pred = S.PLSDMvalidation.CVresults.Gpred_bin(:) == 1;
        if isfield(S.PLSDMvalidation,'OriginalClassVal')
            trueClass = S.PLSDMvalidation.OriginalClassVal(:);
        else
            trueClass = S.ClassVal(:);
        end
        targetClass = [];
        if isfield(S.PLSDMvalidation,'TargetClass'), targetClass = S.PLSDMvalidation.TargetClass; end
        txt{end+1} = ' ';
        txt{end+1} = 'Contingency table';
        txt{end+1} = 'Idx | True | Decision | Status';
        nshow = min(length(pred),200);
        for ii = 1:nshow
            if pred(ii), dec = 'accepted'; else dec = 'rejected'; end
            if ~isempty(targetClass)
                isT = trueClass(ii) == targetClass;
            else
                isT = S.PLSDMvalidation.ClassVal(ii) == 1;
            end
            if isT && pred(ii), st='TP'; elseif isT && ~pred(ii), st='FN *'; elseif ~isT && pred(ii), st='FP *'; else st='TN'; end
            txt{end+1} = sprintf('%3d | %4g | %-8s | %s',ii,trueClass(ii),dec,st);
        end
        if length(pred) > nshow
            txt{end+1} = ['... ' num2str(length(pred)-nshow) ' additional samples not shown'];
        end
    end

    function txt = appendKnownAllClassPredictionTable(txt,S)
        if isempty(S.Xval) || isempty(S.ClassVal) || ~isfield(S,'PLSDMmodelAll') || isempty(S.PLSDMmodelAll)
            return;
        end
        [accepted,classes] = computeAllClassAcceptedMatrix(S.Xval,S.PLSDMmodelAll);
        if isempty(accepted), return; end
        trueClass = S.ClassVal(:);
        n = min(size(accepted,1),length(trueClass));
        txt{end+1} = ' ';
        txt{end+1} = 'Contingency table';
        txt{end+1} = 'Idx | True | Accepted classes | Status';
        nshow = min(n,200);
        for ii = 1:nshow
            accIdx = find(accepted(ii,:));
            if isempty(accIdx)
                dec = 'none';
                st = 'not assigned *';
            elseif length(accIdx) > 1
                dec = local_join_numeric_list(classes(accIdx));
                st = 'ambiguous *';
            else
                dec = num2str(classes(accIdx));
                if trueClass(ii) == classes(accIdx)
                    st = 'correct';
                else
                    st = 'wrong *';
                end
            end
            txt{end+1} = sprintf('%3d | %4g | %-16s | %s',ii,trueClass(ii),dec,st);
        end
        if n > nshow
            txt{end+1} = ['... ' num2str(n-nshow) ' additional samples not shown'];
        end
    end

    function txt = appendUnknownPredictionTable(txt,S)
        if isempty(S.PLSDMpred) || ~isfield(S.PLSDMpred,'accepted')
            return;
        end
        pred = S.PLSDMpred.accepted(:) == 1;
        txt{end+1} = ' ';
        txt{end+1} = 'Contingency table';
        txt{end+1} = 'Idx | Decision';
        nshow = min(length(pred),200);
        for ii = 1:nshow
            if pred(ii), dec = 'accepted'; else dec = 'rejected'; end
            txt{end+1} = sprintf('%3d | %s',ii,dec);
        end
        if length(pred) > nshow
            txt{end+1} = ['... ' num2str(length(pred)-nshow) ' additional samples not shown'];
        end
    end

    function txt = appendUnknownAllClassPredictionTable(txt,S)
        if isempty(S.Xunk) || ~isfield(S,'PLSDMmodelAll') || isempty(S.PLSDMmodelAll)
            return;
        end
        [accepted,classes] = computeAllClassAcceptedMatrix(S.Xunk,S.PLSDMmodelAll);
        if isempty(accepted), return; end
        n = size(accepted,1);
        txt{end+1} = ' ';
        txt{end+1} = 'Contingency table';
        txt{end+1} = 'Idx | Accepted classes | Status';
        nshow = min(n,200);
        for ii = 1:nshow
            accIdx = find(accepted(ii,:));
            if isempty(accIdx)
                dec = 'none';
                st = 'not assigned';
            elseif length(accIdx) > 1
                dec = local_join_numeric_list(classes(accIdx));
                st = 'ambiguous';
            else
                dec = num2str(classes(accIdx));
                st = 'assigned';
            end
            txt{end+1} = sprintf('%3d | %-16s | %s',ii,dec,st);
        end
        if n > nshow
            txt{end+1} = ['... ' num2str(n-nshow) ' additional samples not shown'];
        end
    end

    function [accepted,classes] = computeAllClassAcceptedMatrix(X,models)
        nM = length(models);
        accepted = [];
        classes = zeros(1,nM);
        if isempty(X) || nM < 1, return; end
        accepted = false(size(X,1),nM);
        for jj = 1:nM
            Mj = models{jj};
            if isfield(Mj,'TargetClass') && ~isempty(Mj.TargetClass)
                classes(jj) = Mj.TargetClass;
            else
                classes(jj) = jj;
            end
            try
                Pj = [];
                evalc('Pj = plsdm_predict_unknown(X, Mj);');
                if isfield(Pj,'accepted')
                    accepted(:,jj) = Pj.accepted(:) == 1;
                elseif isfield(Pj,'Gpred_bin')
                    accepted(:,jj) = Pj.Gpred_bin(:) == 1;
                end
            catch
            end
        end
    end

    function s = local_join_numeric_list(v)
        s = '';
        for ii = 1:length(v)
            if ii == 1
                s = num2str(v(ii));
            else
                s = [s ',' num2str(v(ii))];
            end
        end
    end

    function updateKnownValidationConfusion(hObj)
        S = guidata(hObj);
        if ~isfield(S,'axValConf') || isempty(S.axValConf) || ~ishandle(S.axValConf)
            return;
        end
        if isempty(S.PLSDMvalidation) || ~isfield(S.PLSDMvalidation,'CVresults')
            resetSingleConfusionAxis(S.axValConf,'Known-class validation');
            return;
        end
        C = S.PLSDMvalidation.CVresults;
        if isfield(C,'TP') && isfield(C,'FP') && isfield(C,'TN') && isfield(C,'FN')
            TP = C.TP; FP = C.FP; TN = C.TN; FN = C.FN;
            if numel(TP) > 1, TP = TP(end); end
            if numel(FP) > 1, FP = FP(end); end
            if numel(TN) > 1, TN = TN(end); end
            if numel(FN) > 1, FN = FN(end); end
            plotConfusionColorMap(S.axValConf, TP, FP, TN, FN, 'Known-class validation');
        else
            resetSingleConfusionAxis(S.axValConf,'Known-class validation');
        end
    end

    function PLSDMvalidation = enrich_known_validation_result(PLSDMvalidation, Xval, ClassVal, PLSDMmodel)
        
        LV = PLSDMmodel.LVopt;
        if numel(LV) > 1
            LV = LV(end);
        end
        PLSmodel = PLSDMmodel.FinalModel;
        Qlimit = PLSDMmodel.FinalModel.Qlimit;
        flimit = PLSDMmodel.FinalModel.flimit;
        PVresult = pls_predict(Xval, PLSmodel, LV);
        CVresults = classify_pls_dm(PVresult.Q, PVresult.f, Qlimit, flimit, ClassVal);
        PLSDMvalidation.PVresult = PVresult;
        PLSDMvalidation.CVresults = CVresults;
        PLSDMvalidation.Xval = Xval;
        PLSDMvalidation.ClassVal = ClassVal(:);
        PLSDMvalidation.LV = LV;
    end

    function updateMetricsText(hObj)
        S = guidata(hObj);
        M = getCVModelForPlot(S);
        txt = {};
        if isempty(M) || ~isstruct(M)
            set(S.txtMetrics,'String',{'No CV result available.'});
            return;
        end
        lv = get(S.popupLVopt,'Value');
        if isfield(M,'LVopt') && ~isempty(M.LVopt) && isempty(S.CVmodel)
            lv = M.LVopt;
        end
        txt{end+1} = ['Selected LV: ' num2str(lv)];
        if isfield(M,'caseType'), txt{end+1} = ['Case type: ' M.caseType]; end
        if isfield(M,'sen_all') && numel(M.sen_all) >= lv, txt{end+1} = ['CV sensitivity: ' num2str(M.sen_all(lv),4)]; end
        if isfield(M,'spec_all') && numel(M.spec_all) >= lv, txt{end+1} = ['CV specificity: ' num2str(M.spec_all(lv),4)]; end
        if isfield(M,'eff_all') && numel(M.eff_all) >= lv, txt{end+1} = ['CV efficiency: ' num2str(M.eff_all(lv),4)]; end
        if isfield(M,'precision_all') && numel(M.precision_all) >= lv, txt{end+1} = ['CV precision: ' num2str(M.precision_all(lv),4)]; end
        if isfield(M,'f1score_all') && numel(M.f1score_all) >= lv, txt{end+1} = ['CV F1: ' num2str(M.f1score_all(lv),4)]; end
        if isfield(M,'acc_all') && numel(M.acc_all) >= lv, txt{end+1} = ['CV accuracy: ' num2str(M.acc_all(lv),4)]; end
        if isfield(M,'TP_all') && numel(M.TP_all) >= lv, txt{end+1} = ['TP: ' num2str(M.TP_all(lv))]; end
        if isfield(M,'FP_all') && numel(M.FP_all) >= lv, txt{end+1} = ['FP: ' num2str(M.FP_all(lv))]; end
        if isfield(M,'TN_all') && numel(M.TN_all) >= lv, txt{end+1} = ['TN: ' num2str(M.TN_all(lv))]; end
        if isfield(M,'FN_all') && numel(M.FN_all) >= lv, txt{end+1} = ['FN: ' num2str(M.FN_all(lv))]; end
        set(S.txtMetrics,'String',txt);
    end

    function updateConfusionText(hObj)
        S = guidata(hObj);
        if ~isfield(S,'axConfTrain') || isempty(S.axConfTrain) || ~ishandle(S.axConfTrain) || ...
           ~isfield(S,'axConfCV') || isempty(S.axConfCV) || ~ishandle(S.axConfCV)
            return;
        end
        if isempty(S.PLSDMmodel)
            resetConfusionAxes(S);
            return;
        end

        lv = getSelectedLVForConfusion(S);

        [TPcv,FPcv,TNcv,FNcv,okCV] = extract_confusion_from_model(S.CVmodel, lv);
        [TPtr,FPtr,TNtr,FNtr,okTR] = extract_final_confusion_values(S.PLSDMmodel, lv);

        if okTR
            plotConfusionColorMap(S.axConfTrain, TPtr, FPtr, TNtr, FNtr, ['Training - LV = ' num2str(lv)]);
        else
            resetSingleConfusionAxis(S.axConfTrain,'Training');
        end

        if okCV
            plotConfusionColorMap(S.axConfCV, TPcv, FPcv, TNcv, FNcv, ['CV - LV = ' num2str(lv)]);
        else
            resetSingleConfusionAxis(S.axConfCV,'CV');
        end
    end

    function updateModelText(hObj)
        S = guidata(hObj);
        M = S.PLSDMmodel;
        txt = {};
        txt = appendCVSummaryLines(txt,S);
        txt{end+1} = ' ';
        if isempty(M)
            txt{end+1} = 'Final model: not fitted yet.';
            set(S.txtModel,'String',txt);
            return;
        end
        txt{end+1} = 'Final PLS-DM model';
        if isfield(M,'model'), txt{end+1} = ['Model: ' M.model]; end
        if isfield(M,'preprocessing'), txt{end+1} = ['Preprocessing: ' preprocessing_display_name(M.preprocessing)]; end
        if isfield(M,'K'), txt{end+1} = ['K-fold: ' num2str(M.K)]; end
        if isfield(M,'LV'), txt{end+1} = ['Max LV evaluated: ' num2str(M.LV)]; end
        if isfield(M,'LVopt'), txt{end+1} = ['LV used in final model: ' num2str(M.LVopt)]; end
        if isfield(M,'conflev'), txt{end+1} = ['Confidence: ' num2str(M.conflev)]; end
        if isfield(M,'alpha'), txt{end+1} = ['Smoothing coefficient: ' num2str(M.alpha)]; end
        if isfield(M,'FinalModel') && isfield(M.FinalModel,'Qlimit')
            txt{end+1} = ['Q limit: ' num2str(M.FinalModel.Qlimit,4)];
        end
        if isfield(M,'FinalModel') && isfield(M.FinalModel,'flimit')
            txt{end+1} = ['f limit: ' num2str(M.FinalModel.flimit,4)];
        end
        txt = appendSampleStatusSummary(txt,S);
        set(S.txtModel,'String',txt);
    end

    function txt = appendSampleStatusSummary(txt,S)
        txt{end+1} = ' ';
        txt{end+1} = 'Sample status table';
        if isempty(S.ClassTrain)
            txt{end+1} = '  ClassTrain not available.';
            return;
        end
        if isfield(S,'PLSDMmodelAll') && ~isempty(S.PLSDMmodelAll)
            txt = appendAllClassSampleStatus(txt,S,'Training final models',S.PLSDMmodelAll,'train');
            if isfield(S,'CVmodelAll') && ~isempty(S.CVmodelAll)
                txt = appendAllClassSampleStatus(txt,S,'Cross-validation models',S.CVmodelAll,'cv');
            end
        elseif ~isempty(S.PLSDMmodel)
            txt = appendOneClassSampleStatus(txt,S,'Training final model',S.PLSDMmodel,'train');
            if ~isempty(S.CVmodel)
                txt = appendOneClassSampleStatus(txt,S,'Cross-validation model',S.CVmodel,'cv');
            end
        else
            txt{end+1} = '  Fit final model to show sample status.';
        end
        txt{end+1} = '  * = sample requiring attention';
    end

    function txt = appendAllClassSampleStatus(txt,S,sectionTitle,models,modeName)
        n = length(S.ClassTrain);
        nModels = length(models);
        classes = zeros(nModels,1);
        acceptedMat = zeros(n,nModels);
        for jj = 1:nModels
            Mj = models{jj};
            if isfield(Mj,'TargetClass')
                classes(jj) = Mj.TargetClass;
            else
                classes(jj) = jj;
            end
            acc = getModelAcceptedByOriginalSample(Mj,S,modeName,jj);
            if length(acc) == n
                acceptedMat(:,jj) = acc(:);
            end
        end
        txt{end+1} = ['  ' sectionTitle];
        txt{end+1} = '  Idx | True | Accepted classes | Status';
        maxRows = min(n,200);
        for ii = 1:maxRows
            ids = find(acceptedMat(ii,:) == 1);
            if isempty(ids)
                acceptedText = 'none';
                statusText = 'not assigned *';
            else
                acceptedClasses = classes(ids);
                acceptedText = vector_to_csv_text(acceptedClasses);
                if length(ids) > 1
                    if any(acceptedClasses == S.ClassTrain(ii))
                        statusText = 'ambiguous *';
                    else
                        statusText = 'ambiguous/misclassified *';
                    end
                elseif acceptedClasses(1) == S.ClassTrain(ii)
                    statusText = 'correct';
                else
                    statusText = 'misclassified *';
                end
            end
            txt{end+1} = sprintf('  %3d | %4g | %-16s | %s',ii,S.ClassTrain(ii),acceptedText,statusText);
        end
        if n > maxRows
            txt{end+1} = ['  ... ' num2str(n-maxRows) ' additional samples not shown'];
        end
    end

    function txt = appendOneClassSampleStatus(txt,S,sectionTitle,M,modeName)
        n = length(S.ClassTrain);
        acc = getModelAcceptedByOriginalSample(M,S,modeName,1);
        if length(acc) ~= n
            txt{end+1} = ['  ' sectionTitle ': sample-level status unavailable.'];
            return;
        end
        targetClass = [];
        if isfield(M,'TargetClass'), targetClass = M.TargetClass; end
        txt{end+1} = ['  ' sectionTitle];
        txt{end+1} = '  Idx | True group | Decision | Status';
        maxRows = min(n,200);
        for ii = 1:maxRows
            isTarget = false;
            if ~isempty(targetClass)
                isTarget = S.ClassTrain(ii) == targetClass;
            elseif isfield(M,'ClassTrain') && length(M.ClassTrain) == n
                isTarget = M.ClassTrain(ii) == 1;
            end
            if acc(ii)
                decisionText = 'accepted';
            else
                decisionText = 'rejected';
            end
            if isTarget && acc(ii)
                statusText = 'TP';
            elseif isTarget && ~acc(ii)
                statusText = 'FN *';
            elseif ~isTarget && acc(ii)
                statusText = 'FP *';
            else
                statusText = 'TN';
            end
            if isTarget, groupText = 'target'; else, groupText = 'non-target'; end
            txt{end+1} = sprintf('  %3d | %-10s | %-8s | %s',ii,groupText,decisionText,statusText);
        end
        if n > maxRows
            txt{end+1} = ['  ... ' num2str(n-maxRows) ' additional samples not shown'];
        end
    end

    function acc = getModelAcceptedByOriginalSample(M,S,modeName,modelIndex)
        n = length(S.ClassTrain);
        acc = zeros(n,1);
        if isempty(M) || ~isstruct(M)
            acc = [];
            return;
        end
        if strcmpi(modeName,'train')
            if isfield(M,'Cresults') && isfield(M.Cresults,'Gpred_bin')
                predTrain = M.Cresults.Gpred_bin(:) == 1;
                if length(predTrain) == n
                    acc = predTrain;
                elseif isfield(M,'TrainingRows') && length(M.TrainingRows) == length(predTrain)
                    rows = M.TrainingRows(:);
                    okRows = rows >= 1 & rows <= n;
                    acc(rows(okRows)) = predTrain(okRows);
                else
                    acc = [];
                end
            else
                acc = [];
            end
            return;
        end
        lv = 1;
        if isfield(S,'SelectedLVByClass') && numel(S.SelectedLVByClass) >= modelIndex
            lv = S.SelectedLVByClass(modelIndex);
        elseif isfield(M,'LVopt') && ~isempty(M.LVopt)
            lv = M.LVopt; if numel(lv)>1, lv = lv(end); end
        else
            lv = get(S.popupLVopt,'Value');
        end
        if ~isfield(M,'Compliance') || numel(M.Compliance) < lv || isempty(M.Compliance{lv}) || ...
                ~isfield(M.Compliance{lv},'Gpred_bin') || ~isfield(M.Compliance{lv},'Gtrue')
            acc = [];
            return;
        end
        pred = M.Compliance{lv}.Gpred_bin(:) == 1;
        gtrue = M.Compliance{lv}.Gtrue(:);
        if length(pred) == n
            acc = pred;
            return;
        end
        classOne = [];
        if isfield(M,'ClassTrain') && length(M.ClassTrain) == n
            classOne = M.ClassTrain(:);
        elseif isfield(M,'TargetClass')
            classOne = double(S.ClassTrain(:) == M.TargetClass);
            classOne(classOne == 0) = 2;
        end
        if isempty(classOne)
            acc = [];
            return;
        end
        targetRows = find(classOne == 1);
        nonRows = find(classOne ~= 1);
        idxT = find(gtrue == 1);
        idxN = find(gtrue ~= 1);
        for ii = 1:min(length(idxT),length(targetRows))
            acc(targetRows(ii)) = pred(idxT(ii));
        end
        nUnt = length(nonRows);
        if nUnt > 0 && ~isempty(idxN)
            if mod(length(idxN),nUnt) == 0
                Klocal = length(idxN)/nUnt;
                for jj = 1:nUnt
                    ids = idxN(jj:nUnt:length(idxN));
                    acc(nonRows(jj)) = any(pred(ids));
                end
            else
                for jj = 1:min(nUnt,length(idxN))
                    acc(nonRows(jj)) = pred(idxN(jj));
                end
            end
        end
    end

    function s = vector_to_csv_text(v)
        if isempty(v)
            s = 'none';
            return;
        end
        s = num2str(v(1));
        for ii = 2:length(v)
            s = [s ',' num2str(v(ii))];
        end
    end

    function txt = appendCVSummaryLines(txt,S)
        M = getCVModelForPlot(S);
        if isempty(M) || ~isstruct(M)
            txt{end+1} = 'CV summary: not available.';
            return;
        end
        txt{end+1} = 'CV summary by LV';
        if isfield(M,'caseType'), txt{end+1} = ['Case type: ' M.caseType]; end
        if isfield(M,'TargetClass'), txt{end+1} = ['Active class: ' num2str(M.TargetClass)]; end
        if isfield(M,'GUI_CV_preprocessing')
            txt{end+1} = ['CV parameters: preprocessing=' preprocessing_display_name(M.GUI_CV_preprocessing) ...
                ', smoothing=' num2str(M.GUI_CV_alpha) ', kappa=' num2str(M.GUI_CV_kappa)];
        elseif isfield(M,'preprocessing') || isfield(M,'alpha') || isfield(M,'kappa')
            ptxt = 'CV parameters:';
            if isfield(M,'preprocessing'), ptxt = [ptxt ' preprocessing=' preprocessing_display_name(M.preprocessing)]; end
            if isfield(M,'alpha'), ptxt = [ptxt ', smoothing=' num2str(M.alpha)]; end
            if isfield(M,'kappa'), ptxt = [ptxt ', kappa=' num2str(M.kappa)]; end
            txt{end+1} = ptxt;
        end

        nLV = get_cv_table_nlv(M);
        if nLV < 1
            txt{end+1} = 'No LV metrics available.';
            return;
        end
        txt{end+1} = ' ';
        txt{end+1} = 'LV | SEN  | SPC  | EFF  | PREC | F1   | ACC  | TP | FP | TN | FN';
        for lv = 1:nLV
            txt{end+1} = sprintf('%2d | %4s | %4s | %4s | %4s | %4s | %4s | %2s | %2s | %2s | %2s', ...
                lv, metric_text(M,'sen_all',lv), metric_text(M,'spec_all',lv), ...
                metric_text(M,'eff_all',lv), metric_text(M,'precision_all',lv), ...
                metric_text(M,'f1score_all',lv), metric_text(M,'acc_all',lv), ...
                count_text(M,'TP_all',lv), count_text(M,'FP_all',lv), ...
                count_text(M,'TN_all',lv), count_text(M,'FN_all',lv));
        end
    end

    function nLV = get_cv_table_nlv(M)
        nLV = 0;
        fields = {'sen_all','spec_all','eff_all','precision_all','f1score_all','acc_all','TP_all','FP_all','TN_all','FN_all'};
        for ii = 1:length(fields)
            if isfield(M,fields{ii}) && ~isempty(M.(fields{ii}))
                nLV = max(nLV,numel(M.(fields{ii})));
            end
        end
    end

    function s = metric_text(M,fieldName,idx)
        s = ' -- ';
        if isfield(M,fieldName) && numel(M.(fieldName)) >= idx
            v = M.(fieldName)(idx);
            if isfinite(v)
                s = sprintf('%.2f',v);
            end
        end
    end

    function s = count_text(M,fieldName,idx)
        s = '--';
        if isfield(M,fieldName) && numel(M.(fieldName)) >= idx
            v = M.(fieldName)(idx);
            if isfinite(v)
                s = sprintf('%g',v);
            end
        end
    end

    function lv = getSelectedLVForConfusion(S)
        lv = get(S.popupLVopt,'Value');
        if isfield(S.PLSDMmodel,'LVopt') && ~isempty(S.PLSDMmodel.LVopt)
            lvtmp = S.PLSDMmodel.LVopt;
            if numel(lvtmp) > 1
                lvtmp = lvtmp(end);
            end
            if isnumeric(lvtmp) && isfinite(lvtmp) && lvtmp >= 1
                lv = round(lvtmp);
            end
        end
    end

    function resetConfusionAxes(S)
        if isfield(S,'axConfTrain') && ~isempty(S.axConfTrain) && ishandle(S.axConfTrain)
            resetSingleConfusionAxis(S.axConfTrain,'Training');
        end
        if isfield(S,'axConfCV') && ~isempty(S.axConfCV) && ishandle(S.axConfCV)
            resetSingleConfusionAxis(S.axConfCV,'CV');
        end
    end

    function resetSingleConfusionAxis(ax, ttl)
        axes(ax); cla;
        title(ttl,'FontWeight','bold');
        set(ax,'XTick',[],'YTick',[]);
        box on;
        text(0.5,0.5,'Fit final model','Units','normalized', ...
             'HorizontalAlignment','center','FontSize',10);
    end

    function [TP,FP,TN,FN,ok] = extract_final_confusion_values(M, lv)
        ok = false; TP = []; FP = []; TN = []; FN = [];
        if isempty(M) || ~isstruct(M)
            return;
        end
        if isfield(M,'Cresults') && isstruct(M.Cresults)
            C = M.Cresults;
            if isfield(C,'TP') && isfield(C,'FP') && isfield(C,'TN') && isfield(C,'FN')
                TP = C.TP; FP = C.FP; TN = C.TN; FN = C.FN;
                if numel(TP) > 1, TP = TP(end); end
                if numel(FP) > 1, FP = FP(end); end
                if numel(TN) > 1, TN = TN(end); end
                if numel(FN) > 1, FN = FN(end); end
                ok = true;
                return;
            end
        end
        [TP,FP,TN,FN,ok] = extract_confusion_from_model(M, lv);
    end

    function plotConfusionColorMap(ax, TP, FP, TN, FN, ttl)
        
        axes(ax);
        cla(ax);

        TP = round(double(TP));
        FP = round(double(FP));
        TN = round(double(TN));
        FN = round(double(FN));
        C = [TP FN; FP TN];

        imagesc(C,'Parent',ax);
        colormap(plsdm_blue_colormap(64));

        maxv = max(C(:));
        if isempty(maxv) || ~isfinite(maxv) || maxv <= 0
            maxv = 1;
        end
        set(ax,'CLim',[0 maxv]);
        axis(ax,'equal');
        axis(ax,'tight');
        box(ax,'on');

        set(ax,'XTick',[1 2], ...
               'XTickLabel',{'Pred +','Pred -'}, ...
               'YTick',[1 2], ...
               'YTickLabel',{'Actual +','Actual -'}, ...
               'YDir','normal', ...
               'FontName','Arial', ...
               'FontSize',8);
        title(ax,ttl,'FontWeight','bold','FontSize',9);

        labs = {'TP','FN';'FP','TN'};
        for rr = 1:2
            for cc = 1:2
                value = C(rr,cc);
                if value > 0.55*maxv
                    tcol = [1 1 1];
                else
                    tcol = [0.05 0.05 0.05];
                end
                text('Parent',ax, ...
                     'Position',[cc rr 0], ...
                     'String',sprintf('%s\n%d',labs{rr,cc},value), ...
                     'HorizontalAlignment','center', ...
                     'VerticalAlignment','middle', ...
                     'FontWeight','bold', ...
                     'FontSize',9, ...
                     'Color',tcol);
            end
        end
    end

    function cmap = plsdm_blue_colormap(n)
        if nargin < 1 || isempty(n), n = 64; end
        n = max(2,round(n));
        c1 = [0.94 0.97 1.00];
        c2 = [0.10 0.32 0.68];
        cmap = zeros(n,3);
        for ii = 1:n
            t = (ii-1)/(n-1);
            cmap(ii,:) = (1-t).*c1 + t.*c2;
        end
    end

    function txt = append_confusion_matrix_lines(txt, M, lv)
        if isempty(M) || ~isstruct(M)
            txt{end+1} = '  CV result not available.';
            return;
        end
        [TP,FP,TN,FN,ok] = extract_confusion_from_model(M, lv);
        if ~ok
            txt{end+1} = '  CV confusion values not available.';
            return;
        end
        txt = append_matrix_block(txt, TP, FP, TN, FN);
    end

    function txt = append_final_confusion_lines(txt, M, lv)
        if isempty(M) || ~isstruct(M)
            txt{end+1} = '  Final model not available.';
            return;
        end
        ok = false; TP = []; FP = []; TN = []; FN = [];
        if isfield(M,'Cresults') && isstruct(M.Cresults)
            C = M.Cresults;
            if isfield(C,'TP') && isfield(C,'FP') && isfield(C,'TN') && isfield(C,'FN')
                TP = C.TP; FP = C.FP; TN = C.TN; FN = C.FN;
                if numel(TP) > 1, TP = TP(end); end
                if numel(FP) > 1, FP = FP(end); end
                if numel(TN) > 1, TN = TN(end); end
                if numel(FN) > 1, FN = FN(end); end
                ok = true;
            end
        end
        if ~ok
            [TP,FP,TN,FN,ok] = extract_confusion_from_model(M, lv);
        end
        if ~ok
            txt{end+1} = '  Final-model confusion values not available.';
            return;
        end
        txt = append_matrix_block(txt, TP, FP, TN, FN);
    end

    function [TP,FP,TN,FN,ok] = extract_confusion_from_model(M, lv)
        TP = []; FP = []; TN = []; FN = []; ok = false;
        if isempty(M) || ~isstruct(M)
            return;
        end
        if isfield(M,'TP_all') && isfield(M,'FP_all') && isfield(M,'TN_all') && isfield(M,'FN_all')
            n = length(M.TP_all);
            lv = max(1,min(n,lv));
            TP = M.TP_all(lv);
            FP = M.FP_all(lv);
            TN = M.TN_all(lv);
            FN = M.FN_all(lv);
            ok = true;
        end
    end

    function txt = append_matrix_block(txt, TP, FP, TN, FN)
        txt{end+1} = '                    Predicted +    Predicted -';
        txt{end+1} = sprintf('Actual +              %6d         %6d', TP, FN);
        txt{end+1} = sprintf('Actual -              %6d         %6d', FP, TN);
    end

    function plotCVPerformance(ax,M)
        axes(ax); cla; hold on; box on; grid on;
        if isempty(M) || ~isstruct(M) || ~isfield(M,'sen_all')
            title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
            xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
            ylabel('Cross-validated performance','FontWeight','bold');
            hold off;
            return;
        end

        sensitivities = M.sen_all;
        LVs = 1:length(sensitivities);
        [LVs, ord] = sort(LVs(:).');
        sensitivities = sensitivities(ord);

        specificities = [];
        efficiencies = [];
        if isfield(M,'spec_all') && numel(M.spec_all)==numel(LVs)
            specificities = M.spec_all(ord);
        end
        if isfield(M,'eff_all') && numel(M.eff_all)==numel(LVs)
            efficiencies = M.eff_all(ord);
        end

        if isfield(M,'caseType')
            caseType = lower(M.caseType);
        elseif ~isempty(specificities) && any(~isnan(specificities))
            caseType = 'compliant';
        else
            caseType = 'rigorous';
        end

        col.sen  = [0.85  0.33  0.10 ];
        col.spe  = [0.00  0.45  0.74 ];
        col.eff  = [0.47  0.67  0.19 ];
        msz = 7; lw = 2;
        p = [];
        leg = {};

        switch lower(caseType)
            case 'compliant'
                p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, ...
                          'MarkerSize', msz, 'MarkerFaceColor', col.sen);
                p = [p p1]; leg{end+1} = 'Sensitivity';
                if ~isempty(specificities)
                    p2 = plot(LVs, specificities, '-s', 'Color', col.spe, 'LineWidth', lw, ...
                              'MarkerSize', msz, 'MarkerFaceColor', col.spe);
                    p = [p p2]; leg{end+1} = 'Specificity';
                end
                if ~isempty(efficiencies)
                    p3 = plot(LVs, efficiencies, '-d', 'Color', col.eff, 'LineWidth', lw, ...
                              'MarkerSize', msz, 'MarkerFaceColor', col.eff);
                    p = [p p3]; leg{end+1} = 'Efficiency';
                end
            otherwise
                p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, ...
                          'MarkerSize', msz, 'MarkerFaceColor', col.sen);
                p = [p p1]; leg{end+1} = 'Sensitivity';
        end

        LVsel = get(S.popupLVopt,'Value');
        if LVsel >= min(LVs) && LVsel <= max(LVs)
            line([LVsel LVsel],[0 1],'LineStyle','--','Color',[0 0 0],'LineWidth',1.1);
        end

        set(gca,'FontSize',12,'XMinorTick','on','YMinorTick','on');
        xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
        ylabel('Cross-validated performance','FontWeight','bold');
        title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
        ylim([0 1]);
        if min(LVs) == max(LVs)
            xlim([min(LVs)-0.5 max(LVs)+0.5]);
        else
            xlim([min(LVs) max(LVs)]);
        end
        set(gca,'XTick',unique(LVs));
        if ~isempty(p)
            lg = legend(p,leg,'Location','Best'); set(lg,'Box','off');
        end
        hold off;
    end


    function CVmodel = call_classical_cv(Xtrain, ClassTrain, K, LVmax, conflev, alpha, kappa, preprocessing, var_label, status)
        % 
        CVmodel = [];
        evalc('CVmodel = plsdm_CV(Xtrain, ClassTrain, K, LVmax, conflev, alpha, kappa, preprocessing, var_label, status);');
    end

    function CVmodel = call_robust_cv(Xtrain, ClassTrain, K, LVmax, conflev, alpha, kappa, preprocessing, var_label, gama, status)
        
        CVmodel = [];
        if exist('rplsdm_CV','file') == 2
            evalc('CVmodel = rplsdm_CV(Xtrain, ClassTrain, K, LVmax, conflev, alpha, kappa, preprocessing, var_label, gama, status);');
        else
            evalc('CVmodel = rplsdm_cv(Xtrain, ClassTrain, K, LVmax, conflev, alpha, kappa, preprocessing, var_label, gama, status);');
        end
    end

    function PLSDMmodel = call_classical_fit(Xtrain, ClassTrain, K, LVopt, conflev, alpha, kappa, preprocessing, var_label, status)
       
        PLSDMmodel = [];
        evalc('PLSDMmodel = plsdm_ft(Xtrain, ClassTrain, K, LVopt, conflev, alpha, kappa, preprocessing, var_label, status);');
    end

    function PLSDMmodel = call_robust_fit(Xtrain, ClassTrain, K, LVopt, conflev, alpha, kappa, preprocessing, var_label, gama, status)
        
        PLSDMmodel = [];
        evalc('PLSDMmodel = rplsdm_ft(Xtrain, ClassTrain, K, LVopt, conflev, alpha, kappa, preprocessing, var_label, gama, status);');
    end

    function M = getCVModelForPlot(S)
        if isfield(S,'CVmodel') && ~isempty(S.CVmodel)
            M = S.CVmodel;
        else
            M = S.PLSDMmodel;
        end
    end

%     function copy_axes_content(axSource, axDest)
%         copyobj(allchild(axSource), axDest);
%         set(axDest,'XLim',get(axSource,'XLim'),'YLim',get(axSource,'YLim'));
%         xlabel(axDest,get(get(axSource,'XLabel'),'String'));
%         ylabel(axDest,get(get(axSource,'YLabel'),'String'));
%         title(axDest,get(get(axSource,'Title'),'String'));
%         grid(axDest,'on'); box(axDest,'on');
%     end
function copy_axes_content(axSource, axDest)

    
    ch = allchild(axSource);

    for ii = 1:length(ch)
        typ = get(ch(ii),'Type');

       
        if strcmpi(typ,'text')
            continue;
        end

        copyobj(ch(ii), axDest);
    end

    
    set(axDest,'XLim',get(axSource,'XLim'), ...
               'YLim',get(axSource,'YLim'), ...
               'XTick',get(axSource,'XTick'), ...
               'YTick',get(axSource,'YTick'));

    % Recreate labels (only once)
    xlabel(axDest,get(get(axSource,'XLabel'),'String'));
    ylabel(axDest,get(get(axSource,'YLabel'),'String'));
    title(axDest,get(get(axSource,'Title'),'String'));

    grid(axDest,'on');
    box(axDest,'on');

end

function [applied,datasets] = plsdm_fit_exclude_samples_dialog(parentFig,datasets)
% Fit/Validation-specific inclusion editor with training outlier-status load.
applied = false;
for kk=1:numel(datasets)
    n=size(datasets(kk).X,1);
    if ~isfield(datasets(kk),'included') || numel(datasets(kk).included)~=n
        datasets(kk).included=true(n,1);
    else
        datasets(kk).included=logical(datasets(kk).included(:));
    end
    if ~isfield(datasets(kk),'outlierStatus') || numel(datasets(kk).outlierStatus)~=n
        datasets(kk).outlierStatus=zeros(n,1);
    else
        datasets(kk).outlierStatus=datasets(kk).outlierStatus(:);
    end
end
labels={datasets.label}; current=1;
scr=get(0,'ScreenSize'); w=820; h=570;
dlg=figure('Name','Exclude samples','NumberTitle','off','MenuBar','none','Toolbar','none', ...
    'WindowStyle','modal','Resize','on','Color',[.95 .96 .94], ...
    'Position',[scr(3)/2-w/2 scr(4)/2-h/2 w h], ...
    'CloseRequestFcn',@onCancel);
uicontrol(dlg,'Style','text','String','Dataset','Units','normalized', ...
    'Position',[.03 .935 .10 .035],'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(dlg,'Color'));
popup=uicontrol(dlg,'Style','popupmenu','String',labels,'Units','normalized', ...
    'Position',[.13 .925 .32 .05],'BackgroundColor','w','Callback',@onDataset);
summary=uicontrol(dlg,'Style','text','String','','Units','normalized', ...
    'Position',[.48 .93 .49 .04],'HorizontalAlignment','right','BackgroundColor',get(dlg,'Color'));
loadStatus=uicontrol(dlg,'Style','pushbutton','String','Load outlier status...', ...
    'Units','normalized','Position',[.03 .855 .22 .055],'FontWeight','bold','Callback',@onLoadStatus);
uicontrol(dlg,'Style','text','String','Class','Units','normalized', ...
    'Position',[.28 .875 .07 .028],'HorizontalAlignment','left','BackgroundColor',get(dlg,'Color'));
classPopup=uicontrol(dlg,'Style','popupmenu','String',{'--'},'Units','normalized', ...
    'Position',[.35 .855 .14 .05],'BackgroundColor','w');
excludeClass=uicontrol(dlg,'Style','pushbutton','String','Exclude class','Units','normalized', ...
    'Position',[.51 .855 .14 .05],'Callback',{@onClass,false});
includeClass=uicontrol(dlg,'Style','pushbutton','String','Include class','Units','normalized', ...
    'Position',[.66 .855 .14 .05],'Callback',{@onClass,true});
onlyClass=uicontrol(dlg,'Style','pushbutton','String','Only class','Units','normalized', ...
    'Position',[.81 .855 .16 .05],'Callback',@onOnlyClass);
tbl=uitable(dlg,'Units','normalized','Position',[.03 .19 .94 .64], ...
    'ColumnName',{'Include','Original row','Class','Sample name','Outlier status'}, ...
    'ColumnEditable',[true false false false false], ...
    'ColumnFormat',{'logical','numeric','char','char','char'}, ...
    'ColumnWidth',{65 85 80 330 145});
uicontrol(dlg,'Style','pushbutton','String','Include all','Units','normalized', ...
    'Position',[.03 .105 .14 .05],'Callback',@onIncludeAll);
uicontrol(dlg,'Style','pushbutton','String','Exclude status 3','Units','normalized', ...
    'Position',[.18 .105 .18 .05],'Callback',@onExcludeOutliers);
uicontrol(dlg,'Style','pushbutton','String','Apply','Units','normalized', ...
    'Position',[.73 .055 .11 .06],'FontWeight','bold','Callback',@onApply);
uicontrol(dlg,'Style','pushbutton','String','Cancel','Units','normalized', ...
    'Position',[.86 .055 .11 .06],'Callback',@onCancel);
refreshTable(); uiwait(dlg); if ishandle(dlg), delete(dlg); end

    function saveCurrent()
        data=get(tbl,'Data'); if ~isempty(data), datasets(current).included=logical(cell2mat(data(:,1))); end
    end
    function onDataset(src,ev), saveCurrent(); current=get(popup,'Value'); refreshTable(); end
    function refreshTable()
        d=datasets(current); n=size(d.X,1); data=cell(n,5);
        for ii=1:n
            data{ii,1}=d.included(ii); data{ii,2}=d.originalRows(ii);
            if iscell(d.classDisplay), data{ii,3}=d.classDisplay{ii}; else, data{ii,3}=d.classDisplay(ii); end
            data{ii,4}=d.sampleNames{ii}; data{ii,5}=statusLabel(d.outlierStatus(ii));
        end
        set(tbl,'Data',data);
        set(summary,'String',sprintf('%d included / %d total | %d status-3 outliers',sum(d.included),n,sum(d.outlierStatus==3)));
        isTraining=strcmpi(d.key,'train'); if isTraining,en='on';else,en='off';end; set(loadStatus,'Enable',en);
        [known,classes]=knownClasses(d.classDisplay);
        if known
            set(classPopup,'String',arrayfun(@num2str,classes,'UniformOutput',false),'Value',1,'Enable','on');
            set([excludeClass includeClass onlyClass],'Enable','on');
        else
            set(classPopup,'String',{'--'},'Value',1,'Enable','off'); set([excludeClass includeClass onlyClass],'Enable','off');
        end
    end
    function onLoadStatus(src,ev)
        saveCurrent(); d=datasets(current);
        if ~strcmpi(d.key,'train'), return; end
        [ok,names,vals]=plsdm_select_workspace_vars('Load training outlier status', ...
            {'Outliers status'},{'status'},{false});
        if ~ok, return; end
        v=vals{1};
        if ~isnumeric(v) || ~isvector(v) || numel(v)~=size(d.X,1) || ...
                any(~isfinite(v(:))) || any(abs(v(:)-round(v(:)))>1e-12) || any(v(:)<0 | v(:)>3)
            errordlg('Status must be a numeric vector with one value (0, 1, 2 or 3) for every original training row.','Invalid outlier status');
            return;
        end
        datasets(current).outlierStatus=round(v(:));
        datasets(current).included(datasets(current).outlierStatus==3)=false;
        refreshTable();
        msgbox(['Loaded ' names{1} '. Samples with status 3 were unchecked.'],'Outlier status loaded');
    end
    function onExcludeOutliers(src,ev), saveCurrent(); datasets(current).included(datasets(current).outlierStatus==3)=false; refreshTable(); end
    function onIncludeAll(src,ev), saveCurrent(); for jj=1:numel(datasets),datasets(jj).included(:)=true;end; refreshTable(); end
    function onClass(src,ev,includeValue), saveCurrent(); mask=classMask(); datasets(current).included(mask)=includeValue; refreshTable(); end
    function onOnlyClass(src,ev), saveCurrent(); mask=classMask(); datasets(current).included(:)=false; datasets(current).included(mask)=true; refreshTable(); end
    function mask=classMask()
        d=datasets(current); [known,classes]=knownClasses(d.classDisplay); mask=false(size(d.included)); if ~known,return;end
        if iscell(d.classDisplay), vals=cell2mat(d.classDisplay(:));else,vals=d.classDisplay(:);end
        mask=vals==classes(get(classPopup,'Value'));
    end
    function onApply(src,ev)
        saveCurrent(); empty=find(arrayfun(@(d)~any(d.included),datasets),1);
        if ~isempty(empty),errordlg(['At least one sample must remain included in ' datasets(empty).label '.'],'Exclude samples');return;end
        applied=true; uiresume(dlg);
    end
    function onCancel(src,ev), applied=false; if strcmp(get(dlg,'WaitStatus'),'waiting'),uiresume(dlg);else,delete(dlg);end; end
end

function s=statusLabel(v)
switch round(v)
    case 1, s='1 - Regular';
    case 2, s='2 - Extreme';
    case 3, s='3 - Outlier';
    otherwise, s='0 - Not assigned';
end
end

function [known,classes]=knownClasses(classDisplay)
known=false; classes=[];
if isnumeric(classDisplay), vals=classDisplay(:);
elseif iscell(classDisplay) && all(cellfun(@(x)isnumeric(x)&&isscalar(x)&&isfinite(x),classDisplay(:))), vals=cell2mat(classDisplay(:));
else, return; end
for ii=1:numel(vals), if ~any(classes==vals(ii)), classes(end+1)=vals(ii); end; end
known=~isempty(classes);
end

function plsdm_custom_figure_menu(owner,guiName,plotNames,classNames,renderFcn)
% Embedded custom-figure builder: keeps this GUI file self-contained.
D.items=struct('plot',{},'class',{},'title',{}); D.render=renderFcn;
D.f=figure('Name',[guiName ' - Custom figure'],'NumberTitle','off','MenuBar','none', ...
 'Toolbar','none','Resize','on','WindowStyle','normal','Color',[.94 .95 .98],'Position',[180 100 780 520]);
uicontrol(D.f,'Style','text','String','Plot type','Position',[25 475 330 20], ...
 'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(D.f,'Color'));
D.p=uicontrol(D.f,'Style','popupmenu','String',plotNames,'Position',[25 442 330 28],'BackgroundColor','w');
uicontrol(D.f,'Style','text','String','Class/model','Position',[380 475 210 20], ...
 'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(D.f,'Color'));
D.c=uicontrol(D.f,'Style','popupmenu','String',classNames,'Position',[380 442 210 28],'BackgroundColor','w');
uicontrol(D.f,'Style','pushbutton','String','Add panel','Position',[615 442 140 30], ...
 'FontWeight','bold','Callback',@addItem);
uicontrol(D.f,'Style','text','String','Figure panels (list order = subplot order)', ...
 'Position',[25 405 500 20],'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(D.f,'Color'));
D.l=uicontrol(D.f,'Style','listbox','String',{'No panels added.'},'Position',[25 175 560 230],'BackgroundColor','w');
uicontrol(D.f,'Style','pushbutton','String','Move up','Position',[615 355 140 30],'Callback',{@moveItem,-1});
uicontrol(D.f,'Style','pushbutton','String','Move down','Position',[615 315 140 30],'Callback',{@moveItem,1});
uicontrol(D.f,'Style','pushbutton','String','Duplicate','Position',[615 275 140 30],'Callback',@duplicateItem);
uicontrol(D.f,'Style','pushbutton','String','Remove','Position',[615 235 140 30],'Callback',@removeItem);
uicontrol(D.f,'Style','pushbutton','String','Clear','Position',[615 195 140 30],'Callback',@clearItems);
uicontrol(D.f,'Style','text','String','Panel title','Position',[25 140 100 20], ...
 'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(D.f,'Color'));
D.t=uicontrol(D.f,'Style','edit','Position',[125 137 460 27],'BackgroundColor','w','Callback',@editTitle);
uicontrol(D.f,'Style','text','String','Columns','Position',[615 140 60 20],'BackgroundColor',get(D.f,'Color'));
D.cols=uicontrol(D.f,'Style','popupmenu','String',{'Auto','1','2','3','4'},'Position',[680 137 75 27],'BackgroundColor','w');
D.over=uicontrol(D.f,'Style','edit','String',[guiName ' - Custom figure'], ...
 'Position',[125 97 630 27],'BackgroundColor','w');
uicontrol(D.f,'Style','text','String','Figure title','Position',[25 100 100 20], ...
 'HorizontalAlignment','left','FontWeight','bold','BackgroundColor',get(D.f,'Color'));
uicontrol(D.f,'Style','pushbutton','String','Generate','Position',[360 35 120 36], ...
 'FontWeight','bold','Callback',{@makeFigure,false});
uicontrol(D.f,'Style','pushbutton','String','Generate and save .fig','Position',[490 35 170 36], ...
 'FontWeight','bold','Callback',{@makeFigure,true});
uicontrol(D.f,'Style','pushbutton','String','Cancel','Position',[670 35 85 36],'Callback',@(h,e)close(D.f));
set(findall(D.f,'Type','uicontrol'),'Units','normalized');
guidata(D.f,D);
 function addItem(h,e), d=guidata(D.f); p=get(d.p,'Value'); c=get(d.c,'Value');
  ps=get(d.p,'String'); cs=get(d.c,'String'); if ~iscell(ps),ps=cellstr(ps);end;if ~iscell(cs),cs=cellstr(cs);end
  q.plot=p;q.class=c;q.title=[ps{p} ' - ' cs{c}];d.items(end+1)=q;guidata(D.f,d);refresh(length(d.items));end
 function moveItem(h,e,z),d=guidata(D.f);if isempty(d.items),return;end;i=get(d.l,'Value');j=i+z;
  if j<1||j>length(d.items),return;end;q=d.items(i);d.items(i)=d.items(j);d.items(j)=q;guidata(D.f,d);refresh(j);end
 function duplicateItem(h,e),d=guidata(D.f);if isempty(d.items),return;end;i=get(d.l,'Value');d.items(end+1)=d.items(i);guidata(D.f,d);refresh(length(d.items));end
 function removeItem(h,e),d=guidata(D.f);if isempty(d.items),return;end;i=get(d.l,'Value');d.items(i)=[];guidata(D.f,d);refresh(max(1,i-1));end
 function clearItems(h,e),d=guidata(D.f);d.items=struct('plot',{},'class',{},'title',{});guidata(D.f,d);refresh(1);end
 function editTitle(h,e),d=guidata(D.f);if isempty(d.items),return;end;i=get(d.l,'Value');d.items(i).title=get(d.t,'String');guidata(D.f,d);refresh(i);end
 function refresh(i),d=guidata(D.f);if isempty(d.items),set(d.l,'String',{'No panels added.'},'Value',1);set(d.t,'String','');return;end
  s=cell(length(d.items),1);for k=1:length(s),s{k}=sprintf('%d. %s',k,d.items(k).title);end;i=min(i,length(s));set(d.l,'String',s,'Value',i);set(d.t,'String',d.items(i).title);end
 function makeFigure(h,e,saveIt),d=guidata(D.f);if isempty(d.items),errordlg('Add at least one panel.');return;end
  n=length(d.items);v=get(d.cols,'Value');if v==1,nc=ceil(sqrt(n));else,nc=v-1;end;nr=ceil(n/nc);
  out=figure('Color','w','Name',get(d.over,'String'),'NumberTitle','off', ...
   'MenuBar','figure','Toolbar','figure','Resize','on','WindowStyle','normal','DockControls','on', ...
   'Position',[60 50 max(760,450*nc) max(520,330*nr)]);
  hasVIP=any(ismember([d.items.plot],[7 8]));
   if hasVIP,set(out,'Position',[60 50 min(2400,1250*nc) max(630,560*nr)]);end
   for k=1:n,ax=subplot(nr,nc,k,'Parent',out);set(ax,'Units','normalized','HandleVisibility','on','HitTest','on');if hasVIP,pos=get(ax,'Position');pos(2)=.02+.88*pos(2);pos(4)=.88*pos(4);set(ax,'Position',pos);end;try,d.render(d.items(k).plot,d.items(k).class,ax);title(ax,d.items(k).title,'Interpreter','none');catch ME,cla(ax);axis(ax,'off');text(.5,.5,ME.message,'Parent',ax,'HorizontalAlignment','center','Interpreter','none');title(ax,d.items(k).title,'Interpreter','none');end,end
  annotation(out,'textbox',[.05 .955 .9 .035],'String',get(d.over,'String'),'LineStyle','none','HorizontalAlignment','center','FontWeight','bold','Interpreter','none');
  try,plotedit(out,'on');catch,end
  if saveIt,[fn,pn]=uiputfile('*.fig','Save custom MATLAB figure');if ~isequal(fn,0),file=fullfile(pn,fn);if exist('savefig','file')==2,savefig(out,file);else,hgsave(out,file);end,end,end
 end
end
    function strs = make_lv_strings(LVmax)
        strs = cell(1,LVmax);
        for ii=1:LVmax
            strs{ii} = num2str(ii);
        end
    end

    function v = parsePositiveInteger(strValue,label)
        v = str2double(strValue);
        if isnan(v) || v < 1 || abs(v-round(v)) > 1e-12
            error([label ' must be a positive integer.']);
        end
        v = round(v);
    end

    function v = parseProbability(strValue,label)
        v = str2double(strValue);
        if isnan(v) || v <= 0 || v >= 1
            error([label ' must be a number between 0 and 1.']);
        end
    end

    function v = parseScalarNumber(strValue,label)
        v = str2double(strValue);
        if isnan(v) || ~isfinite(v)
            error([label ' must be a numeric scalar.']);
        end
    end


end

