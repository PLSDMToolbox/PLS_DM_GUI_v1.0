%
function [f_query,f_alpha,f_train] = plsdm_original_pfm(Ttrain,Tquery,alpha,conflev)
% PLSDM_ORIGINAL_PFM Toolbox routine.
% Syntax: function [f_query,f_alpha,f_train] = plsdm_original_pfm(Ttrain,Tquery,alpha,conflev)
% Inputs and outputs are defined by the function signature.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 4 || isempty(conflev), conflev = 0.95; end
if nargin < 3 || isempty(alpha), alpha = 0.5; end
Ttrain = double(Ttrain);
Tquery = double(Tquery);
[n,V] = size(Ttrain);
nq = size(Tquery,1);
muT = zeros(1,V);
sdT = ones(1,V);
for j = 1:V
    s = 0;
    for i = 1:n
        s = s + Ttrain(i,j);
    end
    if n > 0
        muT(j) = s / n;
    end
    ss = 0;
    if n > 1
        for i = 1:n
            tmpd = Ttrain(i,j) - muT(j);
            ss = ss + tmpd*tmpd;
        end
        sdT(j) = sqrt(ss / (n-1));
    end
    if sdT(j) == 0 || ~isfinite(sdT(j))
        sdT(j) = 1;
    end
end
for j = 1:V
    for i = 1:n
        Ttrain(i,j) = (Ttrain(i,j) - muT(j)) / sdT(j);
    end
    for i = 1:nq
        Tquery(i,j) = (Tquery(i,j) - muT(j)) / sdT(j);
    end
end
if n < 2
    f_train = ones(n,1);
    f_query = ones(nq,1);
    f_alpha = min(f_train);
    return
end
sv = ones(1,V);
for j = 1:V
    m = 0;
    for i = 1:n
        m = m + Ttrain(i,j);
    end
    m = m / n;
    ss = 0;
    for i = 1:n
        tmpd = Ttrain(i,j) - m;
        ss = ss + tmpd*tmpd;
    end
    sv(j) = sqrt(ss / (n-1));
    if sv(j) == 0 || ~isfinite(sv(j))
        sv(j) = 1;
    end
end
scaleLV = alpha .* sv;
for j = 1:V
    if scaleLV(j) == 0 || ~isfinite(scaleLV(j))
        scaleLV(j) = eps;
    end
end
f_train = zeros(n,1);
for i = 1:n
    acc = 0;
    cnt = 0;
    for r = 1:n
        if r ~= i
            d2 = 0;
            for j = 1:V
                z = (Ttrain(i,j) - Ttrain(r,j)) / scaleLV(j);
                d2 = d2 + z*z;
            end
            acc = acc + exp(-0.5*d2);
            cnt = cnt + 1;
        end
    end
    if cnt > 0
        f_train(i) = acc / cnt;
    else
        f_train(i) = 1;
    end
end
f_query = zeros(nq,1);
for i = 1:nq
    acc = 0;
    for r = 1:n
        d2 = 0;
        for j = 1:V
            z = (Tquery(i,j) - Ttrain(r,j)) / scaleLV(j);
            d2 = d2 + z*z;
        end
        acc = acc + exp(-0.5*d2);
    end
    f_query(i) = acc / (n-1);
end
for i = 1:n
    if f_train(i) <= 0 || ~isfinite(f_train(i))
        f_train(i) = realmin('double');
    end
end
for i = 1:nq
    if f_query(i) <= 0 || ~isfinite(f_query(i))
        f_query(i) = realmin('double');
    end
end
chi2 = chi2inv(conflev,V);
f_alpha = 2^(V/2) * mean(f_train) * exp(-chi2/2);
if ~isfinite(f_alpha) || f_alpha <= 0
    f_alpha = realmin('double');
end
end