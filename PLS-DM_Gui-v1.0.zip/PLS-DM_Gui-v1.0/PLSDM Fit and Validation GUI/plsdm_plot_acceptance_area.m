%
function plsdm_plot_acceptance_area(ax,Q,f,Qcrit,falpha,Gtrue,titleStr,showLabels,labels,markerSpec)
% PLSDM_PLOT_ACCEPTANCE_AREA Toolbox routine.
% Syntax: function plsdm_plot_acceptance_area(ax,Q,f,Qcrit,falpha,Gtrue,titleStr,showLabels,labels,markerSpec)
% Inputs and outputs are defined by the function signature.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 1 || isempty(ax), ax = gca; end
if nargin < 6, Gtrue = []; end
if nargin < 7 || isempty(titleStr), titleStr = 'Acceptance area'; end
if nargin < 8 || isempty(showLabels), showLabels = false; end
if nargin < 9, labels = {}; end
if nargin < 10 || isempty(markerSpec), markerSpec = struct(); end

Q = Q(:);
f = f(:);
if isempty(Q)
    cla(ax); title(ax,titleStr); return;
end
nPlot = numel(Q);
floor_f = 1e-12;
c = 10;

if numel(Qcrit) == 1
    Qcrit_v = repmat(Qcrit,nPlot,1);
else
    Qcrit_v = Qcrit(:);
    if numel(Qcrit_v) ~= nPlot
        Qcrit_v = repmat(Qcrit_v(1),nPlot,1);
    end
end
if numel(falpha) == 1
    falpha_v = repmat(falpha,nPlot,1);
else
    falpha_v = falpha(:);
    if numel(falpha_v) ~= nPlot
        falpha_v = repmat(falpha_v(1),nPlot,1);
    end
end
[fplot,Qplot,Qnorm,logf_norm,acceptance_limit_x,accepted] = ...
    plsdm_acceptance_coordinates(Q,f,Qcrit_v,falpha_v);
acceptance_limit_y = acceptance_limit_x;
if isempty(Gtrue)
    Gtrue = ones(nPlot,1);
else
    Gtrue = Gtrue(:);
    if numel(Gtrue) ~= nPlot
        Gtrue = ones(nPlot,1);
    end
end

TP_idx = find(accepted & (Gtrue == 1));
FP_idx = find(accepted & (Gtrue ~= 1));
FN_idx = find((~accepted) & (Gtrue == 1));
TN_idx = find((~accepted) & (Gtrue ~= 1));

msTP = 9; msFP = 9; msFN = 9; msTN = 9;
lwAx = 1.4; lwLine = 2.2; lwPts = 1.2;
fsLbl = 12; fsLeg = 12;
colTP = [0.10 0.60 0.20];
colFP = [0.95 0.70 0.10];
colFN = [0.20 0.45 0.80];
colTN = [0.85 0.15 0.20];

cla(ax);
axes(ax);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');
set(ax,'LineWidth',lwAx,'FontSize',fsLbl,'FontName','Arial', ...
    'XMinorTick','on','YMinorTick','on');

x_rect = [0 acceptance_limit_x acceptance_limit_x 0 0];
y_rect = [0 0 acceptance_limit_y acceptance_limit_y 0];
plot(ax,x_rect,y_rect,'-','Color',[0.00 0.50 0.00],'LineWidth',lwLine);
fill(x_rect,y_rect,[0.85 0.97 0.85],'FaceAlpha',0.25,'EdgeColor','none','Parent',ax);

useFoldShade = false;
foldIndex = ones(nPlot,1);
nFolds = 1;
if isstruct(markerSpec)
    if isfield(markerSpec,'UseFoldShade') && markerSpec.UseFoldShade, useFoldShade = true; end
    if isfield(markerSpec,'FoldIndex') && numel(markerSpec.FoldIndex) == nPlot
        foldIndex = markerSpec.FoldIndex(:);
    end
    if isfield(markerSpec,'NFolds') && ~isempty(markerSpec.NFolds), nFolds = markerSpec.NFolds; end
end
if useFoldShade
    for kk = 1:nFolds
        local_plot_group(ax,fplot,Qplot,find(accepted & (Gtrue == 1) & (foldIndex == kk)), ...
            'o',local_fold_shade(colTP,kk,nFolds),msTP,lwPts);
        local_plot_group(ax,fplot,Qplot,find(accepted & (Gtrue ~= 1) & (foldIndex == kk)), ...
            'd',local_fold_shade(colFP,kk,nFolds),msFP,lwPts);
        local_plot_group(ax,fplot,Qplot,find((~accepted) & (Gtrue == 1) & (foldIndex == kk)), ...
            's',local_fold_shade(colFN,kk,nFolds),msFN,lwPts);
        local_plot_group(ax,fplot,Qplot,find((~accepted) & (Gtrue ~= 1) & (foldIndex == kk)), ...
            '^',local_fold_shade(colTN,kk,nFolds),msTN,lwPts);
    end
else
    local_plot_group(ax,fplot,Qplot,TP_idx,'o',colTP,msTP,lwPts);
    local_plot_group(ax,fplot,Qplot,FP_idx,'d',colFP,msFP,lwPts);
    local_plot_group(ax,fplot,Qplot,FN_idx,'s',colFN,msFN,lwPts);
    local_plot_group(ax,fplot,Qplot,TN_idx,'^',colTN,msTN,lwPts);
end

hArea = plot(ax,NaN,NaN,'-','Color',[0.00 0.50 0.00],'LineWidth',lwLine);
hTP = plot(ax,NaN,NaN,'o','MarkerFaceColor',colTP,'MarkerEdgeColor',[0 0 0], ...
    'MarkerSize',msTP,'LineWidth',lwPts,'Visible','off');
hFP = plot(ax,NaN,NaN,'d','MarkerFaceColor',colFP,'MarkerEdgeColor',[0 0 0], ...
    'MarkerSize',msFP,'LineWidth',lwPts,'Visible','off');
hFN = plot(ax,NaN,NaN,'s','MarkerFaceColor',colFN,'MarkerEdgeColor',[0 0 0], ...
    'MarkerSize',msFN,'LineWidth',lwPts,'Visible','off');
hTN = plot(ax,NaN,NaN,'^','MarkerFaceColor',colTN,'MarkerEdgeColor',[0 0 0], ...
    'MarkerSize',msTN,'LineWidth',lwPts,'Visible','off');
axes(ax);
leg = legend([hArea hTP hFP hFN hTN], ...
    {'Acceptance boundary','True Positive (TP)','False Positive (FP)', ...
     'False Negative (FN)','True Negative (TN)'}, ...
    'Location','EastOutside');
set(leg,'FontSize',fsLeg,'Box','off');

xlabel(ax,'Log-scaled PF','FontSize',fsLbl,'FontWeight','bold');
ylabel(ax,'Log-scaled Q residual','FontSize',fsLbl,'FontWeight','bold');
title(ax,'');

xmin = min(fplot) - 0.05;
xmax = max(fplot) + 5;
ymin = min(Qplot) - 0.05;
ymax = max(Qplot) + 3;
xmax = max(xmax,acceptance_limit_x);
ymax = max(ymax,acceptance_limit_y);
xr = xmax - xmin; if xr <= 0, xr = 1; end
yr = ymax - ymin; if yr <= 0, yr = 1; end
xlim(ax,[0 xmax + 0.15*xr]);
ylim(ax,[0 ymax + 0.15*yr]);
axis(ax,'square');

if showLabels
    for i = 1:nPlot
        if isempty(labels)
            lab = num2str(i);
        elseif iscell(labels)
            if i <= numel(labels), lab = labels{i}; else, lab = num2str(i); end
        else
            if i <= numel(labels), lab = num2str(labels(i)); else, lab = num2str(i); end
        end
        text(fplot(i),Qplot(i),[' ' lab],'Parent',ax,'FontSize',8,'Color',[0.10 0.10 0.10]);
    end
end
hold(ax,'off');

function local_plot_group(ax,x,y,idx,markerSymbol,faceColor,ms,lw)
if isempty(idx), return; end
plot(ax,x(idx),y(idx),markerSymbol,'MarkerFaceColor',faceColor, ...
    'MarkerEdgeColor',[0 0 0],'MarkerSize',ms,'LineWidth',lw);
end

function col = local_fold_shade(baseColor,fold,nFolds)
if nFolds <= 1
    t = 1;
else
    t = 0.55 + 0.45*(fold-1)/(nFolds-1);
end
col = t.*baseColor + (1-t).*[1 1 1];
col(col < 0) = 0;
col(col > 1) = 1;
end

end
