%
function plsdm_plot_acceptance_projection(ax,PLSDMmodel,Qnew,fnew,Gnew,titleStr,showLabels,newLabels)
% PLSDM_PLOT_ACCEPTANCE_PROJECTION Toolbox routine.
% Syntax: function plsdm_plot_acceptance_projection(ax,PLSDMmodel,Qnew,fnew,Gnew,titleStr,showLabels,newLabels)
% Inputs and outputs are defined by the function signature.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 1 || isempty(ax), ax = gca; end
if nargin < 5, Gnew = []; end
if nargin < 6 || isempty(titleStr), titleStr = 'Training + projected samples'; end
if nargin < 7 || isempty(showLabels), showLabels = false; end
if nargin < 8, newLabels = {}; end

Qtrain = [];
ftrain = [];
Gtrain = [];
if isfield(PLSDMmodel,'acp_train_q'), Qtrain = PLSDMmodel.acp_train_q; end
if isfield(PLSDMmodel,'acp_train_pf'), ftrain = PLSDMmodel.acp_train_pf; end
if isfield(PLSDMmodel,'ClassTrain'), Gtrain = PLSDMmodel.ClassTrain; end
Qcrit = PLSDMmodel.FinalModel.Qlimit;
falpha = PLSDMmodel.FinalModel.flimit;

Qall = [Qtrain(:); Qnew(:)];
fall = [ftrain(:); fnew(:)];
[~,~,x,y,~,accepted] = plsdm_acceptance_coordinates(Qall,fall,Qcrit,falpha);

nT = numel(Qtrain);
xt = x(1:nT); yt = y(1:nT);
xn = x(nT+1:end); yn = y(nT+1:end);

cla(ax); hold(ax,'on'); box(ax,'on'); grid(ax,'on');
if ~isempty(Gtrain)
    Gtrain = Gtrain(:);
    plot(ax,xt(Gtrain==1),yt(Gtrain==1),'bo','MarkerFaceColor',[0.18 0.42 0.78],'MarkerSize',5);
    plot(ax,xt(Gtrain~=1),yt(Gtrain~=1),'ro','MarkerFaceColor',[0.85 0.25 0.20],'MarkerSize',5);
else
    plot(ax,xt,yt,'bo','MarkerFaceColor',[0.18 0.42 0.78],'MarkerSize',5);
end

if isempty(Gnew)
    acc = accepted(nT+1:end);
    plot(ax,xn(acc),yn(acc),'gs','MarkerFaceColor',[0.20 0.70 0.30],'MarkerSize',7);
    plot(ax,xn(~acc),yn(~acc),'ks','MarkerFaceColor',[0.10 0.10 0.10],'MarkerSize',7);
else
    Gnew = Gnew(:);
    plot(ax,xn(Gnew==1),yn(Gnew==1),'cs','MarkerFaceColor',[0.00 0.70 0.90],'MarkerSize',7);
    plot(ax,xn(Gnew~=1),yn(Gnew~=1),'ms','MarkerFaceColor',[0.75 0.20 0.75],'MarkerSize',7);
end

xlimv = axis_limits(x);
ylimv = axis_limits(y);
line([1 1],ylimv,'Parent',ax,'Color',[0.25 0.25 0.25],'LineStyle','--','LineWidth',1.2);
line(xlimv,[1 1],'Parent',ax,'Color',[0.25 0.25 0.25],'LineStyle','--','LineWidth',1.2);
xlim(ax,xlimv); ylim(ax,ylimv);
xlabel(ax,'Q / Qcrit'); ylabel(ax,'Normalized PF distance (boundary = 1)');
title(ax,titleStr);
legend(ax,{'Train target','Train non-target','New accepted/target','New rejected/non-target'},'Location','Best');

if showLabels
    for i = 1:numel(xn)
        if isempty(newLabels)
            lab = num2str(i);
        elseif iscell(newLabels)
            if i <= numel(newLabels), lab = newLabels{i}; else, lab = num2str(i); end
        else
            if i <= numel(newLabels), lab = num2str(newLabels(i)); else, lab = num2str(i); end
        end
        text(xn(i),yn(i),[' ' lab],'Parent',ax,'FontSize',8);
    end
end
hold(ax,'off');

    function lim = axis_limits(v)
        v = v(:); v = v(isfinite(v));
        if isempty(v), lim = [0 1.2]; return; end
        mn = min([0; v; 1]);
        mx = max([1; v]);
        if mn == mx, mn = mn-0.5; mx = mx+0.5; end
        pad = 0.08*(mx-mn);
        lim = [max(0,mn-pad) mx+pad];
    end
end
