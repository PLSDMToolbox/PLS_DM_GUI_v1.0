%
function PLSDMpred = plsdm_predict_unknown(Xunk, PLSDMmodel);
% PLSMD_PREDICT_UNKNOWN - Applies a trained PLS-DM model to unknown samples
%
% SYNTAX:
%   PLSDMpred = plsdm_predict_unknown(Xunk, PLSDMmodel)
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

LV = PLSDMmodel.LVopt;
if numel(LV) > 1, LV = LV(end); end
PLSmodel = PLSDMmodel.FinalModel;
Qcrit    = PLSmodel.Qlimit;
f_alpha  = PLSmodel.flimit;
PV = pls_predict(Xunk, PLSmodel, LV);   
Qcrit   = max(Qcrit, realmin('double'));
floor_f = 1e-12;
f       = PV.f;  f(~isfinite(f) | f<=0) = floor_f;
if ~(isfinite(f_alpha) && f_alpha>0), f_alpha = floor_f; end

Q      = PV.Q;
Qnorm  = Q ./ Qcrit;
logf   = -log(f);
loga   = -log(f_alpha);
logf_norm = logf ./ loga;

% --- Acceptance (original PLS-DM direct decision)
accepted       = (Q <= Qcrit) & (f >= f_alpha);
predictedLabel = double(accepted);  % 1=accepted; 0=rejected

%  results
PLSDMpred = struct();
PLSDMpred.Q              = Q(:);
PLSDMpred.f              = f(:);
PLSDMpred.Qcrit          = Qcrit;
PLSDMpred.f_alpha        = f_alpha;
PLSDMpred.Qnorm          = Qnorm(:);
PLSDMpred.logf_norm      = logf_norm(:);
PLSDMpred.accepted       = accepted(:);
PLSDMpred.predictedLabel = predictedLabel(:);
PLSDMpred.counts         = struct('accepted', sum(accepted), ...
                                  'rejected', sum(~accepted));

PLSDMpred.PVresult = PV;
PLSDMpred.Xunk = Xunk;

% Plotting is controlled by the GUI/export buttons.
% plot_plsdm_acceptance_logscale_unknown(Q, f, Qcrit, f_alpha, [], PLSDMmodel, Xunk);
