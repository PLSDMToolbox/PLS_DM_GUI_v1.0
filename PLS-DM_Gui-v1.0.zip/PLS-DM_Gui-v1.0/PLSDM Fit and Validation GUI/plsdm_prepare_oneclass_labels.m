%
function [ClassOne, info] = plsdm_prepare_oneclass_labels(ClassTrain, targetClass)
% PLSDM_PREPARE_ONECLASS_LABELS Toolbox routine.
% Syntax: function [ClassOne, info] = plsdm_prepare_oneclass_labels(ClassTrain, targetClass)
% Inputs and outputs are defined by the function signature.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

ClassTrain = ClassTrain(:);
targetClass = targetClass(1);

idxTarget = (ClassTrain == targetClass);
if sum(idxTarget) == 0
    error('Selected target class was not found in ClassTrain.');
end

ClassOne = 2*ones(size(ClassTrain));
ClassOne(idxTarget) = 1;

classes = unique(ClassTrain);
info = struct();
info.targetClass = targetClass;
info.originalClasses = classes(:);
info.originalClassTrain = ClassTrain;
info.nTarget = sum(idxTarget);
info.nNonTarget = sum(~idxTarget);
end
