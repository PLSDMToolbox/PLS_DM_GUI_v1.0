%
function [ok, names, values] = plsdm_select_workspace_vars(titleStr, labels, defaults, allowNone)
% PLSDM_SELECT_WORKSPACE_VARS Toolbox routine.
% Syntax: function [ok, names, values] = plsdm_select_workspace_vars(titleStr, labels, defaults, allowNone)
% Inputs and outputs are defined by the function signature.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

ok = false;
names = {};
values = {};

if nargin < 1 || isempty(titleStr), titleStr = 'Select workspace variables'; end
if nargin < 2, labels = {}; end
n = length(labels);
if nargin < 3 || isempty(defaults), defaults = cell(n,1); end
if nargin < 4 || isempty(allowNone), allowNone = num2cell(false(n,1)); end

W = evalin('base','whos');
varNames = cell(length(W),1);
for i = 1:length(W)
    varNames{i} = W(i).name;
end
if isempty(varNames)
    varNames = {'<workspace empty>'};
end

figH = max(210, 95 + 45*n);
figW = 430;
scr = get(0,'ScreenSize');
dlg = figure('Name',titleStr,'NumberTitle','off','MenuBar','none','Toolbar','none', ...
    'WindowStyle','modal','Resize','off','Color',[0.96 0.97 0.99], ...
    'Units','pixels','Position',[scr(3)/2-figW/2 scr(4)/2-figH/2 figW figH]);

uicontrol('Parent',dlg,'Style','text','String',titleStr, ...
    'Units','pixels','Position',[18 figH-48 figW-36 24], ...
    'BackgroundColor',[0.96 0.97 0.99], ...
    'ForegroundColor',[0.12 0.18 0.28], ...
    'HorizontalAlignment','left','FontWeight','bold','FontSize',11);

pop = zeros(n,1);
for i = 1:n
    y = figH - 80 - 38*(i-1);
    uicontrol('Parent',dlg,'Style','text','String',labels{i}, ...
        'Units','pixels','Position',[22 y 145 22], ...
        'BackgroundColor',[0.96 0.97 0.99], ...
        'HorizontalAlignment','left');
    choices = varNames;
    if allowNone{i}
        choices = [{'<none>'}; choices(:)];
    end
    val = 1;
    if ~isempty(defaults{i})
        for j = 1:length(choices)
            if strcmp(choices{j},defaults{i})
                val = j;
                break;
            end
        end
    end
    pop(i) = uicontrol('Parent',dlg,'Style','popupmenu','String',choices, ...
        'Value',val,'Units','pixels','Position',[175 y 230 24], ...
        'BackgroundColor',[1 1 1]);
end

uicontrol('Parent',dlg,'Style','pushbutton','String','OK', ...
    'Units','pixels','Position',[235 18 78 30], ...
    'FontWeight','bold','Callback',@onOK);
uicontrol('Parent',dlg,'Style','pushbutton','String','Cancel', ...
    'Units','pixels','Position',[325 18 78 30], ...
    'Callback',@onCancel);

uiwait(dlg);

    function onOK(src,ev)
        names = cell(n,1);
        values = cell(n,1);
        try
            for k = 1:n
                choices = get(pop(k),'String');
                idx = get(pop(k),'Value');
                nm = choices{idx};
                names{k} = nm;
                if strcmp(nm,'<none>') || strcmp(nm,'<workspace empty>')
                    values{k} = [];
                else
                    values{k} = evalin('base',nm);
                end
            end
            ok = true;
        catch ME
            errordlg(ME.message,titleStr);
            return;
        end
        if ishandle(dlg), uiresume(dlg); delete(dlg); end
    end

    function onCancel(src,ev)
        ok = false;
        if ishandle(dlg), uiresume(dlg); delete(dlg); end
    end
end
