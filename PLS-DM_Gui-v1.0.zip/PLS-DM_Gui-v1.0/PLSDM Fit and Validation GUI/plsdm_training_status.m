%
function status = plsdm_training_status(Q,f,Qalpha,falpha,Qgamma,fgamma,Gtrue)
% Target-training categories under the paper's inclusive joint rule.
% 0: non-target; 1: regular; 2: extreme; 3: outlier.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================
Q = Q(:); f = f(:); Gtrue = Gtrue(:);
if numel(Gtrue) ~= numel(Q), error('Invalid training class length.'); end
[~,~,~,~,~,regular] = plsdm_acceptance_coordinates(Q,f,Qalpha,falpha);
[~,~,~,~,~,insideOuter] = plsdm_acceptance_coordinates(Q,f,Qgamma,fgamma);
target = Gtrue == 1;
status = zeros(numel(Q),1);
status(target & regular) = 1;
status(target & ~regular & insideOuter) = 2;
status(target & ~insideOuter) = 3;
end
