%
function PLSDMvalidation = plsdm_val(Xval, ClassVal, PLSDMmodel)
% PLSDM_VAL - Validates a PLS-DM model using an external validation set.
%
% SYNTAX:
%   PLSDMvalidation = plsdm_val(Xval, ClassVal, PLSDMmodel)
%
% INPUTS:
%   Xval        - Validation data matrix (samples-by-variables)
%   ClassVal    - Class labels for the validation set (target vs non-target)
%   PLSDMmodel  - Struct containing the trained PLS-DM model, including:
%                 .LVopt     - Optimal number of latent variables
%                 .FinalModel - Struct with PLS model, Q limit, and f limit
%
% OUTPUT:
%   PLSDMvalidation - Struct containing validation results and metrics
%
% DESCRIPTION:
%   This function applies the trained PLS-DM model to an external validation set,
%   classifies the samples, calculates performance metrics (e.g., sensitivity,
%   specificity, precision, accuracy, F1-score, efficiency), and displays
%   the results in a formatted table. It also plots the acceptance diagram
%   for the validation set in log scale.
% Indicate validation type
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

PLSDMvalidation.val = 'Validation by external set';

% Retrieve optimal LV and model parameters
LV      = PLSDMmodel.LVopt;
PLSmodel = PLSDMmodel.FinalModel;
Qlimit   = PLSDMmodel.FinalModel.Qlimit;
flimit   = PLSDMmodel.FinalModel.flimit;

% Predict using the trained PLS-DM model
PVresult = pls_predict(Xval, PLSmodel, LV);

% Classify results according to Q and f limits
CVresults = classify_pls_dm(PVresult.Q, PVresult.f, Qlimit, flimit, ClassVal);

% Extract metrics
TP          = CVresults.TP; 
FP          = CVresults.FP;
TN          = CVresults.TN;
FN          = CVresults.FN;
sensitivities = CVresults.sensitivity;
specificities = CVresults.specificity;
precision     = CVresults.precision;
accuracy      = CVresults.accuracy;
f1score       = CVresults.f1score;
efficiency    = CVresults.efficiency;

% Display separator
disp('--------------------------------------------------------------------')
disp(' ')

% Print report header
fprintf('Report generated based on validation set evaluation metrics.\n\n');

% Print table header
fprintf(' LV |  FP |  FN |  TP |  TN | Sensitivity | Specificity | Precision |  F1-Score | Accuracy | Efficiency\n');
fprintf('----|-----|-----|-----|-----|-------------|-------------|-----------|-----------|----------|-----------\n');

% Print metrics for each LV
for i = 1:length(LV)
    fprintf('%3d | %3d | %3d | %3d | %3d |     %6.3f   |     %6.3f   |   %6.3f  |   %6.3f  |  %6.3f  |   %6.3f\n', ...
        LV(i), FP(i), FN(i), TP(i), TN(i), sensitivities(i), specificities(i), precision(i), f1score(i), accuracy(i), efficiency(i));
end

% Display confusion matrix for the last LV
fprintf('\nConfusion Matrix for LV = %d:\n', LV(end));
fprintf('           Predicted Positive    Predicted Negative\n');
fprintf('Actual Positive      %5d               %5d\n', TP(end), FN(end));
fprintf('Actual Negative      %5d               %5d\n', FP(end), TN(end));

PLSDMvalidation.PVresult = PVresult;
PLSDMvalidation.CVresults = CVresults;
PLSDMvalidation.Xval = Xval;
PLSDMvalidation.ClassVal = ClassVal(:);
PLSDMvalidation.LV = LV;
PLSDMvalidation.Qlimit = Qlimit;
PLSDMvalidation.flimit = flimit;

% Plotting is controlled by the GUI/export buttons.
% plot_plsdm_acceptance_logscale_val_ext(PVresult.Q, PVresult.f, Qlimit, flimit, ClassVal,10, PLSDMmodel, Xval);

end
