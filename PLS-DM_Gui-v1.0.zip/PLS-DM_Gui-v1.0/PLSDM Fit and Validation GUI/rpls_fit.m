%
function PLSmodel = rpls_fit(X, y, maxLV, conflev, alpha, preprocessing, gama)
% SYNTAX: PLSMODEL = pls_fit(X, y, maxLV, conflev, alpha, preprocessing, gama)
%
% Fits a (robust) PLS model with optional preprocessing and computes
% Q-residual statistics and potential-function densities for PLS-DM.
%
% The robust PRM-like PLS core uses weighted NIPALS with sample weights.
% Weights are updated iteratively from y residuals (r_y), X-residual Q
% statistics, and score leverage. Tukey bisquare weighting is applied.
%
% Inputs:
%   X            - Training predictors (n x m)
%   y            - Training responses (n x 1)
%   maxLV        - Number of latent variables to extract
%   conflev      - Confidence level for Q and f limits (e.g., 0.95)
%   alpha        - Smoothing coefficient for PFM (e.g., 0.3-0.8)
%   preprocessing - 'raw' | 'centered' | 'scaled' | 'autoscaled'
%   gama         - Significance level for outlier detection (used in QlimitO, flimitO)
%
% Output:
%   PLSmodel - Struct with all model parameters and thresholds

% Check inputs
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 7
    error('All 7 arguments must be provided.');
end

[n, m] = size(X);
y      = y(:);

% === Robust preprocessing based on the median and MAD ===
mu    = median(X, 1);
sigma = mad(X, 0, 1) * 1.4826;
sigma(sigma == 0) = 1;

olimit = (1 - gama)^(1/n);

switch lower(preprocessing)
    case 'raw'
        Xp    = X;
        mu    = zeros(1, m);
        sigma = ones(1, m);

    case 'centered'
        Xp = X - repmat(mu, n, 1);

    case 'scaled'
        Xp = X ./ repmat(sigma, n, 1);

    case 'autoscaled'
        Xp = (X - repmat(mu, n, 1)) ./ repmat(sigma, n, 1);

    otherwise
        error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
end

% =====================================================================
% === ROBUST PRM-LIKE PLS CORE ============================================
% =====================================================================
% Fit maxLV latent variables simultaneously while iterating sample weights.

% Initial sample weights.
wSample   = ones(n,1);
maxRobIter = 10;
tolRob     = 1e-3;

% Initialization.
T  = zeros(n, maxLV);
P  = zeros(m, maxLV);
W  = zeros(m, maxLV);
Qy = zeros(1, maxLV);

for itRob = 1:maxRobIter

    % 1) PLS ponderado com maxLV LVs (NIPALS multi-LV)
    [W, P, Qy, T] = wpls_nipals_multilv(Xp, y, maxLV, wSample);

    % 2) Regression coefficients.
    B = W * ((P' * W) \ Qy');

    % 3) Training prediction and y residuals.
    y_pred = Xp * B;
    r_y    = y - y_pred;

    % 4) X-residual Q statistics using reconstruction with all LVs.
    Xhat        = T(:,1:maxLV) * P(:,1:maxLV)';
    Resid_train = Xp - Xhat;
    Qtrain      = sum(Resid_train.^2, 2);

    % 5) Score-based leverage using all LVs.
    h = sum(T.^2, 2) ./ (sum(sum(T.^2)) + eps);

    % 6) Robust median/MAD scales for r_y, Qtrain, and h.
    med_ry = median(r_y);
    s_ry   = mad(r_y, 1) * 1.4826;  if s_ry == 0, s_ry = eps; end
    zY     = (r_y - med_ry) / s_ry;

    med_Q = median(Qtrain);
    s_Q   = mad(Qtrain, 1) * 1.4826; if s_Q == 0, s_Q = eps; end
    zQ    = (Qtrain - med_Q) / s_Q;

    med_h = median(h);
    s_h   = mad(h, 1) * 1.4826; if s_h == 0, s_h = eps; end
    zH    = (h - med_h) / s_h;

    % 7) Combine diagnostics into the global distance d.
    cY = 4.685; cQ = 4.685; cH = 3.0;
    alphaY = 1;  alphaQ = 1;   alphaH = 1;

    d = sqrt( ...
        (alphaY * (zY / cY)).^2 + ...
        (alphaQ * (zQ / cQ)).^2 + ...
        (alphaH * (zH / cH)).^2 );

    % 8) Robust Tukey bisquare weights.
    w_new = bisquare_tukey(d);
    if all(w_new == 0)
        w_new = ones(n,1);
    end
    w_new = w_new / sum(w_new);

    % 9) Weight-convergence criterion.
    if norm(w_new - wSample) < tolRob * norm(wSample)
        wSample = w_new;
        break;
    end

    wSample = w_new;
end


% =====================================================================
% === Q residuals and Jackson limits ======================================
% =====================================================================

% Q residuals using all latent variables.
Xhat = T(:,1:maxLV) * P(:,1:maxLV)';
Xrec = Xp - Xhat;
Q    = sum(Xrec.^2, 2);

% Residual covariance for the Jackson approximation.
Qlimit = plsdm_original_qlimit(Xrec,conflev);
QlimitO = plsdm_original_qlimit(Xrec,olimit);

% =====================================================================
% === Potential Function (PFM) f estimation ===========================
% =====================================================================
[~,f_alpha,f_train] = plsdm_original_pfm(T(:,1:maxLV),T(:,1:maxLV),alpha,conflev);
[~,f_alphaO] = plsdm_original_pfm(T(:,1:maxLV),T(:,1:maxLV),alpha,olimit);

% =====================================================================
% === VIP scores =======================================================
% =====================================================================
SSY = zeros(maxLV,1);
for a = 1:maxLV
    ta = T(:,a);
    qa = Qy(a);
    SSY(a) = (ta' * ta) * (qa^2);
end
denSSY = sum(SSY);
if denSSY <= eps
    vip = NaN(m,1);
else
    vip = zeros(m,1);
    for j = 1:m
        s = 0;
        for a = 1:maxLV
            wa      = W(:,a);
            wja     = W(j,a);
            denom_w = wa' * wa;
            if denom_w <= eps, denom_w = eps; end
            s = s + SSY(a) * (wja^2) / denom_w;
        end
        vip(j) = sqrt( (m * s) / denSSY );
    end
end

% =====================================================================
% === Output struct ====================================================
% =====================================================================
PLSmodel.Xmean         = mu;
PLSmodel.Xstd          = sigma;
PLSmodel.preprocessing = preprocessing;
PLSmodel.W             = W;
PLSmodel.P             = P;
PLSmodel.Qy            = Qy;
PLSmodel.B             = B;
PLSmodel.T             = T;
PLSmodel.maxLV         = maxLV;
PLSmodel.conflev       = conflev;
PLSmodel.alpha         = alpha;
PLSmodel.Qlimit        = Qlimit;
PLSmodel.Qresid        = Q;
PLSmodel.flimit        = f_alpha;
PLSmodel.f_train       = f_train;
PLSmodel.VIP           = vip;
PLSmodel.QlimitO       = QlimitO;
PLSmodel.flimitO       = f_alphaO;

end % ===== end main function =====


% =====================================================================
% === LOCAL HELPERS FOR ROBUST PLS ========================================
% =====================================================================

function [W, P, Qy, T] = wpls_nipals_multilv(X, y, a, wSample)
% WPLS_NIPALS_MULTILV - Multi-LV PLS with sample weights (NIPALS).
%
% X       : (n x m)
% y       : (n x 1)
% a       : number of latent variables
% wSample : n-by-1 sample weights; normalization is not required

    y       = y(:);
    wSample = wSample(:);
    wSample = wSample / sum(wSample);

    [n, m] = size(X);

    W  = zeros(m,a);
    P  = zeros(m,a);
    Qy = zeros(1,a);
    T  = zeros(n,a);

    Xres = X;
    yres = y;

    maxIter = 100;
    tol     = 1e-10;

    for comp = 1:a
        % Initialize u from yres.
        u = yres;

        for it = 1:maxIter
            % Weighted regression Xres ~ u.
            Wu = wSample .* u;
            w  = Xres' * Wu;            % p x 1
            w  = w / max(norm(w), eps); % normaliza

            % score t
            t = Xres * w;               % n x 1

            % Weighted regression yres ~ t.
            Wt   = wSample .* t;
            numq = (yres' * Wt);
            denq = (t'    * Wt) + eps;
            q    = numq / denq;

            % novo u
            u_new = q * t;

            if norm(u_new - u) < tol * (norm(u) + eps)
                u = u_new;
                break;
            end
            u = u_new;
        end

        % X loading.
        Wt   = wSample .* t;
        nump = Xres' * Wt;
        denp = (t'   * Wt) + eps;
        p    = nump / denp;

        % salva
        W(:,comp)  = w;
        P(:,comp)  = p;
        Qy(:,comp) = q;
        T(:,comp)  = t;

        % Deflation.
        Xres = Xres - t * p';
        yres = yres - t * q;
    end
end


function w = bisquare_tukey(d)
% BISQUARE_TUKEY  Tukey's bisquare weights
%
% Input:
%   d : vector of combined distances (already scaled)
%
% Output:
%   w : vector of weights in [0,1]

    w   = zeros(size(d));
    idx = (d < 1);
    di  = d(idx);
    w(idx) = (1 - di.^2).^2;
end
