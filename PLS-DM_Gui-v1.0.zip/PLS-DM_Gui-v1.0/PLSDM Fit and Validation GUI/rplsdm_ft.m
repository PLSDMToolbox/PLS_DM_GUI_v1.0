%
function PLSDMmodel=rplsdm_ft(Xtrain, ClassTrain, K, LV, conflev, alpha, kappa,preprocessing,var_label,gama,status);
% PLSDM_FT - Train and evaluate a PLS-DM (Partial Least Squares - Density Modeling)
%
% Syntax:
%   PLSDMmodel = plsdm_ft(Xtrain, ClassTrain, K, LV, conflev, alpha, kappa, preprocessing)
%
%             or
%   PLSDMmodel = plsdm_ft(Xtrain, ClassTrain)
%--------------------------------------------------------------------------
% Description:
%   This function trains and evaluates a PLS-DM model for one-class
%   classification using Q-residuals and the Potential Function Method (PFM).
%   It supports evaluation in "compliant" mode (sensitivity, specificity, and
%   efficiency) or "rigorous" mode (sensitivity only). The procedure includes
%   data pre-processing, cross-validation, performance metric computation,
%   and visualization of results.
%
% Inputs:
%   Xtrain        - Data matrix (N x M) of predictor variables for the training set.
%                   N = number of samples, M = number of variables.
%
%   ClassTrain    - Column vector (N x 1) of class labels.
%                   Must contain 1 for target-class samples and values
%                   different from 1 for non-target samples.
%                   Any value different from 1 will be automatically converted to 2.
%
%   K             - Number of folds for K-fold cross-validation (positive integer).
%                   Default: 5.
%
%   LV            - Maximum number of latent variables (LVs) to be evaluated
%                   during cross-validation.
%                   Default: 10.
%
%   conflev       - Confidence level for computing the critical thresholds
%                   of Q-residuals and the potential function (0 < conflev < 1).
%                   Default: 0.95.
%
%   alpha         - Smoothing coefficient for the potential function (PFM),
%                   used to smooth the estimated densities.
%                    Default: 0.3.
%
%   kappa         - Number of nearest neighbors (kNN) used to estimate the
%                   class density, which is used as the response variable in PLS.
%                   Default: 1.
%
%   preprocessing - String specifying the type of data pre-processing:
%                       'raw'        -> no pre-processing
%                       'centered'   -> mean centering
%                       'scaled'     -> scaling by standard deviation
%                       'autoscaled' -> mean centering + scaling
%                       Default: 'raw'
%
%   var_label - label of varibles in X matrix i smust be a vector (1 x N)
%                        Default: absent
%   gama      - Significance level for outlier detection. Defalut 0.01
%   Status     - The status vector contains the classification result of each
%                sample according to the two-boundary outlier detection scheme.
%                Each element %  corresponds to one sample in the input data 
%                and can take one of the following values: 
%                                 1 - Regular sample,
%                                 2 - Extreme sample,
%                                 3 - Outlier sample,
%                                 0 - Not evaluated/non-target (implementation dependent)
% Outputs:
%   PLSDMmodel - Structure containing:
%       .model         - Model name ('PLS-DM model')
%       .Xtrain        - Original input data
%       .ClassTrain    - Class vector used for training
%       .K             - Number of folds used
%       .LV            - Maximum number of LVs evaluated
%       .conflev       - Confidence level used
%       .alpha         - Alpha coefficient used in PFM
%       .preprocessing - Applied pre-processing method
%       .kfoldmodel    - Structure with cross-validation results
%       .Compliance    - Classification results for each LV
%       .caseType      - 'compliant' or 'rigorous'
%       .TP_all, .FP_all, .TN_all, .FN_all - Vectors with counts per LV
%       .sen_all, .spec_all, .acc_all      - Sensitivity, specificity, accuracy per LV
%       .f1score_all, .precision_all, .eff_all - Additional performance metrics per LV
%       .LVopt         - Optimal number of LVs selected by the user
%       .FinalModel    - Final PLS-DM model trained with LVopt
%
% Required subfunctions:
%   ClassDensity1, pls_kfold, classify_pls_dm, pls_fit, pls_predict,
%   plot_plsdm_acceptance_logscale, plot_plsdm_acceptance_logscale_cv
% clc, close all,warning off
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

PLSDMmodel.model='PLS-DM model'

if nargin > 9
    [nX, ~] = size(Xtrain);
    nC      = numel(ClassTrain);
    nS      = numel(status);
    
    if nX ~= nC || nX ~= nS
        error('Inconsistent sizes: Xtrain (%d rows), ClassTrain (%d), status (%d).', ...
            nX, nC, nS);
    end
    % Ensure column vectors
    ClassTrain = ClassTrain(:);
    status     = status(:);
    % Find outliers (status == 3)
    idxRemoved = find(status == 3);
    idxKept    = setdiff((1:nX).', idxRemoved);
    % Remove outliers
    Xtrain   = Xtrain(idxKept, :);
    ClassTrain= ClassTrain(idxKept);
end

%--------------------------------------------------------------------------
[Nsam Nvar]=size(Xtrain);
max_class=max(ClassTrain);
Ctrain=ClassTrain;
%
if max_class>1
    nt_samples = find(ClassTrain ~= 1);
    Ctrain(nt_samples)=2;
    Xtrain2=Xtrain(nt_samples,:);
    Nsam2=size(Xtrain2,1);
end
%
t_samples=find(ClassTrain==1);
Xtrain1=Xtrain(t_samples,:);
Nsam1=size(Xtrain1,1);
%% -------------------------Check inputs-----------------------------------
if nargin < 3 || isempty(K)
    if Nsam1 > 19
        K = 5;
    else
        K =1;
    end
end

if nargin < 4 || isempty(LV)
    if Nsam > 10
        LV=10;
    else
        LV=Nsam-1;
    end
end

if nargin < 5 || isempty(conflev)
    conflev = 0.95;
end

if conflev <= 0 || conflev >= 1
    error('conflev must be between 0 and 1 (exclusive).');
end
%
if nargin < 6 || isempty(alpha)
    alpha = 0.3;
end
if nargin < 7 || isempty(kappa)
    kappa=1;
end
if nargin < 8 || isempty(preprocessing)
    preprocessing = 'raw';
end
if nargin < 9 || isempty(var_label)
    var_label=1:Nvar;
end

if nargin < 10 || isempty(gama)
    gama=0.01;
end
%%-------------------------------------------------------------------------
PLSDMmodel.Xtrain=Xtrain;
PLSDMmodel.ClassTrain=ClassTrain;
PLSDMmodel.K=K;
PLSDMmodel.LV=LV;
PLSDMmodel.conflev=conflev;
PLSDMmodel.gama=gama;
PLSDMmodel.alpha=alpha;
PLSDMmodel.preprocessing=preprocessing;
PLSDMmodel.var_label=var_label;
%%
%=== Preprocessing ===
[n, m] = size(Xtrain1);
mu = median(Xtrain1, 1);
sigma = mad(Xtrain1, 0, 1)* 1.4826;;
sigma(sigma == 0) = 1;

switch lower(preprocessing)
    case 'raw'
        Xpt = Xtrain1;
        mu = zeros(1, m);
        sigma = ones(1, m);
        if  max_class>1
            Xpu=Xtrain2;
        end
    case 'centered'
        Xpt = Xtrain1 - repmat(mu, n, 1);
        if  max_class>1
            Xpu=Xtrain2- repmat(mu, Nsam2, 1);
        end
    case 'scaled'
        Xpt = (Xtrain1./ repmat(sigma, n, 1));
        if  max_class>1
            Xpu=(Xtrain2 ./ repmat(sigma, Nsam2, 1));
        end
    case 'autoscaled'
        Xpt = (Xtrain1 - repmat(mu, n, 1)) ./ repmat(sigma, n, 1);
        if  max_class>1
            Xpu=(Xtrain2 - repmat(mu, Nsam2, 1)) ./ repmat(sigma, Nsam2, 1);
        end
    otherwise
        error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
end

%% Class density by knn
[D_sorted, idx_sorted, D] = ClassDensity1(Xpt,true);
dist1=D_sorted(:,2:Nsam1);
dist1=dist1(:,1:kappa);
ytrain=sum(dist1,2);
%
if  max_class==1
    Modelpls_kfold = rpls_kfold(Xtrain1,K, LV, conflev, alpha, preprocessing,kappa,[],gama);
end
%
if  max_class>1
    Modelpls_kfold = rpls_kfold(Xtrain1, K, LV, conflev, alpha, preprocessing,kappa,Xtrain2,gama);
end

PLSDMmodel.kfoldmodel=Modelpls_kfold;

% Samples Compliance
for k=1:LV
    
    Qresid=Modelpls_kfold .Qresid;
    Fdensity_cv=Modelpls_kfold .f_cv;
    % Regular cv limit
    Qlim=Modelpls_kfold .Qlims_perLV;
    qlimit=median(Qlim{k});
    flimits_perLV=Modelpls_kfold .flimits_perLV;
    flimit= median(flimits_perLV{k});
    qlimit_target=Modelpls_kfold.Qlimit_cv(:,k);
    flimit_target=Modelpls_kfold.flimit_cv(:,k);
%
%     Outliers cv limit
%     QlimOcv=Modelpls_kfold.QlimsO_perLV;
%     qlimitOcv=median(QlimOcv{k});
%     flimits_perLVO=Modelpls_kfold.flimitsO_perLV;
%     flimitOcv= median(flimits_perLVO{k});
    %
    if  max_class>1
        f_untarget_cv=Modelpls_kfold .f_untarget_cv;
        Q_untarget_cv=Modelpls_kfold .Q_untarget_cv;
        
    end
    %-----------------
    if  max_class == 1
        Qstat=[Qresid(:,k)];
        f_density=[Fdensity_cv(:,k)];
        qlimit=qlimit_target;
        flimit=flimit_target;
        Gtrue=ones(Nsam1,1);
    end
    %
    if  max_class> 1
        Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
        f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
        qlimit=[qlimit_target;Modelpls_kfold.Qlimit_untarget_cv(:,k)];
        flimit=[flimit_target;Modelpls_kfold.flimit_untarget_cv(:,k)];
        Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
    end
    %------------------
    results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
    Compliance{k}=results;
end
PLSDMmodel.Compliance=Compliance;

caseType = '';  % Will be determined dynamically
% Extract results from each LV
% ----------------------
for lv = 1:LV
    res = Compliance{lv};
    % Determine case type
    if isfield(res, 'Gtrue') && any(res.Gtrue ~= 1)
        caseType = 'compliant';
    else
        caseType = 'rigorous';
    end
    %
    TP_all(lv)=res.TP;
    FP_all(lv)=res.FP;
    TN_all(lv)=res.TN;
    FN_all(lv)=res.FN;
    sen_all(lv)= res.sensitivity;
    spec_all(lv) = res.specificity;
    acc_all(lv)  = res.accuracy;
    f1score_all(lv)=res.f1score;
    precision_all(lv)=res.precision;
    eff_all(lv)=res.efficiency;
    
end
% ----------------------
PLSDMmodel.caseType=caseType;
PLSDMmodel.TP_all=TP_all;
PLSDMmodel.FP_all= FP_all;
PLSDMmodel.TN_all=TN_all;
PLSDMmodel.FN_all=FN_all;
PLSDMmodel.sen_all=sen_all;
PLSDMmodel.spec_all=spec_all;
PLSDMmodel. acc_all= acc_all;
PLSDMmodel.f1score_all=f1score_all;
PLSDMmodel.precision_all= precision_all;
PLSDMmodel.eff_all=eff_all;
sensitivities = sen_all;
specificities =  spec_all;
efficiencies =eff_all;
LVs = 1:length(sensitivities);
[LVs, ord] = sort(LVs(:).');
sensitivities = sensitivities(ord);
if exist('specificities','var') && numel(specificities)==numel(LVs), specificities = specificities(ord); end
if exist('efficiencies','var')  && numel(efficiencies)==numel(LVs),  efficiencies  = efficiencies(ord);  end

% switch lower(caseType)
%     case 'compliant'
%         
%         col.rmse = [0.635 0.078 0.184];
%         col.sen  = [0.85  0.33  0.10 ];
%         col.spe  = [0.00  0.45  0.74 ];
%         col.eff  = [0.47  0.67  0.19 ];
%         msz = 7; lw = 2;
%         
%         
%         [dummy,i_eff]  = max(efficiencies(:));
%         lv_eff  = LVs(i_eff);
%         
%         figure('Color','w');
%         
%         % --- plot : Sensitivity / Specificity / Efficiency
%         
%         hold on; box on; grid on;
%         p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.sen);
%         p2 = plot(LVs, specificities, '-s', 'Color', col.spe, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.spe);
%         p3 = plot(LVs, efficiencies,  '-d', 'Color', col.eff, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.eff);
%         set(gca,'FontSize',12,'XMinorTick','on','YMinorTick','on');
%         xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
%         ylabel('Cross-validated performance','FontWeight','bold');
%         title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
%         ylim([0 1]);
%         xlim([min(LVs) max(LVs)]);
%         set(gca,'XTick',unique(LVs));
%         leg = legend([p1 p2 p3], {'Sensitivity','Specificity','Efficiency'}, 'Location','Best');
%         set(leg,'Box','off');
%         
%     case 'rigorous'
%         col.rmse = [0.635 0.078 0.184];
%         col.sen  = [0.85  0.33  0.10 ];
%         msz = 7; lw = 2;
%         [dummy,i_sen ] = max(sensitivities(:));
%         lv_sen  = LVs(i_sen);
%         figure('Color','w');
%         % --- plot 2: Sensitivity
%         hold on; box on; grid on;
%         p1 = plot(LVs, sensitivities, '-o', 'Color', col.sen, 'LineWidth', lw, 'MarkerSize', msz, 'MarkerFaceColor', col.sen);
%         set(gca,'FontSize',12,'XMinorTick','on','YMinorTick','on');
%         xlabel('Number of Latent Variables (LVs)','FontWeight','bold');
%         ylabel('Cross-validated performance','FontWeight','bold');
%         title('PLS-DM Model Performance vs Number of LVs','FontWeight','bold');
%         ylim([0 1]);
%         xlim([min(LVs) max(LVs)]);
%         set(gca,'XTick',unique(LVs));
%         leg = legend(p1, {'Sensitivity'}, 'Location','Best');
%         set(leg,'Box','off');
%         
%     otherwise
%         error('Invalid caseType. Must be ''compliant'' or ''rigorous''.');
% end
% 
% % =========================================================================
%     function h = vline2010(x, style, color, labelStr)
%         
%         if nargin < 2 || isempty(style), style = '--'; end
%         if nargin < 3 || isempty(color), color = [0 0 0]; end
%         if nargin < 4, labelStr = ''; end
%         ax = gca;
%         yl = get(ax,'YLim');
%         h  = line([x x], yl, 'LineStyle', style, 'Color', color, 'LineWidth', 1.2);
%         
%         if ~isempty(labelStr)
%             dy = 0.04*(yl(2)-yl(1));
%             text(x, yl(1)+dy, labelStr, 'HorizontalAlignment','center', ...
%                 'VerticalAlignment','bottom', 'Color', color, 'FontSize',10, 'FontWeight','bold');
%         end
%     end

%% FINAL MODEL -----------------
% clc
% disp('--------------------------------------------------------------------')
% disp('          *PLS - DM: Training stage*                            ')
% disp('--------------------------------------------------------------------')
% %
% disp(' ')
% LVopt=input ('Indicate the optimal number of latent variables to be used in the final model :  ');
LVopt=LV;
if numel(LVopt) > 1
    LVopt = LVopt(end);
end
PLSDMmodel.LVopt=LVopt;
PLSmodel = rpls_fit(Xtrain1, ytrain,LVopt, conflev, alpha, preprocessing,gama);
%% CV lv optimal results
Qresidcv=Modelpls_kfold .Qresid;
Fdensity_cv=Modelpls_kfold .f_cv;
Qlim=Modelpls_kfold .Qlims_perLV;
qlimitcv=mean(Qlim{LVopt});
flimits_perLV=Modelpls_kfold .flimits_perLV;
flimitcv= mean(flimits_perLV{LVopt});
qlimit_target_cv=Modelpls_kfold.Qlimit_cv(:,LVopt);
flimit_target_cv=Modelpls_kfold.flimit_cv(:,LVopt);
Gtruecv=ones(Nsam1,1);
if  max_class>1
    f_untarget_cv=Modelpls_kfold .f_untarget_cv;
    Q_untarget_cv=Modelpls_kfold .Q_untarget_cv;
    
end
%-----------------
if  max_class == 1
    Qstatcv=[Qresid(:,LVopt)];
    f_densitycv=[Fdensity_cv(:,LVopt)];
    qlimitcv=qlimit_target_cv;
    flimitcv=flimit_target_cv;
end
%
if  max_class> 1
    Qstatcv=[Qresid(:,LVopt);Q_untarget_cv(:,LVopt)];
    f_densitycv=[Fdensity_cv(:,LVopt);f_untarget_cv(:,LVopt)];
    qlimitcv=[qlimit_target_cv;Modelpls_kfold.Qlimit_untarget_cv(:,LVopt)];
    flimitcv=[flimit_target_cv;Modelpls_kfold.flimit_untarget_cv(:,LVopt)];
    Gtruecv=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
end
%
TP=TP_all(LVopt);
FP=FP_all(LVopt);
TN=TN_all(LVopt);
FN=FN_all(LVopt);
sensitivities=sen_all(LVopt);
specificities=spec_all(LVopt);
accuracy=acc_all(LVopt);
f1score=f1score_all(LVopt);
precision=precision_all(LVopt);
efficiency=eff_all(LVopt);
LVs = LVopt;
% clc disabled for GUI use
PLSDMmodel.FinalModel=PLSmodel;
Qlimit=PLSDMmodel.FinalModel.Qlimit;
flimit=PLSDMmodel.FinalModel.flimit;
Gtrue=ClassTrain;
Presult = pls_predict(Xtrain, PLSmodel, LVopt);
Cresults = classify_pls_dm(Presult.Q, Presult.f, Qlimit, flimit, Gtrue);
PLSDMmodel.Presult=Presult;
PLSDMmodel.Cresults=Cresults;
TP=Cresults.TP ;
FP=Cresults.FP ;
TN=Cresults.TN;
FN=Cresults.FN;
sensitivities=Cresults.sensitivity;
specificities=Cresults.specificity;
precision=Cresults.precision;
accuracy=Cresults.accuracy;
f1score=Cresults.f1score;
efficiency=Cresults.efficiency;
%--------------------------------------------------------------------------
PLSDMmodel.acp_train_q=Presult.Q;
PLSDMmodel.acp_train_pf=Presult.f;
PLSDMmodel.acp_train_Qlimit= Qlimit;
PLSDMmodel.acp_train_flimit= flimit;
PLSDMmodel.acp_cv_q=Qstatcv;
PLSDMmodel.acp_cv_pf=f_densitycv;
PLSDMmodel.acp_cv_qlimitcv=qlimitcv;
PLSDMmodel.acp_cv_flimitcv=flimitcv;
PLSDMmodel.kfoldmodel=Modelpls_kfold;
if isfield(Modelpls_kfold,'Qlims_perLV')
    PLSDMmodel.Qlims_perLV=Modelpls_kfold.Qlims_perLV;
end
if isfield(Modelpls_kfold,'flimits_perLV')
    PLSDMmodel.flimits_perLV=Modelpls_kfold.flimits_perLV;
end
if isfield(Modelpls_kfold,'Qlimit_cv')
    PLSDMmodel.Qlimit_cv=Modelpls_kfold.Qlimit_cv;
end
if isfield(Modelpls_kfold,'flimit_cv')
    PLSDMmodel.flimit_cv=Modelpls_kfold.flimit_cv;
end
%
%% 25/11/2025 Outiliers detection
QlimitO=PLSmodel.QlimitO;
FalphaO=PLSmodel.flimitO;
QlimOcv=Modelpls_kfold.QlimsO_perLV;
qlimitOcv=median(QlimOcv{LVopt});
flimits_perLVO=Modelpls_kfold.flimitsO_perLV;
flimitOcv= median(flimits_perLVO{LVopt});
%
% Plotting is handled by the GUI buttons (Q/f plot, CV plot).
% The command-line plotting calls are disabled here to avoid blocking the GUI.
% plot_plsdm_acceptance_logscale(Presult.Q, Presult.f, Qlimit, flimit, Gtrue,10,PLSDMmodel);
% plot_plsdm_acceptance_logscale_cv(Qstatcv, f_densitycv, qlimitcv, flimitcv, Gtruecv,10,PLSDMmodel);
% status = plot_plsdm_acceptance_logscale_out(Qstatcv, f_densitycv, qlimitcv, flimitcv, Gtrue,10,PLSDMmodel, QlimitO, FalphaO);
% status = plot_plsdm_acceptance_logscale_out(Qstatcv, f_densitycv, qlimitcv, flimitcv, Gtruecv,10,PLSDMmodel, qlimitOcv, flimitOcv);
PLSDMmodel.samples_status = plsdm_training_status(Presult.Q,Presult.f, ...
    Qlimit,flimit,QlimitO,FalphaO,Gtrue);
% PLSDMmodel.samples_status_cv=status_cv;
% clc
% disp(' ')
% fprintf('Report generated based on Robust PLS-DM cv evaluation metrics.\n\n');
% fprintf(' LV |  FP |  FN |  TP |  TN | Sensitivity | Specificity | Precision |  F1-Score | Accuracy | Efficiency\n');
% fprintf('----|-----|-----|-----|-----|-------------|-------------|-----------|-----------|----------|-----------\n');
% % Loop through each LV and print metrics
% for i = 1:length(LVs)
%     fprintf('%3d | %3d | %3d | %3d | %3d |     %6.3f   |     %6.3f   |   %6.3f  |   %6.3f  |  %6.3f  |   %6.3f\n', ...
%         LVs(i), FP(i), FN(i), TP(i), TN(i), sensitivities(i), specificities(i), precision(i), f1score(i), accuracy(i), efficiency(i));
% end
% 
% % Display confusion matrix for last LV
% fprintf('\nConfusion Matrix for LV = %d:\n', LVs(end));
% fprintf('           Predicted Positive    Predicted Negative\n');
% fprintf('Actual Positive      %5d               %5d\n', TP(end), FN(end));
% fprintf('Actual Negative      %5d               %5d\n', FP(end), TN(end));
%%
%--------------------------------------------------------------------------
% disp('--------------------------------------------------------------------')
% %
% disp(' ')
% 
% fprintf('Report generated based on Robust PLS-DM model evaluation metrics.\n\n');
% fprintf(' LV |  FP |  FN |  TP |  TN | Sensitivity | Specificity | Precision |  F1-Score | Accuracy | Efficiency\n');
% fprintf('----|-----|-----|-----|-----|-------------|-------------|-----------|-----------|----------|-----------\n');
% % Loop through each LV and print metrics
% for i = 1:length(LVs)
%     fprintf('%3d | %3d | %3d | %3d | %3d |     %6.3f   |     %6.3f   |   %6.3f  |   %6.3f  |  %6.3f  |   %6.3f\n', ...
%         LVs(i), FP(i), FN(i), TP(i), TN(i), sensitivities(i), specificities(i), precision(i), f1score(i), accuracy(i), efficiency(i));
% end
% % Display confusion matrix for last LV
% fprintf('\nConfusion Matrix for LV = %d:\n', LVs(end));
% fprintf('           Predicted Positive    Predicted Negative\n');
% fprintf('Actual Positive      %5d               %5d\n', TP(end), FN(end));
% fprintf('Actual Negative      %5d               %5d\n', FP(end), TN(end));
% %% Plotting acceptance
% area------------------------------------------------
end
