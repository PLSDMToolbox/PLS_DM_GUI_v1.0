%
function [D_sorted, idx_sorted, D] = ClassDensity1(X, include_self)
% SORTED_PAIRWISE_DISTANCES Compute pairwise Euclidean distances and sort them
% -------------------------------------------------------------------------
% [D_sorted, idx_sorted, D] = ClassDensity1(X)
% [D_sorted, idx_sorted, D] =ClassDensity1(X, include_self)
%
% Inputs:
%   X            - data matrix (n x p), n samples, p variables
%   include_self - optional logical flag:
%                  true  -> keep self-distances (zeros on diagonal) when sorting
%                  false -> exclude self-distances by treating diagonal as Inf (default)
%
% Outputs:
%   D_sorted  - (n x n) matrix where each row i contains distances from sample i
%               to all samples sorted in ascending order
%   idx_sorted- (n x n) matrix with corresponding column indices: idx_sorted(i,k)
%               gives the original column index of the k-th nearest sample to i
%   D         - (n x n) full symmetric distance matrix (unsorted)
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 2
    include_self = false; % default: exclude self-distances when sorting
end

if ~isnumeric(X)
    error('Input X must be a numeric matrix.');
end
[n, p] = size(X);
sq_norms = sum(X.^2, 2);
D2 = bsxfun(@plus, sq_norms, sq_norms') - 2 * (X * X');
D2(D2 < 0 & D2 > -1e-12) = 0;
D = sqrt(D2);
if ~include_self
    D_no_self = D;
    D_no_self(1:n+1:end) = Inf;
else
    D_no_self = D;
end
[D_sorted, idx_sorted] = sort(D_no_self, 2, 'ascend');

end
