%
function PLSDMopt_avd(PLSDMopt, prepro)
% Advanced wrapper to launch the optimization dashboard for a given preprocessing
% Syntax:%   PLSDMopt_avd(PLSDMopt, 'raw' | 'centered' | 'scale' | 'autoscale')
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    if nargin < 2 || isempty(prepro)
        prepro = 'raw';
    end

    % Normalize preprocessing label
    prepro_norm = normalize_prepro_local(prepro);
    field_candidates = get_field_candidates(prepro_norm);
    compliance = [];
    chosen_field = '';
    for k = 1:numel(field_candidates)
        f = field_candidates{k};
        if isfield(PLSDMopt, f) && ~isempty(PLSDMopt.(f))
            compliance = PLSDMopt.(f);
            chosen_field = f;
            break;
        end
    end

    if isempty(compliance)
        fprintf('PLSDMopt_avd: No compliance cube found for preprocessing "%s". Tried fields: ', prepro_norm);
        fprintf('%s ', field_candidates{:}); fprintf('\n');
        return;
    end

   
    if ~iscell(compliance) || ndims(compliance) ~= 3
        error('PLSDMopt_avd: The selected compliance field "%s" must be a 3D cell array (kappa x smooth x LV).', chosen_field);
    end

    [nK,nS,~] = size(compliance);
    [kappa_values, smooth_values] = derive_axes_vectors(PLSDMopt, nK, nS);
    conflev = PLSDMopt.conflev;

    
    try
        pls_dm_opt_dashboard(compliance, kappa_values, smooth_values, conflev, prepro_norm);
    catch ME
        fprintf('PLSDMopt_avd: Error while calling pls_dm_opt_dashboard: %s\n', ME.message);
    end
end

% --------------------

function out = normalize_prepro_local(prepro)
    if ~ischar(prepro), out = 'raw'; return; end
    p = lower(strtrim(char(prepro)));
    switch p
        case {'raw','none'}
            out = 'raw';
        case {'centered','centereed','center','centering','centre'}
            out = 'centered';
        case {'scale','scaled','scaling'}
            out = 'scale';
        case {'autoscale','auto','standardize','standardised','standardized'}
            out = 'autoscale';
        otherwise
            out = p; 
    end
end

function candidates = get_field_candidates(prepro_norm)
    
    switch prepro_norm
        case 'raw'
            candidates = {'ComplianceRAWmodels','ComplianceRawModels','ComplianceRawModel','ComplianceRAWmodel'};
        case 'centered'
            candidates = {'ComplianceCenteredmodel','ComplianceCenteredModel','ComplianceCenteredModels'};
        case 'scale'
            candidates = {'ComplianceScaledmodel','ComplianceScaledModel','ComplianceScaledModels'};
        case 'autoscale'
            candidates = {'ComplianceAutoscaledmodel','ComplianceAutoscaledModel','ComplianceAutoscaledModels'};
        otherwise
         %
            candidates = {['Compliance' prepro_norm 'model'], ['Compliance' prepro_norm 'Models']};
    end
end

function [kappa_values, smooth_values] = derive_axes_vectors(S, nK, nS)
    %
    kappa_values  = [];
    smooth_values = [];
     %
    if isfield(S,'KappaValues') && ~isempty(S.KappaValues) ...
            && isnumeric(S.KappaValues) && numel(S.KappaValues)==nK
        kappa_values = S.KappaValues(:).';
    end
    if isfield(S,'SmoothValues') && ~isempty(S.SmoothValues) ...
            && isnumeric(S.SmoothValues) && numel(S.SmoothValues)==nS
        smooth_values = S.SmoothValues(:).';
    end
   %
    if isempty(kappa_values),  kappa_values  = 1:nK; end
    if isempty(smooth_values), smooth_values = 1:nS; end
end
