%
function [results_struct, pareto_struct, best_model] = analyze_pls_dm_results(compliance, kappa_values, smooth_values, conflev, prepro)
% ANALYZE_PLS_DM_RESULTS - Analyze and visualize PLS-DM model results.
%
% INPUTS:
%   compliance     - 3D cell array of result structs (kappa x smooth x LV)
%   kappa_values   - Vector of kappa values (optional)
%   smooth_values  - Vector of smooth values (optional)
%   conflev        - (optional) threshold in rigorous mode (interpreted as 1 - alpha). Default = 0.95
%   prepro         - (optional) preprocessing name for titles/datapoints:
%                    'raw', 'centered', 'scale', 'autoscale'
%
% OUTPUTS:
%   results_struct - Struct array with metrics for all models
%   pareto_struct  - Pareto set in compliant mode; closest-sensitivity set in rigorous mode
% ---------------- PLOT FLAG -----------------------------------------------
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

showAllRigorous = true;   % true: plot all rigorous models; false: only closest models
% --------------------------------------------------------------------------

% Defaults
if nargin < 2 || isempty(kappa_values)
    kappa_values = 1:6;
    smooth_values = 0.3:0.1:0.8;
end
if nargin < 4 || isempty(conflev), conflev = 0.95; end
if nargin < 5 || isempty(prepro), prepro = 'raw'; end
prepro = normalize_prepro(prepro); %  label for titles/datapoints

[nK, nS, nLV] = size(compliance);
results_struct = [];
idx = 0;

% Extract & index models; keep grid indices for callbacks 
for i = 1:nK
    for j = 1:nS
        for lv = 1:nLV
            res = compliance{i,j,lv};
            if isempty(res), continue; end

            % Case type per model
            if isfield(res, 'Gtrue') && any(res.Gtrue ~= 1)
                caseType = 'compliant';
            else
                caseType = 'rigorous';
            end

            idx = idx + 1;
            results_struct(idx).ModelNum    = idx;
            results_struct(idx).Kappa       = kappa_values(i);
            results_struct(idx).Smooth      = smooth_values(j);
            results_struct(idx).LV          = lv;
            results_struct(idx).CaseType    = caseType;

            results_struct(idx).Sensitivity = getfield_safe(res, 'sensitivity');
            results_struct(idx).Specificity = getfield_safe(res, 'specificity');
            results_struct(idx).Precision   = getfield_safe(res, 'precision');
            results_struct(idx).Accuracy    = getfield_safe(res, 'accuracy');
            results_struct(idx).F1Score     = getfield_safe(res, 'f1score');
            results_struct(idx).Efficiency  = getfield_safe(res, 'efficiency');

            results_struct(idx).KIndex = i;
            results_struct(idx).SIndex = j;
            results_struct(idx).LVIndex = lv;
        end
    end
end

%  If nothing extracted, return empty 
if isempty(results_struct)
    pareto_struct = struct([]); best_model = struct([]);
    warning('No models found in input "compliance".');
    return;
end

%  Console table 
fprintf('\n=== ALL MODELS ===\n');
fprintf('Num | Kappa | Smooth | LV | Case      | Sens   | Spec   | Prec   | Acc    | F1     | Eff    \n');
fprintf('---------------------------------------------------------------------------------------------\n');
for ii = 1:length(results_struct)
    r = results_struct(ii);
    fprintf('%3d | %5d | %6.2f | %2d | %-9s | %.4f | %.4f | %.4f | %.4f | %.4f | %.4f\n', ...
        r.ModelNum, r.Kappa, r.Smooth, r.LV, r.CaseType, ...
        r.Sensitivity, r.Specificity, r.Precision, ...
        r.Accuracy, r.F1Score, r.Efficiency);
end

%  Decide which case to plot 
hasCompliant = any(strcmp({results_struct.CaseType}, 'compliant'));
hasRigorous  = any(strcmp({results_struct.CaseType}, 'rigorous'));

pareto_struct = struct([]); best_model = struct([]);

% ========================= COMPLIANT (Pareto) ============================
if hasCompliant
    selected_idx = strcmp({results_struct.CaseType}, 'compliant');
    all_idx = find(selected_idx);

    % Original metrics
    spec_all = [results_struct(all_idx).Specificity];
    sens_all = [results_struct(all_idx).Sensitivity];

    % Validity (for Pareto) and missing (for plotting only)
    valid_mask   = ~isnan(spec_all) & ~isnan(sens_all);
    missing_mask = ~valid_mask;

    % For plotting only: use 0 where NaN so every model appears
    spec_plot = spec_all;  spec_plot(missing_mask) = 0;
    sens_plot = sens_all;  sens_plot(missing_mask) = 0;

    % Pareto on valid points only
    ispareto_local = false(size(all_idx));
    if any(valid_mask)
        ispareto_valid = pareto_front(spec_all(valid_mask), sens_all(valid_mask));
        vidx = find(valid_mask);
        ispareto_local(vidx(ispareto_valid)) = true;
    end

    pareto_struct = results_struct(all_idx(ispareto_local));
    if ~isempty(pareto_struct)
        effs = [pareto_struct.Efficiency];
        [~, best_idx] = max(effs);
        best_model = pareto_struct(best_idx);
    end

    % Masks for plotting classes
    inefficient_mask = ~ispareto_local;  % includes valid-nonPareto and missing

    % ===== Plot =====
    figure('Name','PLS-DM (Compliant)'); hold on;
    ms_all  = 60; lw_ax = 1.2; lw_line = 1.8; fs_lbl = 12; fs_tit = 14;

    % 1) Inefficient = blue hollow circles
    if any(inefficient_mask)
        hInef = scatter(spec_plot(inefficient_mask), sens_plot(inefficient_mask), ...
                        ms_all, 'o', 'MarkerEdgeColor', [0 0 1], ...
                        'MarkerFaceColor', 'none', 'LineWidth', 1.2);
        ud_inef = make_userdata_array(results_struct, all_idx(inefficient_mask));
        set(hInef, 'UserData', ud_inef, 'HitTest', 'on');
    end

    % 2) Efficient (Pareto front) = blue filled circles + connecting line
    if any(ispareto_local)
        eff_idx_local = all_idx(ispareto_local);
        x_p = spec_all(ispareto_local);
        y_p = sens_all(ispareto_local);

        % Build sorted chain and deduplicate identical (x,y) for plotting
        [xs, ys, eff_plot_idx] = build_pareto_chain_sorted(x_p, y_p, eff_idx_local);

        % Draw the connecting line if at least two points
        if numel(xs) >= 2
            plot(xs, ys, '-', 'Color', [0 0 1], 'LineWidth', lw_line, 'HitTest','off');
        end

        % Draw efficient points (blue filled)
        hEff = scatter(xs, ys, ms_all, 'o', ...
                       'MarkerFaceColor', [0 0 1], 'MarkerEdgeColor', [0 0 0], ...
                       'LineWidth', 1.0);

        % UserData must match the number of plotted efficient points
        ud_eff = make_userdata_array(results_struct, eff_plot_idx);
        set(hEff, 'UserData', ud_eff, 'HitTest', 'on');
    end

    % 3) Ideal point (1,1) = red triangle
    hIdeal = plot(1, 1, '^', 'MarkerSize', 9, ...
                  'MarkerFaceColor', [0.8 0.1 0.1], ...
                  'MarkerEdgeColor', [0 0 0], 'LineWidth', 0.8);

    % 4) Grey dotted guide lines to (1,1)
    plot([0 1], [1 1], ':', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.0, 'HitTest','off'); % horizontal
    plot([1 1], [0 1], ':', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.0, 'HitTest','off'); % vertical

    xlabel('Specificity','FontSize',fs_lbl);
    ylabel('Sensitivity','FontSize',fs_lbl);
    title(['PLS-DM (Compliant) - Preprocess: ' prepro], 'FontSize',fs_tit,'FontWeight','bold');

    % Legend
    legH = []; legT = {};
    if exist('hInef','var') && ishandle(hInef)
        legH(end+1) = hInef; legT{end+1} = 'Inefficient';
    end
    if exist('hEff','var') && ishandle(hEff)
        legH(end+1) = hEff;  legT{end+1} = 'Efficient (Pareto front)';
    end
    legH(end+1) = hIdeal;     legT{end+1} = 'Ideal point';
    legend(legH, legT, 'Location', 'eastoutside');

    grid on; box on; set(gca,'FontSize',11,'LineWidth',lw_ax);
    xlim([0 1.02]); ylim([0 1.02]); axis square;

    % Datatips
    dcm = datacursormode(gcf);
    set(dcm, 'Enable', 'on', 'DisplayStyle', 'datatip', ...
             'UpdateFcn', @(~,ev) compliant_click_callback(ev, prepro));
end

% =========================== RIGOROUS =====================================
if hasRigorous
    selected_idx = strcmp({results_struct.CaseType}, 'rigorous');
    valid_idx = find(selected_idx);

    sens = [results_struct(valid_idx).Sensitivity];
    valid_mask = ~isnan(sens);
    valid_idx  = valid_idx(valid_mask);
    all_sens   = [results_struct(valid_idx).Sensitivity];

    sens_distance = abs(all_sens - conflev);
    min_distance = min(sens_distance);
    tol_numeric = 10*eps(max(1,abs(conflev)));
    eff_mask = abs(sens_distance-min_distance) <= tol_numeric;
    eff_idx  = valid_idx(eff_mask);
    pareto_struct = results_struct(eff_idx);
    if ~isempty(eff_idx)
        tied = results_struct(eff_idx);
        [dummy,best_local] = min([tied.LV]);
        best_model = tied(best_local);
    end

    figure('Name','PLS-DM (Rigorous)'); hold on;
    ms_i = 7; ms_e = 9; lw_m = 1.3; lw_ax = 1.2; fs_lbl = 12; fs_tit = 14;
    col_red   = [0.8 0.1 0.1];
    col_green = [0.1 0.6 0.2];

    idx_plot = 1:length(all_sens);

    if showAllRigorous
        ine_mask = ~eff_mask;
        if any(ine_mask)
            hI = scatter(idx_plot(ine_mask), all_sens(ine_mask), ms_i, 'o', ...
                         'MarkerEdgeColor', col_red, 'MarkerFaceColor','none', 'LineWidth', lw_m);
            ud_i = make_userdata_array(results_struct, valid_idx(ine_mask));
            set(hI, 'UserData', ud_i, 'HitTest', 'on');
        end
        if any(eff_mask)
            hE = scatter(idx_plot(eff_mask), all_sens(eff_mask), ms_e, 's', ...
                         'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col_green, 'LineWidth', lw_m);
            ud_e = make_userdata_array(results_struct, valid_idx(eff_mask));
            set(hE, 'UserData', ud_e, 'HitTest', 'on');
        end
        titleText = 'PLS-DM (Rigorous) - Sensitivity closest to 1 - \alpha';
        legendItems = {'Other Models', 'Optimal Models (closest sensitivity)', ...
                       'Expected Sensitivity (1 - \alpha)'};
    else
        if any(eff_mask)
            hE = scatter(idx_plot(eff_mask), all_sens(eff_mask), ms_e, 's', ...
                         'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col_green, 'LineWidth', lw_m);
            ud_e = make_userdata_array(results_struct, valid_idx(eff_mask));
            set(hE, 'UserData', ud_e, 'HitTest', 'on');
        end
        titleText = 'PLS-DM (Rigorous) - Optimal Models';
        legendItems = {'Optimal Models (closest sensitivity)', 'Expected Sensitivity (1 - \alpha)'};
    end

    % Threshold line "1 - alpha" 
    xl = [1 max(1, length(all_sens)+0.5)];
    plot([xl(1) xl(2)], [conflev conflev], 'k--', 'LineWidth', 1.1);

    ylim([0 1]); xlim(xl);
    xlabel('Model Index','FontSize',fs_lbl);
    ylabel('Sensitivity','FontSize',fs_lbl);
    title([titleText ' - Preprocess: ' prepro], 'FontSize',fs_tit,'FontWeight','bold','Interpreter','tex');
    legend(legendItems, 'Location', 'eastoutside', 'Interpreter', 'tex');

    grid on; box on; set(gca,'FontSize',11,'LineWidth',lw_ax);

    % Datatips
    dcm = datacursormode(gcf);
    set(dcm, 'Enable', 'on', 'DisplayStyle', 'datatip', ...
             'UpdateFcn', @(~,ev) rigorous_click_callback(ev, prepro));
end

end % ===== end main function =====


% ==============================================

function val = getfield_safe(s, f)
if isfield(s, f)
    val = s.(f);
    if isempty(val), val = NaN; end
else
    val = NaN;
end
end

function ispareto = pareto_front(x, y)
% Non-dominated front for maximization of both x and y
x = x(:); y = y(:);
n = length(x);
ispareto = true(n,1);
for i = 1:n
    % another point dominates i if it is >= on both and > on at least one
    if any( (x > x(i) & y >= y(i)) | (x >= x(i) & y > y(i)) )
        ispareto(i) = false;
    end
end
end

function [xs, ys, eff_plot_idx] = build_pareto_chain_sorted(xp, yp, eff_idx_local)
% Build a sorted chain (by specificity) through ALL efficient points,
% removing exact duplicate coordinates for plotting and aligning UserData.
% Inputs:
%   xp, yp          : efficient points (specificity, sensitivity)
%   eff_idx_local   : indices into results_struct corresponding to xp, yp
% Outputs:
%   xs, ys          : sorted, de-duplicated coordinates to plot & connect
%   eff_plot_idx    : indices aligned 1:1 with xs/ys for datatips

    % Ensure column vectors
    xp = xp(:); yp = yp(:); eff_idx_local = eff_idx_local(:);

    % Sort by specificity asc, then sensitivity asc
    XY = [xp yp];
    XYs = sortrows(XY, [1 2]);
    ord = sortrows([(1:numel(xp))' XY], [2 3]);  

    % We need the permutation indices; do it explicitly
    [~, ord] = sortrows([xp yp], [1 2]);
    xp_s = xp(ord);  yp_s = yp(ord);  idx_s = eff_idx_local(ord);

    % Deduplicate identical (x,y) consecutive rows; keep first occurrence
    keep = true(size(xp_s));
    for k = 2:numel(xp_s)
        if xp_s(k)==xp_s(k-1) && yp_s(k)==yp_s(k-1)
            keep(k) = false;
        end
    end

    xs = xp_s(keep);
    ys = yp_s(keep);
    eff_plot_idx = idx_s(keep);
end

function ud = make_userdata_array(results_struct, idx_list)
% Build a lightweight array of structs for datatips/callbacks
ud = repmat(struct('ModelNum',[],'Kappa',[],'Smooth',[],'LV',[], ...
                   'Sensitivity',[],'Specificity',[],'Precision',[], ...
                   'Accuracy',[],'F1Score',[],'Efficiency',[], ...
                   'KIndex',[],'SIndex',[],'LVIndex',[]), 1, numel(idx_list));
for k = 1:numel(idx_list)
    r = results_struct(idx_list(k));
    ud(k) = struct('ModelNum', r.ModelNum, ...
                   'Kappa', r.Kappa, 'Smooth', r.Smooth, 'LV', r.LV, ...
                   'Sensitivity', r.Sensitivity, 'Specificity', r.Specificity, ...
                   'Precision', r.Precision, 'Accuracy', r.Accuracy, ...
                   'F1Score', r.F1Score, 'Efficiency', r.Efficiency, ...
                   'KIndex', r.KIndex, 'SIndex', r.SIndex, 'LVIndex', r.LVIndex);
end
end

function print_model_report(r, prepro)
% Standardized console report
fprintf('\n[MODEL INFO]\n');
fprintf('Model #%d | Kappa=%g | Smooth=%.3g | LV=%d | Preprocess=%s\n', ...
        r.ModelNum, r.Kappa, r.Smooth, r.LV, prepro);
fprintf('Sensitivity=%.4f | Specificity=%.4f | Precision=%.4f | Accuracy=%.4f | F1=%.4f | Efficiency=%.4f\n', ...
        r.Sensitivity, r.Specificity, r.Precision, r.Accuracy, r.F1Score, r.Efficiency);
end

function txt = compliant_click_callback(event_obj, prepro)
tgt = get(event_obj, 'Target');
idx = get(event_obj, 'DataIndex');
ud  = get(tgt, 'UserData');
if isempty(ud) || idx < 1 || idx > numel(ud)
    txt = {'Model info not available'}; return;
end
r = ud(idx);
txt = {sprintf('Model #%d', r.ModelNum), ...
       sprintf('Sens=%.4f | Spec=%.4f', r.Sensitivity, r.Specificity), ...
       sprintf('Preprocess: %s', prepro)};
print_model_report(r, prepro);
end

function txt = rigorous_click_callback(event_obj, prepro)
tgt = get(event_obj, 'Target');
idx = get(event_obj, 'DataIndex');
ud  = get(tgt, 'UserData');
if isempty(ud) || idx < 1 || idx > numel(ud)
    txt = {'Model info not available'}; return;
end
r = ud(idx);
txt = {sprintf('Model #%d', r.ModelNum), ...
       sprintf('Sensitivity=%.4f', r.Sensitivity), ...
       sprintf('Preprocess: %s', prepro)};
print_model_report(r, prepro);
end

function s = normalize_prepro(s)
% Normalize preprocessing names for display
if isempty(s), s = 'raw'; return; end
s = lower(strtrim(s));
switch s
    case {'raw'}
        s = 'raw';
    case {'centered','centereed','centre','center','centred'}
        s = 'centered';
    case {'scale','scaled'}
        s = 'scale';
    case {'autoscale','auto-scale','auto scaled'}
        s = 'autoscale';
    otherwise
        
end
end
