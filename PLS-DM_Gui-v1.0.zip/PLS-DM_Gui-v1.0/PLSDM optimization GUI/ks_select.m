%
function [sel_idx,Xcal,Ycal,Xrem,Yrem] = ks_select(X,nsel,mean_start,~,Y)
%
% Kennard-Stone subset selection.
% INPUT:
%   X          : data matrix (samples x variables)
%   nsel       : number of samples to select
%   mean_start : 1 = first sample closest to mean
%                0 = first sample farthest from mean
%   Y          : response matrix/vector
%
% OUTPUT:
%   sel_idx : indices of selected samples
%   Xcal    : selected X samples
%   Ycal    : selected Y samples
%   Xrem    : remaining X samples
%   Yrem    : remaining Y samples
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

[n_samples,~] = size(X);

Xwork = X;

% First selected sample
Xmean = mean(Xwork);
Xcentered = Xwork - ones(n_samples,1)*Xmean;

dist_to_mean = zeros(1,n_samples);
for ii = 1:n_samples
    dist_to_mean(ii) = Xcentered(ii,:)*Xcentered(ii,:)';
end

if mean_start == 1
    [~,first_idx] = min(dist_to_mean);
else
    [~,first_idx] = max(dist_to_mean);
end

sel_idx(1) = first_idx;

% Second selected sample: farthest from the first
Xdiff = Xwork - ones(n_samples,1)*Xwork(sel_idx(1),:);

dist_first = zeros(1,n_samples);
for ii = 1:n_samples
    dist_first(ii) = Xdiff(ii,:)*Xdiff(ii,:)';
end

[~,second_idx] = max(dist_first);
sel_idx(2) = second_idx;

% Remaining selected samples
for kk = 3:nsel
    
    all_idx = 1:n_samples;
    remaining_idx = all_idx;
    remaining_idx(sel_idx) = [];
    
    Xremaining = Xwork;
    Xremaining(sel_idx,:) = [];
    
    n_remaining = length(remaining_idx);
    min_distances = zeros(1,n_remaining);
    
    for jj = 1:n_remaining
        
        current_distances = zeros(1,length(sel_idx));
        
        for ii = 1:length(sel_idx)
            delta = Xremaining(jj,:) - Xwork(sel_idx(ii),:);
            current_distances(ii) = delta*delta';
        end
        
        min_distances(jj) = min(current_distances);
    end
    
    [~,best_pos] = max(min_distances);
    sel_idx(kk) = remaining_idx(best_pos);
end

sel_idx = sel_idx(1:nsel);

Xcal = X(sel_idx,:);
Ycal = Y(sel_idx,:);

all_indices = (1:n_samples)';
all_indices(sel_idx) = [];

Xrem = X(all_indices,:);
Yrem = Y(all_indices,:);