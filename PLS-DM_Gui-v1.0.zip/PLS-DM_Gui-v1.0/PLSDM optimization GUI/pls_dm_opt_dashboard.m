%
function pls_dm_opt_dashboard(compliance, kappa_values, smooth_values, conflev, prepro)
%                 Advanced PLS-DM optimization dashboard
% Generates contour surface panels to evaluate Sensitivity/Specificity
% as a function of LV (X-axis) vs Smooth/Kappa (Y-axis), separating cases:
%   - RIGOROUS
%   - COMPLIANT
% Graphical outputs:
%   RIGOROUS:
%     Fig 1: subplot(3,2): by Kappa  -> Sensitivity in (LV vs Smooth)
%     Fig 2: subplot(3,2): by Smooth -> Sensitivity in (LV vs Kappa)
%   COMPLIANT:
%     Fig 3: subplot(3,2): by Kappa  -> Sensitivity in (LV vs Smooth)
%     Fig 4: subplot(3,2): by Smooth -> Sensitivity in (LV vs Kappa)
%     Fig 5: subplot(3,2): by Kappa  -> Specificity in (LV vs Smooth)
%     Fig 6: subplot(3,2): by Smooth -> Specificity in (LV vs Kappa)
%
% INPUTS:
%   compliance     3D cell (nK x nS x nLV), each cell is a result struct
%   kappa_values   vector of kappa values (optional)
%   smooth_values  vector of smooth values (optional)
%   conflev        1 - alpha (optional, default 0.95; kept for reference)
%   prepro         preprocessing label for titles: 'raw','centered',
%                  'scale','autoscale' (accepts variations, e.g., 'centereed')
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 4 || isempty(conflev),       conflev       = 0.95; end
if nargin < 5 || isempty(prepro),        prepro        = 'raw'; end
prepro = normalize_prepro_local(prepro);


if ~iscell(compliance) || ndims(compliance) ~= 3
    error('compliance must be a 3D cell array (kappa x smooth x LV).');
end
[nK, nS, nLV] = size(compliance);
%
if nargin < 2 || isempty(kappa_values),  kappa_values  = 1:nK; end
if nargin < 3 || isempty(smooth_values), smooth_values = 1:nS; end
kappa_values  = kappa_values(:)';
smooth_values = smooth_values(:)';

if numel(kappa_values) ~= nK
    error('numel(kappa_values) (%d) must match size(compliance,1) = %d.', numel(kappa_values), nK);
end
if numel(smooth_values) ~= nS
    error('numel(smooth_values) (%d) must match size(compliance,2) = %d.', numel(smooth_values), nS);
end


Sens_rig = nan(nK, nS, nLV);  % Sensitivity (rigorous)
Sens_cmp = nan(nK, nS, nLV);  % Sensitivity (compliant)
Spec_cmp = nan(nK, nS, nLV);  % Specificity (compliant)

for i = 1:nK
    for j = 1:nS
        for lv = 1:nLV
            res = compliance{i,j,lv};
            if isempty(res) || ~isstruct(res), continue; end
            
            
            isCompliant = false;
            if isfield(res,'Gtrue') && ~isempty(res.Gtrue) && any(res.Gtrue ~= 1)
                isCompliant = true;
            end
            
            sen = getfield_safe_local(res, 'sensitivity', NaN);
            spc = getfield_safe_local(res, 'specificity', NaN);
            
            if isCompliant
                Sens_cmp(i,j,lv) = sen;
                Spec_cmp(i,j,lv) = spc;
            else
                Sens_rig(i,j,lv) = sen;
            end
        end
    end
end


LV_grid     = 1:nLV;
Smooth_grid = smooth_values(:)';
Kappa_grid  = kappa_values(:)';
levels = 0:0.05:1;

% RIGOROUS - Sensitivity =====================
if any(isfinite(Sens_rig(:)))
    % Fig 1: por Kappa -> Sensitivity (LV x Smooth)
    fh1 = figure('Color','w','Name','RIGOROUS | Sensitivity: LV x Smooth per Kappa');
    [rowsK, colsK] = get_subplot_grid(nK);
    for kk = 1:nK
        subplot(rowsK,colsK,kk); hold on; box on;
        Z = squeeze(Sens_rig(kk,:,:));     % (nS x nLV)
        plot_contour(Z, LV_grid, Smooth_grid, levels);
        title(sprintf('Kappa = %g | Prepro = %s', kappa_values(kk), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Smooth');
    end
    set_suptitle(fh1, 'RIGOROUS - Sensitivity per Kappa: LV x Smooth');
    
    % Fig 2: por Smooth -> Sensitivity (LV x Kappa)
    fh2 = figure('Color','w','Name','RIGOROUS | Sensitivity: LV x Kappa per Smooth');
    [rowsS, colsS] = get_subplot_grid(nS);
    for ss = 1:nS
        subplot(rowsS,colsS,ss); hold on; box on;
        Z = squeeze(Sens_rig(:,ss,:));     % (nK x nLV)
        plot_contour(Z, LV_grid, Kappa_grid, levels);
        title(sprintf('Smooth = %g | Prepro = %s', smooth_values(ss), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Kappa');
    end
    set_suptitle(fh2, 'RIGOROUS - Sensitivity per Smooth: LV x Kappa');
else
    fprintf('Note: no RIGOROUS entries found.\n');
end

%  COMPLIANT - Sensitivity =====================
if any(isfinite(Sens_cmp(:)))
    % Fig 3: por Kappa -> Sensitivity (LV x Smooth)
    fh3 = figure('Color','w','Name','COMPLIANT | Sensitivity: LV x Smooth per Kappa');
    [rowsK, colsK] = get_subplot_grid(nK);
    for kk = 1:nK
        subplot(rowsK,colsK,kk); hold on; box on;
        Z = squeeze(Sens_cmp(kk,:,:));     % (nS x nLV)
        plot_contour(Z, LV_grid, Smooth_grid, levels);
        title(sprintf('Kappa = %g | Prepro = %s', kappa_values(kk), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Smooth');
    end
    set_suptitle(fh3, 'COMPLIANT - Sensitivity per Kappa: LV x Smooth');
    
    % Fig 4: por Smooth -> Sensitivity (LV x Kappa)
    fh4 = figure('Color','w','Name','COMPLIANT | Sensitivity: LV x Kappa per Smooth');
    [rowsS, colsS] = get_subplot_grid(nS);
    for ss = 1:nS
        subplot(rowsS,colsS,ss); hold on; box on;
        Z = squeeze(Sens_cmp(:,ss,:));     % (nK x nLV)
        plot_contour(Z, LV_grid, Kappa_grid, levels);
        title(sprintf('Smooth = %g | Prepro = %s', smooth_values(ss), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Kappa');
    end
    set_suptitle(fh4, 'COMPLIANT - Sensitivity per Smooth: LV x Kappa');
else
    fprintf('Note: no COMPLIANT entries with Sensitivity.\n');
end

% COMPLIANT - Specificity =====================
if any(isfinite(Spec_cmp(:)))
    % Fig 5: por Kappa -> Specificity (LV x Smooth)
    fh5 = figure('Color','w','Name','COMPLIANT | Specificity: LV x Smooth per Kappa');
    [rowsK, colsK] = get_subplot_grid(nK);
    for kk = 1:nK
        subplot(rowsK,colsK,kk); hold on; box on;
        Z = squeeze(Spec_cmp(kk,:,:));     % (nS x nLV)
        plot_contour(Z, LV_grid, Smooth_grid, levels);
        title(sprintf('Kappa = %g | Prepro = %s', kappa_values(kk), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Smooth');
    end
    set_suptitle(fh5, 'COMPLIANT - Specificity per Kappa: LV x Smooth');
    
    % Fig 6: por Smooth -> Specificity (LV x Kappa)
    fh6 = figure('Color','w','Name','COMPLIANT | Specificity: LV x Kappa per Smooth');
    [rowsS, colsS] = get_subplot_grid(nS);
    for ss = 1:nS
        subplot(rowsS,colsS,ss); hold on; box on;
        Z = squeeze(Spec_cmp(:,ss,:));     % (nK x nLV)
        plot_contour(Z, LV_grid, Kappa_grid, levels);
        title(sprintf('Smooth = %g | Prepro = %s', smooth_values(ss), prepro), 'Interpreter','none');
        xlabel('LV'); ylabel('Kappa');
    end
    set_suptitle(fh6, 'COMPLIANT - Specificity per Smooth: LV x Kappa');
else
    fprintf('Note: no COMPLIANT entries with Specificity.\n');
end
end


function [rows, cols] = get_subplot_grid(nPanels)
if nPanels <= 0
    rows = 1;
    cols = 1;
    return;
end
cols = ceil(sqrt(nPanels));
rows = ceil(nPanels / cols);
end

function plot_contour(Z, LV_grid, Y_grid, levels)

[X, Y] = meshgrid(LV_grid, Y_grid);
zv = Z(:);
zv = zv(~isnan(zv));
if ~isempty(zv) && all(abs(zv - zv(1)) < eps)
    imagesc(LV_grid, Y_grid, Z);
else
    contourf(X, Y, Z, levels, 'LineStyle','none');
end

try
    colormap('parula');
catch
    colormap('jet');
end
caxis([0 1]); colorbar;
set(gca,'YDir','normal','LineWidth',1.1,'FontName','Arial','FontSize',11,...
    'XMinorTick','on','YMinorTick','on');
axis tight;
end

function set_suptitle(figH, txt)
if exist('sgtitle','file') == 2
    figure(figH);
    sgtitle(txt, 'FontWeight','bold','Interpreter','none','FontSize',12);
else
    
    figure(figH);
    annotation('textbox',[0 0.965 1 0.035],'String',txt,'EdgeColor','none',...
        'HorizontalAlignment','center','FontWeight','bold','FontSize',12,...
        'Interpreter','none');
end
end


function v = getfield_safe_local(s, fname, default)
if nargin < 3, default = NaN; end
if isstruct(s) && isfield(s, fname) && ~isempty(s.(fname))
    v = s.(fname);
else
    v = default;
end
end

function out = normalize_prepro_local(prepro)
if ~ischar(prepro), out = 'raw'; return; end
p = lower(strtrim(char(prepro)));
switch p
    case {'raw','none'}
        out = 'raw';
    case {'centered','centereed','center','centering','centre'}
        out = 'centered';
    case {'scale','scaled','scaling'}
        out = 'scale';
    case {'autoscale','auto','standardize','standardised','standardized'}
        out = 'autoscale';
    otherwise
        out = p;
end
end
