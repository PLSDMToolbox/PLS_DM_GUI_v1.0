%
function Modelpls_kfold = pls_kfold(X,K, maxLV, conflev, alpha, preprocessing, kappa,Xuntarget,targetFoldIndex)
% PLS with K-fold cross-validation (NIPALS algorithm) 
%
% Syntax:
% Modelpls_kfold = pls_kfold(X, y, K, maxLV, conflev, alpha, preprocessing,kappa, Xuntarget)
%
% Inputs:
%   X       - predictors (n x m), Model data (no centering/scaling)
%   K       - number of folds
%   maxLV   - maximum number of latent variables to evaluate
%   conflev - confidence level for Q-limits and f-limits (scalar in (0,1), default 0.95)
%   alpha   - smoothing coefficient for PFM (e.g., 0.3-0.8). REQUIRED.
%   preprocessing - 'raw' | 'centered' | 'scaled' | 'autoscaled'
%   Xuntarget - (optional) additional predictors for potential function calculation
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 5 || isempty(conflev)
    conflev = 0.95;
end
if nargin < 6
    error('You must provide smoothing coefficient alpha as 6th argument.');
end
if conflev <= 0 || conflev >= 1
    error('conflev must be between 0 and 1 (exclusive).');
end
if nargin < 7
    error('All 7 arguments must be provided.');
end
%
[Nsam Nvar] = size(X);
% Initialize output struct
Modelpls_kfold.type = 'Model PLS k fold';
Modelpls_kfold.K = K;
Modelpls_kfold.maxLV = maxLV;
Modelpls_kfold.conflev = conflev;
Modelpls_kfold.alpha = alpha;
Modelpls_kfold.preprocessing = preprocessing;
%
XModel = X;

% Venetian blinds assignment. When supplied by PLSDM_OPT, targetFoldIndex
% preserves the folds assigned before the original toolbox separated the
% target class from the complete training set.
cvFolds = cell(1, K);
if nargin >= 9 && ~isempty(targetFoldIndex)
    targetFoldIndex = targetFoldIndex(:);
    if numel(targetFoldIndex) ~= Nsam || any(targetFoldIndex < 1 | targetFoldIndex > K)
        error('Invalid targetFoldIndex.');
    end
    for k = 1:K
        cvFolds{k} = find(targetFoldIndex == k).';
    end
else
    for k = 1:K
        cvFolds{k} = k:K:Nsam;
    end
end
hasUntarget = (nargin > 7 && ~isempty(Xuntarget));
if hasUntarget
    n_unt = size(Xuntarget,1);
end

% Preallocate
RMSEcv = zeros(maxLV,1);
y_pred_cv = zeros(Nsam,1);
Qresid = nan(Nsam, maxLV);
Qlimit_cv = nan(Nsam,maxLV);
flimit_cv = nan(Nsam,maxLV);
if hasUntarget
    n_unt_cv = n_unt*K;
    Modelpls_kfold.Q_untarget_cv = nan(n_unt_cv,maxLV);
    Modelpls_kfold.f_untarget_cv = nan(n_unt_cv,maxLV);
    Modelpls_kfold.Qlimit_untarget_cv = nan(n_unt_cv,maxLV);
    Modelpls_kfold.flimit_untarget_cv = nan(n_unt_cv,maxLV);
    Modelpls_kfold.untarget_fold_index = kron((1:K)',ones(n_unt,1));
end

% storage for Qtrain, Qtest, ftrain, ftest
Modelpls_kfold.Qtrain = cell(maxLV, K);
Modelpls_kfold.Qtest  = cell(maxLV, K);
Modelpls_kfold.ftrain = cell(maxLV, K);
Modelpls_kfold.ftest  = cell(maxLV, K);
Modelpls_kfold.Ytraincv  = cell(maxLV, K);
% PFM outputs
f_cv = nan(Nsam, maxLV);
flimits_perLV = cell(maxLV,1);
Qlims_perLV = cell(maxLV,1);

try
    zq = norminv(conflev);
catch
    zq = sqrt(2) * erfinv(2*conflev - 1);
end

% Main loop over LV
for a = 1:maxLV
    y_pred_all = zeros(Nsam,1);
    qlim_fold = nan(K,1);
    flimit_fold = nan(K,1);
    fold_counter = 0;
    
    for fold = 1:K
        test_idx=cvFolds{fold};
        train_idx=1:Nsam;train_idx(test_idx)=0;
        train_idx=find(train_idx);
        
        fold_counter = fold_counter + 1;
        
        % Train/test split
        Xtrain = XModel(train_idx,:);
        Xtest  = XModel(test_idx,:);
        %------------------------------------------------------------------
        % === Preprocessing ===
        [n, m] = size(Xtrain);
        [np]=size(Xtest,1);
        mu = mean(Xtrain, 1);
        sigma = std(Xtrain, 0, 1);
        sigma(sigma == 0) = 1;
        
        switch lower(preprocessing)
            case 'raw'
                mu = zeros(1, m);
                sigma = ones(1, m);
            case 'centered'
                Xtrain = Xtrain - repmat(mu, n, 1);
                Xtest =Xtest - repmat(mu, np, 1);
            case 'scaled'
                Xtrain = Xtrain ./ repmat(sigma, n, 1);
                Xtest = Xtest ./ repmat(sigma, np, 1);
                mu = zeros(1,m);
            case 'autoscaled'
                Xtrain = (Xtrain - repmat(mu, n, 1)) ./ repmat(sigma, n, 1);
                Xtest = (Xtest - repmat(mu, np, 1)) ./ repmat(sigma, np, 1);
            otherwise
                error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
        end
                 
        
        %% Class density by knn
        [D_sorted, idx_sorted, D] = ClassDensity1(Xtrain,true);
        DENSITY_Train=D_sorted(:,2:n);
        dist1=DENSITY_Train(:,1:kappa);
        ytrain=sum(dist1,2);
        Modelpls_kfold.Ytraincv {a, fold}=   ytrain;
        %-----------------------------------------------------------------
        % === NIPALS ===
        nt = size(Xtrain,1);
        T = zeros(nt, a);
        P = zeros(m, a);
        Qy = zeros(1, a);
        W = zeros(m, a);
        
        Xres = Xtrain;
        yres = ytrain;
        
        for comp = 1:a
            u = yres;
            diff = 1;
            while diff > 1e-10
                w = (Xres' * u) / (u' * u);
                w = w / norm(w);
                t = Xres * w;
                q = (yres' * t) / (t' * t);
                u_new = yres * (q / (q^2));
                diff = norm(u_new - u);
                u = u_new;
            end
            p = (Xres' * t) / (t' * t);
            
            W(:,comp) = w;
            T(:,comp) = t;
            P(:,comp) = p;
            Qy(:,comp) = q;
            
            Xres = Xres - t * p';
            yres = yres - t * q;
        end
        
        B_pls = W * ((P' * W) \ Qy');
        
        y_pred_fold = Xtest * B_pls;
        y_pred_all(test_idx) = y_pred_fold;
        
        % === Q residuals TRAIN and TEST ===
        Wcoeff = W / (P' * W);
        
        % TRAIN
        Ttrain_proj = Xtrain * Wcoeff;
        Xhat_train = Ttrain_proj * P';
        Resid_train = Xtrain - Xhat_train;
        Qtrain = sum(Resid_train.^2, 2);
        Modelpls_kfold.Qtrain{a, fold} = Qtrain;
        
        % TEST
        
        Ttest = Xtest * Wcoeff;
        Xhat_test = Ttest * P';
        Resid_test = Xtest - Xhat_test;
        Qtest = sum(Resid_test .^ 2, 2);
        Qresid(test_idx, a) = Qtest;
        Modelpls_kfold.Qtest{a, fold} = Qtest;
        
        Qlim = plsdm_original_qlimit(Resid_train,conflev);
        qlim_fold(fold_counter) = Qlim;
        Qlimit_cv(test_idx,a) = Qlim;
        
        % === PFM (Potential Function Method) ===
        nt_train = size(T,1);
        [f_test,f_alpha_fold,f_train] = plsdm_original_pfm(T,Ttest,alpha,conflev);
        Modelpls_kfold.ftrain{a, fold} = f_train;
        f_cv(test_idx, a) = f_test;
        Modelpls_kfold.ftest{a, fold} = f_test;
        flimit_fold(fold_counter)=f_alpha_fold;
        flimit_cv(test_idx,a)=f_alpha_fold;
 
        % === Additional calculations for Xuntarget ===
        if hasUntarget
            ut_idx = ((fold-1)*n_unt + 1):(fold*n_unt);
            Xuntargetcv = Xuntarget;
            Nsam_untarget = n_unt;
            
            switch lower(preprocessing)
                case 'raw'
                    Xuntarget_processed = Xuntargetcv;
                case 'centered'
                    Xuntarget_processed = Xuntargetcv - repmat(mu, Nsam_untarget, 1);
                case 'scaled'
                    Xuntarget_processed = Xuntargetcv ./ repmat(sigma, Nsam_untarget, 1);
                case 'autoscaled'
                    Xuntarget_processed = (Xuntargetcv - repmat(mu, Nsam_untarget, 1)) ./ repmat(sigma, Nsam_untarget, 1);
                otherwise
                    error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
            end
            
            
            T_untarget = Xuntarget_processed* Wcoeff;
          
            f_untarget = plsdm_original_pfm(T,T_untarget,alpha,conflev);
            Modelpls_kfold.f_untarget_cv(ut_idx, a)  = f_untarget;
            Modelpls_kfold.Qlimit_untarget_cv(ut_idx,a)=Qlim;
            Modelpls_kfold.flimit_untarget_cv(ut_idx,a)=f_alpha_fold;
      
            % ---- Q residual for Xuntarget ----
            Xhat_untarget = T_untarget * P';
            Resid_untarget = Xuntarget_processed - Xhat_untarget;
            Q_untarget = sum(Resid_untarget.^2, 2);
            Modelpls_kfold.Q_untarget_cv(ut_idx, a) = Q_untarget;
        end
        
    end
    
% Store results for current LV
%     Modelpls_kfold.RMSEcv(a) = sqrt(mean((y_pred_all - yModel).^2));
    Modelpls_kfold.Qlims_perLV{a} = qlim_fold;
    Modelpls_kfold.flimits_perLV{a} = flimit_fold;
end

Modelpls_kfold.f_cv = f_cv;
Modelpls_kfold.Qresid = Qresid;
Modelpls_kfold.Qlimit_cv = Qlimit_cv;
Modelpls_kfold.flimit_cv = flimit_cv;
Modelpls_kfold.y_pred_cv = y_pred_cv;

end
