%
function [info,applied] = plsdm_add_data_info(parent,classv,nSamples,currentInfo)
%PLSDM_ADD_DATA_INFO Edit optional display-only metadata for a GUI session.
% This function never changes X, class labels, or any model input. (Adriano)
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    if nargin < 4 || isempty(currentInfo)
        currentInfo = struct();
    end
    classes = plsdm_unique_stable(classv(:));
    info = normalizeInfo(currentInfo,classes,nSamples);
    applied = false;

    nClass = numel(classes);
    rowH = 28;
    % Leave a fixed lower area for sample import and Apply/Cancel buttons.
    figH = 380 + rowH*nClass;
    f = figure('Name','Add data info','NumberTitle','off','MenuBar','none', ...
        'ToolBar','none','WindowStyle','modal','Resize','off', ...
        'Color',[0.95 0.95 0.95],'Position',centerOnParent(parent,520,figH), ...
        'CloseRequestFcn',@onCancel);

    uicontrol(f,'Style','text','String','Optional axis labels', ...
        'Position',[25 figH-60 460 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    uicontrol(f,'Style','text','String','X-axis label','Position',[25 figH-94 115 22], ...
        'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
    edX = uicontrol(f,'Style','edit','String',info.xLabel, ...
        'Position',[145 figH-96 340 26],'BackgroundColor','white','HorizontalAlignment','left');
    uicontrol(f,'Style','text','String','Y-axis label','Position',[25 figH-128 115 22], ...
        'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
    edY = uicontrol(f,'Style','edit','String',info.yLabel, ...
        'Position',[145 figH-130 340 26],'BackgroundColor','white','HorizontalAlignment','left');

    classTop = figH-170;
    uicontrol(f,'Style','text','String','Optional class names', ...
        'Position',[25 classTop 460 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    edClass = zeros(nClass,1);
    for k = 1:nClass
        y = classTop-32-(k-1)*rowH;
        uicontrol(f,'Style','text','String',sprintf('Class %g',classes(k)), ...
            'Position',[25 y 115 22],'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
        edClass(k) = uicontrol(f,'Style','edit','String',info.classNames{k}, ...
            'Position',[145 y-2 340 26],'BackgroundColor','white','HorizontalAlignment','left');
    end

    sampleY = classTop-55-nClass*rowH;
    uicontrol(f,'Style','text','String','Optional sample names', ...
        'Position',[25 sampleY 460 25],'HorizontalAlignment','left','FontWeight','bold', ...
        'BackgroundColor',get(f,'Color'));
    txtSamples = uicontrol(f,'Style','text','String',sampleStatus(info.sampleNames,nSamples), ...
        'Position',[25 sampleY-34 270 25],'HorizontalAlignment','left','BackgroundColor',get(f,'Color'));
    uicontrol(f,'Style','pushbutton','String','Import from workspace...', ...
        'Position',[300 sampleY-34 185 28],'Callback',@onImportNames);
    uicontrol(f,'Style','pushbutton','String','Clear names', ...
        'Position',[300 sampleY-68 185 28],'Callback',@onClearNames);

    uicontrol(f,'Style','pushbutton','String','Apply','FontWeight','bold', ...
        'Position',[280 20 95 32],'Callback',@onApply);
    uicontrol(f,'Style','pushbutton','String','Cancel', ...
        'Position',[390 20 95 32],'Callback',@onCancel);

    uiwait(f);

    function onImportNames(~,~)
        vars = evalin('base','whos');
        keep = strcmp({vars.class},'cell') | strcmp({vars.class},'char') | ...
               strcmp({vars.class},'string') | strcmp({vars.class},'categorical');
        vars = vars(keep);
        if isempty(vars)
            errordlg('No cell, string, character, or categorical variable is available in the workspace.','Sample names');
            return;
        end
        [idx,ok] = listdlg('PromptString',sprintf('Select a variable with %d sample names:',nSamples), ...
            'SelectionMode','single','ListString',{vars.name},'ListSize',[330 220]);
        if ~ok, return; end
        candidate = evalin('base',vars(idx).name);
        [names,ok,msg] = normalizeNames(candidate,nSamples);
        if ~ok
            errordlg(msg,'Sample names');
            return;
        end
        info.sampleNames = names;
        set(txtSamples,'String',sampleStatus(info.sampleNames,nSamples));
    end

    function onClearNames(~,~)
        info.sampleNames = {};
        set(txtSamples,'String',sampleStatus(info.sampleNames,nSamples));
    end

    function onApply(~,~)
        info.xLabel = strtrim(get(edX,'String'));
        info.yLabel = strtrim(get(edY,'String'));
        for j = 1:nClass
            value = strtrim(get(edClass(j),'String'));
            if isempty(value), value = sprintf('Class %g',classes(j)); end
            info.classNames{j} = value;
        end
        info.classValues = classes;
        applied = true;
        uiresume(f); delete(f);
    end

    function onCancel(~,~)
        applied = false;
        uiresume(f); delete(f);
    end
end

function info = normalizeInfo(info,classes,nSamples)
    if ~isfield(info,'xLabel'), info.xLabel = ''; end
    if ~isfield(info,'yLabel'), info.yLabel = ''; end
    if ~isfield(info,'sampleNames'), info.sampleNames = {}; end
    if ~isfield(info,'classValues'), info.classValues = classes; end
    if ~isfield(info,'classNames'), info.classNames = {}; end
    oldValues = info.classValues(:);
    oldNames = info.classNames;
    names = cell(numel(classes),1);
    for k = 1:numel(classes)
        hit = find(oldValues == classes(k),1);
        if ~isempty(hit) && hit <= numel(oldNames) && ~isempty(oldNames{hit})
            names{k} = oldNames{hit};
        else
            names{k} = sprintf('Class %g',classes(k));
        end
    end
    info.classValues = classes;
    info.classNames = names;
    if numel(info.sampleNames) ~= nSamples, info.sampleNames = {}; end
end

function [names,ok,msg] = normalizeNames(value,nSamples)
    ok = false; msg = ''; names = {};
    if ischar(value)
        value = cellstr(value);
    elseif isa(value,'categorical') || isa(value,'string')
        value = cellstr(value(:));
    end
    if ~iscell(value)
        msg = 'The selected variable cannot be converted to sample names.'; return;
    end
    value = value(:);
    if numel(value) ~= nSamples
        msg = sprintf('Expected %d names, but the selected variable contains %d.',nSamples,numel(value)); return;
    end
    names = cell(nSamples,1);
    for k = 1:nSamples
        v = value{k};
        if isa(v,'string'), v = char(v); end
        if isnumeric(v) && isscalar(v), v = num2str(v); end
        if ~ischar(v) || isempty(strtrim(v))
            msg = sprintf('Sample name %d is empty or invalid.',k); return;
        end
        names{k} = strtrim(v);
    end
    ok = true;
end

function s = sampleStatus(names,nSamples)
    if isempty(names)
        s = sprintf('Not loaded (numeric labels will be used; %d samples).',nSamples);
    else
        s = sprintf('%d sample names loaded. Example: %s',numel(names),names{1});
    end
end

function pos = centerOnParent(parent,w,h)
    if ishghandle(parent)
        oldUnits = get(parent,'Units'); set(parent,'Units','pixels'); p = get(parent,'Position'); set(parent,'Units',oldUnits);
        pos = [p(1)+(p(3)-w)/2 p(2)+(p(4)-h)/2 w h];
    else
        scr = get(0,'ScreenSize'); pos = [(scr(3)-w)/2 (scr(4)-h)/2 w h];
    end
end
