%
function name = plsdm_data_info_class_name(info,classValue)
% Return a display name without changing the numeric class identifier.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    name = sprintf('Class %g',classValue);
    if isempty(info) || ~isfield(info,'classValues') || ~isfield(info,'classNames'), return; end
    idx = find(info.classValues(:) == classValue,1);
    if ~isempty(idx) && idx <= numel(info.classNames) && ~isempty(info.classNames{idx})
        name = info.classNames{idx};
    end
end
