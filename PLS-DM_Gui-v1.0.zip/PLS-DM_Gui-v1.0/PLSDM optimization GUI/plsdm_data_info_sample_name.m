%
function name = plsdm_data_info_sample_name(info,sampleIndex)
% Return an optional sample name, falling back to its original index.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    name = num2str(sampleIndex);
    if isempty(info) || ~isfield(info,'sampleNames'), return; end
    if sampleIndex >= 1 && sampleIndex <= numel(info.sampleNames) && ~isempty(info.sampleNames{sampleIndex})
        name = info.sampleNames{sampleIndex};
    end
end
