%
function [applied,datasets] = plsdm_exclude_samples_dialog(parent,datasets)
% Shared non-destructive sample inclusion editor for PLS-DM GUIs.
% Each dataset must contain: label, X, classDisplay, sampleNames,
% originalRows and included.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

applied = false;
if nargin < 2 || isempty(datasets)
    errordlg('No sample datasets are currently loaded.','Exclude samples');
    return;
end

for k = 1:numel(datasets)
    n = size(datasets(k).X,1);
    if ~isfield(datasets(k),'label') || isempty(datasets(k).label)
        datasets(k).label = ['Dataset ' num2str(k)];
    end
    if ~isfield(datasets(k),'originalRows') || numel(datasets(k).originalRows) ~= n
        datasets(k).originalRows = (1:n)';
    else
        datasets(k).originalRows = datasets(k).originalRows(:);
    end
    if ~isfield(datasets(k),'included') || numel(datasets(k).included) ~= n
        datasets(k).included = true(n,1);
    else
        datasets(k).included = logical(datasets(k).included(:));
    end
    if ~isfield(datasets(k),'sampleNames') || numel(datasets(k).sampleNames) ~= n
        datasets(k).sampleNames = arrayfun(@(i)sprintf('Sample %d',i),(1:n)', ...
            'UniformOutput',false);
    else
        datasets(k).sampleNames = datasets(k).sampleNames(:);
    end
    if ~isfield(datasets(k),'classDisplay') || numel(datasets(k).classDisplay) ~= n
        datasets(k).classDisplay = repmat({'Unknown'},n,1);
    end
end

labels = {datasets.label};
scr = get(0,'ScreenSize');
w = min(760,scr(3)-100); h = min(560,scr(4)-120);
dlg = figure('Name','Exclude samples','NumberTitle','off','MenuBar','none', ...
    'Toolbar','none','WindowStyle','modal','Resize','on', ...
    'Color',[0.95 0.96 0.94],'Units','pixels', ...
    'Position',[max(20,(scr(3)-w)/2) max(20,(scr(4)-h)/2) w h], ...
    'CloseRequestFcn',@onCancel);

uicontrol('Parent',dlg,'Style','text','String','Dataset:', ...
    'Units','normalized','Position',[0.03 0.925 0.10 0.045], ...
    'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',[0.95 0.96 0.94]);
popup = uicontrol('Parent',dlg,'Style','popupmenu','String',labels, ...
    'Units','normalized','Position',[0.14 0.925 0.40 0.05], ...
    'Callback',@onDatasetChanged);
status = uicontrol('Parent',dlg,'Style','text','String','', ...
    'Units','normalized','Position',[0.57 0.925 0.40 0.045], ...
    'HorizontalAlignment','right','BackgroundColor',[0.95 0.96 0.94]);

uicontrol('Parent',dlg,'Style','text','String','Class:', ...
    'Units','normalized','Position',[0.03 0.855 0.08 0.04], ...
    'HorizontalAlignment','left','FontWeight','bold', ...
    'BackgroundColor',[0.95 0.96 0.94]);
classPopup = uicontrol('Parent',dlg,'Style','popupmenu','String',{'No known classes'}, ...
    'Units','normalized','Position',[0.11 0.855 0.16 0.05],'Tag','ClassPopup');
excludeClassButton = uicontrol('Parent',dlg,'Style','pushbutton','String','Exclude class', ...
    'Units','normalized','Position',[0.29 0.855 0.19 0.05], ...
    'Tag','ExcludeClassButton','Callback',@onExcludeClass);
includeClassButton = uicontrol('Parent',dlg,'Style','pushbutton','String','Include class', ...
    'Units','normalized','Position',[0.50 0.855 0.19 0.05], ...
    'Callback',@onIncludeClass);
onlyClassButton = uicontrol('Parent',dlg,'Style','pushbutton','String','Include only class', ...
    'Units','normalized','Position',[0.71 0.855 0.26 0.05], ...
    'Callback',@onIncludeOnlyClass);

table = uitable('Parent',dlg,'Units','normalized', ...
    'Position',[0.03 0.19 0.94 0.64], ...
    'ColumnName',{'Include','Original row','Class','Sample name'}, ...
    'ColumnEditable',[true false false false], ...
    'ColumnFormat',{'logical','numeric','char','char'}, ...
    'ColumnWidth',{70 95 90 360});

uicontrol('Parent',dlg,'Style','pushbutton','String','Include all in current dataset', ...
    'Units','normalized','Position',[0.03 0.10 0.29 0.06], ...
    'Callback',@onIncludeCurrent);
uicontrol('Parent',dlg,'Style','pushbutton','String','Include all datasets', ...
    'Units','normalized','Position',[0.34 0.10 0.23 0.06], ...
    'Callback',@onIncludeAll);
uicontrol('Parent',dlg,'Style','pushbutton','String','Apply', ...
    'Units','normalized','Position',[0.70 0.075 0.12 0.08], ...
    'FontWeight','bold','Callback',@onApply);
uicontrol('Parent',dlg,'Style','pushbutton','String','Cancel', ...
    'Units','normalized','Position',[0.84 0.075 0.12 0.08], ...
    'Callback',@onCancel);

current = 1;
refreshTable();
uiwait(dlg);

    function saveCurrent()
        data = get(table,'Data');
        if ~isempty(data)
            datasets(current).included = logical(cell2mat(data(:,1)));
        end
    end

    function refreshTable()
        d = datasets(current);
        n = size(d.X,1);
        data = cell(n,4);
        for ii = 1:n
            data{ii,1} = d.included(ii);
            data{ii,2} = d.originalRows(ii);
            if iscell(d.classDisplay)
                data{ii,3} = d.classDisplay{ii};
            else
                data{ii,3} = d.classDisplay(ii);
            end
            data{ii,4} = d.sampleNames{ii};
        end
        set(table,'Data',data);
        set(status,'String',sprintf('%d included / %d total',sum(d.included),n));
        refreshClassControls(d);
    end

    function refreshClassControls(d)
        [known,classes] = getKnownClasses(d.classDisplay);
        if known
            labelsClass = arrayfun(@num2str,classes,'UniformOutput',false);
            set(classPopup,'String',labelsClass,'Value',1,'Enable','on');
            set([excludeClassButton includeClassButton onlyClassButton],'Enable','on');
        else
            set(classPopup,'String',{'Unknown'},'Value',1,'Enable','off');
            set([excludeClassButton includeClassButton onlyClassButton],'Enable','off');
        end
    end

    function [known,classes] = getKnownClasses(classDisplay)
        known = false; classes = [];
        if isnumeric(classDisplay)
            values = classDisplay(:);
        elseif iscell(classDisplay) && all(cellfun(@(v)isnumeric(v) && isreal(v) && isscalar(v) && isfinite(v),classDisplay(:)))
            values = cell2mat(classDisplay(:));
        else
            return;
        end
        classes = localUniqueStable(values);
        known = ~isempty(classes);
    end

    function valuesUnique = localUniqueStable(values)
        % 
        values = values(:);
        valuesUnique = values([]);
        for jj = 1:numel(values)
            if ~any(valuesUnique == values(jj))
                valuesUnique(end+1,1) = values(jj); 
            end
        end
    end

    function mask = selectedClassMask()
        d = datasets(current);
        [known,classes] = getKnownClasses(d.classDisplay);
        if ~known, mask = false(size(d.included)); return; end
        selectedClass = classes(get(classPopup,'Value'));
        if isnumeric(d.classDisplay)
            values = d.classDisplay(:);
        else
            values = cell2mat(d.classDisplay(:));
        end
        mask = (values == selectedClass);
    end

    function onExcludeClass(src,ev)
        saveCurrent();
        mask = selectedClassMask();
        datasets(current).included(mask) = false;
        refreshTable();
    end

    function onIncludeClass(src,ev)
        saveCurrent();
        mask = selectedClassMask();
        datasets(current).included(mask) = true;
        refreshTable();
    end

    function onIncludeOnlyClass(src,ev)
        saveCurrent();
        mask = selectedClassMask();
        datasets(current).included(:) = false;
        datasets(current).included(mask) = true;
        refreshTable();
    end

    function onDatasetChanged(src,ev)
        saveCurrent();
        current = get(popup,'Value');
        refreshTable();
    end

    function onIncludeCurrent(src,ev)
        saveCurrent();
        datasets(current).included(:) = true;
        refreshTable();
    end

    function onIncludeAll(src,ev)
        saveCurrent();
        for jj = 1:numel(datasets)
            datasets(jj).included(:) = true;
        end
        refreshTable();
    end

    function onApply(src,ev)
        saveCurrent();
        emptySets = find(arrayfun(@(d)~any(d.included),datasets),1);
        if ~isempty(emptySets)
            errordlg(['At least one sample must remain included in ' ...
                datasets(emptySets).label '.'],'Exclude samples');
            return;
        end
        applied = true;
        if ishandle(dlg), uiresume(dlg); delete(dlg); end
    end

    function onCancel(src,ev)
        applied = false;
        if ishandle(dlg), uiresume(dlg); delete(dlg); end
    end
end
