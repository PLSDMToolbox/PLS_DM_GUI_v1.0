%
function plsdm_gui_optimization()
%                         PLS-DM OPTIMIZATION GUI
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

try
    thisFile = mfilename('fullpath');
    [thisPath,~,~] = fileparts(thisFile);
    if ~isempty(thisPath)
        addpath(thisPath,'-begin');
    end
catch
end

%%-------------------------------------------------------------------------
GUI_VERSION = 'PLS-DM Toolbox GUI v1.0';

scr = get(0,'ScreenSize');
figW = min(1400, scr(3)-80);
figH = min(820,  scr(4)-100);

fig = figure('Name',['PLS-DM Toolbox - Optimization - ' GUI_VERSION], ...
    'NumberTitle','off', ...
    'MenuBar','none', ...
    'Toolbar','none', ...
    'Color',[0.97 0.93 0.94], ...
    'Units','pixels', ...
    'Position',[40 40 figW figH]);

S = struct();
S.Xtrain = [];
S.ClassTrain = [];
S.XtrainAll = []; S.ClassTrainAll = []; S.includeTrain = [];
S.trainOriginalRows = []; S.trainNamesAll = {};
S.PLSDMopt = [];
S.PLSDMoptAll = [];
S.TargetClasses = [];
S.TargetClass = [];
S.CurrentPrepro = 'raw';
S.PlotType = 'Preprocessing';
S.CurrentResults = struct([]);
S.CurrentPareto = struct([]);
S.CurrentBest = struct([]);
S.SelectedIndex = [];
S.ModelNumToIndex = [];
S.ListRowToModel = [];
S.ModellingType = 'Compliant';
S.RigorousTolerance = 0.02;
S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});

% -----------------------------
% Visual layout
% -----------------------------
themeDark  = [0.50 0.16 0.22];
themeLight = [0.97 0.93 0.94];

S.pnlHeader = uipanel('Parent',fig, ...
    'Units','normalized','Position',[0.01 0.88 0.98 0.10], ...
    'BackgroundColor',themeDark, ...
    'BorderType','none');

uicontrol('Parent',S.pnlHeader,'Style','text','String','PLS-DM optimization', ...
    'Units','normalized','Position',[0.025 0.45 0.60 0.42], ...
    'BackgroundColor',themeDark, ...
    'ForegroundColor',[1 1 1], ...
    'HorizontalAlignment','left','FontSize',17,'FontWeight','bold');

uicontrol('Parent',S.pnlHeader,'Style','text', ...
    'String','Optimize preprocessing, latent variables, smoothing coefficients and kappa values for PLS-DM models', ...
    'Units','normalized','Position',[0.025 0.12 0.86 0.26], ...
    'BackgroundColor',themeDark, ...
    'ForegroundColor',[0.92 0.92 0.92], ...
    'HorizontalAlignment','left','FontSize',10);

uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Help', ...
    'Units','normalized','Position',[0.895 0.30 0.080 0.42], ...
    'FontWeight','bold', ...
    'BackgroundColor',[0.98 0.98 0.98], ...
    'ForegroundColor',themeDark, ...
    'Callback',@onHelp);
S.btnDataInfo = uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Add data info...', ...
    'Units','normalized','Position',[0.705 0.30 0.125 0.42],'FontWeight','bold', ...
    'BackgroundColor',[0.98 0.98 0.98],'ForegroundColor',themeDark,'Enable','off','Callback',@onDataInfo);

% ================================================================
% LEFT PANEL - CONTROLS
% ================================================================
S.pnlCtrl = uipanel('Parent',fig,'Title','Optimization settings', ...
    'Units','normalized','Position',[0.01 0.02 0.27 0.84], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'FontWeight','bold');
S.btnExclude = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Exclude...', ...
    'Units','normalized','Position',[0.52 0.855 0.43 0.043],'FontWeight','bold', ...
    'Enable','off','Callback',@onExcludeSamples);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data source', ...
    'Units','normalized','Position',[0.05 0.95 0.30 0.03], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'HorizontalAlignment','left','FontWeight','bold');

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Import workspace', ...
    'Units','normalized','Position',[0.05 0.905 0.42 0.043], ...
    'Callback',@onImportWorkspace);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Load saved PLSDMopt', ...
    'Units','normalized','Position',[0.52 0.905 0.43 0.043], ...
    'Callback',@onLoadSavedPLSDMopt);

S.btnSeeData = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','See data', ...
    'Units','normalized','Position',[0.05 0.855 0.42 0.043], ...
    'TooltipString','Inspect the imported training profiles and class means.', ...
    'Enable','off','Callback',@onSeeData);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Target class', ...
    'Units','normalized','Position',[0.05 0.810 0.24 0.026], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.popupTargetClass = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
    'String',{'import data'}, ...
    'Units','normalized','Position',[0.31 0.805 0.24 0.035], ...
    'BackgroundColor',[1 1 1]);
S.chkAllClasses = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
    'String','All classes', ...
    'Units','normalized','Position',[0.59 0.805 0.35 0.035], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',0);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','K-fold CV', ...
    'Units','normalized','Position',[0.05 0.755 0.24 0.028], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edKcv = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','5', ...
    'Units','normalized','Position',[0.31 0.748 0.16 0.042], ...
    'BackgroundColor',[1 1 1]);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Max LV', ...
    'Units','normalized','Position',[0.55 0.755 0.22 0.028], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edMaxLV = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','10', ...
    'Units','normalized','Position',[0.77 0.748 0.15 0.042], ...
    'BackgroundColor',[1 1 1]);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Conf. lev. (1-alpha)', ...
    'Units','normalized','Position',[0.05 0.705 0.24 0.028], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edConf = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','0.95', ...
    'Units','normalized','Position',[0.31 0.698 0.16 0.042], ...
    'BackgroundColor',[1 1 1]);

S.chkRobust = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
    'String','Robust PLS', ...
    'Units','normalized','Position',[0.55 0.698 0.37 0.042], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',0);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Gamma', ...
    'Units','normalized','Position',[0.05 0.655 0.24 0.028], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edGamma = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','0.01', ...
    'Units','normalized','Position',[0.31 0.648 0.16 0.042], ...
    'BackgroundColor',[1 1 1]);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Model type', ...
    'Units','normalized','Position',[0.52 0.655 0.18 0.028], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'HorizontalAlignment','left');
S.popupModellingType = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
    'String',{'Compliant','Rigorous'}, ...
    'Units','normalized','Position',[0.70 0.648 0.22 0.042], ...
    'BackgroundColor',[1 1 1], ...
    'Callback',@onModellingTypeChanged);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Preprocessing to optimize', ...
    'Units','normalized','Position',[0.05 0.605 0.70 0.035], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'HorizontalAlignment','left','FontWeight','bold');

S.chkRaw = uicontrol('Parent',S.pnlCtrl,'Style','checkbox','String','Raw', ...
    'Units','normalized','Position',[0.05 0.555 0.18 0.04], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',1);
S.chkCentered = uicontrol('Parent',S.pnlCtrl,'Style','checkbox','String','Center', ...
    'Units','normalized','Position',[0.24 0.555 0.25 0.04], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',1);
S.chkScaled = uicontrol('Parent',S.pnlCtrl,'Style','checkbox','String','Scale', ...
    'Units','normalized','Position',[0.51 0.555 0.20 0.04], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',1);
S.chkAutoscaled = uicontrol('Parent',S.pnlCtrl,'Style','checkbox','String','Autoscale', ...
    'Units','normalized','Position',[0.72 0.555 0.25 0.04], ...
    'BackgroundColor',[0.97 0.93 0.94], 'Value',1);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Smoothing coefficients', ...
    'Units','normalized','Position',[0.05 0.505 0.60 0.035], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edSmooth = uicontrol('Parent',S.pnlCtrl,'Style','edit', ...
    'String','[0.3 0.4 0.5 0.6 0.7 0.8]', ...
    'Units','normalized','Position',[0.05 0.460 0.90 0.043], ...
    'BackgroundColor',[1 1 1]);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Kappa values', ...
    'Units','normalized','Position',[0.05 0.415 0.34 0.03], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.edKappa = uicontrol('Parent',S.pnlCtrl,'Style','edit', ...
    'String','1:6', ...
    'Units','normalized','Position',[0.05 0.370 0.40 0.04], ...
    'BackgroundColor',[1 1 1]);

btn_w = 0.40;
btn_h = 0.055;

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Restore defaults', ...
    'Units','normalized','Position',[0.50 0.365 btn_w btn_h], ...
    'Callback',@onRestoreDefaults);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Run optimization', ...
    'Units','normalized','Position',[0.05 0.300 btn_w btn_h], ...
    'FontWeight','bold','Callback',@onRunOptimization);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export PLSDMopt', ...
    'Units','normalized','Position',[0.50 0.300 btn_w btn_h], ...
    'Callback',@onExportPLSDMopt);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export selected model', ...
    'Units','normalized','Position',[0.05 0.235 btn_w btn_h], ...
    'Callback',@onExportSelectedModel);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export current table', ...
    'Units','normalized','Position',[0.50 0.235 btn_w btn_h], ...
    'Callback',@onExportCurrentTable);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export current plot', ...
    'Units','normalized','Position',[0.05 0.170 btn_w btn_h], ...
    'Callback',@onExportCurrentPlot);

uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Outliers report', ...
    'Units','normalized','Position',[0.50 0.170 btn_w btn_h], ...
    'Callback',@onOutliersReport);

uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data / run summary', ...
    'Units','normalized','Position',[0.05 0.135 0.45 0.03], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'HorizontalAlignment','left','FontWeight','bold');

S.txtSummary = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
    'Units','normalized','Position',[0.05 0.03 0.90 0.10], ...
    'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
    'String',{'No training data loaded.'});

% ================================================================
% RIGHT PANEL - VIEW
% ================================================================
S.pnlView = uipanel('Parent',fig,'Title','Optimization results', ...
    'Units','normalized','Position',[0.29 0.02 0.70 0.84], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'FontWeight','bold');

uicontrol('Parent',S.pnlView,'Style','text','String','Plot type', ...
    'Units','normalized','Position',[0.03 0.945 0.09 0.030], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.popupPlotType = uicontrol('Parent',S.pnlView,'Style','popupmenu', ...
    'String',{'All','Preprocessing','Kappa','LV','Smooth coefficient','Best LV'}, ...
    'Value',2, ...
    'Units','normalized','Position',[0.12 0.935 0.17 0.045], ...
    'BackgroundColor',[1 1 1], ...
    'Callback',@onPlotTypeChanged);

uicontrol('Parent',S.pnlView,'Style','text','String','Selected value', ...
    'Units','normalized','Position',[0.31 0.945 0.12 0.030], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.popupPlotValue = uicontrol('Parent',S.pnlView,'Style','popupmenu', ...
    'String',{'Raw'}, ...
    'Units','normalized','Position',[0.43 0.935 0.15 0.045], ...
    'BackgroundColor',[1 1 1], ...
    'Callback',@onPlotValueChanged);

uicontrol('Parent',S.pnlView,'Style','text','String','Active class/model', ...
    'Units','normalized','Position',[0.61 0.945 0.14 0.030], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left');
S.popupTargetModelView = uicontrol('Parent',S.pnlView,'Style','popupmenu', ...
    'String',{'current'}, ...
    'Units','normalized','Position',[0.76 0.935 0.20 0.045], ...
    'BackgroundColor',[1 1 1], ...
    'Callback',@onTargetModelViewChanged);

S.axMain = axes('Parent',S.pnlView,'Units','normalized','Position',[0.07 0.40 0.50 0.47]);
title(S.axMain,'Optimization plot'); box(S.axMain,'on');

uicontrol('Parent',S.pnlView,'Style','text','String','Candidate models', ...
    'Units','normalized','Position',[0.04 0.325 0.24 0.030], ...
    'BackgroundColor',[0.97 0.93 0.94], 'HorizontalAlignment','left', ...
    'FontWeight','bold');
S.lstModels = uicontrol('Parent',S.pnlView,'Style','listbox', ...
    'Units','normalized','Position',[0.04 0.03 0.54 0.28], ...
    'BackgroundColor',[1 1 1], 'Max',1,'Min',0, ...
    'String',{'No models available.'}, ...
    'Callback',@onSelectModelFromList);

S.pnlAdvanced = uipanel('Parent',S.pnlView,'Title','Advanced results', ...
    'Units','normalized','Position',[0.63 0.60 0.33 0.32], ...
    'BackgroundColor',[0.97 0.93 0.94]);

uicontrol('Parent',S.pnlAdvanced,'Style','text', ...
    'String','SEN / SPEC maps across kappa, LV and smoothing alpha.', ...
    'Units','normalized','Position',[0.08 0.74 0.84 0.16], ...
    'BackgroundColor',[0.97 0.93 0.94], ...
    'HorizontalAlignment','left','FontWeight','bold', ...
    'FontName','Arial');
S.popupDashboard = uicontrol('Parent',S.pnlAdvanced,'Style','popupmenu', ...
    'String',{'Current preprocessing','Raw','Center','Scale','Autoscale'}, ...
    'Units','normalized','Position',[0.08 0.56 0.84 0.12], ...
    'BackgroundColor',[1 1 1]);

uicontrol('Parent',S.pnlAdvanced,'Style','pushbutton','String','Open advanced results', ...
    'Units','normalized','Position',[0.08 0.39 0.84 0.18], ...
    'FontWeight','bold', ...
    'Callback',@onOpenDashboard);

uicontrol('Parent',S.pnlAdvanced,'Style','pushbutton','String','Custom figure...', ...
    'Units','normalized','Position',[0.08 0.13 0.84 0.18], ...
    'FontWeight','bold','Callback',@onCustomFigure);

S.pnlSelected = uipanel('Parent',S.pnlView,'Title','Selected model', ...
    'Units','normalized','Position',[0.63 0.03 0.33 0.50], ...
    'BackgroundColor',[0.97 0.93 0.94]);

S.txtInspector = uicontrol('Parent',S.pnlSelected,'Style','listbox', ...
    'Units','normalized','Position',[0.08 0.07 0.84 0.88], ...
    'BackgroundColor',[1 1 1], 'Max',2,'Min',0, ...
    'String',{'Run optimization to inspect models.'});


guidata(fig,S);
refreshSummary(fig,{});
clearView(fig);

% ================================================================
% CALLBACKS
% ================================================================
    function onImportWorkspace(hObj,ev)
        S = guidata(hObj);
        [ok, names, vals] = plsdm_select_workspace_vars('Import training data', ...
            {'Xtrain','ClassTrain'}, {'Xtrain','ClassTrain'}, {false,false});
        if ~ok, return; end
        try
            Xtrain = vals{1};
            ClassTrain = vals{2};
            if size(ClassTrain,1)==1
                ClassTrain = ClassTrain';
            end
            if size(Xtrain,1) ~= length(ClassTrain)
                error('Xtrain rows and ClassTrain length are inconsistent.');
            end
            S.Xtrain = Xtrain;
            S.ClassTrain = ClassTrain;
            S.XtrainAll = Xtrain; S.ClassTrainAll = ClassTrain(:);
            S.includeTrain = true(size(Xtrain,1),1); S.trainOriginalRows = (1:size(Xtrain,1))';
            S.trainNamesAll = arrayfun(@(i)sprintf('Sample %d',i),(1:size(Xtrain,1))','UniformOutput',false);
            S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
            set(S.btnDataInfo,'Enable','on','String','Add data info...'); set(S.btnSeeData,'Enable','on');
            set(S.btnExclude,'Enable','on');
            guidata(hObj,S);
            updateTargetClassMenu(hObj);
            refreshSummary(hObj,{['Training data imported: ' names{1} ', ' names{2}]});
        catch ME
            errordlg(['Import error: ' ME.message],'Import');
        end
    end

    function onDataInfo(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain), errordlg('Load training data first.','Add data info'); return; end
        [info,applied] = plsdm_add_data_info(fig,S.ClassTrain,size(S.Xtrain,1),S.dataInfo);
        if ~applied, return; end
        S.dataInfo = info;
        if ~isempty(info.sampleNames), S.trainNamesAll(S.includeTrain) = info.sampleNames(:); end
        set(S.btnDataInfo,'String','Edit data info...'); guidata(fig,S);
    end

    function onExcludeSamples(hObj,ev)
        S = guidata(hObj);
        if isempty(S.XtrainAll), errordlg('Import training data first.','Exclude samples'); return; end
        d = struct('label','Training','X',S.XtrainAll, ...
            'classDisplay',{num2cell(S.ClassTrainAll(:))},'sampleNames',{S.trainNamesAll(:)}, ...
            'originalRows',S.trainOriginalRows(:),'included',S.includeTrain(:));
        [applied,d] = plsdm_exclude_samples_dialog(fig,d);
        if ~applied || isequal(S.includeTrain,d.included), return; end
        S.includeTrain = d.included;
        S.Xtrain = S.XtrainAll(S.includeTrain,:);
        S.ClassTrain = S.ClassTrainAll(S.includeTrain);
        S.dataInfo.sampleNames = S.trainNamesAll(S.includeTrain);
        S.PLSDMopt = []; S.PLSDMoptAll = [];
        S.CurrentResults = struct([]); S.CurrentPareto = struct([]); S.CurrentBest = struct([]);
        guidata(hObj,S);
        updateTargetClassMenu(hObj);
        refreshSummary(hObj,{'Sample selection changed; optimization results are outdated.'});
        msgbox('Training sample selection updated. Run the optimization again to visualize the updated results.', ...
            'Sample selection updated');
    end

    function onSeeData(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain), errordlg('Load training data first.','See data'); return; end
        fData = figure('Name','Optimization training data','NumberTitle','off','Color','w');
        axData = axes('Parent',fData); hold(axData,'on'); box(axData,'on'); grid(axData,'on');
        classes = plsdm_unique_stable(S.ClassTrain(:)); colors = lines(max(1,numel(classes)));
        hh = zeros(numel(classes),1); labels = cell(numel(classes),1);
        for kk = 1:numel(classes)
            rows = find(S.ClassTrain == classes(kk));
            plot(axData,1:size(S.Xtrain,2),S.Xtrain(rows,:),'Color',0.75*[1 1 1]+0.25*colors(kk,:));
            hh(kk) = plot(axData,1:size(S.Xtrain,2),mean(S.Xtrain(rows,:),1),'LineWidth',2.2,'Color',colors(kk,:));
            labels{kk} = [plsdm_data_info_class_name(S.dataInfo,classes(kk)) ' mean'];
        end
        xlab = 'Variable index'; ylab = 'Signal';
        if ~isempty(S.dataInfo.xLabel), xlab = S.dataInfo.xLabel; end
        if ~isempty(S.dataInfo.yLabel), ylab = S.dataInfo.yLabel; end
        xlabel(axData,xlab,'FontWeight','bold'); ylabel(axData,ylab,'FontWeight','bold');
        title(axData,'Optimization training data'); legend(axData,hh,labels,'Location','eastoutside');
    end

    function onLoadSavedPLSDMopt(hObj,ev)
        S = guidata(hObj);
        choice = questdlg('How do you want to load a saved PLSDMopt?', ...
            'Load PLSDMopt', ...
            'Workspace variable','MAT-file','Cancel','Workspace variable');
        if isempty(choice) || strcmp(choice,'Cancel')
            return;
        end
        try
            if strcmp(choice,'Workspace variable')
                [ok, names, vals] = plsdm_select_workspace_vars('Load saved PLSDMopt', ...
                    {'PLSDMopt'}, {'PLSDMopt'}, {false});
                if ~ok, return; end
                PLSDMopt = vals{1};
            else
                [file,path] = uigetfile('*.mat','Select MAT-file containing PLSDMopt');
                if isequal(file,0), return; end
                loaded = load(fullfile(path,file));
                if isfield(loaded,'PLSDMopt')
                    PLSDMopt = loaded.PLSDMopt;
                else
                    fn = fieldnames(loaded);
                    idx = [];
                    for ii = 1:length(fn)
                        if isstruct(loaded.(fn{ii})) && isfield(loaded.(fn{ii}),'model')
                            idx = ii;
                            break;
                        end
                    end
                    if isempty(idx)
                        error('No PLSDMopt-like structure was found in the MAT-file.');
                    end
                    PLSDMopt = loaded.(fn{idx});
                end
            end
            
            if ~isstruct(PLSDMopt)
                error('Loaded object is not a structure.');
            end
            
            S.PLSDMopt = PLSDMopt;
            if isfield(PLSDMopt,'AllClassesModels')
                S.PLSDMoptAll = PLSDMopt.AllClassesModels;
            end
            if isfield(PLSDMopt,'OriginalXtrain')
                S.Xtrain = PLSDMopt.OriginalXtrain;
            elseif isfield(PLSDMopt,'Xtrain')
                S.Xtrain = PLSDMopt.Xtrain;
            end
            if isfield(PLSDMopt,'OriginalClassTrain')
                S.ClassTrain = PLSDMopt.OriginalClassTrain;
            elseif isfield(PLSDMopt,'ClassTrain')
                S.ClassTrain = PLSDMopt.ClassTrain;
            end
            if ~isempty(S.Xtrain) && ~isempty(S.ClassTrain)
                S.XtrainAll = S.Xtrain; S.ClassTrainAll = S.ClassTrain(:);
                S.includeTrain = true(size(S.Xtrain,1),1); S.trainOriginalRows = (1:size(S.Xtrain,1))';
                S.trainNamesAll = arrayfun(@(i)sprintf('Sample %d',i),(1:size(S.Xtrain,1))','UniformOutput',false);
                S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
                set(S.btnDataInfo,'Enable','on','String','Add data info...'); set(S.btnSeeData,'Enable','on');
                set(S.btnExclude,'Enable','on');
            end
            if isfield(PLSDMopt,'ModellingType') && ~isempty(PLSDMopt.ModellingType)
                S.ModellingType = PLSDMopt.ModellingType;
            elseif isfield(PLSDMopt,'TargetInfo') && isfield(PLSDMopt.TargetInfo,'modellingType')
                S.ModellingType = PLSDMopt.TargetInfo.modellingType;
            else
                S.ModellingType = 'Compliant';
            end
            if strcmpi(S.ModellingType,'Rigorous')
                expected = str2double(get(S.edConf,'String'));
                if isfield(PLSDMopt,'ExpectedSensitivity'), expected = PLSDMopt.ExpectedSensitivity; end
                if isfield(PLSDMopt,'SensitivityTolerance')
                    S.RigorousTolerance = PLSDMopt.SensitivityTolerance;
                end
                PLSDMopt = local_attach_rigorous_selection(PLSDMopt,expected,S.RigorousTolerance);
                S.PLSDMopt = PLSDMopt;
            end
            if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
                vals = get(S.popupModellingType,'String');
                if iscell(vals)
                    idxMode = find(strcmpi(vals,S.ModellingType),1);
                    if ~isempty(idxMode)
                        set(S.popupModellingType,'Value',idxMode);
                    end
                end
            end
            guidata(hObj,S);
            updateTargetClassMenu(hObj);
            updateTargetModelViewMenu(hObj);
            
            updatePlotControls(hObj);
            applyPlotFilter(hObj);
            refreshSummary(hObj,{'Saved PLSDMopt loaded successfully.'});
        catch ME
            errordlg(['Load error: ' ME.message],'Load saved PLSDMopt');
        end
    end

    function updateTargetClassMenu(hObj)
        S = guidata(hObj);
        if isempty(S.ClassTrain) || ~isfield(S,'popupTargetClass') || ~ishandle(S.popupTargetClass)
            return;
        end
        classes = unique(S.ClassTrain(:));
        S.TargetClasses = classes(:);
        strs = cell(length(classes),1);
        for ii = 1:length(classes)
            strs{ii} = num2str(classes(ii));
        end
        if isempty(strs)
            strs = {'import data'};
            set(S.popupTargetClass,'String',strs,'Value',1);
            S.TargetClass = [];
        else
            set(S.popupTargetClass,'String',strs,'Value',1);
            S.TargetClass = classes(1);
        end
        guidata(hObj,S);
    end

    function targetClasses = getTargetClassesForRun(S)
        if isempty(S.ClassTrain)
            error('Import Xtrain and ClassTrain before running optimization.');
        end
        classes = unique(S.ClassTrain(:));
        if isfield(S,'chkAllClasses') && ishandle(S.chkAllClasses) && get(S.chkAllClasses,'Value') == 1
            targetClasses = classes(:)';
            return;
        end
        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            val = get(S.popupTargetClass,'Value');
            if val < 1 || val > length(classes)
                val = 1;
            end
            targetClasses = classes(val);
        else
            targetClasses = classes(1);
        end
    end

    function onRestoreDefaults(hObj,ev)
        S = guidata(hObj);
        set(S.edKcv,'String','5');
        set(S.edMaxLV,'String','10');
        set(S.edConf,'String','0.95');
        set(S.chkRaw,'Value',1);
        set(S.chkCentered,'Value',1);
        set(S.chkScaled,'Value',1);
        set(S.chkAutoscaled,'Value',1);
        set(S.edSmooth,'String','[0.3 0.4 0.5 0.6 0.7 0.8]');
        set(S.edKappa,'String','1:6');
        set(S.chkRobust,'Value',0);
        set(S.edGamma,'String','0.01');
        if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
            set(S.popupModellingType,'Value',1);
        end
        S.ModellingType = 'Compliant';
        guidata(hObj,S);
        refreshSummary(hObj,{});
    end

    function onModellingTypeChanged(hObj,ev)
        S = guidata(hObj);
        S.ModellingType = getSelectedModellingType(S);
        guidata(hObj,S);
        refreshSummary(hObj,{});
    end

    function modellingType = getSelectedModellingType(S)
        modellingType = 'Compliant';
        if isfield(S,'popupModellingType') && ishandle(S.popupModellingType)
            vals = get(S.popupModellingType,'String');
            idx = get(S.popupModellingType,'Value');
            if ischar(vals)
                modellingType = vals;
            elseif idx >= 1 && idx <= numel(vals)
                modellingType = vals{idx};
            end
        elseif isfield(S,'ModellingType') && ~isempty(S.ModellingType)
            modellingType = S.ModellingType;
        end
    end

    function [Xmodel,ClassOne,targetInfo] = prepareOptimizationModellingData(S,targetClass,modellingType)
        if nargin < 3 || isempty(modellingType)
            modellingType = 'Compliant';
        end
        ClassTrain = S.ClassTrain(:);
        switch lower(modellingType)
            case 'rigorous'
                idxTarget = find(ClassTrain == targetClass);
                if isempty(idxTarget)
                    error('Selected target class was not found in ClassTrain.');
                end
                Xmodel = S.Xtrain(idxTarget,:);
                ClassOne = ones(numel(idxTarget),1);
                classes = unique(ClassTrain);
                targetInfo = struct();
                targetInfo.targetClass = targetClass;
                targetInfo.originalClasses = classes(:);
                targetInfo.originalClassTrain = ClassTrain;
                targetInfo.nTarget = numel(idxTarget);
                targetInfo.nNonTarget = 0;
                targetInfo.modellingType = 'Rigorous';
                targetInfo.trainingRows = idxTarget(:);
            otherwise
                [ClassOne,targetInfo] = plsdm_prepare_oneclass_labels(ClassTrain,targetClass);
                Xmodel = S.Xtrain;
                targetInfo.modellingType = 'Compliant';
                targetInfo.trainingRows = (1:numel(ClassTrain))';
        end
    end

    function onRunOptimization(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xtrain) || isempty(S.ClassTrain)
            errordlg('Import Xtrain and ClassTrain before running optimization.','Optimization');
            return;
        end
        
        try
            Kcv = parsePositiveInteger(get(S.edKcv,'String'),'K-fold CV');
            maxLV = parsePositiveInteger(get(S.edMaxLV,'String'),'Max LV');
            conflev = parseProbability(get(S.edConf,'String'),'Confidence');
            preprotype = parsePreprocessingGrid(S);
            smooth_coef = parseNumericVector(get(S.edSmooth,'String'),'Smoothing coefficients');
            kappa_vals = parseNumericVector(get(S.edKappa,'String'),'Kappa values');
            if any(abs(kappa_vals-round(kappa_vals)) > 1e-12) || any(kappa_vals < 1)
                error('Kappa values must be positive integers.');
            end
            kappa_vals = round(kappa_vals);
            rob = get(S.chkRobust,'Value');
            gama = parseProbability(get(S.edGamma,'String'),'Robust gamma');
            modellingType = getSelectedModellingType(S);
            if strcmpi(modellingType,'Rigorous')
                [okTolerance,rigorousTolerance] = promptRigorousTolerance(conflev,S.RigorousTolerance);
                if ~okTolerance, return; end
                S.RigorousTolerance = rigorousTolerance;
                guidata(hObj,S);
            else
                rigorousTolerance = NaN;
            end
            option = cell(4,1);
            option{1} = smooth_coef;
            option{2} = kappa_vals;
            option{3} = rob;
            option{4} = gama;
        catch ME
            errordlg(ME.message,'Invalid optimization settings');
            return;
        end
        
%AAG   %set(S.txtInspector,'String',{'Running original-compatible plsdm_opt...'});
        set(S.txtInspector,'String',{'Running plsdm_opt...'});
        drawnow;
        
        try
            targetClasses = getTargetClassesForRun(S);
            if length(targetClasses) == 1
                [Xmodel, ClassOne, targetInfo] = prepareOptimizationModellingData(S,targetClasses(1),modellingType);
                PLSDMopt = plsdm_opt(Xmodel, ClassOne, Kcv, maxLV, conflev, preprotype, option);
                PLSDMopt = local_fix_compliance_metrics_for_dashboard(PLSDMopt, ClassOne);
                PLSDMopt.TargetClass = targetInfo.targetClass;
                PLSDMopt.TargetInfo = targetInfo;
                PLSDMopt.OriginalXtrain = S.Xtrain;
                PLSDMopt.OriginalClassTrain = S.ClassTrain;
                PLSDMopt.ClassTrain = ClassOne;
                PLSDMopt.ModellingType = modellingType;
                PLSDMopt.GUIVersion = GUI_VERSION;
                PLSDMopt = local_attach_rigorous_selection(PLSDMopt,conflev,rigorousTolerance);
                PLSDMopt = local_add_robust_outlier_report(PLSDMopt,rob);
                S.ModellingType = modellingType;
                S.TargetClass = targetInfo.targetClass;
                S.PLSDMoptAll = [];
            else
                PLSDMoptAll = cell(length(targetClasses),1);
                for cc = 1:length(targetClasses)
                    set(S.txtInspector,'String',{['Running target class ' num2str(targetClasses(cc)) ' (' num2str(cc) '/' num2str(length(targetClasses)) ')...']});
                    drawnow;
                    [Xmodel, ClassOne, targetInfo] = prepareOptimizationModellingData(S,targetClasses(cc),modellingType);
                    tmp = plsdm_opt(Xmodel, ClassOne, Kcv, maxLV, conflev, preprotype, option);
                    tmp = local_fix_compliance_metrics_for_dashboard(tmp, ClassOne);
                    tmp.TargetClass = targetInfo.targetClass;
                    tmp.TargetInfo = targetInfo;
                    tmp.OriginalXtrain = S.Xtrain;
                    tmp.OriginalClassTrain = S.ClassTrain;
                    tmp.ClassTrain = ClassOne;
                    tmp.ModellingType = modellingType;
                    tmp.GUIVersion = GUI_VERSION;
                    tmp = local_attach_rigorous_selection(tmp,conflev,rigorousTolerance);
                    tmp = local_add_robust_outlier_report(tmp,rob);
                    PLSDMoptAll{cc} = tmp;
                end
                PLSDMopt = PLSDMoptAll{1};
                PLSDMopt.AllClassesModels = PLSDMoptAll;
                PLSDMopt.AllTargetClasses = targetClasses;
                PLSDMopt.OriginalXtrain = S.Xtrain;
                PLSDMopt.ModellingType = modellingType;
                PLSDMopt.GUIVersion = GUI_VERSION;
                PLSDMopt = local_attach_rigorous_selection(PLSDMopt,conflev,rigorousTolerance);
                PLSDMopt = local_add_robust_outlier_report(PLSDMopt,rob);
                S.ModellingType = modellingType;
                S.PLSDMoptAll = PLSDMoptAll;
                S.TargetClass = targetClasses(1);
            end
        catch ME
            errordlg(['plsdm_opt failed: ' ME.message],'Optimization');
            return;
        end
        
        if isempty(PLSDMopt) || ~isstruct(PLSDMopt)
            errordlg('plsdm_opt returned an empty result. Check the target class composition.','Optimization');
            return;
        end
        
        S.PLSDMopt = PLSDMopt;
        guidata(hObj,S);
        
        updateTargetModelViewMenu(hObj);
        updatePlotControls(hObj);
        applyPlotFilter(hObj);
        msg = {'Optimization completed successfully.'};
        if isfield(PLSDMopt,'WarningMessages') && ~isempty(PLSDMopt.WarningMessages)
            msg = [msg(:); {' '}; PLSDMopt.WarningMessages(:)];
        end
        if isfield(PLSDMopt,'RobustNotice')
            msg = [msg(:); {PLSDMopt.RobustNotice}];
        end
        refreshSummary(hObj,msg);
    end

    function onPlotTypeChanged(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMopt)
            return;
        end
        list = get(S.popupPlotType,'String');
        val = get(S.popupPlotType,'Value');
        if iscell(list)
            S.PlotType = list{val};
        else
            S.PlotType = list;
        end
        guidata(hObj,S);
        updatePlotValueMenu(hObj);
        applyPlotFilter(hObj);
    end

    function onPlotValueChanged(hObj,ev)
        applyPlotFilter(hObj);
    end

    function applyPlotFilter(hObj)
        S = guidata(hObj);
        if isempty(S.PLSDMopt), return; end
        allResults = collectOptimizationResults(S.PLSDMopt);
        [filtered, selectedLabel] = filterOptimizationResults(allResults,S);
        filtered = renumberDisplayModels(filtered);
        pareto = buildDisplayPareto(filtered,get(S.edConf,'String'));
        S.CurrentResults = filtered;
        S.CurrentPareto = pareto;
        S.CurrentBest = selectBestDisplayModel(filtered,get(S.edConf,'String'));
        if strcmpi(S.PlotType,'Preprocessing')
            S.CurrentPrepro = selectedLabel;
        else
            S.CurrentPrepro = 'multiple';
        end
        if ~isempty(filtered)
            S.SelectedIndex = 1;
        else
            S.SelectedIndex = [];
        end
        S.ModelNumToIndex = buildModelNumMap(filtered);
        syncDashboardDropdown(S);
        guidata(hObj,S);
        updateResultsTable(hObj);
        updateModelListbox(hObj);
        plotMainOptimization(hObj);
        updateSelectedModelInspector(hObj);
        refreshSummary(hObj,{});
    end

    function updateTargetModelViewMenu(hObj)
        S = guidata(hObj);
        labels = {'current'};
        if isfield(S,'PLSDMoptAll') && ~isempty(S.PLSDMoptAll)
            labels = cell(length(S.PLSDMoptAll),1);
            for ii = 1:length(S.PLSDMoptAll)
                if isfield(S.PLSDMoptAll{ii},'TargetClass')
                    labels{ii} = ['Class ' num2str(S.PLSDMoptAll{ii}.TargetClass)];
                else
                    labels{ii} = ['Model ' num2str(ii)];
                end
            end
        elseif ~isempty(S.PLSDMopt) && isfield(S.PLSDMopt,'TargetClass')
            labels = {['Class ' num2str(S.PLSDMopt.TargetClass)]};
        end
        if isfield(S,'popupTargetModelView') && ishandle(S.popupTargetModelView)
            set(S.popupTargetModelView,'String',labels,'Value',1);
        end
        guidata(hObj,S);
    end

    function onTargetModelViewChanged(hObj,ev)
        S = guidata(hObj);
        if isfield(S,'PLSDMoptAll') && ~isempty(S.PLSDMoptAll)
            idx = get(S.popupTargetModelView,'Value');
            idx = max(1,min(idx,length(S.PLSDMoptAll)));
            S.PLSDMopt = S.PLSDMoptAll{idx};
            if isfield(S.PLSDMopt,'TargetClass')
                S.TargetClass = S.PLSDMopt.TargetClass;
            end
            guidata(hObj,S);
            updatePlotControls(hObj);
            applyPlotFilter(hObj);
            refreshSummary(hObj,{['Active model changed to class ' num2str(S.TargetClass)]});
        end
    end

    function onSelectModelFromList(hObj,ev)
        S = guidata(hObj);
        if isempty(S.CurrentResults)
            return;
        end
        row = get(S.lstModels,'Value');
        if isempty(row) || row < 1 || row > numel(S.ListRowToModel)
            return;
        end
        val = S.ListRowToModel(row);
        if val < 1 || val > length(S.CurrentResults)
            set(S.lstModels,'Value',findListRowForModel(S.ListRowToModel,S.SelectedIndex));
            return;
        end
        S.SelectedIndex = val;
        guidata(hObj,S);
        updateSelectedModelInspector(hObj);
        plotMainOptimization(hObj);
    end

    function onOpenDashboard(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMopt)
            errordlg('No PLSDMopt available.','Dashboard');
            return;
        end
        try
            list = get(S.popupDashboard,'String');
            val = get(S.popupDashboard,'Value');
            if iscell(list)
                choice = list{val};
            else
                choice = list;
            end
            if strcmpi(choice,'Current preprocessing')
                choice = S.CurrentPrepro;
                if strcmpi(choice,'multiple')
                    avail = get_available_prepro_list(S.PLSDMopt);
                    if isempty(avail), error('No preprocessing result is available.'); end
                    choice = avail{1};
                end
            else
                choice = local_prepro_internal_name(choice);
            end
            
            PLSDMopt_dash = S.PLSDMopt;
            if isfield(PLSDMopt_dash,'ClassTrain')
                PLSDMopt_dash = local_fix_compliance_metrics_for_dashboard(PLSDMopt_dash, PLSDMopt_dash.ClassTrain);
            elseif ~isempty(S.ClassTrain)
                PLSDMopt_dash = local_fix_compliance_metrics_for_dashboard(PLSDMopt_dash, S.ClassTrain);
            end
            
            
            if exist('PLSDMopt_avd','file') == 2
                PLSDMopt_avd(PLSDMopt_dash, choice);
            else
                error('No dashboard wrapper was found (PLSDMopt_avd).');
            end
        catch ME
            errordlg(['Unable to open dashboard: ' ME.message],'Dashboard');
        end
    end

    function onCustomFigure(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMopt)
            errordlg('Run or load an optimization before creating a custom figure.','Custom figure');
            return;
        end
        classNames = get(S.popupTargetModelView,'String');
        if ~iscell(classNames), classNames = cellstr(classNames); end
        plots = {'Optimization performance (current filters)'; ...
                 'Training data profiles by class'};
        % Always use the companion builder delivered with this GUI. This
        % prevents an older copy elsewhere on the MATLAB path from creating
        % a legacy/static FIG window.
        guiFolder = fileparts(mfilename('fullpath'));
        helperFile = fullfile(guiFolder,'plsdm_custom_figure_menu.m');
        if exist(helperFile,'file') ~= 2
            errordlg(['Required companion file was not found: ' helperFile], ...
                'Custom figure');
            return;
        end
        addpath(guiFolder,'-begin');
        rehash path;
        plsdm_custom_figure_menu(hObj,'PLS-DM Optimization',plots,classNames,@renderCustomOptimizationPanel);
    end

    function renderCustomOptimizationPanel(plotIndex,classIndex,ax)
        S0 = guidata(fig);
        oldClass = get(S0.popupTargetModelView,'Value');
        cleanup = onCleanup(@()restoreCustomOptimizationState(oldClass));
        if isfield(S0,'PLSDMoptAll') && ~isempty(S0.PLSDMoptAll)
            set(S0.popupTargetModelView,'Value',max(1,min(classIndex,length(S0.PLSDMoptAll))));
            onTargetModelViewChanged(fig,[]);
        end
        S1 = guidata(fig);
        if plotIndex == 1
            copyCustomAxes(S1.axMain,ax);
        else
            plotCustomTrainingData(ax,S1);
        end
    end

    function restoreCustomOptimizationState(oldClass)
        if ~ishandle(fig), return; end
        Sx=guidata(fig);
        if isfield(Sx,'popupTargetModelView') && ishandle(Sx.popupTargetModelView)
            set(Sx.popupTargetModelView,'Value',oldClass); onTargetModelViewChanged(fig,[]);
        end
    end

    function plotCustomTrainingData(ax,Sx)
        X=Sx.Xtrain; C=Sx.ClassTrain(:); classes=unique(C); cols=lines(length(classes)); hold(ax,'on');
        for ii=1:length(classes)
            idx=find(C==classes(ii)); pale=.75*[1 1 1]+.25*cols(ii,:);
            for jj=1:length(idx), plot(ax,1:size(X,2),X(idx(jj),:),'-','Color',pale,'LineWidth',.5); end
            plot(ax,1:size(X,2),mean(X(idx,:),1),'-','Color',cols(ii,:),'LineWidth',2);
        end
        box(ax,'on'); grid(ax,'on'); xlabel(ax,'Variable index'); ylabel(ax,'Signal');
    end

    function copyCustomAxes(src,dst)
        cla(dst); kids=allchild(src); if ~isempty(kids), copyobj(kids,dst); end
        set(dst,'XLim',get(src,'XLim'),'YLim',get(src,'YLim'),'XScale',get(src,'XScale'),'YScale',get(src,'YScale'));
        xlabel(dst,get(get(src,'XLabel'),'String')); ylabel(dst,get(get(src,'YLabel'),'String')); box(dst,'on'); grid(dst,'on');
    end

    function onExportPLSDMopt(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PLSDMopt)
            errordlg('No PLSDMopt available.','Export');
            return;
        end
        assignin('base','PLSDMopt',S.PLSDMopt);
        if isfield(S,'PLSDMoptAll') && ~isempty(S.PLSDMoptAll)
            assignin('base','PLSDMoptAll',S.PLSDMoptAll);
            msgbox('PLSDMopt and PLSDMoptAll exported to workspace.','Export');
        else
            msgbox('PLSDMopt exported to workspace.','Export');
        end
    end

    function onExportSelectedModel(hObj,ev)
        S = guidata(hObj);
        if isempty(S.SelectedIndex) || isempty(S.CurrentResults)
            errordlg('No model selected.','Export selected model');
            return;
        end
        selected_model = S.CurrentResults(S.SelectedIndex);
        assignin('base','PLSDM_selected_model',selected_model);
        msgbox('Selected model exported to workspace as PLSDM_selected_model.','Export');
    end

    function onExportCurrentTable(hObj,ev)
        S = guidata(hObj);
        if isempty(S.CurrentResults)
            errordlg('No results available.','Export table');
            return;
        end
        [file,path] = uiputfile('*.csv','Export current table');
        if isequal(file,0), return; end
        filename = fullfile(path,file);
        write_results_csv(filename, S.CurrentResults);
        msgbox('Current table exported successfully.','Export');
    end

%     function onExportCurrentPlot(hObj,ev) % Legacy export implementation.
%         S = guidata(hObj);
%         if isempty(S.CurrentResults)
%             errordlg('No plot available.','Export plot');
%             return;
%         end
%         [file,path,idx] = uiputfile({'*.png';'*.fig'},'Export current plot');
%         if isequal(file,0), return; end
%         outFile = fullfile(path,file);
%
%         f = figure('Visible','off');
%         ax = axes('Parent',f);
%         copyobj(allchild(S.axMain), ax);
%         set(ax,'XLim',get(S.axMain,'XLim'),'YLim',get(S.axMain,'YLim'));
%         xlabel(ax,get(get(S.axMain,'XLabel'),'String'));
%         ylabel(ax,get(get(S.axMain,'YLabel'),'String'));
%         title(ax,get(get(S.axMain,'Title'),'String'));
%         grid(ax,'on'); box(ax,'on');
%
%         if idx == 1
%             print(f,'-dpng','-r300',outFile);
%         else
%             saveas(f,outFile);
%         end
%         close(f);
%         msgbox('Current plot exported successfully.','Export');
%     end
    function onExportCurrentPlot(hObj,ev) % modified by AAG in 29/07/2026
        S = guidata(hObj);
        
        if isempty(S.CurrentResults)
            errordlg('No plot available.','Open current plot');
            return;
        end
        
        % Create an editable figure outside the GUI.
        f = figure( ...
            'Name','PLS-DM Optimization - Current plot', ...
            'NumberTitle','off', ...
            'Color',[1 1 1], ...
            'Units','normalized', ...
            'Position',[0.12 0.12 0.76 0.72]);
        
        % Copy the complete axes displayed inside the GUI.
        ax = copyobj(S.axMain,f);
        
        % Reserve space on the right for the legend.
        set(ax, ...
            'Units','normalized', ...
            'Position',[0.08 0.12 0.62 0.80]);
        
        hold(ax,'on');
        grid(ax,'on');
        box(ax,'on');
        
        caseType = lower(S.CurrentResults(1).CaseType);
        
        if strcmp(caseType,'rigorous')

            % Invisible objects used only for the legend.
            hOutside = plot(ax,nan,nan,'ro', ...
                'MarkerFaceColor',[1 1 1], ...
                'MarkerEdgeColor','r', ...
                'MarkerSize',7, ...
                'LineWidth',1.2);

            hWithin = plot(ax,nan,nan,'bo', ...
                'MarkerFaceColor',[0.25 0.55 0.90], ...
                'MarkerEdgeColor','b', ...
                'MarkerSize',7, ...
                'LineWidth',1.2);

            hRecommended = plot(ax,nan,nan,'gs', ...
                'MarkerFaceColor',[0.1 0.65 0.2], ...
                'MarkerEdgeColor','g', ...
                'MarkerSize',8, ...
                'LineWidth',1.3);

            hBand = patch('Parent',ax,'XData',[nan nan nan nan], ...
                'YData',[nan nan nan nan],'FaceColor',[0.90 0.90 0.90], ...
                'EdgeColor',[0.65 0.65 0.65]);

            hTarget = plot(ax,nan,nan,'k-','LineWidth',1.2);

            hSelected = plot(ax,nan,nan,'rs', ...
                'MarkerFaceColor','none', ...
                'MarkerEdgeColor','r', ...
                'MarkerSize',10, ...
                'LineWidth',1.5);
            
            lg = legend(ax, ...
                [hRecommended hWithin hOutside hBand hTarget hSelected], ...
                {'Recommended: closest to 1 - \alpha', ...
                'Within sensitivity tolerance', ...
                'Outside sensitivity tolerance', ...
                'Sensitivity tolerance band', ...
                'Target sensitivity: 1 - \alpha', ...
                'Selected model'}, ...
                'Location','EastOutside');
            
        else
            
            % Invisible objects used only for the legend.
            hNonPareto = plot(ax,nan,nan,'ko', ...
                'MarkerFaceColor',[1 1 1], ...
                'MarkerEdgeColor','k', ...
                'MarkerSize',7, ...
                'LineWidth',1.2);
            
            hPareto = plot(ax,nan,nan,'bo-', ...
                'MarkerFaceColor',[0 0 1], ...
                'MarkerEdgeColor','b', ...
                'MarkerSize',7, ...
                'LineWidth',1.5);
            
            hIdeal = plot(ax,nan,nan,'r^', ...
                'MarkerFaceColor','r', ...
                'MarkerEdgeColor','r', ...
                'MarkerSize',8, ...
                'LineWidth',1.2);
            
            hSelected = plot(ax,nan,nan,'rs', ...
                'MarkerFaceColor','none', ...
                'MarkerEdgeColor','r', ...
                'MarkerSize',10, ...
                'LineWidth',1.5);
            
            lg = legend(ax, ...
                [hNonPareto hPareto hIdeal hSelected], ...
                {'Non-Pareto models', ...
                'Pareto frontier', ...
                'Ideal point', ...
                'Selected model'}, ...
                'Location','EastOutside');
        end
        
        % Format and position the legend outside the plotting area.
        set(lg, ...
            'Box','off', ...
            'FontSize',9, ...
            'Units','normalized');
        
        legendPos = get(lg,'Position');
        legendPos(1) = 0.74;
        legendPos(2) = 0.50 - legendPos(4)/2;
        set(lg,'Position',legendPos);
        
        % Reapply the axes position because legend() may resize the axes.
        set(ax, ...
            'Units','normalized', ...
            'Position',[0.08 0.12 0.62 0.80]);
        
        hold(ax,'off');
    end
    function onOutliersReport(hObj,ev)
        S = guidata(hObj);
        models = {};
        if isfield(S,'PLSDMoptAll') && ~isempty(S.PLSDMoptAll)
            models = S.PLSDMoptAll;
        elseif isfield(S,'PLSDMopt') && ~isempty(S.PLSDMopt)
            models = {S.PLSDMopt};
        end
        
        if isempty(models)
            errordlg('Run or load a robust optimization before requesting the outliers report.','Outliers report');
            return;
        end
        
        for ii = 1:length(models)
            M = models{ii};
            if ~isempty(M) && isstruct(M) && isfield(M,'robust') && isequal(M.robust,1)
                if ~isfield(M,'RobustOutlierReport'), M = local_add_robust_outlier_report(M,1); end
                models{ii} = M;
            end
        end
        local_show_outlier_report_window(models);
    end

% ================================================================
% SUPPORT FUNCTIONS
% ================================================================
    function updatePlotControls(hObj)
        S = guidata(hObj);
        if ~isfield(S,'PlotType') || isempty(S.PlotType)
            S.PlotType = 'Preprocessing';
        end
        types = {'All','Preprocessing','Kappa','LV','Smooth coefficient','Best LV'};
        idx = find(strcmpi(types,S.PlotType),1);
        if isempty(idx), idx = 1; S.PlotType = types{1}; end
        set(S.popupPlotType,'String',types,'Value',idx);
        guidata(hObj,S);
        updatePlotValueMenu(hObj);
        syncDashboardDropdown(S);
    end

    function updatePlotValueMenu(hObj)
        S = guidata(hObj);
        allResults = collectOptimizationResults(S.PLSDMopt);
        values = {'No values'};
        enableState = 'on';
        switch lower(S.PlotType)
            case 'all'
                values = {'All models'};
                enableState = 'off';
            case 'preprocessing'
                values = local_prepro_display_list(get_available_prepro_list(S.PLSDMopt));
            case 'kappa'
                values = numericPopupValues(getResultFieldValues(allResults,'Kappa'));
            case 'lv'
                values = numericPopupValues(getResultFieldValues(allResults,'LV'));
            case 'smooth coefficient'
                values = numericPopupValues(getResultFieldValues(allResults,'Smooth'));
            case 'best lv'
                values = {'Automatic'};
                enableState = 'off';
        end
        if isempty(values), values = {'No values'}; end
        set(S.popupPlotValue,'String',values,'Value',1,'Enable',enableState);
    end

    function syncDashboardDropdown(S)
        base = {'Current preprocessing'};
        avail = {'raw','centered','scale','autoscale'};
        keep = {};
        if ~isempty(S.PLSDMopt)
            present = get_available_prepro_list(S.PLSDMopt);
            for ii = 1:length(avail)
                if any(strcmpi(present,avail{ii}))
                    keep{end+1} = avail{ii};
                end
            end
        else
            keep = avail;
        end
        set(S.popupDashboard,'String',[base local_prepro_display_list(keep)],'Value',1);
    end

    function refreshSummary(hObj,msg)
        S = guidata(hObj);
        txt = {};
        if ~isempty(S.Xtrain)
            txt{end+1} = ['Samples: ' num2str(size(S.Xtrain,1))];
            txt{end+1} = ['Variables: ' num2str(size(S.Xtrain,2))];
            classes = unique(S.ClassTrain(:));
            txt{end+1} = ['Classes: ' num2str(classes(:)')];
            txt{end+1} = ['Modelling type: ' getSelectedModellingType(S)];
            if isfield(S,'chkAllClasses') && ishandle(S.chkAllClasses) && get(S.chkAllClasses,'Value') == 1
                txt{end+1} = 'Target mode: all classes';
            elseif ~isempty(classes)
                targetClasses = getTargetClassesForRun(S);
                txt{end+1} = ['Target class: ' num2str(targetClasses(1)) ' | n=' num2str(sum(S.ClassTrain == targetClasses(1)))];
                txt{end+1} = ['Non-target: n=' num2str(sum(S.ClassTrain ~= targetClasses(1)))];
            end
        else
            txt{end+1} = 'No training data loaded.';
        end
        if ~isempty(S.PLSDMopt)
            txt{end+1} = ['Plot filter: ' S.PlotType];
            if strcmpi(S.PlotType,'Best LV')
                txt{end+1} = 'Selected value: Automatic';
            else
                txt{end+1} = ['Selected value: ' getPopupSelection(S.popupPlotValue)];
            end
            txt{end+1} = ['Models in view: ' num2str(length(S.CurrentResults))];
        end
        if ~isempty(S.SelectedIndex) && ~isempty(S.CurrentResults)
            txt{end+1} = ['Selected model #: ' num2str(S.CurrentResults(S.SelectedIndex).ModelNum)];
        end
        if nargin >= 2 && ~isempty(msg)
            txt = [txt(:); {' '}; msg(:)];
        end
        set(S.txtSummary,'String',txt);
    end

    function clearView(hObj)
        S = guidata(hObj);
        cla(S.axMain);
        title(S.axMain,'Optimization plot');
        set(S.lstModels,'String',{'No models available.'},'Value',1);
        set(S.txtInspector,'String',{'Run optimization to inspect models.'});
        if isfield(S,'tblResults') && ishandle(S.tblResults), set(S.tblResults,'Data',cell(0,6),'ColumnName',{'#','Kappa','Smooth','LV','Sens','Spec'}); end
        syncDashboardDropdown(S);
    end

    function updateResultsTable(hObj)
        
        S = guidata(hObj);
        return;
    end

    function updateModelListbox(hObj)
        S = guidata(hObj);
        if isempty(S.CurrentResults)
            set(S.lstModels,'String',{'No models available.'},'Value',1);
            S.ListRowToModel = 0;
            guidata(hObj,S);
            return;
        end
        efficientNums = [];
        if ~isempty(S.CurrentPareto) && isfield(S.CurrentPareto,'ModelNum')
            efficientNums = [S.CurrentPareto.ModelNum];
        end
        isEfficient = false(1,length(S.CurrentResults));
        modelStrings = cell(length(S.CurrentResults),1);
        for i = 1:length(S.CurrentResults)
            isEff = any(efficientNums == S.CurrentResults(i).ModelNum);
            isEfficient(i) = isEff;
            modelStrings{i} = resultToString(S.CurrentResults(i),isEff);
        end

        if strcmpi(S.CurrentResults(1).CaseType,'rigorous')
            recommended = find_rigorous_recommended(S.CurrentResults);
            within = find_rigorous_within(S.CurrentResults,S.RigorousTolerance);
            outside = setdiff(1:numel(S.CurrentResults),within);
            sections = {'--- RECOMMENDED (CLOSEST TO TARGET) ---',recommended; ...
                '--- WITHIN SENSITIVITY TOLERANCE ---',setdiff(within,recommended); ...
                '--- OUTSIDE SENSITIVITY TOLERANCE ---',outside};
            strs = {}; rowMap = [];
            for ss = 1:size(sections,1)
                strs{end+1,1} = sections{ss,1}; rowMap(end+1,1) = 0;
                idxs = sort_rigorous_indices(S.CurrentResults,sections{ss,2});
                if isempty(idxs)
                    strs{end+1,1} = '  No models in this section'; rowMap(end+1,1) = 0;
                else
                    for ii = 1:numel(idxs)
                        strs{end+1,1} = modelStrings{idxs(ii)}; rowMap(end+1,1) = idxs(ii);
                    end
                end
                strs{end+1,1} = ' '; rowMap(end+1,1) = 0;
            end
            S.ListRowToModel = rowMap;
            val = findListRowForModel(rowMap,S.SelectedIndex);
            set(S.lstModels,'String',strs,'Value',val);
            guidata(hObj,S);
            return;
        else
            firstHeader = '--- PARETO FRONT MODELS ---';
        end
        priorityIdx = find(isEfficient);
        strs = {firstHeader};
        rowMap = 0;
        if isempty(priorityIdx)
            strs{end+1,1} = '  No models in this section';
            rowMap(end+1,1) = 0;
        else
            for ii = 1:numel(priorityIdx)
                idx = priorityIdx(ii);
                strs{end+1,1} = modelStrings{idx};
                rowMap(end+1,1) = idx;
            end
        end
        strs{end+1,1} = ' ';
        rowMap(end+1,1) = 0;
        strs{end+1,1} = '--- ALL MODELS ---';
        rowMap(end+1,1) = 0;
        for ii = 1:numel(modelStrings)
            strs{end+1,1} = modelStrings{ii};
            rowMap(end+1,1) = ii;
        end
        S.ListRowToModel = rowMap;
        val = findListRowForModel(rowMap,S.SelectedIndex);
        set(S.lstModels,'String',strs,'Value',val);
        guidata(hObj,S);
    end

    function updateSelectedModelInspector(hObj)
        S = guidata(hObj);
        if isempty(S.CurrentResults) || isempty(S.SelectedIndex)
            set(S.txtInspector,'String',{'No selected model.'});
            return;
        end
        m = S.CurrentResults(S.SelectedIndex);
        txt = {};
        txt{end+1} = ['Model #: ' num2str(m.ModelNum)];
        txt{end+1} = ['Preprocessing: ' local_prepro_display_name(getModelPreprocessing(m,S.CurrentPrepro))];
        txt{end+1} = ['Case type: ' m.CaseType];
        txt{end+1} = ['Kappa: ' num2str(m.Kappa)];
        txt{end+1} = ['Smooth: ' num2str(m.Smooth)];
        txt{end+1} = ['LV: ' num2str(m.LV)];
        txt{end+1} = ['Sensitivity: ' num2str(m.Sensitivity,4)];
        if isfield(m,'Specificity') && ~isnan(m.Specificity)
            txt{end+1} = ['Specificity: ' num2str(m.Specificity,4)];
        else
            txt{end+1} = 'Specificity: n/a for rigorous optimization';
        end
        txt{end+1} = ['Precision: ' num2str(m.Precision,4)];
        txt{end+1} = ['Accuracy: ' num2str(m.Accuracy,4)];
        txt{end+1} = ['F1: ' num2str(get_f1_field(m),4)];
        txt{end+1} = ['Efficiency: ' num2str(m.Efficiency,4)];
        % Determine the priority status used in the current display.
        %         txt{end+1} = ['Efficient: ' logical_to_yesno(is_model_efficient(m, S.CurrentPareto))];
        isEff = is_model_efficient_for_display( ...
            m, ...
            S.CurrentPareto, ...
            get(S.edConf,'String'));
        
        if strcmpi(m.CaseType,'rigorous')
            expected = get_rigorous_value(m,'ExpectedSensitivity',str2double(get(S.edConf,'String')));
            tolerance = get_rigorous_value(m,'SensitivityTolerance',S.RigorousTolerance);
            distance = abs(m.Sensitivity-expected);
            txt{end+1} = ['Expected sensitivity: ' num2str(expected,4)];
            txt{end+1} = ['Absolute distance: ' num2str(distance,4)];
            txt{end+1} = ['Tolerance: +/- ' num2str(tolerance,4)];
            txt{end+1} = ['Tolerance interval: [' num2str(max(0,expected-tolerance),4) ', ' num2str(min(1,expected+tolerance),4) ']'];
            txt{end+1} = ['Within tolerance: ' logical_to_yesno(distance <= tolerance + 10*eps)];
            txt{end+1} = ['Recommended: ' logical_to_yesno(isEff)];
        else
            txt{end+1} = ['Pareto-front model: ' logical_to_yesno(isEff)];
        end
        %
        if isfield(S,'PLSDMopt') && isfield(S.PLSDMopt,'RobustNotice')
            txt = appendRobustOptimizationOutlierLines(txt,S,m);
        end
        set(S.txtInspector,'String',txt);
    end

    function txt = appendRobustOptimizationOutlierLines(txt,S,m)
        txt{end+1} = ' ';
        txt{end+1} = 'Robust outlier screening:';
        if isfield(S.PLSDMopt,'RobustOutlierReport') && ~isempty(S.PLSDMopt.RobustOutlierReport)
            report = S.PLSDMopt.RobustOutlierReport;
            mask = false(size(report));
            for ii = 1:numel(report)
                mask(ii) = strcmpi(report(ii).Preprocessing,getModelPreprocessing(m,S.CurrentPrepro)) && ...
                    report(ii).KIndex == m.KIndex && report(ii).SIndex == m.SIndex && ...
                    report(ii).LVIndex == m.LVIndex;
            end
            rows = report(mask);
            txt{end+1} = ['  Target samples outside outlier boundary: ' num2str(numel(rows))];
            if ~isempty(rows)
                line = '  Sample indices: ';
                nshow = min(20,numel(rows));
                for ii = 1:nshow
                    if ii > 1, line = [line ', ']; end
                    line = [line num2str(rows(ii).Sample)];
                end
                if numel(rows) > nshow
                    line = [line ', ...'];
                end
                txt{end+1} = line;
            else
                txt{end+1} = '  No target sample outside the robust outlier boundary.';
            end
        else
            res = getComplianceResultForSelectedModel(S,m);
            if isempty(res) || ~isfield(res,'Gtrue') || ~isfield(res,'Gpred_bin')
                txt{end+1} = '  No compliance details available for this model.';
                return;
            end
            idxTarget = find(res.Gtrue == 1);
            rejectedTarget = idxTarget(find(res.Gpred_bin(idxTarget) == 0));
            txt{end+1} = ['  Target samples outside regular boundary: ' num2str(length(rejectedTarget))];
            txt{end+1} = '  Run/load a model with stored outlier limits to split extreme and outlier samples.';
        end
    end

    function res = getComplianceResultForSelectedModel(S,m)
        res = [];
        comp = [];
        pre = lower(getModelPreprocessing(m,S.CurrentPrepro));
        if strcmp(pre,'raw') && isfield(S.PLSDMopt,'ComplianceRAWmodels')
            comp = S.PLSDMopt.ComplianceRAWmodels;
        elseif strcmp(pre,'centered') && isfield(S.PLSDMopt,'ComplianceCenteredmodel')
            comp = S.PLSDMopt.ComplianceCenteredmodel;
        elseif (strcmp(pre,'scaled') || strcmp(pre,'scale')) && isfield(S.PLSDMopt,'ComplianceScaledmodel')
            comp = S.PLSDMopt.ComplianceScaledmodel;
        elseif (strcmp(pre,'autoscaled') || strcmp(pre,'autoscale')) && isfield(S.PLSDMopt,'ComplianceAutoscaledmodel')
            comp = S.PLSDMopt.ComplianceAutoscaledmodel;
        end
        if isempty(comp), return; end
        if isfield(m,'KIndex') && isfield(m,'SIndex') && isfield(m,'LVIndex')
            try
                res = comp{m.KIndex,m.SIndex,m.LVIndex};
            catch
                res = [];
            end
        end
    end

    function plotMainOptimization(hObj)
        S = guidata(hObj);
        axes(S.axMain); cla; hold on;
        if isempty(S.CurrentResults)
            title('Optimization plot');
            hold off;
            return;
        end
        
        caseType = lower(S.CurrentResults(1).CaseType);
        if strcmp(caseType,'compliant')
            plotCompliantInsideAxes(S.axMain, S.CurrentResults, S.CurrentPareto);
        else
            plotRigorousInsideAxes(S.axMain, S.CurrentResults, S.CurrentPareto, ...
                get(S.edConf,'String'),S.RigorousTolerance);
        end
        highlightSelectedPoint(hObj);
        title(S.axMain,buildPlotTitle(S,caseType),'Interpreter','none');
        hold off;
    end

    function highlightSelectedPoint(hObj)
        S = guidata(hObj);
        if isempty(S.CurrentResults) || isempty(S.SelectedIndex)
            return;
        end
        axes(S.axMain); hold on;
        m = S.CurrentResults(S.SelectedIndex);
        if strcmpi(m.CaseType,'rigorous')
            plot(S.SelectedIndex, m.Sensitivity, 'rs', 'MarkerSize',10, 'LineWidth',1.5, ...
                'ButtonDownFcn',@onMainPlotClick);
        else
            if isfield(m,'Specificity') && ~isnan(m.Specificity)
                plot(m.Specificity, m.Sensitivity, 'rs', 'MarkerSize',10, 'LineWidth',1.5, ...
                    'ButtonDownFcn',@onMainPlotClick);
            end
        end
        hold off;
    end

    function onMainPlotClick(src,ev)
        S = guidata(src);
        if isempty(S.CurrentResults)
            return;
        end
        pt = get(S.axMain,'CurrentPoint');
        x = pt(1,1);
        y = pt(1,2);
        idx = find_nearest_model_from_plot(S, x, y);
        if isempty(idx)
            return;
        end
        S.SelectedIndex = idx;
        guidata(src,S);
        set(S.lstModels,'Value',findListRowForModel(S.ListRowToModel,idx));
        updateSelectedModelInspector(src);
        plotMainOptimization(src);
    end

    function onHelp(hObj,ev)
        helpText = { ...
            ' '; ...
            'PURPOSE OF THIS MODULE'; ...
            '  This module searches for suitable PLS-DM modelling conditions using'; ...
            '  cross-validation. The result is an optimization structure that can be'; ...
            '  exported and later used in the final fitting/validation module.'; ...
            ' '; ...
            'Required input data'; ...
            '  Xtrain: numerical matrix with samples in rows and variables in columns.'; ...
            '  ClassTrain: class/status vector with one value per sample.'; ...
            '  The target class is defined according to the coding used by the toolbox.'; ...
            '  In the usual one-class setting, target samples are coded as class 1.'; ...
            ' '; ...
            'Rigorous versus compliant optimization'; ...
            '  Rigorous mode: optimization is based only on the target class. The main'; ...
            '  criterion is the absolute distance |SENS-(1-alpha)|. The recommended'; ...
            '  model is the one whose CV sensitivity is closest to the expected'; ...
            '  sensitivity (1-alpha), whether it lies slightly above or below it.'; ...
            '  Compliant mode: available non-target samples are also used. In this case'; ...
            '  sensitivity and specificity are evaluated together, usually through'; ...
            '  efficiency or Pareto-like compromise between both figures of merit.'; ...
            ' '; ...
            'Main parameters'; ...
            '  K-fold CV: number of deletion groups used during cross-validation.'; ...
            '  LV max: maximum number of latent variables tested in the PLS model.'; ...
            '  Confidence level: controls the PLS-DM acceptance limits.'; ...
            '  Kappa: number of nearest-neighbour distances used to estimate the'; ...
            '  density response for PLS-DM. Default search usually includes 1 to 6.'; ...
            '  Smoothing coefficient: controls the smoothness of the potential-function'; ...
            '  density estimate. Default search usually includes 0.3 to 0.8.'; ...
            ' '; ...
            'Preprocessing options'; ...
            '  Raw: data are used as imported.'; ...
            '  Center: variable means are subtracted.'; ...
            '  Scaled: variables are scaled according to the selected toolbox routine.'; ...
            '  Autoscale: variables are centered and scaled.'; ...
            '  The optimization compares the selected preprocessing choices together'; ...
            '  with LV, kappa and smoothing coefficient combinations.'; ...
            ' '; ...
            'Typical workflow'; ...
            '  1. Import Xtrain and ClassTrain from the MATLAB workspace.'; ...
            '  2. Select rigorous or compliant optimization mode.'; ...
            '  3. Define K-fold, LV max, confidence level, kappa values, smoothing'; ...
            '     coefficients and preprocessing options.'; ...
            '  4. Click Run optimization. In Rigorous mode, a modal window requests'; ...
            '     the sensitivity tolerance; Cancel leaves the current results unchanged.'; ...
            '  5. Inspect candidate models in the list and in the graphical panel.'; ...
            '  6. Select a suitable model considering the adopted strategy.'; ...
            '  7. Export PLSDMopt and/or the selected model to the workspace.'; ...
            ' '; ...
            'How to interpret the results'; ...
            '  Sensitivity: fraction of target samples accepted by the model.'; ...
            '  Specificity: fraction of non-target samples rejected by the model.'; ...
            '  Efficiency: global performance, commonly based on the balance between'; ...
            '  sensitivity and specificity.'; ...
            '  In rigorous mode, the target line is the expected sensitivity 1-alpha.'; ...
            '  The tolerance defines the acceptable band around that line. Models in'; ...
            '  the band are acceptable, but only the closest model is recommended;'; ...
            '  ties are resolved by the lowest LV and then the model number.'; ...
            '  If no model is inside the band, the closest one remains highlighted only'; ...
            '  as a reference and the plot explicitly reports that no model is within tolerance.'; ...
            '  In compliant mode, inspect the sensitivity-specificity compromise and'; ...
            '  avoid unnecessarily complex models when similar performance is obtained.'; ...
            ' '; ...
            'Advanced results'; ...
            '  The advanced dashboard summarizes the effect of LV, kappa, smoothing'; ...
            '  coefficient and preprocessing on the optimization results. It is useful'; ...
            '  for detecting unstable choices and for selecting robust final conditions.'; ...
            ' '; ...
            'Buttons and result navigation'; ...
            '  Help: opens this reference and does not modify imported data or results.'; ...
            '  Import workspace: select Xtrain, ClassTrain and optional supporting variables.'; ...
            '  Exclude: omit individual training samples or complete classes non-destructively.'; ...
            '    Changing inclusion invalidates stored optimization results; run optimization again before interpretation or export.'; ...
            '  Load saved PLSDMopt: restore a previously exported optimization structure.'; ...
            '  Target class: choose the one-class target currently optimized.'; ...
            '  All classes: run one independent one-class optimization for each class.'; ...
            '  Robust PLS: unchecked calls classical routines; checked calls robust routines and activates Gamma.'; ...
            '  Raw/Center/Scale/Autoscale: include each checked preprocessing in the search. At least one must be selected.'; ...
            '  Restore defaults: reset numerical fields and preprocessing selections.'; ...
            '  Run optimization: requires imported data, validates all settings and evaluates every requested combination. A new run replaces the current result.'; ...
            '  Plot type: choose how the displayed models are filtered.'; ...
            '    All: show every optimized model together. Selected value is disabled.'; ...
            '    Preprocessing: fix Raw, Center, Scale or Autoscale.'; ...
            '    Kappa: fix one of the kappa values evaluated in the optimization.'; ...
            '    LV: fix one latent-variable count evaluated in the optimization.'; ...
            '    Smooth coefficient: fix one smoothing coefficient evaluated in the optimization.'; ...
            '    Best LV: in Compliant mode use maximum efficiency; in Rigorous mode use'; ...
            '      minimum |SENS-(1-alpha)|. Ties use the lowest LV.'; ...
            '  Selected value: choose the value associated with Plot type. It is updated'; ...
            '    from the optimization results. For Best LV it shows Automatic and is disabled.'; ...
            '  Active class/model: select the class whose results are shown in All mode.'; ...
            '  Candidate models: Compliant mode lists Pareto-front models first.'; ...
            '    Rigorous mode separates Recommended, Within tolerance and Outside tolerance.'; ...
            '    In the rigorous plot, the green square is the recommended closest model;'; ...
            '    blue circles are other models within tolerance; hollow red circles are'; ...
            '    outside tolerance; the gray band is the tolerance interval; and the'; ...
            '    black line is the target sensitivity 1-alpha.'; ...
            '    Section headings are not selectable; repeated models refer to the same condition.'; ...
            '  Open advanced results: open the dashboard selected in the adjacent menu.'; ...
            '  Export PLSDMopt: requires a result and exports the complete search structure as PLSDMopt.'; ...
            '  Export selected model: requires a selected candidate and exports only that condition.'; ...
            '  Export current table: exports the rows currently represented by the filtered table.'; ...
            '    Rigorous exports include target, tolerance limits, sensitivity distance,'; ...
            '    within-tolerance flag and recommended-model flag.'; ...
            '  Export current plot: opens the displayed result plot in a standalone editable figure.'; ...
            '  Outliers report: opens a separate table window for robust results. Select a model to inspect its outlier rows; results are no longer printed in the Command Window.'; ...
            '  Close in the Help window: closes only this Help; the optimization GUI and its data remain open.'; ...
            ' '; ...
            'Outputs'; ...
            '  PLSDMopt: complete optimization output.'; ...
            '  Selected model/condition: preprocessing, LV, kappa, smoothing coefficient'; ...
            '  and corresponding cross-validation results for the chosen condition.'; ...
            ' '; ...
            ' '; ...
            };
        hHelp = figure('Name','PLS-DM Optimization Help', ...
            'NumberTitle','off', ...
            'MenuBar','none', ...
            'ToolBar','none', ...
            'Color',[1.00 1.00 1.00], ...
            'Units','normalized', ...
            'Position',[0.25 0.18 0.50 0.64], ...
            'Resize','on');
        
        %         uicontrol('Parent',hHelp, ...
        %                   'Style','text', ...
        %                   'String','PLS-DM Optimization - Help', ...
        %                   'Units','normalized', ...
        %                   'Position',[0.04 0.92 0.92 0.055], ...
        %                   'BackgroundColor',[0.94 0.97 1.00], ...
        %                   'ForegroundColor',[0.05 0.20 0.35], ...
        %                   'FontSize',12, ...
        %                   'FontWeight','bold', ...
        %                   'HorizontalAlignment','center');
        
        uicontrol('Parent',hHelp, ...
            'Style','listbox', ...
            'String',helpText, ...
            'Units','normalized', ...
            'Position',[0.04 0.11 0.92 0.79], ...
            'BackgroundColor',[1 1 1], ...
            'ForegroundColor',[0.05 0.05 0.05], ...
            'FontName','Courier New', ...
            'FontSize',9, ...
            'Max',2, ...
            'Min',0, ...
            'Value',1);
        
        %         uicontrol('Parent',hHelp, ...
        %                   'Style','pushbutton', ...
        %                   'String','Close', ...
        %                   'Units','normalized', ...
        %                   'Position',[0.40 0.035 0.20 0.05], ...
        %                   'FontWeight','bold', ...
        %                   'Callback',@(src,evt) close(hHelp));
    end
end

% ================================================================
% LOCAL HELPERS
% ================================================================
function v = parsePositiveInteger(strValue,label)
v = str2double(strValue);
if isnan(v) || v < 1 || abs(v-round(v)) > 1e-12
    error([label ' must be a positive integer.']);
end
v = round(v);
end

function v = parseProbability(strValue,label)
v = str2double(strValue);
if isnan(v) || v <= 0 || v >= 1
    error([label ' must be a number between 0 and 1.']);
end
end

function [ok,tolerance] = promptRigorousTolerance(expected,defaultTolerance)
ok = false;
tolerance = defaultTolerance;
while true
    lowerLimit = max(0,expected-defaultTolerance);
    upperLimit = min(1,expected+defaultTolerance);
    prompt = {sprintf(['Expected sensitivity (1-alpha): %.4f\n' ...
        'Enter the maximum absolute distance |SENS-(1-alpha)|.\n' ...
        'With the current value, the interval is [%.4f, %.4f].'], ...
        expected,lowerLimit,upperLimit)};
    answer = inputdlg(prompt,'Rigorous sensitivity tolerance',1,{num2str(defaultTolerance,'%.4g')});
    if isempty(answer), return; end
    tolerance = str2double(answer{1});
    if isfinite(tolerance) && tolerance >= 0 && tolerance <= 1
        ok = true;
        return;
    end
    errordlg('Sensitivity tolerance must be a number from 0 to 1.', ...
        'Invalid rigorous tolerance','modal');
end
end

function PLSDMopt = local_attach_rigorous_selection(PLSDMopt,expected,tolerance)
PLSDMopt.ExpectedSensitivity = expected;
PLSDMopt.SensitivityTolerance = tolerance;
PLSDMopt.ToleranceLowerLimit = max(0,expected-tolerance);
PLSDMopt.ToleranceUpperLimit = min(1,expected+tolerance);
suffixes = {'Raw','Centered','Scaled','Autoscaled'};
for ss = 1:numel(suffixes)
    resultField = ['results_struct' suffixes{ss}];
    paretoField = ['pareto_struct' suffixes{ss}];
    if ~isfield(PLSDMopt,resultField) || isempty(PLSDMopt.(resultField)), continue; end
    results = PLSDMopt.(resultField);
    distance = abs([results.Sensitivity]-expected);
    distance(isnan(distance)) = Inf;
    within = distance <= tolerance + 10*eps(max(1,abs(expected)));
    closest = min(distance);
    tied = find(abs(distance-closest) <= 10*eps(max(1,abs(expected))));
    orderData = [[results(tied).LV]' [results(tied).ModelNum]'];
    [dummy,ord] = sortrows(orderData,[1 2]); 
    recommended = false(size(distance));
    if ~isempty(tied), recommended(tied(ord(1))) = true; end
    closestMask = abs(distance-closest) <= 10*eps(max(1,abs(expected)));
    for ii = 1:numel(results)
        results(ii).ExpectedSensitivity = expected;
        results(ii).SensitivityTolerance = tolerance;
        results(ii).ToleranceLowerLimit = max(0,expected-tolerance);
        results(ii).ToleranceUpperLimit = min(1,expected+tolerance);
        results(ii).SensitivityDistance = distance(ii);
        results(ii).WithinSensitivityTolerance = within(ii);
        results(ii).RigorousRecommended = recommended(ii);
    end
    PLSDMopt.(resultField) = results;
    PLSDMopt.(paretoField) = results(closestMask);
end
end

function v = parseNumericVector(strValue,label)
try
    v = eval(strValue);
catch
    error([label ' must be a valid numeric vector, e.g. [0.3 0.4 0.5] or 1:6.']);
end
if isempty(v) || ~isnumeric(v)
    error([label ' must be a non-empty numeric vector.']);
end
v = v(:)';
end

function preprotype = parsePreprocessingGrid(S)
preprotype = [get(S.chkRaw,'Value') get(S.chkCentered,'Value') get(S.chkScaled,'Value') get(S.chkAutoscaled,'Value')];
if sum(preprotype) == 0
    error('At least one preprocessing option must be selected.');
end
end

function avail = get_available_prepro_list(PLSDMopt)
avail = {};
if isfield(PLSDMopt,'results_structRaw'),        avail{end+1} = 'raw';        end
if isfield(PLSDMopt,'results_structCentered'),   avail{end+1} = 'centered';   end
if isfield(PLSDMopt,'results_structScaled'),     avail{end+1} = 'scale';      end
if isfield(PLSDMopt,'results_structAutoscaled'), avail{end+1} = 'autoscale';  end
end

function labels = local_prepro_display_list(names)
labels = cell(size(names));
for ii = 1:numel(names), labels{ii} = local_prepro_display_name(names{ii}); end
end

function label = local_prepro_display_name(name)
switch lower(name)
    case 'raw', label = 'Raw';
    case 'centered', label = 'Center';
    case {'scale','scaled'}, label = 'Scale';
    case {'autoscale','autoscaled'}, label = 'Autoscale';
    otherwise, label = name;
end
end

function name = local_prepro_internal_name(label)
switch lower(label)
    case 'raw', name = 'raw';
    case 'center', name = 'centered';
    case {'scale','scaled'}, name = 'scale';
    case {'autoscale','autoscaled'}, name = 'autoscale';
    otherwise, name = label;
end
end

function [results_struct, pareto_struct, best_model] = getCurrentPreproBlocks(PLSDMopt, prepro)
results_struct = struct([]);
pareto_struct = struct([]);
best_model = struct([]);
switch lower(prepro)
    case 'raw'
        if isfield(PLSDMopt,'results_structRaw'), results_struct = PLSDMopt.results_structRaw; end
        if isfield(PLSDMopt,'pareto_structRaw'),  pareto_struct  = PLSDMopt.pareto_structRaw;  end
    case 'centered'
        if isfield(PLSDMopt,'results_structCentered'), results_struct = PLSDMopt.results_structCentered; end
        if isfield(PLSDMopt,'pareto_structCentered'),  pareto_struct  = PLSDMopt.pareto_structCentered;  end
    case 'scale'
        if isfield(PLSDMopt,'results_structScaled'), results_struct = PLSDMopt.results_structScaled; end
        if isfield(PLSDMopt,'pareto_structScaled'),  pareto_struct  = PLSDMopt.pareto_structScaled;  end
    case 'autoscale'
        if isfield(PLSDMopt,'results_structAutoscaled'), results_struct = PLSDMopt.results_structAutoscaled; end
        if isfield(PLSDMopt,'pareto_structAutoscaled'),  pareto_struct  = PLSDMopt.pareto_structAutoscaled;  end
end
if ~isempty(pareto_struct)
    if strcmpi(pareto_struct(1).CaseType,'rigorous')
        if isfield(pareto_struct,'RigorousRecommended') && any([pareto_struct.RigorousRecommended])
            idx = find([pareto_struct.RigorousRecommended],1,'first');
        else
            orderData = [[pareto_struct.LV]' [pareto_struct.ModelNum]'];
            [dummy,ord] = sortrows(orderData,[1 2]); 
            idx = ord(1);
        end
    else
        effs = [pareto_struct.Efficiency];
        [dummy,idx] = max(effs); 
    end
    best_model = pareto_struct(idx);
end
end

function results = collectOptimizationResults(PLSDMopt)
results = struct([]);
prepros = get_available_prepro_list(PLSDMopt);
for ii = 1:numel(prepros)
    [block,~,~] = getCurrentPreproBlocks(PLSDMopt,prepros{ii});
    if isempty(block), continue; end
    for jj = 1:numel(block)
        block(jj).Preprocessing = prepros{ii};
        block(jj).OriginalModelNum = block(jj).ModelNum;
    end
    if isempty(results), results = block; else, results = [results block]; end
end
end

function [filtered,label] = filterOptimizationResults(results,S)
filtered = results;
label = '';
if isempty(results), return; end
selection = getPopupSelection(S.popupPlotValue);
switch lower(S.PlotType)
    case 'all'
        filtered = results;
        label = 'All models';
    case 'preprocessing'
        selection = local_prepro_internal_name(selection);
        label = local_prepro_display_name(selection);
        filtered = results(strcmpi({results.Preprocessing},selection));
    case 'kappa'
        value = str2double(selection);
        filtered = results(abs([results.Kappa]-value) < 1e-12);
        label = selection;
    case 'lv'
        value = str2double(selection);
        filtered = results(abs([results.LV]-value) < 1e-12);
        label = selection;
    case 'smooth coefficient'
        value = str2double(selection);
        filtered = results(abs([results.Smooth]-value) < 1e-12);
        label = selection;
    case 'best lv'
        filtered = selectBestLVPerCombination(results);
        label = 'Automatic';
end
end

function txt = buildPlotTitle(S,caseType)
if strcmpi(caseType,'rigorous'), mode = 'Rigorous'; else, mode = 'Compliant'; end
switch lower(S.PlotType)
    case 'all'
        detail = 'All models';
    case 'best lv'
        detail = 'Best LV by efficiency';
    otherwise
        detail = [S.PlotType ' = ' getPopupSelection(S.popupPlotValue)];
end
txt = ['PLS-DM (' mode ') - ' detail];
end

function best = selectBestLVPerCombination(results)
best = struct([]);
if isempty(results), return; end
used = false(1,numel(results));
for ii = 1:numel(results)
    if used(ii), continue; end
    same = strcmpi({results.Preprocessing},results(ii).Preprocessing) & ...
        abs([results.Kappa]-results(ii).Kappa) < 1e-12 & ...
        abs([results.Smooth]-results(ii).Smooth) < 1e-12;
    idx = find(same);
    used(idx) = true;
    metric = [results(idx).Efficiency];
    if all(isnan(metric)), metric = [results(idx).Sensitivity]; end
    metric(isnan(metric)) = -Inf;
    top = max(metric);
    tied = idx(abs(metric-top) < 1e-12);
    [~,which] = min([results(tied).LV]);
    chosen = results(tied(which));
    if isempty(best), best = chosen; else, best(end+1) = chosen; end
end
end

function results = renumberDisplayModels(results)
for ii = 1:numel(results)
    results(ii).ModelNum = ii;
end
end

function pareto = buildDisplayPareto(results,confstr)
pareto = struct([]);
if isempty(results), return; end
if strcmpi(results(1).CaseType,'rigorous')
    conflev = str2double(confstr); if isnan(conflev), conflev = 0.95; end
    distance = abs([results.Sensitivity]-conflev);
    distance(isnan(distance)) = Inf;
    closest = min(distance);
    keep = abs(distance-closest) <= 10*eps(max(1,abs(conflev)));
else
    sen = [results.Sensitivity]; spec = [results.Specificity];
    keep = false(size(sen));
    for ii = 1:numel(results)
        valid = ~isnan(sen) & ~isnan(spec);
        dominates = valid & sen >= sen(ii) & spec >= spec(ii) & ...
            (sen > sen(ii) | spec > spec(ii));
        keep(ii) = valid(ii) && ~any(dominates);
    end
end
pareto = results(keep);
end

function best = selectBestDisplayModel(results,confstr)
best = struct([]);
if isempty(results), return; end
if strcmpi(results(1).CaseType,'rigorous')
    conflev = str2double(confstr); if isnan(conflev), conflev = 0.95; end
    distance = abs([results.Sensitivity]-conflev);
    distance(isnan(distance)) = Inf;
    closest = min(distance);
    tied = find(abs(distance-closest) <= 10*eps(max(1,abs(conflev))));
    orderData = [[results(tied).LV]' [results(tied).ModelNum]'];
    [dummy,ord] = sortrows(orderData,[1 2]); 
    best = results(tied(ord(1)));
    return;
end
metric = [results.Efficiency];
if all(isnan(metric)), metric = [results.Sensitivity]; end
metric(isnan(metric)) = -Inf;
[~,idx] = max(metric);
best = results(idx);
end

function values = getResultFieldValues(results,fieldName)
values = [];
if isempty(results) || ~isfield(results,fieldName), return; end
values = unique([results.(fieldName)]);
values = sort(values(isfinite(values)));
end

function labels = numericPopupValues(values)
labels = cell(1,numel(values));
for ii = 1:numel(values), labels{ii} = num2str(values(ii),'%.12g'); end
end

function value = getPopupSelection(handle)
items = get(handle,'String'); idx = get(handle,'Value');
if iscell(items), value = items{max(1,min(idx,numel(items)))}; else, value = items; end
end

function prepro = getModelPreprocessing(model,fallback)
if isfield(model,'Preprocessing') && ~isempty(model.Preprocessing)
    prepro = model.Preprocessing;
else
    prepro = fallback;
end
end

function map = buildModelNumMap(results_struct)
map = [];
if isempty(results_struct), return; end
nums = [results_struct.ModelNum];
maxn = max(nums);
map = NaN(1,maxn);
for i=1:length(nums)
    map(nums(i)) = i;
end
end

function row = findListRowForModel(rowMap,modelIndex)
row = 1;
if isempty(rowMap) || isempty(modelIndex), return; end
match = find(rowMap == modelIndex,1,'first');
if ~isempty(match), row = match; end
end

function tf = is_model_efficient(model, pareto_struct)
tf = false;
if isempty(model) || isempty(pareto_struct), return; end
nums = [pareto_struct.ModelNum];
tf = any(nums == model.ModelNum);
end
% Determine whether the model belongs to the displayed priority set.
function tf = is_model_efficient_for_display(model,pareto_struct,confstr)
tf = false;

if isempty(model)
    return;
end

if isfield(model,'CaseType') && strcmpi(model.CaseType,'rigorous')
    
    % If a rigorous efficient-model structure is available, use it.
    if ~isempty(pareto_struct)
        tf = is_model_efficient(model,pareto_struct);
        return;
    end
    
    if isfield(model,'RigorousRecommended')
        tf = logical(model.RigorousRecommended);
    end
    
else
    % Compliant optimization: efficient models belong to the
    % sensitivity-specificity Pareto frontier.
    tf = is_model_efficient(model,pareto_struct);
end
end
%-----------------------

function txt = resultToString(m, isEff)
tag = ' '; if isEff, tag = '*'; end
pre = '';
if isfield(m,'Preprocessing')
    pre = [' | prep=' local_prepro_display_name(m.Preprocessing)];
end
txt = [tag ' #' num2str(m.ModelNum) pre ...
    ' | k=' num2str(m.Kappa) ...
    ' | a=' num2str(m.Smooth) ...
    ' | LV=' num2str(m.LV) ...
    ' | Sens=' num2str(m.Sensitivity,3) ...
    ' | Spec=' num2str(m.Specificity,3)];
if isfield(m,'SensitivityDistance')
    txt = [txt ' | dSens=' num2str(m.SensitivityDistance,3)];
end
end

function value = get_rigorous_value(model,fieldName,fallback)
value = fallback;
if isfield(model,fieldName) && ~isempty(model.(fieldName)) && isfinite(model.(fieldName))
    value = model.(fieldName);
end
end

function idx = find_rigorous_recommended(results)
idx = [];
if isempty(results), return; end
if isfield(results,'RigorousRecommended')
    idx = find([results.RigorousRecommended]);
end
if isempty(idx)
    expected = get_rigorous_value(results(1),'ExpectedSensitivity',0.95);
    distance = abs([results.Sensitivity]-expected); distance(isnan(distance)) = Inf;
    closest = min(distance);
    tied = find(abs(distance-closest) <= 10*eps(max(1,abs(expected))));
    tied = sort_rigorous_indices(results,tied);
    if ~isempty(tied), idx = tied(1); end
end
end

function idx = find_rigorous_within(results,defaultTolerance)
idx = [];
if isempty(results), return; end
if isfield(results,'WithinSensitivityTolerance')
    idx = find([results.WithinSensitivityTolerance]);
else
    expected = get_rigorous_value(results(1),'ExpectedSensitivity',0.95);
    tolerance = get_rigorous_value(results(1),'SensitivityTolerance',defaultTolerance);
    idx = find(abs([results.Sensitivity]-expected) <= tolerance + 10*eps);
end
end

function idx = sort_rigorous_indices(results,idx)
if isempty(idx), return; end
expected = get_rigorous_value(results(1),'ExpectedSensitivity',0.95);
distance = abs([results(idx).Sensitivity]'-expected);
orderData = [distance [results(idx).LV]' [results(idx).ModelNum]'];
[dummy,ord] = sortrows(orderData,[1 2 3]); 
idx = idx(ord);
end

function out = logical_to_yesno(tf)
if tf, out = 'Yes'; else out = 'No'; end
end

function f1 = get_f1_field(m)
if isfield(m,'F1Score')
    f1 = m.F1Score;
elseif isfield(m,'F1')
    f1 = m.F1;
else
    f1 = NaN;
end
end

function idx = find_nearest_model_from_plot(S, x, y)
idx = [];
if isempty(S.CurrentResults), return; end
if strcmpi(S.CurrentResults(1).CaseType,'rigorous')
    xs = 1:length(S.CurrentResults);
    ys = [S.CurrentResults.Sensitivity];
else
    xs = [S.CurrentResults.Specificity];
    ys = [S.CurrentResults.Sensitivity];
end
d = (xs - x).^2 + (ys - y).^2;
[~, idx] = min(d);
end

function plotCompliantInsideAxes(ax, results_struct, pareto_struct)
axes(ax); cla; hold on;
spec_all = [results_struct.Specificity];
sens_all = [results_struct.Sensitivity];
valid_mask = ~isnan(spec_all) & ~isnan(sens_all);
missing_mask = ~valid_mask;
spec_plot = spec_all; spec_plot(missing_mask) = 0;
sens_plot = sens_all; sens_plot(missing_mask) = 0;

ispareto_local = false(1,length(results_struct));
if ~isempty(pareto_struct)
    nums = [pareto_struct.ModelNum];
    allnums = [results_struct.ModelNum];
    for i=1:length(nums)
        ispareto_local = ispareto_local | (allnums == nums(i));
    end
end
inefficient_mask = ~ispareto_local;

if any(inefficient_mask)
    plot(spec_plot(inefficient_mask), sens_plot(inefficient_mask), 'ko', ...
        'MarkerFaceColor',[1 1 1], 'LineWidth',1.2, 'ButtonDownFcn',@local_click_passthrough);
end
if any(ispareto_local)
    x_p = spec_all(ispareto_local);
    y_p = sens_all(ispareto_local);
    [xs, ord] = sort(x_p);
    ys = y_p(ord);
    if numel(xs) >= 2
        plot(xs, ys, 'b-', 'LineWidth',1.5, 'ButtonDownFcn',@local_click_passthrough);
    end
    plot(x_p, y_p, 'bo', 'MarkerFaceColor',[0 0 1], 'LineWidth',1.0, 'ButtonDownFcn',@local_click_passthrough);
end
plot(1,1,'r^','MarkerSize',8,'MarkerFaceColor','r','ButtonDownFcn',@local_click_passthrough);
plot([0 1],[1 1],':','Color',[0.6 0.6 0.6],'LineWidth',1.0,'ButtonDownFcn',@local_click_passthrough);
plot([1 1],[0 1],':','Color',[0.6 0.6 0.6],'LineWidth',1.0,'ButtonDownFcn',@local_click_passthrough);
xlabel('Specificity'); ylabel('Sensitivity');
title('PLS-DM (Compliant)');
grid on; box on; xlim([0 1.02]); ylim([0 1.02]); axis square;
end

function plotRigorousInsideAxes(ax, results_struct,pareto_struct,confstr,tolerance)
axes(ax); cla; hold on;
sens = [results_struct.Sensitivity];
valid_mask = ~isnan(sens);
idx_valid = find(valid_mask);
all_sens = sens(valid_mask);
conflev = str2double(confstr);
if isnan(conflev), conflev = 0.95; end
if nargin < 5 || isempty(tolerance) || ~isfinite(tolerance), tolerance = 0.02; end
lowerLimit = max(0,conflev-tolerance);
upperLimit = min(1,conflev+tolerance);
idx_plot = 1:length(all_sens);
xRight = max(1,length(all_sens)+0.5);
patch([1 xRight xRight 1],[lowerLimit lowerLimit upperLimit upperLimit], ...
    [0.90 0.90 0.90],'EdgeColor','none','Parent',ax);
within = abs(all_sens-conflev) <= tolerance + 10*eps;
recommended = false(size(all_sens));
if ~isempty(all_sens)
    distance = abs(all_sens-conflev);
    closest = min(distance);
    tied = find(abs(distance-closest) <= 10*eps(max(1,abs(conflev))));
    originalIdx = idx_valid(tied);
    ordered = sort_rigorous_indices(results_struct,originalIdx);
    recommended(idx_valid == ordered(1)) = true;
end
outside = ~within;
withinOther = within & ~recommended;
if any(outside)
    plot(idx_plot(outside), all_sens(outside), 'ro', 'MarkerFaceColor',[1 1 1], ...
        'LineWidth',1.2, 'ButtonDownFcn',@local_click_passthrough);
end
if any(withinOther)
    plot(idx_plot(withinOther), all_sens(withinOther), 'bo', 'MarkerFaceColor',[0.25 0.55 0.90], ...
        'LineWidth',1.2, 'ButtonDownFcn',@local_click_passthrough);
end
if any(recommended)
    plot(idx_plot(recommended),all_sens(recommended),'gs','MarkerFaceColor',[0.1 0.65 0.2], ...
        'MarkerSize',8,'LineWidth',1.3,'ButtonDownFcn',@local_click_passthrough);
end
plot([1 xRight],[lowerLimit lowerLimit],'--','Color',[0.45 0.45 0.45],'LineWidth',1.0, ...
    'ButtonDownFcn',@local_click_passthrough);
plot([1 xRight],[upperLimit upperLimit],'--','Color',[0.45 0.45 0.45],'LineWidth',1.0, ...
    'ButtonDownFcn',@local_click_passthrough);
plot([1 xRight], [conflev conflev], 'k-', 'LineWidth',1.2, ...
    'ButtonDownFcn',@local_click_passthrough);
ylim([0 1]); xlim([1 xRight]);
xlabel('Model Index'); ylabel('Sensitivity');
if any(within)
    title(sprintf('PLS-DM (Rigorous): target %.3f, tolerance +/- %.3f',conflev,tolerance));
else
    title(sprintf('PLS-DM (Rigorous): no model within %.3f +/- %.3f',conflev,tolerance));
end
grid on; box on;
end

function local_click_passthrough(src,ev)
fig = ancestor(src,'figure');
end


function PLSDMopt = local_fix_compliance_metrics_for_dashboard(PLSDMopt, ClassTrain)
%LOCAL_FIX_COMPLIANCE_METRICS_FOR_DASHBOARD
% Ensures the compliant optimization cube uses the same sample order used
% inside plsdm_opt: all target samples first, followed by all non-target
% samples. This is important for the advanced results dashboard, especially
% when robust PLS is selected and ClassTrain is not originally grouped.
if nargin < 2 || isempty(ClassTrain) || ~isstruct(PLSDMopt)
    return;
end

ClassTrain = ClassTrain(:);
nT  = sum(ClassTrain == 1);
nNT = sum(ClassTrain ~= 1);
if nT < 1 || nNT < 1
    return;
end

Gordered = [ones(nT,1); 2*ones(nNT,1)];
fields = {'ComplianceRAWmodels','ComplianceCenteredmodel', ...
    'ComplianceScaledmodel','ComplianceAutoscaledmodel'};

for ff = 1:numel(fields)
    fname = fields{ff};
    if ~isfield(PLSDMopt,fname) || isempty(PLSDMopt.(fname)) || ~iscell(PLSDMopt.(fname))
        continue;
    end
    
    cube = PLSDMopt.(fname);
    for ii = 1:numel(cube)
        res = cube{ii};
        if isempty(res) || ~isstruct(res)
            continue;
        end
        
        nRes = local_result_length(res);
        if nRes ~= numel(Gordered)
            cube{ii} = res;
            continue;
        end
        
        res.Gtrue     = Gordered;
        res.Gtrue_bin = (Gordered == 1);
        
        if isfield(res,'Gpred_bin') && ~isempty(res.Gpred_bin)
            pred = logical(res.Gpred_bin(:));
        else
            pred = local_predict_from_norm_fields(res);
        end
        
        if numel(pred) == numel(Gordered)
            [res.TP,res.TN,res.FP,res.FN, ...
                res.sensitivity,res.specificity,res.precision, ...
                res.accuracy,res.f1score,res.efficiency] = ...
                local_recompute_binary_metrics(pred, res.Gtrue_bin);
        end
        
        cube{ii} = res;
    end
    PLSDMopt.(fname) = cube;
end
end

function nRes = local_result_length(res)
nRes = NaN;
if isfield(res,'Gpred_bin') && ~isempty(res.Gpred_bin)
    nRes = numel(res.Gpred_bin);
elseif isfield(res,'Qnorm') && ~isempty(res.Qnorm)
    nRes = numel(res.Qnorm);
elseif isfield(res,'Gtrue') && ~isempty(res.Gtrue)
    nRes = numel(res.Gtrue);
end
end

function pred = local_predict_from_norm_fields(res)
pred = [];
if isfield(res,'Qnorm') && isfield(res,'logf_norm') && ...
        ~isempty(res.Qnorm) && ~isempty(res.logf_norm)
    pred = (res.Qnorm(:) <= 1) & (res.logf_norm(:) <= 1);
end
end

function [TP,TN,FP,FN,sens,spec,prec,acc,f1,eff] = local_recompute_binary_metrics(pred, truth)
pred  = logical(pred(:));
truth = logical(truth(:));

TP = sum(pred & truth);
FN = sum(~pred & truth);
TN = sum(~pred & ~truth);
FP = sum(pred & ~truth);

sens = TP / max(TP + FN, eps);
spec = TN / max(TN + FP, eps);
prec = TP / max(TP + FP, eps);
acc  = (TP + TN) / max(numel(truth), 1);

if (prec + sens) > 0
    f1 = 2 * (prec * sens) / (prec + sens);
else
    f1 = NaN;
end

if isfinite(sens) && isfinite(spec)
    eff = sqrt(max(sens,0) * max(spec,0));
else
    eff = NaN;
end
end

function PLSDMopt = local_add_robust_outlier_report(PLSDMopt,rob)
if nargin < 2 || isempty(rob)
    rob = isfield(PLSDMopt,'robust') && isequal(PLSDMopt.robust,1);
end
if isempty(PLSDMopt) || ~isstruct(PLSDMopt) || ~rob
    return;
end

report = local_empty_outlier_report();
defs = { ...
    'raw',        'RAWmodels',        'results_structRaw'; ...
    'centered',   'Centeredmodels',   'results_structCentered'; ...
    'scale',      'Scaledmodels',     'results_structScaled'; ...
    'autoscale',  'Autoscaledmodels', 'results_structAutoscaled'};

targetRows = local_get_target_sample_rows(PLSDMopt);

for dd = 1:size(defs,1)
    preproName = defs{dd,1};
    modelField = defs{dd,2};
    resultField = defs{dd,3};
    if ~isfield(PLSDMopt,modelField) || isempty(PLSDMopt.(modelField))
        continue;
    end
    
    models = PLSDMopt.(modelField);
    for kk = 1:size(models,1)
        for ss = 1:size(models,2)
            M = models{kk,ss};
            if isempty(M) || ~isstruct(M) || ~isfield(M,'Qresid') || ~isfield(M,'f_cv')
                continue;
            end
            
            nEval = size(M.Qresid,1);
            if isempty(targetRows)
                sampleRows = (1:nEval)';
            else
                sampleRows = targetRows(:);
                if numel(sampleRows) > nEval
                    sampleRows = sampleRows(1:nEval);
                elseif numel(sampleRows) < nEval
                    sampleRows = (1:nEval)';
                end
            end
            
            nLV = min(size(M.Qresid,2),size(M.f_cv,2));
            for lv = 1:nLV
                Q = M.Qresid(:,lv);
                F = M.f_cv(:,lv);
                QlimO = local_get_model_limit_vector(M,'QlimitO_cv','QlimsO_perLV',lv,nEval);
                FlimO = local_get_model_limit_vector(M,'flimitO_cv','flimitsO_perLV',lv,nEval);
                if isempty(QlimO) || isempty(FlimO)
                    continue;
                end
                
                badQ = isfinite(Q) & isfinite(QlimO) & Q > QlimO;
                badF = isfinite(F) & isfinite(FlimO) & F < FlimO;
                idxOut = find(badQ | badF);
                for ii = 1:numel(idxOut)
                    rr = idxOut(ii);
                    entry = local_empty_outlier_entry();
                    entry.TargetClass = local_get_target_class_value(PLSDMopt);
                    entry.Sample = sampleRows(rr);
                    entry.EvaluationIndex = rr;
                    entry.Preprocessing = preproName;
                    entry.Kappa = local_get_vector_value(PLSDMopt,{'kappa_values','kappa'},kk);
                    entry.Smooth = local_get_vector_value(PLSDMopt,{'SmoothValues','smooth_coef'},ss);
                    entry.LV = lv;
                    entry.KIndex = kk;
                    entry.SIndex = ss;
                    entry.LVIndex = lv;
                    entry.ModelNum = local_lookup_model_num(PLSDMopt,resultField,kk,ss,lv);
                    entry.Q = Q(rr);
                    entry.F = F(rr);
                    entry.QlimitOutlier = QlimO(rr);
                    entry.FlimitOutlier = FlimO(rr);
                    entry.Rule = local_outlier_rule_text(badQ(rr),badF(rr));
                    report(end+1) = entry;
                end
            end
        end
    end
end

PLSDMopt.RobustOutlierReport = report;
PLSDMopt.RobustOutlierSummary = local_build_outlier_summary(report);
end

function report = local_empty_outlier_report()
report = struct('TargetClass',{},'Sample',{},'EvaluationIndex',{}, ...
    'Preprocessing',{},'Kappa',{},'Smooth',{},'LV',{}, ...
    'KIndex',{},'SIndex',{},'LVIndex',{},'ModelNum',{}, ...
    'Q',{},'F',{},'QlimitOutlier',{},'FlimitOutlier',{},'Rule',{});
end

function entry = local_empty_outlier_entry()
entry = struct('TargetClass',NaN,'Sample',NaN,'EvaluationIndex',NaN, ...
    'Preprocessing','','Kappa',NaN,'Smooth',NaN,'LV',NaN, ...
    'KIndex',NaN,'SIndex',NaN,'LVIndex',NaN,'ModelNum',NaN, ...
    'Q',NaN,'F',NaN,'QlimitOutlier',NaN,'FlimitOutlier',NaN,'Rule','');
end

function rows = local_get_target_sample_rows(PLSDMopt)
rows = [];
if isfield(PLSDMopt,'OriginalClassTrain') && isfield(PLSDMopt,'TargetClass') && ...
        ~isempty(PLSDMopt.OriginalClassTrain) && ~isempty(PLSDMopt.TargetClass)
    rows = find(PLSDMopt.OriginalClassTrain(:) == PLSDMopt.TargetClass);
elseif isfield(PLSDMopt,'ClassTrain') && ~isempty(PLSDMopt.ClassTrain)
    rows = find(PLSDMopt.ClassTrain(:) == 1);
end
end

function targetClass = local_get_target_class_value(PLSDMopt)
targetClass = NaN;
if isfield(PLSDMopt,'TargetClass') && ~isempty(PLSDMopt.TargetClass)
    targetClass = PLSDMopt.TargetClass;
end
end

function value = local_get_vector_value(S,fieldNames,idx)
value = NaN;
for ii = 1:numel(fieldNames)
    fn = fieldNames{ii};
    if isfield(S,fn) && numel(S.(fn)) >= idx
        tmp = S.(fn);
        value = tmp(idx);
        return;
    end
end
end

function v = local_get_model_limit_vector(M,fieldCv,fieldPerLv,lv,n)
v = [];
if isfield(M,fieldCv) && ~isempty(M.(fieldCv)) && size(M.(fieldCv),2) >= lv
    tmp = M.(fieldCv);
    v = tmp(:,lv);
elseif isfield(M,fieldPerLv) && numel(M.(fieldPerLv)) >= lv && ~isempty(M.(fieldPerLv){lv})
    tmp = M.(fieldPerLv){lv};
    v = repmat(mean(tmp(:)),n,1);
end

if isempty(v)
    return;
end
v = v(:);
if numel(v) == 1
    v = repmat(v,n,1);
elseif numel(v) > n
    v = v(1:n);
elseif numel(v) < n
    v(end+1:n,1) = v(end);
end
end

function modelNum = local_lookup_model_num(PLSDMopt,resultField,kk,ss,lv)
modelNum = NaN;
if ~isfield(PLSDMopt,resultField) || isempty(PLSDMopt.(resultField))
    return;
end
results = PLSDMopt.(resultField);
for ii = 1:numel(results)
    r = results(ii);
    if isfield(r,'KIndex') && isfield(r,'SIndex') && isfield(r,'LVIndex') && ...
            r.KIndex == kk && r.SIndex == ss && r.LVIndex == lv
        modelNum = r.ModelNum;
        return;
    end
end
end

function txt = local_outlier_rule_text(badQ,badF)
if badQ && badF
    txt = 'Q>QlimitO & F<FlimitO';
elseif badQ
    txt = 'Q>QlimitO';
else
    txt = 'F<FlimitO';
end
end

function summary = local_build_outlier_summary(report)
summary = struct('Count',0,'UniqueSamples',[],'UniqueSampleCount',0);
if isempty(report)
    return;
end
samples = [report.Sample];
summary.Count = numel(report);
summary.UniqueSamples = unique(samples(:))';
summary.UniqueSampleCount = numel(summary.UniqueSamples);
end

function local_show_outlier_report_window(models)
allReport = local_empty_outlier_report(); efficientByRow = []; robustFound = false;
for ii = 1:numel(models)
    M = models{ii};
    if isempty(M) || ~isstruct(M) || ~isfield(M,'robust') || ~isequal(M.robust,1), continue; end
    robustFound = true; report = local_empty_outlier_report();
    if isfield(M,'RobustOutlierReport'), report = M.RobustOutlierReport; end
    efficientNums = local_get_efficient_model_nums(M);
    for jj = 1:numel(report)
        allReport(end+1) = report(jj); efficientByRow(end+1,1) = any(efficientNums == report(jj).ModelNum);
    end
end
if ~robustFound
    errordlg('The outliers report is available only for Robust PLS optimization results.','Outliers report'); return;
end
f = figure('Name','PLS-DM optimization - Outliers report','NumberTitle','off','MenuBar','none','Toolbar','none', ...
    'Color',[0.94 0.95 0.98],'Units','normalized','Position',[0.08 0.10 0.84 0.78]);
uicontrol('Parent',f,'Style','text','String','Model','Units','normalized','Position',[0.025 0.925 0.08 0.035], ...
    'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left','FontWeight','bold');
labels = {'All models'}; keys = [NaN NaN];
if ~isempty(allReport)
    pairs = unique([[allReport.TargetClass]' [allReport.ModelNum]'],'rows');
    for ii = 1:size(pairs,1)
        labels{end+1} = sprintf('Class %g - Model %g',pairs(ii,1),pairs(ii,2)); keys(end+1,:) = pairs(ii,:);
    end
end
popup = uicontrol('Parent',f,'Style','popupmenu','String',labels,'Value',1,'Units','normalized', ...
    'Position',[0.105 0.925 0.32 0.045],'BackgroundColor','w','UserData',keys);
summaryText = uicontrol('Parent',f,'Style','text','String','','Units','normalized','Position',[0.45 0.915 0.52 0.055], ...
    'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left');
columnNames = {'Target class','Sample','Target index','Preprocessing','Model','Kappa','Smooth','LV','Q','f', ...
    'Q outlier limit','f outlier limit','Rule','Recommended/Pareto'};
tbl = uitable('Parent',f,'Units','normalized','Position',[0.025 0.08 0.95 0.82], ...
    'Data',cell(0,numel(columnNames)),'ColumnName',columnNames,'RowName',[]);
uicontrol('Parent',f,'Style','text','String','Sample is the original Xtrain row; Target index is its row within the target-class matrix.', ...
    'Units','normalized','Position',[0.025 0.02 0.95 0.035],'BackgroundColor',get(f,'Color'),'HorizontalAlignment','left');
state.report=allReport; state.efficient=efficientByRow; state.popup=popup; state.table=tbl; state.summary=summaryText;
guidata(f,state); set(popup,'Callback',@(src,evt)local_refresh_outlier_report_window(f)); local_refresh_outlier_report_window(f);
end

function local_refresh_outlier_report_window(f)
if isempty(f) || ~ishandle(f), return; end
state=guidata(f); report=state.report; use=true(numel(report),1); value=get(state.popup,'Value'); keys=get(state.popup,'UserData');
if value>1 && size(keys,1)>=value, use=([report.TargetClass]'==keys(value,1)) & ([report.ModelNum]'==keys(value,2)); end
idx=find(use); data=cell(numel(idx),14);
for rr=1:numel(idx)
    e=report(idx(rr)); data(rr,:)={e.TargetClass,e.Sample,e.EvaluationIndex,local_prepro_display_name(e.Preprocessing), ...
        e.ModelNum,e.Kappa,e.Smooth,e.LV,e.Q,e.F,e.QlimitOutlier,e.FlimitOutlier,e.Rule,local_yes_no(state.efficient(idx(rr)))};
end
set(state.table,'Data',data);
if isempty(report), set(state.summary,'String','No robust outliers were detected in the evaluated models.');
else, set(state.summary,'String',sprintf('Rows: %d    Unique samples: %d',numel(idx),numel(unique([report(idx).Sample])))); end
end

function s=local_yes_no(tf)
if tf, s='Yes'; else, s='No'; end
end

function local_print_robust_outlier_report(PLSDMopt)
targetClass = local_get_target_class_value(PLSDMopt);
gammaValue = local_get_gamma_value(PLSDMopt);
report = local_empty_outlier_report();
if isfield(PLSDMopt,'RobustOutlierReport')
    report = PLSDMopt.RobustOutlierReport;
end
efficientNums = local_get_efficient_model_nums(PLSDMopt);

local_print_report_rule();
fprintf('OUTLIER SAMPLES REPORT DURING PLS-DM OPTIMIZATION\n');
local_print_report_rule();
if isnan(targetClass)
    fprintf('Target class       : n/a\n');
else
    fprintf('Target class       : %g\n',targetClass);
end
if isnan(gammaValue)
    fprintf('Gamma              : n/a\n');
else
    fprintf('Gamma              : %.6g\n',gammaValue);
end

if isempty(report)
    fprintf('Outlier rows       : 0\n');
    fprintf('Unique samples     : 0\n');
    fprintf('Status             : No robust outliers detected for the evaluated candidates.\n');
    local_print_report_rule();
    fprintf('\n');
    return;
end

isEffOut = false(size(report));
for ii = 1:numel(report)
    isEffOut(ii) = any(efficientNums == report(ii).ModelNum);
end
efficientAffected = 0;
if any(isEffOut)
    efficientAffected = numel(unique([report(isEffOut).ModelNum]));
end

fprintf('Outlier rows       : %d\n',numel(report));
fprintf('Unique samples     : %d\n',numel(unique([report.Sample])));
fprintf('Recommended/Pareto affected : %d model(s)\n',efficientAffected);
local_print_report_rule();

orderedReport = [report(isEffOut) report(~isEffOut)];
fprintf('ROBUST OUTLIER TABLE\n');
if any(isEffOut)
    fprintf('Rows from recommended/Pareto models are listed first and marked YES.\n');
end
local_print_outlier_rows(orderedReport,efficientNums);
if any(isEffOut)
    fprintf('\n*** ATTENTION: recommended/Pareto models present outliers. Review the first rows before selecting the final model. ***\n');
end
fprintf('\nColumn notes:\n');
fprintf('  XtrainRow = row number of the sample in the original Xtrain matrix.\n');
fprintf('  TargetIdx = row number inside the target-class matrix used during cross-validation.\n');
local_print_report_rule();
fprintf('\n');
end

function local_print_nonrobust_outlier_report(PLSDMopt)
targetClass = local_get_target_class_value(PLSDMopt);
local_print_report_rule();
fprintf('OUTLIER SAMPLES REPORT DURING PLS-DM OPTIMIZATION\n');
local_print_report_rule();
if isnan(targetClass)
    fprintf('Target class       : n/a\n');
else
    fprintf('Target class       : %g\n',targetClass);
end
fprintf('Gamma              : n/a\n');
fprintf('Outlier rows       : n/a\n');
fprintf('Unique samples     : n/a\n');
fprintf('Status             : Robust outlier screening is available only for Robust PLS optimization runs.\n');
local_print_report_rule();
fprintf('\n');
end

function gammaValue = local_get_gamma_value(PLSDMopt)
gammaValue = NaN;
if isfield(PLSDMopt,'gama') && ~isempty(PLSDMopt.gama)
    gammaValue = PLSDMopt.gama;
elseif isfield(PLSDMopt,'gamma') && ~isempty(PLSDMopt.gamma)
    gammaValue = PLSDMopt.gamma;
end
end

function nums = local_get_efficient_model_nums(PLSDMopt)
nums = [];
fields = {'pareto_structRaw','pareto_structCentered','pareto_structScaled','pareto_structAutoscaled'};
for ii = 1:numel(fields)
    fn = fields{ii};
    if isfield(PLSDMopt,fn) && ~isempty(PLSDMopt.(fn)) && isfield(PLSDMopt.(fn),'ModelNum')
        nums = [nums [PLSDMopt.(fn).ModelNum]];
    end
end
nums = unique(nums);
end

function local_print_outlier_rows(report,efficientNums)
if nargin < 2
    efficientNums = [];
end
headerEvery = 10;
local_print_outlier_table_header();
for ii = 1:numel(report)
    if ii > 1 && mod(ii-1,headerEvery) == 0
        local_print_outlier_table_header();
    end
    r = report(ii);
    if any(efficientNums == r.ModelNum)
        effText = 'YES';
    else
        effText = 'NO';
    end
    fprintf('%-10g %-11g %-12s %-8g %-10.5g %-4g %-7g %-10s %-12.5g %-12.5g %-12.5g %-12.5g %s\n', ...
        r.Sample,r.EvaluationIndex,r.Preprocessing,r.Kappa,r.Smooth,r.LV,r.ModelNum, ...
        effText,r.Q,r.F,r.QlimitOutlier,r.FlimitOutlier,r.Rule);
end
local_print_table_rule();
end

function local_print_outlier_table_header()
local_print_table_rule();
fprintf('%-10s %-11s %-12s %-8s %-10s %-4s %-7s %-10s %-12s %-12s %-12s %-12s %s\n', ...
    'XtrainRow','TargetIdx','Prepro','Kappa','Smooth','LV','Model','Priority','Q','F','QlimitO','FlimitO','Rule');
fprintf('%-10s %-11s %-12s %-8s %-10s %-4s %-7s %-10s %-12s %-12s %-12s %-12s %s\n', ...
    'Sample row','CV row','method','k-NN','PFM alpha','PCs','#','Pareto','Q resid.','PFM dens.','Q out lim','F out lim','flag criterion');
local_print_table_rule();
end

function local_print_report_rule()
fprintf('%s\n',repmat('=',1,120));
end

function local_print_table_rule()
fprintf('%s\n',repmat('-',1,150));
end


function write_results_csv(filename, results_struct)
fid = fopen(filename,'w');
if fid == -1
    error('Unable to open file for writing.');
end
fprintf(fid,['ModelNum,Kappa,Smooth,LV,CaseType,Sensitivity,Specificity,Precision,Accuracy,F1Score,Efficiency,' ...
    'ExpectedSensitivity,SensitivityTolerance,ToleranceLowerLimit,ToleranceUpperLimit,' ...
    'SensitivityDistance,WithinSensitivityTolerance,RigorousRecommended\n']);
for i=1:length(results_struct)
    r = results_struct(i);
    expected = local_optional_numeric(r,'ExpectedSensitivity');
    tolerance = local_optional_numeric(r,'SensitivityTolerance');
    lowerLimit = local_optional_numeric(r,'ToleranceLowerLimit');
    upperLimit = local_optional_numeric(r,'ToleranceUpperLimit');
    distance = local_optional_numeric(r,'SensitivityDistance');
    within = local_optional_numeric(r,'WithinSensitivityTolerance');
    recommended = local_optional_numeric(r,'RigorousRecommended');
    fprintf(fid,['%d,%d,%.12g,%d,%s,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,' ...
        '%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g\n'], ...
        r.ModelNum, r.Kappa, r.Smooth, r.LV, r.CaseType, ...
        r.Sensitivity, r.Specificity, r.Precision, r.Accuracy, get_f1_field(r), r.Efficiency, ...
        expected,tolerance,lowerLimit,upperLimit,distance,within,recommended);
end
fclose(fid);
end

function value = local_optional_numeric(s,fieldName)
value = NaN;
if isfield(s,fieldName) && ~isempty(s.(fieldName)), value = double(s.(fieldName)); end
end
