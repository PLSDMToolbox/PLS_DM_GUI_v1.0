%
function plsdm_gui_step_pca_exploratory()
% PLS-DM Toolbox GUI - Step: Exploratory PCA
% Main features:
%   - Load data from example or workspace
%   - PCA on X
%   - Single scores plot with 2D or 3D mode
%   - Loadings vs x-axis for selected PCs
%   - Hotelling T^2 vs Q residual plot
%   - Scree plot + cumulative variance
%   - 95% confidence limits
%   - Class-colored visualization
%   - Click report for Scores 2D and T^2 vs Q
%   - Auxiliary figure with sample spectrum, class mean and residual
%   - Export PCA results to workspace
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    GUI_VERSION = 'PLS-DM Toolbox GUI v1.0';
    scr = get(0,'ScreenSize');
    fig = figure('Name',['PLS-DM Toolbox - Exploratory PCA ',GUI_VERSION ], ...
                 'NumberTitle','off', ...
                 'MenuBar','none', ...
                 'Toolbar','none', ...
                 'Color',[0.95 0.93 0.97], ...
                 'Units','pixels', ...
                 'Position',[70 40 min(1360,scr(3)-100) min(780,scr(4)-120)]);

    S = struct();
    S.X = [];
    S.class = [];
    S.Xall = []; S.classAll = []; S.sampleIncluded = []; S.originalRows = []; S.sampleNamesAll = {};
    S.axis = [];
    S.sampleNames = {};
    S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
    S.classColors = [0 0.4470 0.7410; ...
                     0.8500 0.3250 0.0980; ...
                     0.9290 0.6940 0.1250; ...
                     0.4940 0.1840 0.5560; ...
                     0.4660 0.6740 0.1880; ...
                     0.3010 0.7450 0.9330; ...
                     0.6350 0.0780 0.1840];
    S.PCA = [];
    S.PCAModels = struct([]);
    S.PCAMode = 'Conjoint';
    S.ActiveClass = [];
    S.ScoreViewT = [];
    S.ScoreViewClass = [];
    S.ScoreViewSampleIdx = [];
    S.ActiveSampleIdx = [];
    S.scorePointMap2D = [];
    S.t2qPointMap = [];
    S.preprocessing = 'Center';

    % -----------------------------
    themeDark  = [0.33 0.18 0.46];
    themeLight = [0.95 0.93 0.97];

    S.pnlHeader = uipanel('Parent',fig, ...
                        'Units','normalized','Position',[0.01 0.88 0.98 0.10], ...
                        'BackgroundColor',themeDark, ...
                        'BorderType','none');

    uicontrol('Parent',S.pnlHeader,'Style','text','String','Exploratory PCA ', ...
              'Units','normalized','Position',[0.025 0.45 0.60 0.42], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[1 1 1], ...
              'HorizontalAlignment','left','FontSize',17,'FontWeight','bold');

    uicontrol('Parent',S.pnlHeader,'Style','text', ...
              'String','Explore score patterns, loadings, T^2/Q diagnostics and explained variance before PLS-DM modeling', ...
              'Units','normalized','Position',[0.025 0.12 0.86 0.26], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[0.92 0.92 0.92], ...
              'HorizontalAlignment','left','FontSize',10);

    uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Help', ...
              'Units','normalized','Position',[0.88 0.25 0.09 0.50], ...
              'BackgroundColor',[1 1 1], ...
              'ForegroundColor',themeDark, ...
              'FontWeight','bold', ...
              'TooltipString','Open detailed help for the Exploratory PCA module.', ...
              'Callback',@onHelp);

    S.btnDataInfo = uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Add data info...', ...
              'Units','normalized','Position',[0.72 0.25 0.145 0.50], ...
              'BackgroundColor',[1 1 1],'ForegroundColor',themeDark,'FontWeight','bold', ...
              'Enable','off','TooltipString','Add optional axis, class, and sample display names.', ...
              'Callback',@onDataInfo);

    % -------------------------------------------------
    % Control panel
    % -------------------------------------------------
    S.pnlCtrl = uipanel('Parent',fig,'Title','Control', ...
                        'Units','normalized','Position',[0.01 0.02 0.26 0.84], ...
                        'BackgroundColor',[0.95 0.93 0.97], ...
                        'FontWeight','bold');
    S.btnExclude = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Exclude...', ...
              'Units','normalized','Position',[0.69 0.90 0.22 0.045], ...
              'FontWeight','bold','Enable','off','Callback',@onExcludeSamples);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data', ...
              'Units','normalized','Position',[0.05 0.94 0.25 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left','FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Load example', ...
              'Units','normalized','Position',[0.05 0.90 0.27 0.045], ...
              'TooltipString','Load simulated spectral data with three classes for testing the PCA interface.', ...
              'Callback',@onLoadExample);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Import workspace', ...
              'Units','normalized','Position',[0.35 0.90 0.31 0.045], ...
              'TooltipString','Import X and optional class/x-axis vectors from the MATLAB workspace.', ...
              'Callback',@onImportWorkspace);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PCA settings', ...
              'Units','normalized','Position',[0.05 0.855 0.30 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left','FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PCA model', ...
              'Units','normalized','Position',[0.05 0.815 0.26 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97],'HorizontalAlignment','left');
    S.popupPCAModel = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'PCA conjoint'}, ...
              'Units','normalized','Position',[0.34 0.812 0.56 0.04], ...
              'BackgroundColor',[1 1 1],'Value',1, ...
              'TooltipString','Fit one PCA to all samples or a PCA for one selected class.', ...
              'Callback',@onPCAModelChanged);

    S.chkProjectRemaining = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','Project others', ...
              'Units','normalized','Position',[0.34 0.762 0.56 0.04], ...
              'BackgroundColor',[0.95 0.93 0.97],'Value',0,'Enable','off', ...
              'TooltipString','Project other classes using the preprocessing parameters and loadings of the selected class model.', ...
              'Callback',@onPCASettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Preprocessing', ...
              'Units','normalized','Position',[0.05 0.715 0.26 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left');
    S.popupPreprocess = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Center','Scale','Autoscale','Range scale','Raw'}, ...
              'Units','normalized','Position',[0.34 0.712 0.36 0.04], ...
              'BackgroundColor',[1 1 1], 'Value',1, ...
              'TooltipString','Common preprocessing method. Center is the default; Raw applies no preprocessing.', ...
              'Callback',@onPCASettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Max PCs', ...
              'Units','normalized','Position',[0.05 0.665 0.28 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left');
    S.edA = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','10', ...
              'Units','normalized','Position',[0.34 0.662 0.12 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Maximum number of principal components calculated by SVD.', ...
              'Callback',@onPCASettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text', ...
          'String','T2/Q conf. (%)', ...
          'Units','normalized', ...
          'Position',[0.50 0.665 0.28 0.03], ...
          'BackgroundColor',[0.95 0.93 0.97], ...
          'HorizontalAlignment','left');

S.edConf = uicontrol('Parent',S.pnlCtrl,'Style','edit', ...
          'String','95', ...
          'Units','normalized', ...
          'Position',[0.80 0.662 0.10 0.04], ...
          'BackgroundColor',[1 1 1], ...
          'TooltipString','Confidence level used for Hotelling T^2 and Q residual limits.', ...
          'Callback',@onPCASettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PC opt', ...
              'Units','normalized','Position',[0.05 0.615 0.16 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left');
    S.popupPCOpt = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'run PCA'}, ...
              'Units','normalized','Position',[0.20 0.612 0.14 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Number of PCs used for T2, Q residuals, reconstruction and interactive reports.', ...
              'Callback',@onPCOptChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','PC opt BS', ...
              'Units','normalized','Position',[0.36 0.612 0.16 0.04], ...
              'TooltipString','Select the optimal number of PCs using the Broken Stick criterion.', ...
              'Callback',@onBrokenStick);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Scores mode', ...
              'Units','normalized','Position',[0.54 0.615 0.20 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left','FontWeight','bold');
    S.popupMode = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'2D','3D'}, ...
              'Units','normalized','Position',[0.75 0.612 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Choose whether the scores plot is shown as PC X vs PC Y or as a 3D score plot.', ...
              'Callback',@onViewSettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PC X', ...
              'Units','normalized','Position',[0.05 0.555 0.10 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97]);
    S.popupPCX = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'1','2','3','4','5','6','7','8','9','10'}, ...
              'Units','normalized','Position',[0.16 0.552 0.16 0.04], ...
              'BackgroundColor',[1 1 1], 'Value',1, ...
              'TooltipString','Select the PC used as the x-axis score component.', ...
              'Callback',@onViewSettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PC Y', ...
              'Units','normalized','Position',[0.37 0.555 0.10 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97]);
    S.popupPCY = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'1','2','3','4','5','6','7','8','9','10'}, ...
              'Units','normalized','Position',[0.48 0.552 0.16 0.04], ...
              'BackgroundColor',[1 1 1], 'Value',2, ...
              'TooltipString','Select the PC used as the y-axis score component.', ...
              'Callback',@onViewSettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','PC Z', ...
              'Units','normalized','Position',[0.69 0.555 0.10 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97]);
    S.popupPCZ = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'1','2','3','4','5','6','7','8','9','10'}, ...
              'Units','normalized','Position',[0.80 0.552 0.10 0.04], ...
              'BackgroundColor',[1 1 1], 'Value',3, ...
              'TooltipString','Select the PC used as the z-axis score component for 3D mode.', ...
              'Callback',@onViewSettingsChanged);

    S.chkLabels = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','Show sample labels', ...
              'Units','normalized','Position',[0.05 0.495 0.45 0.04], ...
              'BackgroundColor',[0.95 0.93 0.97], 'Value',0, ...
              'TooltipString','Display sample indices next to points in the 2D scores plot.', ...
              'Callback',@onViewSettingsChanged);

    S.chkEllipse = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','Show 95% score ellipse', ...
              'Units','normalized','Position',[0.50 0.495 0.42 0.04], ...
              'BackgroundColor',[0.95 0.93 0.97], 'Value',1, ...
              'TooltipString','Draw an approximate 95% score ellipse in the 2D scores plot.', ...
              'Callback',@onViewSettingsChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Run PCA', ...
              'Units','normalized','Position',[0.05 0.425 0.19 0.055], ...
              'FontWeight','bold','TooltipString','Compute PCA using the current centering/scaling settings and selected number of PCs.', ...
              'Callback',@onRunPCA);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export PCA', ...
              'Units','normalized','Position',[0.27 0.425 0.20 0.055], ...
              'TooltipString','Export PCAmodel, scores, loadings, explained variance, T2 and Q values to the workspace.', ...
              'Callback',@onExportPCA);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export plots', ...
              'Units','normalized','Position',[0.50 0.425 0.20 0.055], ...
              'TooltipString','Open a standalone figure containing the four PCA plots for saving or editing.', ...
              'Callback',@onExportPlots);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','See data', ...
              'Units','normalized','Position',[0.73 0.425 0.19 0.055], ...
              'TooltipString','Open a standalone figure showing data profiles and class means.', ...
              'Callback',@onSeeData);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Summary', ...
              'Units','normalized','Position',[0.05 0.38 0.20 0.03], ...
              'BackgroundColor',[0.95 0.93 0.97], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.txtInfo = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'Units','normalized','Position',[0.05 0.03 0.87 0.34], ...
              'BackgroundColor',[1 1 1], ...
              'String',{'Load data to begin.'}, 'Max',2,'Min',0);

    % -------------------------------------------------
    % Visualization panel
    % -------------------------------------------------
    S.pnlView = uipanel('Parent',fig,'Title','PCA visualization', ...
                        'Units','normalized','Position',[0.28 0.02 0.71 0.84], ...
                        'BackgroundColor',[0.95 0.93 0.97], ...
                        'FontWeight','bold');

    S.ax1 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.06 0.56 0.40 0.34]);
    title(S.ax1,'Scores plot'); box(S.ax1,'on');

    S.ax2 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.56 0.37 0.34]);
    title(S.ax2,'Loadings vs x-axis'); box(S.ax2,'on');

    S.ax3 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.06 0.12 0.40 0.30]);
    title(S.ax3,'Hotelling T^2 vs Q'); box(S.ax3,'on');

    S.ax4 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.12 0.37 0.30]);
    title(S.ax4,'Scree + cumulative variance'); box(S.ax4,'on');

    guidata(fig,S);

    % ============================================================
    % Callbacks
    % ============================================================
    function onHelp(hObj,ev)
        helpText = {
% 'PLS-DM TOOLBOX - EXPLORATORY PCA HELP'
' '
'PURPOSE OF THIS MODULE'
' '
'This interface performs exploratory Principal Component Analysis (PCA) before PLS-DM modeling.'
'It is intended to help the user inspect global structure, class separation, trends, potential outliers,'
'influential samples, relevant variables and the number of meaningful components.'
' '
'GENERAL WORKFLOW'
' '
'1. Load data'
'   - Use Load example to test the interface with simulated spectral data.'
'   - Use Import workspace to import your own variables from MATLAB.'
'   - The input variables are:'
'       X      : data matrix, with samples in rows and variables/wavelengths in columns.'
'       class  : optional class vector, with one label per sample.'
'                If omitted, every sample is assigned to class 1 for display.'
'       axis   : optional x-axis vector, e.g. wavelength, wavenumber or variable index.'
' '
'2. Choose PCA settings'
'   - PCA model: Conjoint or one model fitted to a selected class.'
'   - The PCA model menu directly identifies the class used by a class-specific model,'
'     T^2/Q and explained-variance plots; there is no separate Active class menu.'
'   - Project others: for a single-class PCA, preprocesses other'
'     classes with the selected class parameters and projects them on its loadings.'
'   - Preprocessing: Center (default), Scale, Autoscale, Range scale or Raw.'
'   - Max PCs: maximum number of principal components calculated by SVD.'
'   - PC opt: number of PCs used in T2/Q diagnostics after PCA is calculated.'
'   - PC opt BS: applies the Broken Stick criterion and selects its suggested PC opt.'
'   - A later manual choice in PC opt overrides the Broken Stick suggestion.'
'   - Confidence (%): confidence level for Hotelling T^2 and Q residual limits.'
' '
'3. Run PCA'
'   - Click Run PCA to calculate scores, loadings, explained variance, T^2 and Q residuals.'
'   - The PCA here is calculated by singular value decomposition (SVD), which is numerically stable.'
' '
'4. Inspect the plots'
'   - Scores plot: shows samples projected on selected PCs.'
'   - Loadings vs x-axis: shows the contribution of variables to the selected PCs.'
'   - Hotelling T^2 vs Q: supports detection of high-leverage samples and residual outliers.'
'   - Scree + cumulative variance: shows individual and cumulative explained variance.'
' '
'5. Export results'
'   - Export PCA sends one structure, PCAmodel, to the workspace.'
'   - Export plots opens the four graphs in a standalone MATLAB figure.'
' '
'SCORES PLOT'
' '
'- The scores are the coordinates of the samples in the PCA space.'
'- Samples close to each other have similar multivariate profiles.'
'- Class separation in the scores plot may indicate systematic differences among classes.'
'- In 2D mode, click on a point to obtain a detailed sample report.'
'- In 3D mode, the plot is useful for visual inspection of three PCs at once.'
' '
'PC SELECTION'
' '
'- Broken Stick compares each observed explained-variance proportion with the expected'
'  proportion obtained by randomly dividing the same total variance among the fitted PCs.'
'- PC opt BS selects the largest fitted PC retained by that comparison, with a minimum of one PC.'
'- Broken Stick is a reproducible suggestion, not a mandatory modelling decision.'
'- PC X and PC Y define the axes of the 2D scores plot.'
'- PC Z is used only in 3D mode.'
'- The selected PCs must be different.'
'- The selected PCs cannot exceed the Number of PCs fitted.'
' '
'SCORE ELLIPSE'
' '
'- Show 95% score ellipse adds one ellipse per class in Conjoint PCA.'
'  In a single-class PCA, only the modeling class defines an ellipse.'
'- It is useful for identifying samples far from the main score distribution.'
'- The ellipse is descriptive and should not replace chemical/analytical interpretation.'
' '
'LOADINGS PLOT'
' '
'- Loadings indicate how strongly each original variable contributes to each PC.'
'- Positive and negative loading regions indicate variables that drive the direction of the PC.'
'- For spectral data, loading peaks can be related to wavelengths/wavenumbers associated with class trends.'
'- The loadings displayed correspond to the same PCs selected for the scores plot.'
' '
'HOTELLING T^2 VS Q RESIDUAL PLOT'
' '
'- Hotelling T^2 measures how far a sample is from the model center inside the PCA subspace.'
'- High T^2 indicates a potentially influential or high-leverage sample.'
'- Q residual measures the part of the sample not explained by the selected PCA model.'
'- High Q indicates poor reconstruction by the retained PCs.'
'- Samples above the horizontal Q limit may be residual outliers.'
'- Samples to the right of the vertical T^2 limit may be leverage outliers.'
'- Click on a point in this plot to inspect the sample spectrum, reconstruction and residual.'
' '
'CLICK-BASED SAMPLE REPORT'
' '
'When clicking a point in the 2D scores plot or in the T^2 vs Q plot, the GUI:'
'   - prints sample index, class, scores, T^2 and Q residual in the MATLAB command window;'
'   - opens an auxiliary figure with:'
'       1) sample spectrum compared with the PCA model-class mean +/- 1 SD;'
'       2) original spectrum and reconstruction obtained from the selected PCA class model;'
'       3) original-scale PCA residual.'
'   - For a projected sample, the titles identify its actual class and the PCA model class.'
' '
'SCREE + CUMULATIVE VARIANCE'
' '
'- The bar plot shows individual explained variance for each fitted PC.'
'- The line shows cumulative explained variance.'
'- This GUI displays PC1 up to the number defined in the Max PCs text box.'
'- A sharp drop after a few PCs suggests that most structured variance is captured early.'
' '
'PREPROCESSING IN THIS MODULE'
' '
'- One common preprocessing method is selected for every model. In class-specific mode,'
'  each class estimates its own preprocessing parameters. In a single-class model,'
'  projected classes use the mean/scale/range and loadings estimated from the modeling class.'
'- Clicking a projected sample reconstructs it with the selected class model, not with its actual class.'
'- The menu order is Center, Scale, Autoscale, Range scale and Raw.'
'- More complete spectral preprocessing should be done in the View and Preprocessing module.'
'- For consistency, use the same processed matrix in downstream PLS-DM steps.'
' '
'BUTTON-BY-BUTTON REFERENCE'
' '
'Help: opens this reference without changing data, settings or results.'
'Load example: replaces current GUI data with simulated spectra, three classes, an x-axis and sample names.'
'Import workspace: selects X and optionally Class and x-axis. Class = <none> creates class 1 for every row. A new import clears the previous PCA result.'
'Exclude: includes or excludes individual samples or complete numeric classes without deleting the imported matrix.'
'  Any inclusion change invalidates the previous PCA. Run PCA again to update scores, loadings, variance and diagnostics.'
'PC opt BS: requires a completed PCA, applies Broken Stick, selects its suggested PC opt and immediately refreshes diagnostics and figures.'
'Run PCA: fits the selected Conjoint or class-specific model and refreshes all plots.'
'PCA model / Project others: directly select the model class and control whether other classes are projected.'
'  When projection is enabled, projected classes are also shown in T^2 versus Q;'
'  the critical limits continue to be estimated only from the modeling class.'
'Export PCA: requires a PCA result and exports PCAmodel with results, diagnostics, Class, sample names and x-axis.'
'Export plots: requires a PCA result and opens the four PCA panels in a standalone editable figure.'
'See data: requires imported data and opens profiles and class means using the current Class and x-axis.'
'PC opt menu: manually changes the number used for reconstruction and T2/Q diagnostics. It overrides PC opt BS.'
'Scores mode and PC X/Y/Z: change displayed score axes without refitting PCA.'
'Show sample labels / Show 95% score ellipse: toggle 2D annotations and refresh the score view.'
' '
'RECOMMENDED USE IN THE PLS-DM WORKFLOW'
' '
'1. First inspect and preprocess spectra in the View and Preprocessing module.'
'2. Use PCA here to check grouping, trends, outliers and possible class structure.'
'3. Use the Sample Partition module to create train/validation/test subsets.'
'4. Continue to PLS-DM Optimization and Fit & Validation.'
' '
'COMMON ERRORS AND HOW TO FIX THEM'
' '
'- Error: selected PCs exceed fitted PCs.'
'  Increase Number of PCs or choose smaller PC indices.'
'- Error: PC X and PC Y must be different.'
'  Select different PCs for the axes.'
'- Error: X rows and class length are inconsistent.'
'  Make sure the class vector has one entry per sample.'
'- Very high Q residuals for many samples.'
'  Consider increasing Number of PCs or reviewing preprocessing.'
'- Too much dominance by one variable region.'
'  Consider autoscaling or spectral preprocessing, depending on the data structure.'
' '
'EXPORTED VARIABLES'
' '
'- PCAmodel      : structure containing scores, loadings, preprocessing, explained variance, PC opt, T2/Q diagnostics and limits.'
' '
'NOTES'
' '
'- Conjoint PCA is unsupervised and class labels are used for coloring and interpretation.'
'- Class-specific mode uses labels only to define which samples enter the independent PCA.'
'- Scores from class-specific PCA models use their own coordinate system; distances to other classes'
'  in the combined score plot are not directly comparable to distances in Conjoint PCA.'
'- PCA separation is exploratory evidence, not a supervised classification result.'
' '};

        fHelp = figure('Name','Help - Exploratory PCA', ...
                       'NumberTitle','off', ...
                       'MenuBar','none', ...
                       'Toolbar','none', ...
                       'Color',[1 1 1], ...
                       'Units','normalized', ...
                       'Position',[0.18 0.12 0.64 0.76]);
%         %------------------------------------------------------------------           
%          uicontrol('Parent',fHelp,'Style','text', ...
%                   'String','Exploratory PCA - Help', ...
%                   'Units','normalized','Position',[0.03 0.91 0.94 0.06], ...
%                   'BackgroundColor',[1 1 1], ...
%                   'ForegroundColor',[0.12 0.32 0.25], ...
%                   'HorizontalAlignment','left', ...
%                   'FontName','Arial','FontSize',14,'FontWeight','bold');
% 
%          %-----------------------------------------------------------------
        uicontrol('Parent',fHelp,'Style','edit', ...
                  'Units','normalized', ...
                  'Position',[0.02 0.02 0.96 0.96], ...
                  'String',helpText, ...
                  'Max',2,'Min',0, ...
                  'HorizontalAlignment','left', ...
                  'FontName','Courier New', ...
                  'FontSize',10, ...
                  'BackgroundColor',[1 1 1]);
    end
    function onLoadExample(hObj,ev)
        S = guidata(hObj);
        [X,classv,axisv,sampleNames] = createExampleData();
        S.X = X;
        S.class = classv;
        S.Xall = X; S.classAll = classv(:); S.sampleIncluded = true(size(X,1),1);
        S.originalRows = (1:size(X,1))'; S.sampleNamesAll = sampleNames(:);
        S.axis = axisv;
        S.sampleNames = sampleNames;
        S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
        set(S.btnDataInfo,'Enable','on','String','Add data info...');
        set(S.btnExclude,'Enable','on');
        S.PCA = [];
        S.PCAModels = struct([]); S.ScoreViewT = []; S.ScoreViewClass = []; S.ScoreViewSampleIdx = [];
        set(S.popupPCOpt,'String',{'run PCA'},'Value',1);
        guidata(hObj,S);
        updatePCAModelMenus(hObj);
        refreshSummary(hObj,{'Example data loaded.'});
        clearAxes(S);
    end

    function onImportWorkspace(hObj,ev)
        S = guidata(hObj);
        [ok,names,vals] = plsdm_select_workspace_vars('Import workspace', ...
            {'X matrix','Class vector','x-axis vector'}, {'X','class','axis'}, {false,true,true});
        if ~ok, return; end
        try
            X = vals{1};
            if isempty(vals{2})
                classv = ones(size(X,1),1);
            else
                classv = vals{2};
                if size(classv,1) == 1
                    classv = classv';
                end
            end
            if isempty(vals{3})
                axisv = 1:size(X,2);
            else
                axisv = vals{3};
            end
            if size(X,1) ~= length(classv)
                error('X rows and class length are inconsistent.');
            end
            S.X = X;
            S.class = classv;
            S.Xall = X; S.classAll = classv(:); S.sampleIncluded = true(size(X,1),1);
            S.originalRows = (1:size(X,1))';
            S.axis = axisv(:)';
            S.sampleNames = buildSampleNames(size(X,1));
            S.sampleNamesAll = S.sampleNames(:);
            S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
            set(S.btnDataInfo,'Enable','on','String','Add data info...');
            set(S.btnExclude,'Enable','on');
            S.PCA = [];
            S.PCAModels = struct([]); S.ScoreViewT = []; S.ScoreViewClass = []; S.ScoreViewSampleIdx = [];
            set(S.popupPCOpt,'String',{'run PCA'},'Value',1);
            guidata(hObj,S);
            updatePCAModelMenus(hObj);
            refreshSummary(hObj,{'Data imported from workspace.'});
            clearAxes(S);
        catch ME
            errordlg(['Import error: ' ME.message],'Import');
        end
    end

    function onDataInfo(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X), errordlg('Load data before adding data information.','Add data info'); return; end
        [info,applied] = plsdm_add_data_info(fig,S.class,size(S.X,1),S.dataInfo);
        if ~applied, return; end
        S.dataInfo = info;
        if ~isempty(info.sampleNames), S.sampleNames = info.sampleNames; else, S.sampleNames = buildSampleNames(size(S.X,1)); end
        S.sampleNamesAll(S.sampleIncluded) = S.sampleNames(:);
        set(S.btnDataInfo,'String','Edit data info...');
        guidata(fig,S);
        updatePCAModelMenus(fig);
        if ~isempty(S.PCA), refreshPCAView(fig); end
    end

    function onExcludeSamples(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xall), errordlg('Load data first.','Exclude samples'); return; end
        d = struct('label','PCA data','X',S.Xall,'classDisplay',{num2cell(S.classAll(:))}, ...
            'sampleNames',{S.sampleNamesAll(:)},'originalRows',S.originalRows(:),'included',S.sampleIncluded(:));
        [applied,d] = plsdm_exclude_samples_dialog(fig,d);
        if ~applied || isequal(S.sampleIncluded,d.included), return; end
        S.sampleIncluded = d.included; S.X = S.Xall(S.sampleIncluded,:);
        S.class = S.classAll(S.sampleIncluded); S.sampleNames = S.sampleNamesAll(S.sampleIncluded);
        S.dataInfo.sampleNames = S.sampleNames; S.PCA = []; S.PCAModels = struct([]);
        set(S.popupPCOpt,'String',{'run PCA'},'Value',1);
        guidata(hObj,S); updatePCAModelMenus(hObj); clearAxes(S); refreshSummary(hObj,{'Sample selection changed; PCA results are outdated.'});
        msgbox('Sample selection updated. Run PCA again to visualize the updated results.','Sample selection updated');
    end

    function updatePCAModelMenus(hObj)
        S = guidata(hObj);
        if isempty(S.class)
            set(S.popupPCAModel,'String',{'PCA conjoint'},'Value',1);
            set(S.chkProjectRemaining,'Value',0,'Enable','off');
            return;
        end
        classes = unique_stable_local(S.class(:)'); classes = classes(:);
        modelLabels = {'PCA conjoint'};
        classLabels = cell(1,numel(classes));
        for ii = 1:numel(classes)
            classLabels{ii} = plsdm_data_info_class_name(S.dataInfo,classes(ii));
            modelLabels{end+1} = ['PCA ' classLabels{ii}];
        end
        oldValue = min(get(S.popupPCAModel,'Value'),numel(modelLabels));
        set(S.popupPCAModel,'String',modelLabels,'Value',oldValue,'UserData',classes);
        updatePCAModeControlState(S);
    end

    function onPCAModelChanged(hObj,ev)
        S = guidata(hObj);
        updatePCAModeControlState(S);
        S = guidata(hObj);
        if ~isempty(S.PCA), onRunPCA(hObj,ev); end
    end

    function updatePCAModeControlState(S)
        value = get(S.popupPCAModel,'Value');
        classes = get(S.popupPCAModel,'UserData');
        if value == 1
            S.PCAMode = 'Conjoint'; S.ActiveClass = [];
            set(S.chkProjectRemaining,'Enable','off','Value',0);
        else
            idx = value-1;
            S.PCAMode = 'Class'; S.ActiveClass = classes(idx);
            set(S.chkProjectRemaining,'Enable','on');
        end
        guidata(S.pnlCtrl,S);
    end

    function onRunPCA(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X)
            errordlg('No data loaded.','PCA');
            return;
        end

        A = parsePositiveInt(get(S.edA,'String'),'Max PCs');
        conf = str2double(get(S.edConf,'String'));
        if isnan(conf) || conf <= 0 || conf >= 100
            errordlg('Confidence must be between 0 and 100.','PCA');
            return;
        end
        preprocessing = getSelectedPreprocessing(S);
        pcX = get(S.popupPCX,'Value');
        pcY = get(S.popupPCY,'Value');
        pcZ = get(S.popupPCZ,'Value');
        modeList = get(S.popupMode,'String');
        scoreMode = modeList{get(S.popupMode,'Value')};

        if pcX > A || pcY > A || (strcmpi(scoreMode,'3D') && pcZ > A)
            errordlg('Selected PCs must be within the fitted number of PCs.','PCA');
            return;
        end
        if pcX == pcY
            errordlg('PC X and PC Y must be different.','PCA');
            return;
        end
        if strcmpi(scoreMode,'3D') && length(unique([pcX pcY pcZ])) < 3
            errordlg('PC X, PC Y and PC Z must be different in 3D mode.','PCA');
            return;
        end

        try
            classes = unique_stable_local(S.class(:)'); classes = classes(:);
            models = struct('Class',{},'SampleIdx',{},'PCA',{});
            scoreT = nan(size(S.X,1),A);
            scoreClass = S.class(:);
            scoreSampleIdx = (1:size(S.X,1))';
            activeSampleIdx = (1:size(S.X,1))';
            if strcmpi(S.PCAMode,'Conjoint')
                PCA = run_pca_local(S.X,A,preprocessing,conf);
                scoreT = PCA.Tall;
            else
                idxClass = find(S.class == S.ActiveClass);
                if A > min(numel(idxClass),size(S.X,2))
                    error('Max PCs exceeds the number supported by the selected class.');
                end
                PCA = run_pca_local(S.X(idxClass,:),A,preprocessing,conf);
                PCA = update_pca_diagnostics(PCA,A,conf);
                models(1).Class = S.ActiveClass;
                models(1).SampleIdx = idxClass(:);
                models(1).PCA = PCA;
                activeSampleIdx = idxClass(:);
                if get(S.chkProjectRemaining,'Value') == 1
                    viewIdx = (1:size(S.X,1))';
                else
                    viewIdx = idxClass(:);
                end
                Xview = apply_pca_preprocessing(S.X(viewIdx,:),PCA.preprocessing);
                scoreT = Xview * PCA.Pall(:,1:A);
                scoreClass = S.class(viewIdx);
                scoreSampleIdx = viewIdx;
            end
        catch ME
            errordlg(['PCA error: ' ME.message],'PCA');
            return;
        end

        pcOpt = A;
        PCA = update_pca_diagnostics(PCA, pcOpt, conf);
        pcStrings = make_pc_strings(A);
        set(S.popupPCOpt,'String',pcStrings,'Value',pcOpt);
        set(S.popupPCX,'String',pcStrings,'Value',min(pcX,A));
        set(S.popupPCY,'String',pcStrings,'Value',min(pcY,A));
        set(S.popupPCZ,'String',pcStrings,'Value',min(pcZ,A));
        S.PCA = PCA;
        S.PCAModels = models;
        S.ScoreViewT = scoreT;
        S.ScoreViewClass = scoreClass;
        S.ScoreViewSampleIdx = scoreSampleIdx;
        S.ActiveSampleIdx = activeSampleIdx;
        S.A = A;
        S.PCopt = pcOpt;
        S.conf = conf;
        S.preprocessing = preprocessing;
        S.pcX = min(pcX,A);
        S.pcY = min(pcY,A);
        S.pcZ = min(pcZ,A);
        S.scoreMode = scoreMode;
        guidata(hObj,S);

        refreshPCAView(hObj);
    end

    function onBrokenStick(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PCA)
            errordlg('Run PCA before applying the Broken Stick criterion.','PC opt BS');
            return;
        end
        proportions = S.PCA.explained(:)' / 100;
        nPC = length(proportions);
        expected = zeros(1,nPC);
        for jj = 1:nPC
            expected(jj) = sum(1 ./ (jj:nPC)) / nPC;
        end
        selected = find(proportions > expected);
        if isempty(selected)
            pcOpt = 1;
        else
            pcOpt = max(selected);
        end
        pcOpt = min(pcOpt,S.A);
        set(S.popupPCOpt,'Value',pcOpt);
        S.PCopt = pcOpt;
        S.PCA = update_pca_diagnostics(S.PCA,pcOpt,S.conf);
        if ~isempty(S.PCAModels)
            idxModel = find([S.PCAModels.Class] == S.ActiveClass,1);
            if ~isempty(idxModel), S.PCAModels(idxModel).PCA = S.PCA; end
        end
        guidata(hObj,S);
        refreshPCAView(hObj);
    end

    function onExportPCA(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PCA)
            errordlg('No PCA result available.','Export');
            return;
        end
        PCA = S.PCA;
        PCA.sampleNames = S.sampleNames;
        PCA.class = S.class;
        PCA.axis = S.axis;
        PCA.modelMode = S.PCAMode;
        PCA.activeClass = S.ActiveClass;
        PCA.classModels = S.PCAModels;
        PCA.scoreViewT = S.ScoreViewT;
        PCA.scoreViewClass = S.ScoreViewClass;
        PCA.scoreViewSampleIdx = S.ScoreViewSampleIdx;
        assignin('base','PCAmodel',PCA);
        msgbox('Exported to workspace: PCAmodel','Export');
    end

    function onExportPlots(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PCA)
            errordlg('No PCA result available.','Export plots');
            return;
        end
        selected = plsdm_select_plots_to_export(fig,{'Scores plot','Loadings vs x-axis','Hotelling T^2 vs Q','Scree + cumulative variance'});
        if isempty(selected), return; end
        f = figure('Name','Exploratory PCA - Exported plots', ...
                   'NumberTitle','off','Color',[1 1 1]);
        n = numel(selected); nr = ceil(sqrt(n)); nc = ceil(n/nr);
        for jj = 1:n
            ax = subplot(nr,nc,jj,'Parent',f);
            switch selected(jj)
                case 1, plotScoresMain(ax,S);
                case 2, plotLoadings(ax,S);
                case 3, plotT2Q(ax,S);
                case 4, plotExplained(ax,S);
            end
        end
    end

    function onSeeData(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X) || isempty(S.class)
            errordlg('Import X and class before plotting data.','See data');
            return;
        end
        try
            X = S.X;
            C = S.class(:);
            classes = unique(C);
            p = size(X,2);
            xaxis = 1:p;
            if ~isempty(S.axis) && numel(S.axis) == p && isnumeric(S.axis)
                xaxis = S.axis(:).';
            end

            f = figure('Color','w','Name','PCA data by class','NumberTitle','off');
            ax = axes('Parent',f); hold(ax,'on'); box(ax,'on'); grid(ax,'on');
            set(ax,'FontName','Arial','FontSize',11,'LineWidth',1.2);
            hMean = zeros(length(classes),1);
            leg = cell(length(classes),1);
            for ii = 1:length(classes)
                idx = find(C == classes(ii));
                col = S.classColors(1+mod(ii-1,size(S.classColors,1)),:);
                pale = 0.72*[1 1 1] + 0.28*col;
                for jj = 1:length(idx)
                    plot(ax,xaxis,X(idx(jj),:),'-','Color',pale,'LineWidth',0.6);
                end
                mu = mean(X(idx,:),1);
                hMean(ii) = plot(ax,xaxis,mu,'-','Color',col,'LineWidth',2.6);
                leg{ii} = [plsdm_data_info_class_name(S.dataInfo,classes(ii)) ' mean'];
            end
            xLabelText = 'x-axis'; yLabelText = 'Signal';
            if ~isempty(S.dataInfo.xLabel), xLabelText = S.dataInfo.xLabel; end
            if ~isempty(S.dataInfo.yLabel), yLabelText = S.dataInfo.yLabel; end
            xlabel(ax,xLabelText,'FontWeight','bold');
            ylabel(ax,yLabelText,'FontWeight','bold');
            title(ax,'PCA input data profiles by class','FontWeight','bold');
            legend(ax,hMean,leg,'Location','EastOutside');
            axis(ax,'tight');
            hold(ax,'off');
        catch ME
            errordlg(['Unable to plot PCA data: ' ME.message],'See data');
        end
    end

    function onPCASettingsChanged(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X)
            return;
        end
        if isempty(S.PCA)
            return;
        end
        onRunPCA(hObj,ev);
    end

    function onPCOptChanged(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PCA)
            return;
        end
        pcOpt = get(S.popupPCOpt,'Value');
        pcOpt = max(1,min(pcOpt,S.PCA.Amax));
        try
            S.PCA = update_pca_diagnostics(S.PCA, pcOpt, S.conf);
        catch ME
            errordlg(['PC opt error: ' ME.message],'PC opt');
            return;
        end
        S.PCopt = pcOpt;
        S.A = S.PCA.A;
        guidata(hObj,S);
        refreshPCAView(hObj);
    end

    function onViewSettingsChanged(hObj,ev)
        S = guidata(hObj);
        if isempty(S.PCA)
            return;
        end

        pcX = get(S.popupPCX,'Value');
        pcY = get(S.popupPCY,'Value');
        pcZ = get(S.popupPCZ,'Value');
        modeList = get(S.popupMode,'String');
        scoreMode = modeList{get(S.popupMode,'Value')};

        if pcX == pcY
            return;
        end
        if strcmpi(scoreMode,'3D') && length(unique_stable_local([pcX pcY pcZ])) < 3
            return;
        end

        S.pcX = pcX;
        S.pcY = pcY;
        S.pcZ = pcZ;
        S.scoreMode = scoreMode;
        guidata(hObj,S);
        refreshPCAView(hObj);
    end

    function refreshPCAView(hObj)
        S = guidata(hObj);
        if isempty(S.PCA)
            return;
        end
        plotScoresMain(S.ax1,S);
        plotLoadings(S.ax2,S);
        plotT2Q(S.ax3,S);
        plotExplained(S.ax4,S);
        refreshSummary(hObj,buildPCASummary(S));
    end

    function refreshSummary(hObj,msg)
        S = guidata(hObj);
        txt = {};
        if ~isempty(S.X)
            txt{end+1} = ['Total samples: ' num2str(size(S.X,1))];
            txt{end+1} = ['Variables: ' num2str(size(S.X,2))];
            txt{end+1} = ['Classes: ' num2str(length(unique(S.class)))];
        end
        if nargin >= 2 && ~isempty(msg)
            txt = [txt(:); {' '}; msg(:)];
        end
        if isempty(txt)
            txt = {'Load data to begin.'};
        end
        set(S.txtInfo,'String',txt);
    end

    function txt = buildPCASummary(S)
        txt = {};
        txt{end+1} = ['PCA model = ' S.PCAMode];
        if ~isempty(S.ActiveClass)
            txt{end+1} = ['PCA model class = ' plsdm_data_info_class_name(S.dataInfo,S.ActiveClass)];
        end
        if strcmpi(S.PCAMode,'Class')
            txt{end+1} = ['Remaining classes projected = ' logical_text(get(S.chkProjectRemaining,'Value') == 1)];
        end
        txt{end+1} = ['PCA fitted with Max PCs = ' num2str(S.PCA.Amax)];
        txt{end+1} = ['PC opt = ' num2str(S.PCA.PCopt)];
        txt{end+1} = ['Preprocessing = ' S.PCA.preprocessing.method];
        txt{end+1} = ['Confidence = ' num2str(S.conf) '%'];
        txt{end+1} = ['Scores mode = ' S.scoreMode];
        txt{end+1} = ['Scores PCs: PC' num2str(S.pcX) ', PC' num2str(S.pcY)];
        if strcmpi(S.scoreMode,'3D')
            txt{end+1} = ['Scores 3D includes PC' num2str(S.pcZ)];
        end
        txt{end+1} = ['Loadings shown for requested PCs'];
        txt{end+1} = ['Cumulative explained variance at PC opt = ' num2str(sum(S.PCA.explained(1:S.PCA.PCopt)),4) '%'];
        txt{end+1} = ['T^2 critical = ' num2str(S.PCA.T2crit,5)];
        txt{end+1} = ['Q critical = ' num2str(S.PCA.Qcrit,5)];
        txt{end+1} = ['Click points in Scores 2D or T^2 vs Q for details'];
    end

    function clearAxes(S)
        cla(S.ax1); cla(S.ax2); cla(S.ax3); cla(S.ax4);
        title(S.ax1,'Scores plot');
        title(S.ax2,'Loadings vs x-axis');
        title(S.ax3,'Hotelling T^2 vs Q');
        title(S.ax4,'Scree + cumulative variance');
    end

    function preprocessing = getSelectedPreprocessing(S)
        vals = get(S.popupPreprocess,'String');
        idx = get(S.popupPreprocess,'Value');
        if ischar(vals)
            preprocessing = vals;
        else
            preprocessing = vals{idx};
        end
    end
end

function labels = make_pc_strings(nPC)
    labels = cell(1,nPC);
    for ii = 1:nPC
        labels{ii} = num2str(ii);
    end
end

% ================================================================
% Plotting functions
% ================================================================
function plotScoresMain(ax,S)
    axes(ax); cla(ax,'reset'); hold(ax,'on');
    T = S.ScoreViewT;
    classv = S.ScoreViewClass;
    sampleMap = S.ScoreViewSampleIdx;
    if isempty(T), T = S.PCA.T; classv = S.class; sampleMap = (1:size(T,1))'; end
    u = unique(classv(:)');
    mode3d = strcmpi(S.scoreMode,'3D');
    hx = [];
    lx = {};
    S.scorePointMap2D = [];

    if mode3d
        view(ax,3);
        for k = 1:length(u)
            idx = find(classv == u(k));
            c = S.classColors(1+mod(k-1,size(S.classColors,1)),:);
            h = plot3(T(idx,S.pcX), T(idx,S.pcY), T(idx,S.pcZ), 'o', ...
                      'MarkerFaceColor',c,'MarkerEdgeColor','k','LineStyle','none');
            hx(end+1) = h;
            lx{end+1} = plsdm_data_info_class_name(S.dataInfo,u(k));
        end
        xlabel(['PC' num2str(S.pcX) ' (' num2str(S.PCA.explained(S.pcX),3) '%)']);
        ylabel(['PC' num2str(S.pcY) ' (' num2str(S.PCA.explained(S.pcY),3) '%)']);
        zlabel(['PC' num2str(S.pcZ) ' (' num2str(S.PCA.explained(S.pcZ),3) '%)']);
        title('Scores plot (3D)');
        view(ax,40,25);
    else
        view(ax,2);
        zlabel('');
        pointMap = [];
        for k = 1:length(u)
            idx = find(classv == u(k));
            c = S.classColors(1+mod(k-1,size(S.classColors,1)),:);
            for i = 1:length(idx)
                h = plot(T(idx(i),S.pcX), T(idx(i),S.pcY), 'o', ...
                         'MarkerFaceColor',c,'MarkerEdgeColor','k','LineStyle','none', ...
                         'ButtonDownFcn',{@onClickScorePoint,sampleMap(idx(i)),S});
                pointMap = [pointMap; sampleMap(idx(i))];
                if i == 1
                    hx(end+1) = h;
                    lx{end+1} = plsdm_data_info_class_name(S.dataInfo,u(k));
                end
                if get(S.chkLabels,'Value')
                    text(T(idx(i),S.pcX), T(idx(i),S.pcY), [' ' plsdm_data_info_sample_name(S.dataInfo,sampleMap(idx(i)))], 'FontSize',7);
                end
            end
        end
        if get(S.chkEllipse,'Value')
            if strcmpi(S.PCAMode,'Class')
                idx = find(classv == S.ActiveClass);
                draw_score_ellipse(T(idx,[S.pcX S.pcY]),ax,[0 0 0]);
            else
                % Conjoint PCA: all classes share the same PCA coordinate
                % system, so class-specific ellipses are directly comparable.
                for k = 1:length(u)
                    idx = find(classv == u(k));
                    c = S.classColors(1+mod(k-1,size(S.classColors,1)),:);
                    draw_score_ellipse(T(idx,[S.pcX S.pcY]),ax,c);
                end
            end
        end
        xlabel(['PC' num2str(S.pcX) ' (' num2str(S.PCA.explained(S.pcX),3) '%)']);
        ylabel(['PC' num2str(S.pcY) ' (' num2str(S.PCA.explained(S.pcY),3) '%)']);
        if strcmpi(S.PCAMode,'Class') && get(S.chkProjectRemaining,'Value') == 1
            title(['PCA ' plsdm_data_info_class_name(S.dataInfo,S.ActiveClass) ' - remaining classes projected']);
        else
            title('Scores plot (2D)');
        end
        S.scorePointMap2D = pointMap;
    end
    if ~isempty(hx)
        legend(hx,lx,'Location','Best');
    end
    axis(ax,'normal');
    box(ax,'on'); grid(ax,'on');
    hold(ax,'off');
end

function plotLoadings(ax,S)
    axes(ax); cla; hold on;
    xax = S.axis;
    if isempty(xax)
        xax = 1:size(S.PCA.P,1);
    end
    pcsToPlot = [S.pcX S.pcY];
    if strcmpi(S.scoreMode,'3D')
        pcsToPlot = [S.pcX S.pcY S.pcZ];
    end
    pcsToPlot = unique_stable_local(pcsToPlot);
    hx = [];
    lx = {};
    for k = 1:length(pcsToPlot)
        pc = pcsToPlot(k);
        c = S.classColors(1+mod(k-1,size(S.classColors,1)),:);
        h = plot(xax, S.PCA.P(:,pc), 'Color',c, 'LineWidth',1.8);
        hx(end+1) = h;
        lx{end+1} = ['Loading PC' num2str(pc)];
    end
    xLabelText = 'x-axis';
    if isfield(S,'dataInfo') && ~isempty(S.dataInfo.xLabel), xLabelText = S.dataInfo.xLabel; end
    xlabel(xLabelText);
    ylabel('Loading');
    title(['Loadings vs x-axis' pca_active_suffix(S)]);
    legend(hx,lx,'Location','Best');
    box on; grid on;
    hold off;
end

function plotT2Q(ax,S)
    axes(ax); cla(ax,'reset'); hold(ax,'on');
    if strcmpi(S.PCAMode,'Class') && get(S.chkProjectRemaining,'Value') == 1
        % Projected samples use the selected class preprocessing, loadings
        % and score variances. Critical limits remain those estimated from
        % the modeling class stored in S.PCA.
        sampleMap = S.ScoreViewSampleIdx(:);
        Ause = S.PCA.PCopt;
        Tuse = S.ScoreViewT(:,1:Ause);
        lambda = var(S.PCA.Tall(:,1:Ause),0,1);
        lambda(lambda <= 0 | ~isfinite(lambda)) = eps;
        T2 = sum((Tuse.^2) ./ repmat(lambda,size(Tuse,1),1),2);
        XprepView = apply_pca_preprocessing(S.X(sampleMap,:),S.PCA.preprocessing);
        XhatView = Tuse * S.PCA.Pall(:,1:Ause)';
        Q = sum((XprepView-XhatView).^2,2);
    else
        T2 = S.PCA.T2;
        Q = S.PCA.Q;
        sampleMap = S.ActiveSampleIdx;
        if isempty(sampleMap), sampleMap = (1:numel(T2))'; end
    end
    classv = S.class(sampleMap);
    u = unique(classv(:)');
    hx = [];
    lx = {};

    xMax = finite_axis_max([T2(:); S.PCA.T2crit]);
    yMax = finite_axis_max([Q(:); S.PCA.Qcrit]);
    xlim(ax,[0 xMax]);
    ylim(ax,[0 yMax]);

    for k = 1:length(u)
        idx = find(classv == u(k));
        c = S.classColors(1+mod(k-1,size(S.classColors,1)),:);
        for i = 1:length(idx)
            h = plot(T2(idx(i)),Q(idx(i)),'o', ...
                     'MarkerFaceColor',c,'MarkerEdgeColor','k','LineStyle','none', ...
                     'ButtonDownFcn',{@onClickT2QPoint,sampleMap(idx(i)),S});
            if i == 1
                hx(end+1) = h;
                lx{end+1} = plsdm_data_info_class_name(S.dataInfo,u(k));
            end
        end
    end
    yl = ylim(ax);
    xl = xlim(ax);
    if isfinite(S.PCA.T2crit)
        plot(ax,[S.PCA.T2crit S.PCA.T2crit], yl, 'r--','LineWidth',1.5);
    end
    if isfinite(S.PCA.Qcrit)
        plot(ax,xl, [S.PCA.Qcrit S.PCA.Qcrit], 'r--','LineWidth',1.5);
    end
    xlim(ax,xl);
    ylim(ax,yl);
    xlabel('Hotelling T^2');
    ylabel('Q residual');
    title(['Hotelling T^2 vs Q' pca_active_suffix(S)]);
    if ~isempty(hx)
        legend(hx,lx,'Location','Best');
    end
    view(ax,2);
    box(ax,'on'); grid(ax,'on');
    hold(ax,'off');
end

function xmax = finite_axis_max(v)
    v = v(:);
    v = v(isfinite(v));
    if isempty(v)
        xmax = 1;
        return;
    end
    xmax = max(v);
    if xmax <= 0
        xmax = 1;
    else
        xmax = xmax * 1.08;
    end
end

function plotExplained(ax,S)
    axes(ax); cla;

    explainedAll = S.PCA.explained(:);
    nPC = S.PCA.Amax;
    nPC = max(1,min(nPC,length(explainedAll)));

    explained = explainedAll(1:nPC);
    pcs = 1:nPC;

    bar(pcs,explained);
    hold on;
    plot(pcs,cumsum(explained),'k-o','LineWidth',1.2,'MarkerFaceColor','w');
    plot([S.PCA.PCopt S.PCA.PCopt], ylim, 'r--','LineWidth',1.2);
    xlabel('Principal component');
    ylabel('Explained variance (%)');
    title(['Scree + cumulative variance' pca_active_suffix(S)]);
    legend({'Individual','Cumulative','PC opt'},'Location','Best');
    set(gca,'XTick',pcs);
    xlim([0.5 nPC+0.5]);
    box on; grid on; hold off;
end

function draw_score_ellipse(T2d, ax, color)
    if size(T2d,2) ~= 2 || size(T2d,1) < 3
        return;
    end
    mu = mean(T2d,1);
    C = cov(T2d);
    [V,D] = eig(C);
    if any(diag(D) <= 0)
        return;
    end
    t = linspace(0,2*pi,200);
    r = sqrt(5.991);
    xy = [cos(t(:)) sin(t(:))] * sqrt(D) * V' * r;
    xy(:,1) = xy(:,1) + mu(1);
    xy(:,2) = xy(:,2) + mu(2);
    axes(ax);
    if nargin < 3, color = [0 0 0]; end
    plot(xy(:,1),xy(:,2),'--','Color',color,'LineWidth',1.2);
end

function suffix = pca_active_suffix(S)
    suffix = '';
    if ~strcmpi(S.PCAMode,'Conjoint') && ~isempty(S.ActiveClass)
        suffix = [' - ' plsdm_data_info_class_name(S.dataInfo,S.ActiveClass)];
    end
end

% ================================================================
% Click callbacks and auxiliary report
% ================================================================
function onClickScorePoint(src,ev,sampleIdx,S)
    report_sample_pca(sampleIdx,S,'Scores plot');
end

function onClickT2QPoint(src,ev,sampleIdx,S)
    report_sample_pca(sampleIdx,S,'T2Q plot');
end

function report_sample_pca(sampleIdx,S,sourceName)
    sampleName = plsdm_data_info_sample_name(S.dataInfo,sampleIdx);
    className = plsdm_data_info_class_name(S.dataInfo,S.class(sampleIdx));
    fprintf('\n---------------------------------------------\n');
    fprintf('PCA sample report (%s)\n', sourceName);
    fprintf('Sample index: %d\n', sampleIdx);
    fprintf('Sample name: %s\n', sampleName);
    fprintf('Class: %s\n', className);
    localRow = find(S.ActiveSampleIdx == sampleIdx,1);
    scoreRow = find(S.ScoreViewSampleIdx == sampleIdx,1);
    if ~isempty(localRow)
        scores = S.PCA.T(localRow,:);
        t2val = S.PCA.T2(localRow);
        qval = S.PCA.Q(localRow);
    elseif ~isempty(scoreRow)
        scores = S.ScoreViewT(scoreRow,:);
        Ause = S.PCA.PCopt;
        lambda = var(S.PCA.Tall(:,1:Ause),0,1);
        t2val = sum((scores(1:Ause).^2) ./ max(lambda,eps));
        xp = apply_pca_preprocessing(S.X(sampleIdx,:),S.PCA.preprocessing);
        resid = xp - scores(1:Ause)*S.PCA.Pall(:,1:Ause)';
        qval = sum(resid.^2);
    else
        return;
    end
    fprintf('Scores: ');
    for a = 1:S.PCA.A
        fprintf('PC%d = %.5f  ', a, scores(a));
    end
    fprintf('\n');
    fprintf('Hotelling T^2: %.6f\n', t2val);
    fprintf('Q residual: %.6f\n', qval);
    fprintf('---------------------------------------------\n');

    open_auxiliary_sample_figure(sampleIdx,S);
end

function open_auxiliary_sample_figure(sampleIdx,S)
    xax = S.axis;
    if isempty(xax)
        xax = 1:size(S.X,2);
    end
    classLabel = S.class(sampleIdx);
    modelClass = classLabel;
    if strcmpi(S.PCAMode,'Class') && ~isempty(S.ActiveClass)
        modelClass = S.ActiveClass;
    end
    idxClass = find(S.class == modelClass);
    classMean = mean(S.X(idxClass,:),1);
    classSD = std(S.X(idxClass,:),0,1);
    A = S.PCA.PCopt;
    xp = apply_pca_preprocessing(S.X(sampleIdx,:),S.PCA.preprocessing);
    scores = xp * S.PCA.P(:,1:A);
    xhat_i = scores * S.PCA.P(:,1:A)';
    xhat_orig = unpreprocess_pca_row(xhat_i,S.PCA);
    residual = S.X(sampleIdx,:) - xhat_orig;
    sampleName = plsdm_data_info_sample_name(S.dataInfo,sampleIdx);
    className = plsdm_data_info_class_name(S.dataInfo,classLabel);
    modelClassName = plsdm_data_info_class_name(S.dataInfo,modelClass);
    xLabelText = 'x-axis'; yLabelText = 'Signal';
    if ~isempty(S.dataInfo.xLabel), xLabelText = S.dataInfo.xLabel; end
    if ~isempty(S.dataInfo.yLabel), yLabelText = S.dataInfo.yLabel; end

    figure('Name',['PCA sample details - ' sampleName], ...
               'NumberTitle','off','Color',[1 1 1]);

    % Panel 1: original sample compared with the class mean
    subplot(3,1,1);
    plot(xax,classMean,'r-','LineWidth',1.5); hold on;
    plot(xax,classMean+classSD,'r:','LineWidth',1.0);
    plot(xax,classMean-classSD,'r:','LineWidth',1.0);
    plot(xax,S.X(sampleIdx,:),'k-','LineWidth',1.5);
    xlabel(xLabelText); ylabel(yLabelText);
    title([sampleName ' (actual: ' className ') vs model Class ' modelClassName ' mean +/- 1 SD']);
    legend({['Model Class ' modelClassName ' mean'],['Model Class ' modelClassName ' mean + 1 SD'], ...
        ['Model Class ' modelClassName ' mean - 1 SD'],sampleName},'Location','Best');
    box on; grid on;

    % Panel 2: reconstructed spectrum only
    subplot(3,1,2);
    plot(xax,S.X(sampleIdx,:),'k-','LineWidth',1.2); hold on;
    plot(xax,xhat_orig,'g-','LineWidth',1.4);
    xlabel(xLabelText); ylabel(yLabelText);
    title(['Reconstruction with PCA model Class ' modelClassName ' (PC opt = ' num2str(S.PCA.PCopt) ')']);
    legend({'Original sample',['Reconstructed by Class ' modelClassName]},'Location','Best');
    box on; grid on;

    % Panel 3: residual only
    subplot(3,1,3);
    plot(xax,residual,'b-','LineWidth',1.3);
    xlabel(xLabelText); ylabel([yLabelText ' residual']);
    title(['Original-scale residual relative to PCA model Class ' modelClassName]);
    legend({'Original - reconstructed'},'Location','Best');
    box on; grid on;
end

% ================================================================
% PCA core
% ================================================================
function PCA = run_pca_local(X, A, preprocessingMethod, conf)
    [n,p] = size(X);
    if A < 1 || A > min(n,p)
        error('Invalid number of PCs.');
    end

    [Xprep,prep] = preprocess_pca_data(X, preprocessingMethod);

    [U,Sv,V] = svd(Xprep,'econ');
    Tall = U(:,1:A) * Sv(1:A,1:A);
    Pall = V(:,1:A);

    fullExplained = 100 * (diag(Sv).^2)' / sum(diag(Sv).^2);
    if isempty(fullExplained)
        error('Unable to compute explained variance.');
    end

    PCA = struct();
    PCA.preprocessing = prep;
    PCA.Xmean = prep.mean;
    PCA.Xstd = prep.std;
    PCA.Xmin = prep.min;
    PCA.Xrange = prep.range;
    PCA.Xprep = Xprep;
    PCA.Tall = Tall;
    PCA.Pall = Pall;
    PCA.T = Tall;
    PCA.P = Pall;
    PCA.E = [];
    PCA.Q = [];
    PCA.T2 = [];
    PCA.T2crit = [];
    PCA.Qcrit = [];
    PCA.explained = fullExplained;
    PCA.Amax = A;
    PCA.A = A;
    PCA.PCopt = A;
    PCA.conf = conf;
end

function [Xprep,prep] = preprocess_pca_data(X, method)
    [n,p] = size(X);
    mu = mean(X,1);
    sd = std(X,0,1);
    sd(sd==0) = 1;
    xmin = min(X,[],1);
    xmax = max(X,[],1);
    xrange = xmax - xmin;
    xrange(xrange==0) = 1;

    Xprep = X;
    methodKey = lower(method);
    switch methodKey
        case {'none','raw'}
            Xprep = X;
        case 'center'
            Xprep = X - repmat(mu,n,1);
        case 'scale'
            Xprep = X ./ repmat(sd,n,1);
        case 'autoscale'
            Xprep = (X - repmat(mu,n,1)) ./ repmat(sd,n,1);
        case 'range scale'
            Xprep = (X - repmat(xmin,n,1)) ./ repmat(xrange,n,1);
        otherwise
            error('Unknown PCA preprocessing method.');
    end

    prep = struct();
    prep.method = method;
    prep.mean = mu;
    prep.std = sd;
    prep.min = xmin;
    prep.range = xrange;
end

function Xprep = apply_pca_preprocessing(X,prep)
    n = size(X,1);
    switch lower(prep.method)
        case {'none','raw'}
            Xprep = X;
        case 'center'
            Xprep = X - repmat(prep.mean,n,1);
        case 'scale'
            Xprep = X ./ repmat(prep.std,n,1);
        case 'autoscale'
            Xprep = (X-repmat(prep.mean,n,1)) ./ repmat(prep.std,n,1);
        case 'range scale'
            Xprep = (X-repmat(prep.min,n,1)) ./ repmat(prep.range,n,1);
        otherwise
            error('Unknown PCA preprocessing method.');
    end
end

function txt = logical_text(tf)
    if tf, txt = 'Yes'; else, txt = 'No'; end
end

function PCA = update_pca_diagnostics(PCA, A, conf)
    A = max(1,min(A,PCA.Amax));
    Tuse = PCA.Tall(:,1:A);
    Puse = PCA.Pall(:,1:A);
    Xhat = Tuse * Puse';
    E = PCA.Xprep - Xhat;
    Q = sum(E.^2,2);

    n = size(PCA.Xprep,1);
    lambda = var(Tuse,0,1);
    T2 = zeros(n,1);
    for i = 1:n
        for a = 1:A
            if lambda(a) > 0
                T2(i) = T2(i) + (Tuse(i,a)^2)/lambda(a);
            end
        end
    end

    PCA.T = PCA.Tall;
    PCA.P = PCA.Pall;
    PCA.E = E;
    PCA.Q = Q;
    PCA.T2 = T2;
    PCA.T2crit = hotelling_t2_limit(n,A,conf/100);
    PCA.Qcrit = percentile_limit(Q,conf/100);
    PCA.A = A;
    PCA.PCopt = A;
    PCA.conf = conf;
    PCA.flagT2 = T2 > PCA.T2crit;
    PCA.flagQ = Q > PCA.Qcrit;
    PCA.flagOutlier = PCA.flagT2 | PCA.flagQ;
end

function xorig = unpreprocess_pca_row(xprep,PCA)
    methodKey = lower(PCA.preprocessing.method);
    switch methodKey
        case {'none','raw'}
            xorig = xprep;
        case 'center'
            xorig = xprep + PCA.preprocessing.mean;
        case 'scale'
            xorig = xprep .* PCA.preprocessing.std;
        case 'autoscale'
            xorig = xprep .* PCA.preprocessing.std + PCA.preprocessing.mean;
        case 'range scale'
            xorig = xprep .* PCA.preprocessing.range + PCA.preprocessing.min;
        otherwise
            xorig = xprep;
    end
end

function lim = hotelling_t2_limit(n,a,alpha)
    if n <= a
        lim = NaN;
        return;
    end
    Fcrit = finv_local(alpha,a,n-a);
    lim = a*(n-1)*(n+1)/(n*(n-a)) * Fcrit;
end

function lim = percentile_limit(v,alpha)
    vs = sort(v(:));
    k = ceil(alpha*length(vs));
    k = max(1,min(length(vs),k));
    lim = vs(k);
end

function f = finv_local(p,v1,v2)
    if p <= 0 || p >= 1
        error('Probability must be between 0 and 1.');
    end
    obj = @(x) fcdf_local(x,v1,v2) - p;
    x1 = 0;
    x2 = 1;
    while obj(x2) < 0
        x2 = x2 * 2;
        if x2 > 1e6
            break;
        end
    end
    for iter = 1:100
        xm = 0.5*(x1+x2);
        fm = obj(xm);
        if abs(fm) < 1e-8
            break;
        end
        if fm > 0
            x2 = xm;
        else
            x1 = xm;
        end
    end
    f = 0.5*(x1+x2);
end

function y = fcdf_local(x,v1,v2)
    z = (v1*x) ./ (v1*x + v2);
    y = betainc(z,v1/2,v2/2);
end

function v = parsePositiveInt(strValue,label)
    v = str2double(strValue);
    if isnan(v) || v < 1 || abs(v-round(v)) > 1e-12
        error([label ' must be a positive integer.']);
    end
    v = round(v);
end

function y = unique_stable_local(x)
    y = [];
    for i = 1:length(x)
        if isempty(y) || ~any(y == x(i))
            y(end+1) = x(i);
        end
    end
end

% ================================================================
% Example data
% ================================================================
function [X,classv,axisv,sampleNames] = createExampleData()
    n1 = 25;
    n2 = 18;
    n3 = 12;
    p = 160;
    axisv = linspace(1100,2500,p);

    X1 = zeros(n1,p);
    X2 = zeros(n2,p);
    X3 = zeros(n3,p);

    for i = 1:n1
        X1(i,:) = 0.50 + 0.04*randn(1,p) ...
                + 0.26*exp(-(axisv-1450).^2/(2*55^2)) ...
                + 0.18*exp(-(axisv-1930).^2/(2*80^2));
    end
    for i = 1:n2
        X2(i,:) = 0.56 + 0.05*randn(1,p) ...
                + 0.18*exp(-(axisv-1520).^2/(2*60^2)) ...
                + 0.24*exp(-(axisv-2080).^2/(2*75^2));
    end
    for i = 1:n3
        X3(i,:) = 0.47 + 0.05*randn(1,p) ...
                + 0.11*exp(-(axisv-1360).^2/(2*60^2)) ...
                + 0.28*exp(-(axisv-2210).^2/(2*85^2));
    end

    X = [X1; X2; X3];
    classv = [ones(n1,1); 2*ones(n2,1); 3*ones(n3,1)];
    sampleNames = buildSampleNames(size(X,1));
end

function names = buildSampleNames(n)
    names = cell(n,1);
    for i = 1:n
        names{i} = ['Sample_' num2str(i)];
    end
end
