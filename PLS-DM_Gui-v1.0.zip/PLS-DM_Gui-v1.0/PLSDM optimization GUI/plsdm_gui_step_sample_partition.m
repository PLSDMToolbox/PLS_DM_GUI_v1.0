%
function plsdm_gui_step_sample_partition()
% PLS-DM Toolbox GUI - Step: Sample Partition
% 
% This module partitions samples into:
%   - Xtrain, ClassTrain
%   - Xval,   ClassVal   (optional)
%   - Xtest,  ClassTest  (optional)
%
% Partition modes:
%   1) Rigorous : Xtrain contains only samples from the selected target class
%   2) Compliant: Xtrain may contain selected target and non-target samples
%
% Selection methods:
%   - Random
%   - Kennard-Stone
%   - Duplex
%
% Rules adopted from user specification:
%   - There must always be Train and at least one additional set (Validation or Test)
%   - Validation and Test are optional individually
%   - The user informs the number of target and non-target samples in each set
%   - The sum over Train + Validation + Test must equal the total number of samples
%   - In Rigorous mode, Xtrain must contain only target samples
%
% Exported variables to workspace:
%   Xtrain, ClassTrain, idxTrain
%   Xval,   ClassVal,   idxVal
%   Xtest,  ClassTest,  idxTest
%   partitionInfo
%%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    GUI_VERSION = 'PLS-DM Toolbox GUI v1.0';
    scr = get(0,'ScreenSize');
    fig = figure('Name',['PLS-DM Toolbox - Sample Partition ',GUI_VERSION ], ...
                 'NumberTitle','off', ...
                 'MenuBar','none', ...
                 'Toolbar','none', ...
                 'Color',[0.96 0.94 0.90], ...
                 'Units','pixels', ...
                 'Position',[80 50 min(1320,scr(3)-100) min(760,scr(4)-120)]);

    S = struct();
    S.X = [];
    S.class = [];
    S.Xall = []; S.classAll = []; S.sampleIncluded = []; S.originalRows = []; S.sampleNamesAll = {};
    S.axis = [];
    S.sampleNames = {};
    S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
    S.mode = 'Rigorous';
    S.method = 'Random';
    S.classSplit = 'Binary target/non-target';
    S.targetClass = [];
    S.idxTrain = [];
    S.idxVal = [];
    S.idxTest = [];
    S.classCountsByClass = [];
    S.classColors = [0 0.4470 0.7410; ...
                     0.8500 0.3250 0.0980; ...
                     0.9290 0.6940 0.1250; ...
                     0.4940 0.1840 0.5560; ...
                     0.4660 0.6740 0.1880; ...
                     0.3010 0.7450 0.9330; ...
                     0.6350 0.0780 0.1840];


    % -----------------------------
    % Visual theme and header
    % -----------------------------
    themeDark  = [0.50 0.29 0.08];
    themeLight = [0.96 0.94 0.90];

    S.pnlHeader = uipanel('Parent',fig, ...
                        'Units','normalized','Position',[0.01 0.88 0.98 0.10], ...
                        'BackgroundColor',themeDark, ...
                        'BorderType','none');

    uicontrol('Parent',S.pnlHeader,'Style','text','String','Sample partition', ...
              'Units','normalized','Position',[0.025 0.45 0.60 0.42], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[1 1 1], ...
              'HorizontalAlignment','left','FontSize',17,'FontWeight','bold');

    uicontrol('Parent',S.pnlHeader,'Style','text', ...
              'String','Split samples into training, validation and test sets for rigorous or compliant PLS-DM workflows', ...
              'Units','normalized','Position',[0.025 0.12 0.86 0.26], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[0.92 0.92 0.92], ...
              'HorizontalAlignment','left','FontSize',10);


    uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Help', ...
              'Units','normalized','Position',[0.88 0.25 0.09 0.50], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'ForegroundColor',[0.20 0.12 0.04], ...
              'FontWeight','bold', ...
              'TooltipString','Open a detailed guide for the Sample Partition module.', ...
              'Callback',@onHelp);
    S.btnDataInfo = uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Add data info...', ...
              'Units','normalized','Position',[0.72 0.25 0.145 0.50], ...
              'BackgroundColor',themeLight,'ForegroundColor',themeDark,'FontWeight','bold', ...
              'Enable','off','Callback',@onDataInfo);

    % -------------------------------------------------
    % Control panel
    % -------------------------------------------------
    S.pnlCtrl = uipanel('Parent',fig,'Title','Control', ...
                        'Units','normalized','Position',[0.01 0.02 0.32 0.84], ...
                        'BackgroundColor',[0.96 0.94 0.90], ...
                        'FontWeight','bold');
    S.btnExclude = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Exclude...', ...
              'Units','normalized','Position',[0.69 0.90 0.23 0.045], ...
              'FontWeight','bold','Enable','off','Callback',@onExcludeSamples);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data', ...
              'Units','normalized','Position',[0.05 0.94 0.30 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Load example', ...
              'Units','normalized','Position',[0.05 0.90 0.27 0.045], ...
              'TooltipString','Load simulated spectral data with target and non-target classes.', ...
              'Callback',@onLoadExample);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Import workspace', ...
              'Units','normalized','Position',[0.35 0.90 0.31 0.045], ...
              'TooltipString','Import X, class and optional x-axis variables from the MATLAB workspace.', ...
              'Callback',@onImportWorkspace);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Partition mode', ...
              'Units','normalized','Position',[0.05 0.84 0.30 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupMode = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Rigorous','Compliant'}, ...
              'Units','normalized','Position',[0.05 0.80 0.35 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Choose Rigorous or Compliant partition mode.', ...
              'Callback',@onModeChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Selection method', ...
              'Units','normalized','Position',[0.48 0.84 0.30 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupMethod = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Random','Kennard-Stone','Duplex'}, ...
              'Units','normalized','Position',[0.50 0.80 0.42 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Choose the sample selection algorithm: Random, Kennard-Stone or Duplex.');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Class split strategy', ...
              'Units','normalized','Position',[0.05 0.755 0.35 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupClassSplit = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'Binary target/non-target','All classes'}, ...
              'Units','normalized','Position',[0.40 0.75 0.52 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Binary splits the selected target class versus all non-targets; All classes asks train/validation/test counts for each original class.', ...
              'Callback',@onClassSplitChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Target class', ...
              'Units','normalized','Position',[0.05 0.705 0.30 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.popupTargetClass = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'import data'}, ...
              'Units','normalized','Position',[0.40 0.70 0.25 0.045], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Class treated as target in Binary target/non-target partitioning.', ...
              'Callback',@onTargetClassChanged);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Set activation', ...
              'Units','normalized','Position',[0.05 0.655 0.30 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.chkUseVal = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','Use Validation set', ...
              'Units','normalized','Position',[0.05 0.615 0.40 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'Value',1, ...
              'TooltipString','Enable or disable an external validation set.', ...
              'Callback',@onSetToggle);

    S.chkUseTest = uicontrol('Parent',S.pnlCtrl,'Style','checkbox', ...
              'String','Use Test set', ...
              'Units','normalized','Position',[0.50 0.615 0.35 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'Value',0, ...
              'TooltipString','Enable or disable an independent test set.', ...
              'Callback',@onSetToggle);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Random seed', ...
              'Units','normalized','Position',[0.05 0.575 0.20 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left');

    S.edSeed = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','123', ...
              'Units','normalized','Position',[0.28 0.572 0.16 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Integer seed used only when the Random method is selected.');

    uicontrol('Parent',S.pnlCtrl,'Style','text', ...
              'String','Counts are requested after Run partition.', ...
              'Units','normalized','Position',[0.05 0.525 0.87 0.035], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Run partition', ...
              'Units','normalized','Position',[0.05 0.46 0.28 0.055], ...
              'FontWeight','bold', ...
              'TooltipString','Open the count window and run the partition after checking all rules.', ...
              'Callback',@onRunPartition);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export partition', ...
              'Units','normalized','Position',[0.36 0.46 0.28 0.055], ...
              'TooltipString','Export Xtrain/ClassTrain, Xval/ClassVal, Xtest/ClassTest and partitionInfo to the workspace.', ...
              'Callback',@onExportPartition);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Clear result', ...
              'Units','normalized','Position',[0.67 0.46 0.25 0.055], ...
              'TooltipString','Clear the current partition result without deleting the loaded data.', ...
              'Callback',@onClearPartition);
          % Additional class-split controls.
          uicontrol('Parent',S.pnlCtrl, ...
              'Style','pushbutton', ...
              'String','Export plots', ...
              'Units','normalized', ...
              'Position',[0.67 0.405 0.25 0.045], ...
              'TooltipString','Open the four current partition plots in an external editable figure.', ...
              'Callback',@onExportPlots);
          %-------------------------------
    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Summary', ...
              'Units','normalized','Position',[0.05 0.405 0.20 0.03], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.txtInfo = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'Units','normalized','Position',[0.05 0.03 0.87 0.365], ...
              'BackgroundColor',[1 1 1], ...
              'String',{'Load data to begin.'}, 'Max',2,'Min',0);

    % -------------------------------------------------
    % Visualization panel
    % -------------------------------------------------
    S.pnlView = uipanel('Parent',fig,'Title','Partition visualization', ...
                        'Units','normalized','Position',[0.34 0.02 0.65 0.84], ...
                        'BackgroundColor',[0.96 0.94 0.90], ...
                        'FontWeight','bold');

    S.ax1 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.08 0.56 0.38 0.34]);
    title(S.ax1,'Sample order'); xlabel(S.ax1,'Sample index'); ylabel(S.ax1,'Class'); box(S.ax1,'on');

    S.ax2 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.56 0.35 0.34]);
    title(S.ax2,'Counts by set'); xlabel(S.ax2,'Set'); ylabel(S.ax2,'Samples'); box(S.ax2,'on');

    S.ax3 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.08 0.11 0.38 0.28]);
    title(S.ax3,'Class composition'); xlabel(S.ax3,'Set'); ylabel(S.ax3,'Samples'); box(S.ax3,'on');

    S.ax4 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.11 0.35 0.28]);
    title(S.ax4,'X overview'); xlabel(S.ax4,'Variable'); ylabel(S.ax4,'Sample'); box(S.ax4,'on');

    guidata(fig,S);
    updateControls(fig);

    % ============================================================
    % Callbacks
    % ============================================================
    function onHelp(hObj,ev)
        helpFig = figure('Name','PLS-DM Toolbox - Sample Partition Help', ...
                         'NumberTitle','off', ...
                         'MenuBar','none', ...
                         'Toolbar','none', ...
                         'Color',[1 1 1], ...
                         'Units','normalized', ...
                         'Position',[0.18 0.10 0.64 0.78]);

         helpPanel = uipanel('Parent',helpFig, ...
                             'Units','normalized', ...
                             'Position',[0.02 0.02 0.96 0.96], ...
                             'BackgroundColor',[1 1 1], ...
                             'Title','', ...
                             'FontWeight','bold');

        helpText = { ...
% 'PLS-DM TOOLBOX - SAMPLE PARTITION MODULE'; ...
' '; ...
'PURPOSE OF THIS MODULE'; ...
'This module divides the available samples into Training, Validation and/or Test sets before PLS-DM modeling.'; ...
'The exported variables are then used by the optimization and fit/validation modules.'; ...
' '; ...
'IMPORTANT CLASS CONVENTION'; ...
'- In Binary target/non-target mode, the target class is selected in the Target class dropdown.'; ...
'- Any class different from the selected target is interpreted as NON-TARGET.'; ...
'- In All classes mode, each original class is treated as a target once by the Fit & Validation All option.'; ...
' '; ...
'GENERAL WORKFLOW'; ...
'1. Load data using Load example or Import workspace.'; ...
'2. Choose the Partition mode: Rigorous or Compliant.'; ...
'3. Choose the Selection method: Random, Kennard-Stone or Duplex.'; ...
'4. Choose the Class split strategy: Binary target/non-target or All classes.'; ...
'4. Enable Validation and/or Test sets. At least one of them must remain enabled.'; ...
'5. Click Run partition and enter the requested sample counts in the external count window.'; ...
'6. Confirm the count window to run the partition.'; ...
'7. Inspect the four plots and the summary panel.'; ...
'8. Click Export partition to send the selected matrices and indices to the workspace.'; ...
' '; ...
'PARTITION MODES'; ...
' '; ...
'Rigorous mode:'; ...
'- The training set contains only samples from the selected target class.'; ...
'- The Train non-target field is automatically forced to zero.'; ...
'- Non-target samples are kept only for Validation and/or Test.'; ...
'- This mode is appropriate for strict one-class modeling, where only the authentic/target class is used to build the model.'; ...
' '; ...
'Compliant mode:'; ...
'- The training set may contain both target and non-target samples.'; ...
'- This mode can be useful when the workflow explicitly uses both target and non-target information during model optimization.'; ...
'- It is less strict than rigorous mode and should be used only when this matches the intended validation philosophy.'; ...
' '; ...
'SET ACTIVATION'; ...
'- Validation set: used for external validation or model assessment after training.'; ...
'- Test set: used as an additional independent evaluation set.'; ...
'- The GUI requires Train plus at least one additional set: Validation or Test.'; ...
'- If Validation or Test is disabled, its requested counts must be zero.'; ...
' '; ...
'REQUESTED COUNTS'; ...
'- Target means samples belonging to the selected target class.'; ...
'- Non-target means all samples whose class label is different from the selected target class.'; ...
'- The sum of target counts across Train + Validation + Test must equal the total number of target samples.'; ...
'- The sum of non-target counts across Train + Validation + Test must equal the total number of non-target samples.'; ...
'- If these sums do not match the available data, the GUI stops and shows an error.'; ...
' '; ...
'SELECTION METHODS'; ...
' '; ...
' ';
'CLASS PARTITION STRATEGY';
' ';
'The GUI supports two strategies for handling class structure during partition:';
' ';
'Binary (target vs non-target):';
'- Samples from the selected target class are treated as target.';
'- All other classes are grouped together as a single non-target group.';
'- Partitioning is performed separately for target and non-target groups.';
'- This is the default and recommended mode for strict one-class classification (PLS-DM).';
' ';
'All classes:';
'- Each original class is treated independently during partition.';
'- When Run partition is clicked, a window asks Train, Validation and Test counts for every class.';
'- The selection method (Random, Kennard-Stone or Duplex) is applied separately to each class.';
'- The final Xtrain, Xval and Xtest matrices are obtained by combining the selected samples from all classes.';
'- This format is ready for the Fit & Validation All option, where each class is modelled one-vs-rest.';
' ';
'When to use each strategy:';
'- Use Binary mode for classical one-class modeling and authenticity problems.';
'- Use All classes mode when every original class will be modelled with the Fit & Validation All option.';
' ';
'Random:'; ...
'- Samples are randomly assigned according to the requested counts.'; ...
'- The Random seed controls reproducibility.'; ...
'- Using the same seed and same data should reproduce the same random split.'; ...
' '; ...
'Kennard-Stone:'; ...
'- Selects samples to maximize coverage of the multivariate X-space.'; ...
'- The first samples are the most distant pair, followed by samples farthest from those already selected.'; ...
'- It is useful when the training set should represent the chemical/spectral variability of the class.'; ...
' '; ...
'Duplex:'; ...
'- Also uses distances in X-space, but distributes representative samples into different groups.'; ...
'- It is useful when both training and validation/test sets should span similar variability.'; ...
' '; ...
'HOW SELECTION IS APPLIED'; ...
'- Target and non-target groups are partitioned separately.'; ...
'- After selection, the final Train, Validation and Test indices are combined.'; ...
'- In Rigorous mode, a final check ensures that Train contains only target samples.'; ...
' '; ...
'PLOT INTERPRETATION'; ...
' '; ...
'Sample order:'; ...
'- Shows each sample index versus its class label.'; ...
'- Selected Train, Validation and Test samples are highlighted with different markers.'; ...
' '; ...
'Counts by set:'; ...
'- Shows the total number of samples assigned to Train, Validation and Test.'; ...
' '; ...
'Target / non-target:'; ...
'- Shows the composition of each set in terms of target and non-target samples.'; ...
'- This is especially important for checking rigorous versus compliant behavior.'; ...
' '; ...
'X overview:'; ...
'- Displays a heatmap of the full X matrix.'; ...
'- Colored rectangles indicate samples assigned to Train, Validation and Test.'; ...
' '; ...
'EXPORTED VARIABLES'; ...
'After clicking Export partition, the following variables are sent to the MATLAB workspace:'; ...
'- Xtrain, ClassTrain, idxTrain'; ...
'- Xval, ClassVal, idxVal'; ...
'- Xtest, ClassTest, idxTest'; ...
'- partitionInfo'; ...
' '; ...
'partitionInfo includes:'; ...
'- selected mode and method'; ...
'- number of samples in each set'; ...
'- number of target and non-target samples in each set'; ...
'- original sample indices assigned to Train, Validation and Test'; ...
' '; ...
'BUTTON-BY-BUTTON REFERENCE'; ...
' '; ...
'Help: opens this reference and preserves the loaded data and current partition.'; ...
'Load example: replaces current GUI data with simulated target/non-target profiles and resets any previous partition.'; ...
'Import workspace: selects X, Class and optional x-axis. It checks row/label and axis/column dimensions and clears the previous partition.'; ...
'Exclude: removes selected samples or complete classes from the pool available for partitioning without deleting the original data.'; ...
'  Run the partition again after changing inclusion. Exported idxTrain, idxVal and idxTest continue to refer to original matrix rows.'; ...
'Run partition: validates the selected mode, method, class strategy and enabled sets, then opens a count dialog.'; ...
'  In Binary mode the dialog requests Target and Non-target counts. In All classes mode it requests counts for every original class.'; ...
'  OK validates that requested counts equal available samples and calculates the split. Cancel closes the dialog without replacing the current result.'; ...
'Export partition: requires a calculated result and exports enabled matrices, class vectors, original indices and partitionInfo.'; ...
'Clear result: removes calculated indices, exported-preview summaries and plot highlights, but keeps X, Class and x-axis loaded.'; ...
'Use Validation set / Use Test set: enable the subset and its count fields. Disabled subsets must receive zero samples.'; ...
'Random seed: affects only Random selection. Kennard-Stone and Duplex ignore this field.'; ...
' '; ...
'PRACTICAL RECOMMENDATIONS'; ...
'- Use Rigorous mode when developing a pure one-class target model.'; ...
'- Use Compliant mode only when non-target information is intentionally allowed in training.'; ...
'- Prefer Kennard-Stone or Duplex when spectral representativeness is important.'; ...
'- Use Random with a fixed seed for simple reproducible splits.'; ...
'- Always inspect the plots before exporting the partition.'; ...
' '; ...
'COMMON ERRORS'; ...
'- Train non-target > 0 in Rigorous mode: not allowed.'; ...
'- Validation disabled but validation counts > 0: not allowed.'; ...
'- Test disabled but test counts > 0: not allowed.'; ...
'- Target or non-target counts do not sum to the total available samples.'; ...
'- X rows and class vector length are inconsistent.'; ...
' '; ...
'MATLAB WORKSPACE INPUT FORMAT'; ...
'- X must be an n x p matrix, with samples in rows and variables in columns.'; ...
'- class must be an n x 1 vector or 1 x n vector.'; ...
'- axis is optional and should have p values if used.'; ...
' '};

        uicontrol('Parent',helpPanel,'Style','edit', ...
                  'Units','normalized', ...
                  'Position',[0.02 0.02 0.96 0.96], ...
                  'String',helpText, ...
                  'Max',2,'Min',0, ...
                  'HorizontalAlignment','left', ...
                  'BackgroundColor',[1 1 1], ...
                  'FontName','Courier New', ...
                  'FontSize',10);
    end

    function onLoadExample(hObj,ev)
        S = guidata(hObj);
        [X,classv,axisv,sampleNames] = createExampleData();
        S.X = X;
        S.class = classv;
        S.Xall = X; S.classAll = classv(:); S.sampleIncluded = true(size(X,1),1);
        S.originalRows = (1:size(X,1))'; S.sampleNamesAll = sampleNames(:);
        S.axis = axisv;
        S.sampleNames = sampleNames;
        S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
        set(S.btnDataInfo,'Enable','on','String','Add data info...');
        set(S.btnExclude,'Enable','on');
        guidata(hObj,S);
        updateTargetClassMenu(hObj);
        autoSuggestCounts(hObj);
        refreshSummary(hObj,{'Example data loaded.'});
        refreshPlots(hObj);
    end

    function onImportWorkspace(hObj,ev)
        S = guidata(hObj);
        [ok,names,vals] = plsdm_select_workspace_vars('Import workspace', ...
            {'X matrix','Class vector','x-axis vector'}, {'X','class','axis'}, {false,false,true});
        if ~ok, return; end
        try
            X = vals{1};
            classv = vals{2};
            if size(classv,1) == 1
                classv = classv';
            end
            if isempty(vals{3})
                axisv = 1:size(X,2);
            else
                axisv = vals{3};
            end
            if size(X,1) ~= length(classv)
                error('X rows and class length are inconsistent.');
            end
            S.X = X;
            S.class = classv;
            S.Xall = X; S.classAll = classv(:); S.sampleIncluded = true(size(X,1),1);
            S.originalRows = (1:size(X,1))';
            S.axis = axisv(:)';
            S.sampleNames = buildSampleNames(size(X,1));
            S.sampleNamesAll = S.sampleNames(:);
            S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
            set(S.btnDataInfo,'Enable','on','String','Add data info...');
            set(S.btnExclude,'Enable','on');
            guidata(hObj,S);
            updateTargetClassMenu(hObj);
            autoSuggestCounts(hObj);
            refreshSummary(hObj,{'Data imported from workspace.'});
            refreshPlots(hObj);
        catch ME
            errordlg(['Import error: ' ME.message],'Import');
        end
    end

    function onDataInfo(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X), errordlg('Load data before adding data information.','Add data info'); return; end
        [info,applied] = plsdm_add_data_info(fig,S.class,size(S.X,1),S.dataInfo);
        if ~applied, return; end
        S.dataInfo = info;
        if ~isempty(info.sampleNames), S.sampleNames = info.sampleNames; else, S.sampleNames = buildSampleNames(size(S.X,1)); end
        S.sampleNamesAll(S.sampleIncluded) = S.sampleNames(:);
        set(S.btnDataInfo,'String','Edit data info...'); guidata(fig,S); refreshPlots(fig);
    end

    function onExcludeSamples(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xall), errordlg('Load data first.','Exclude samples'); return; end
        d = struct('label','Data to partition','X',S.Xall,'classDisplay',{num2cell(S.classAll(:))}, ...
            'sampleNames',{S.sampleNamesAll(:)},'originalRows',S.originalRows(:),'included',S.sampleIncluded(:));
        [applied,d] = plsdm_exclude_samples_dialog(fig,d);
        if ~applied || isequal(S.sampleIncluded,d.included), return; end
        S.sampleIncluded = d.included; S.X = S.Xall(S.sampleIncluded,:);
        S.class = S.classAll(S.sampleIncluded); S.sampleNames = S.sampleNamesAll(S.sampleIncluded);
        S.dataInfo.sampleNames = S.sampleNames;
        S.idxTrain = []; S.idxVal = []; S.idxTest = []; S.classCountsByClass = [];
        guidata(hObj,S); updateTargetClassMenu(hObj); autoSuggestCounts(hObj); refreshPlots(hObj);
        refreshSummary(hObj,{'Sample selection changed; run the partition again.'});
        msgbox('Sample selection updated. Run the partition again to visualize the updated results.','Sample selection updated');
    end

    function onModeChanged(hObj,ev)
        updateControls(hObj);
        autoSuggestCounts(hObj);
    end

    function onSetToggle(hObj,ev)
        updateControls(hObj);
    end

%     function onClassSplitChanged(hObj,ev)
%         updateControls(hObj);
%         refreshSummary(hObj,{});
%     end
    function onClassSplitChanged(hObj,ev) %AAG - 30/07/2026
        updateControls(hObj);
        refreshSummary(hObj,{});
        refreshPlots(hObj);
    end
    function onTargetClassChanged(hObj,ev)
        S = guidata(hObj);
        S.targetClass = getSelectedTargetClass(S);
        guidata(hObj,S);
        refreshSummary(hObj,{});
        refreshPlots(hObj);
    end

    function onRunPartition(hObj,ev)
        S = guidata(hObj);
        if isempty(S.X)
            errordlg('No data loaded.','Partition');
            return;
        end
        modeList = get(S.popupMode,'String');
        methodList = get(S.popupMethod,'String');
        classSplitList = get(S.popupClassSplit,'String');
        S.mode = modeList{get(S.popupMode,'Value')};
        S.method = methodList{get(S.popupMethod,'Value')};
        S.classSplit = classSplitList{get(S.popupClassSplit,'Value')};
        isAllClass = is_all_class_partition(S.classSplit);
        S.targetClass = getSelectedTargetClass(S);
        if ~isAllClass && isempty(S.targetClass)
            errordlg('Select a target class before running binary partition.','Partition');
            return;
        end

        if strcmpi(S.method,'Random')
            try
                localApplyRandomSeed(get(S.edSeed,'String'));
            catch ME
                errordlg(ME.message,'Seed');
                return;
            end
        end

        useVal = logical(get(S.chkUseVal,'Value'));
        useTest = logical(get(S.chkUseTest,'Value'));

        if ~(useVal || useTest)
            errordlg('There must be Train and at least one additional set (Validation or Test).','Partition rule');
            return;
        end

        targetClass = S.targetClass;
        idxTarget = find(S.class == targetClass);
        idxNonTarget = find(S.class ~= targetClass);

        try
            S.classCountsByClass = [];
            if isAllClass
                [okClassReq,classReq] = promptAllClassCounts(S.class,useVal,useTest);
                if ~okClassReq
                    return;
                end
                partAll = selectAndSplitByExplicitClassCounts(S.X, S.class, classReq, S.method);
                S.idxTrain = partAll.train(:);
                S.idxVal   = partAll.val(:);
                S.idxTest  = partAll.test(:);
                S.classCountsByClass = classReq;
            else
                [okReq,req] = promptBinaryCounts(S.class,targetClass,S.mode,useVal,useTest);
                if ~okReq
                    return;
                end
                nTarget = length(idxTarget);
                nNonTarget = length(idxNonTarget);
                nTotal = length(S.class);

                sumTarget = req.trainTarget + req.valTarget + req.testTarget;
                sumNonTarget = req.trainNonTarget + req.valNonTarget + req.testNonTarget;

                if sumTarget ~= nTarget
                    errordlg(sprintf('Target counts do not sum to total target samples. Requested = %d, available = %d.',sumTarget,nTarget), ...
                             'Partition rule');
                    return;
                end
                if sumNonTarget ~= nNonTarget
                    errordlg(sprintf('Non-target counts do not sum to total non-target samples. Requested = %d, available = %d.',sumNonTarget,nNonTarget), ...
                             'Partition rule');
                    return;
                end
                if (sumTarget + sumNonTarget) ~= nTotal
                    errordlg('Total requested counts do not match the total number of samples.','Partition rule');
                    return;
                end
                partTarget = selectAndSplitIndicesImproved(S.X, idxTarget, req.trainTarget, req.valTarget, req.testTarget, S.method);
                partNonTarget = selectAndSplitIndicesImproved(S.X, idxNonTarget, req.trainNonTarget, req.valNonTarget, req.testNonTarget, S.method);
                S.idxTrain = [partTarget.train(:); partNonTarget.train(:)];
                S.idxVal   = [partTarget.val(:);   partNonTarget.val(:)];
                S.idxTest  = [partTarget.test(:);  partNonTarget.test(:)];
            end
        catch ME
            errordlg(['Partition error: ' ME.message],'Partition');
            return;
        end

        if strcmpi(S.mode,'Rigorous') && ~isAllClass
            if any(S.class(S.idxTrain) ~= targetClass)
                errordlg('Rigorous mode violation: Train contains non-target samples.','Partition');
                return;
            end
        end

        S.idxTrain = sort(S.idxTrain(:));
        S.idxVal   = sort(S.idxVal(:));
        S.idxTest  = sort(S.idxTest(:));

        guidata(hObj,S);
        refreshPlots(hObj);
        refreshSummary(hObj,buildPartitionSummary(S));
    end

    function onExportPartition(hObj,ev)
        S = guidata(hObj);
        if isempty(S.idxTrain) && isempty(S.idxVal) && isempty(S.idxTest)
            errordlg('No partition result available.','Export');
            return;
        end

        Xtrain = S.X(S.idxTrain,:);
        ClassTrain = S.class(S.idxTrain,:);
        includedRows = S.originalRows(S.sampleIncluded);
        idxTrain = includedRows(S.idxTrain);

        Xval = S.X(S.idxVal,:);
        ClassVal = S.class(S.idxVal,:);
        idxVal = includedRows(S.idxVal);

        Xtest = S.X(S.idxTest,:);
        ClassTest = S.class(S.idxTest,:);
        idxTest = includedRows(S.idxTest);

        partitionInfo = struct();
        partitionInfo.mode = S.mode;
        partitionInfo.method = S.method;
        partitionInfo.classSplit = S.classSplit;
        partitionInfo.allClassReady = is_all_class_partition(S.classSplit);
        if partitionInfo.allClassReady
            partitionInfo.targetClass = [];
        else
            partitionInfo.targetClass = S.targetClass;
        end
        partitionInfo.nTrain = length(idxTrain);
        partitionInfo.nVal = length(idxVal);
        partitionInfo.nTest = length(idxTest);
        if partitionInfo.allClassReady
            partitionInfo.nTrainTarget = [];
            partitionInfo.nTrainNonTarget = [];
            partitionInfo.nValTarget = [];
            partitionInfo.nValNonTarget = [];
            partitionInfo.nTestTarget = [];
            partitionInfo.nTestNonTarget = [];
        else
            partitionInfo.nTrainTarget = sum(ClassTrain==S.targetClass);
            partitionInfo.nTrainNonTarget = sum(ClassTrain~=S.targetClass);
            partitionInfo.nValTarget = sum(ClassVal==S.targetClass);
            partitionInfo.nValNonTarget = sum(ClassVal~=S.targetClass);
            partitionInfo.nTestTarget = sum(ClassTest==S.targetClass);
            partitionInfo.nTestNonTarget = sum(ClassTest~=S.targetClass);
        end
        partitionInfo.idxTrain = idxTrain;
        partitionInfo.idxVal = idxVal;
        partitionInfo.idxTest = idxTest;
        hasSampleNames = isfield(S,'dataInfo') && isfield(S.dataInfo,'sampleNames') && ...
            numel(S.dataInfo.sampleNames) == size(S.X,1);
        if hasSampleNames
            SamplesTrain = S.dataInfo.sampleNames(S.idxTrain);
            SamplesVal = S.dataInfo.sampleNames(S.idxVal);
            SamplesTest = S.dataInfo.sampleNames(S.idxTest);
            partitionInfo.SamplesTrain = SamplesTrain;
            partitionInfo.SamplesVal = SamplesVal;
            partitionInfo.SamplesTest = SamplesTest;
        end
        if isfield(S,'classCountsByClass') && ~isempty(S.classCountsByClass)
            partitionInfo.classCountsByClass = S.classCountsByClass;
        else
            partitionInfo.classCountsByClass = buildClassCountsStruct(S.class,S.idxTrain,S.idxVal,S.idxTest);
        end

        assignin('base','Xtrain',Xtrain);
        assignin('base','ClassTrain',ClassTrain);
        assignin('base','idxTrain',idxTrain);
        assignin('base','Xval',Xval);
        assignin('base','ClassVal',ClassVal);
        assignin('base','idxVal',idxVal);
        assignin('base','Xtest',Xtest);
        assignin('base','ClassTest',ClassTest);
        assignin('base','idxTest',idxTest);
        if hasSampleNames
            assignin('base','SamplesTrain',SamplesTrain);
            assignin('base','SamplesVal',SamplesVal);
            assignin('base','SamplesTest',SamplesTest);
        end
        assignin('base','partitionInfo',partitionInfo);

        sampleMessage = '';
        if hasSampleNames
            sampleMessage = ['SamplesTrain, SamplesVal, SamplesTest' char(10)];
        end
        msgbox(['Exported to workspace:' char(10) ...
                'Xtrain, ClassTrain, idxTrain' char(10) ...
                'Xval, ClassVal, idxVal' char(10) ...
                'Xtest, ClassTest, idxTest' char(10) ...
                sampleMessage ...
                'partitionInfo (including idxTrain, idxVal, idxTest)'],'Export');
    end

    function onExportPlots(hObj,ev)
        S = guidata(hObj);

        if isempty(S.X)
            errordlg('Load data before exporting the plots.','Export plots');
            return;
        end
        selected = plsdm_select_plots_to_export(fig,{'Sample order','Counts by set','Class composition','X overview'});
        if isempty(selected), return; end

        f = figure( ...
            'Name','PLS-DM Sample Partition - Current plots', ...
            'NumberTitle','off', ...
            'MenuBar','figure', ...
            'Toolbar','figure', ...
            'Color',[1 1 1], ...
            'Units','normalized', ...
            'Position',[0.08 0.08 0.84 0.82]);

        sourceAxes = [S.ax1 S.ax2 S.ax3 S.ax4];
        n = numel(selected); nr = ceil(sqrt(n)); nc = ceil(n/nr); exportedAxes = [];
        for jj = 1:n
            placeholder = subplot(nr,nc,jj,'Parent',f); pos = get(placeholder,'Position'); delete(placeholder);
            axCopy = copyobj(sourceAxes(selected(jj)),f); set(axCopy,'Units','normalized','Position',pos);
            exportedAxes(end+1) = axCopy;
        end
        for ii = 1:length(exportedAxes)
            set(exportedAxes(ii), ...
                'Color',[1 1 1], ...
                'FontName','Arial', ...
                'FontSize',10, ...
                'Box','on');
        end
    end

    function onClearPartition(hObj,ev)
        S = guidata(hObj);
        S.idxTrain = [];
        S.idxVal = [];
        S.idxTest = [];
        S.classCountsByClass = [];
        guidata(hObj,S);
        refreshPlots(hObj);
        refreshSummary(hObj,{'Partition result cleared.'});
    end

    
    % ============================================================
    function updateControls(hObj)
        S = guidata(hObj);
        modeList = get(S.popupMode,'String');
        S.mode = modeList{get(S.popupMode,'Value')};
        classSplitList = get(S.popupClassSplit,'String');
        S.classSplit = classSplitList{get(S.popupClassSplit,'Value')};

        useVal = logical(get(S.chkUseVal,'Value'));
        useTest = logical(get(S.chkUseTest,'Value'));

        if ~useVal && ~useTest
            set(S.chkUseVal,'Value',1);
            useVal = true;
        end

        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            if is_all_class_partition(S.classSplit)
                set(S.popupTargetClass,'Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
            else
                set(S.popupTargetClass,'Enable','on','BackgroundColor',[1 1 1]);
            end
        end

        guidata(hObj,S);
    end

    function updateTargetClassMenu(hObj)
        S = guidata(hObj);
        if isempty(S.class)
            if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
                set(S.popupTargetClass,'String',{'import data'},'Value',1);
            end
            S.targetClass = [];
            guidata(hObj,S);
            return;
        end

        classes = unique(S.class(:));
        labels = cell(length(classes),1);
        for ii = 1:length(classes)
            labels{ii} = num2str(classes(ii));
        end

        oldTarget = [];
        if isfield(S,'targetClass')
            oldTarget = S.targetClass;
        end
        val = 1;
        if ~isempty(oldTarget)
            oldIdx = find(classes == oldTarget,1);
            if ~isempty(oldIdx)
                val = oldIdx;
            end
        end

        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            set(S.popupTargetClass,'String',labels,'Value',val);
        end
        S.targetClass = classes(val);
        guidata(hObj,S);
        updateControls(hObj);
    end

    function targetClass = getSelectedTargetClass(S)
        targetClass = [];
        if isempty(S.class)
            return;
        end
        classes = unique(S.class(:));
        if isempty(classes)
            return;
        end
        idx = 1;
        if isfield(S,'popupTargetClass') && ishandle(S.popupTargetClass)
            idx = get(S.popupTargetClass,'Value');
        elseif isfield(S,'targetClass') && ~isempty(S.targetClass)
            oldIdx = find(classes == S.targetClass,1);
            if ~isempty(oldIdx)
                idx = oldIdx;
            end
        end
        idx = max(1,min(idx,length(classes)));
        targetClass = classes(idx);
    end

    function autoSuggestCounts(hObj)
        % Counts are now requested in modal dialogs when Run partition is clicked.
    end

    function refreshPlots(hObj)
        S = guidata(hObj);
        cla(S.ax1); cla(S.ax2); cla(S.ax3); cla(S.ax4);
        if isempty(S.X)
            return;
        end

        % ax1: sample order and set assignment
        axes(S.ax1); cla; hold on;
        idxAll = (1:length(S.class))';
        hAll = plot(idxAll, S.class, 'ko','MarkerSize',4,'MarkerFaceColor',[0.8 0.8 0.8]);
        legendHandles = hAll;
        legendStrings = {'All'};
        if ~isempty(S.idxTrain)
            hTrain = plot(S.idxTrain, S.class(S.idxTrain), 's', 'MarkerSize',7, 'MarkerFaceColor',[0 0.6 0], 'MarkerEdgeColor','k');
            legendHandles(end+1) = hTrain;
            legendStrings{end+1} = 'Train';
        end
        if ~isempty(S.idxVal)
            hVal = plot(S.idxVal, S.class(S.idxVal), 'd', 'MarkerSize',7, 'MarkerFaceColor',[0 0.45 0.85], 'MarkerEdgeColor','k');
            legendHandles(end+1) = hVal;
            legendStrings{end+1} = 'Validation';
        end
        if ~isempty(S.idxTest)
            hTest = plot(S.idxTest, S.class(S.idxTest), '^', 'MarkerSize',7, 'MarkerFaceColor',[0.85 0.2 0.2], 'MarkerEdgeColor','k');
            legendHandles(end+1) = hTest;
            legendStrings{end+1} = 'Test';
        end
        xlabel('Sample index'); ylabel('Class'); title('Sample order');
        legend(legendHandles,legendStrings,'Location','Best');
        box on; grid on; hold off;

        % ax2: counts by set
        axes(S.ax2); cla;
        counts = [length(S.idxTrain) length(S.idxVal) length(S.idxTest)];
        bar(counts);
        set(gca,'XTick',[1 2 3],'XTickLabel',{'Train','Val','Test'});
        ylabel('Samples'); title('Counts by set'); box on;

        % ax3: composition of Train, Validation and Test
        axes(S.ax3); cla;
        setNames = {'Train','Val','Test'};
        setIndices = {S.idxTrain,S.idxVal,S.idxTest};

        if is_all_class_partition(S.classSplit)
            classes = unique(S.class(:));
            nClasses = length(classes);
            classCounts = zeros(3,nClasses);

            for kk = 1:3
                idxSet = setIndices{kk};
                for cc = 1:nClasses
                    classCounts(kk,cc) = sum(S.class(idxSet) == classes(cc));
                end
            end

            bh = bar(S.ax3,classCounts,'stacked');
            legendText = cell(nClasses,1);

            for cc = 1:nClasses
                colorIndex = 1 + mod(cc-1,size(S.classColors,1));
                set(bh(cc), ...
                    'FaceColor',S.classColors(colorIndex,:), ...
                    'EdgeColor',[0.25 0.25 0.25]);
                legendText{cc} = plsdm_data_info_class_name(S.dataInfo,classes(cc));
            end

            set(S.ax3,'XTick',[1 2 3],'XTickLabel',setNames);
            xlabel(S.ax3,'Set');
            ylabel(S.ax3,'Samples');
            title(S.ax3,'Class composition by set');

            if ~isempty(bh)
                legend(S.ax3,bh,legendText,'Location','Best');
            end
        else
            targetClass = getSelectedTargetClass(S);
            targetCounts = zeros(1,3);
            nonTargetCounts = zeros(1,3);

            for kk = 1:3
                idxSet = setIndices{kk};
                targetCounts(kk) = sum(S.class(idxSet) == targetClass);
                nonTargetCounts(kk) = sum(S.class(idxSet) ~= targetClass);
            end

            bh = bar(S.ax3,[targetCounts(:) nonTargetCounts(:)],'stacked');

            if length(bh) >= 2
                set(bh(1), ...
                    'FaceColor',[0 0.4470 0.7410], ...
                    'EdgeColor',[0.25 0.25 0.25]);
                set(bh(2), ...
                    'FaceColor',[0.8500 0.3250 0.0980], ...
                    'EdgeColor',[0.25 0.25 0.25]);
            end

            set(S.ax3,'XTick',[1 2 3],'XTickLabel',setNames);
            xlabel(S.ax3,'Set');
            ylabel(S.ax3,'Samples');
            title(S.ax3,['Target class ' num2str(targetClass) ' / non-target']);
            legend(S.ax3, ...
                {['Target (=' num2str(targetClass) ')'], ...
                 ['Non-target (~=' num2str(targetClass) ')']}, ...
                'Location','Best');
        end

        box(S.ax3,'on');
        grid(S.ax3,'on');

        % ax4: heatmap overview
        axes(S.ax4); cla;
        imagesc(S.X);
        xLabelText = 'Variable';
        if ~isempty(S.dataInfo.xLabel), xLabelText = S.dataInfo.xLabel; end
        xlabel(xLabelText); ylabel('Sample'); title('X overview'); colorbar;
        hold on;

        nVar = size(S.X,2);
        if ~isempty(S.idxTrain)
            for i = 1:length(S.idxTrain)
                y = S.idxTrain(i);
                rectangle('Position',[0.5, y-0.5, nVar, 1], ...
                          'EdgeColor',[0 0.6 0], 'LineWidth',1.2);
            end
        end
        if ~isempty(S.idxVal)
            for i = 1:length(S.idxVal)
                y = S.idxVal(i);
                rectangle('Position',[0.5, y-0.5, nVar, 1], ...
                          'EdgeColor',[0 0.45 0.85], 'LineWidth',1.2);
            end
        end
        if ~isempty(S.idxTest)
            for i = 1:length(S.idxTest)
                y = S.idxTest(i);
                rectangle('Position',[0.5, y-0.5, nVar, 1], ...
                          'EdgeColor',[0.85 0.2 0.2], 'LineWidth',1.2);
            end
        end

        legendStrings = {};
        legendHandles = [];
        if ~isempty(S.idxTrain)
            legendHandles(end+1) = plot(nan,nan,'s','MarkerFaceColor',[0 0.6 0],'MarkerEdgeColor','k');
            legendStrings{end+1} = 'Train';
        end
        if ~isempty(S.idxVal)
            legendHandles(end+1) = plot(nan,nan,'d','MarkerFaceColor',[0 0.45 0.85],'MarkerEdgeColor','k');
            legendStrings{end+1} = 'Validation';
        end
        if ~isempty(S.idxTest)
            legendHandles(end+1) = plot(nan,nan,'^','MarkerFaceColor',[0.85 0.2 0.2],'MarkerEdgeColor','k');
            legendStrings{end+1} = 'Test';
        end
        if ~isempty(legendHandles)
            legend(legendHandles,legendStrings,'Location','Best');
        end
        hold off;
    end

    function refreshSummary(hObj,msg)
        S = guidata(hObj);
        txt = {};
        if ~isempty(S.X)
            targetClass = getSelectedTargetClass(S);
            txt{end+1} = ['Total samples: ' num2str(size(S.X,1))];
            txt{end+1} = ['Variables: ' num2str(size(S.X,2))];
            if is_all_class_partition(S.classSplit)
                txt{end+1} = 'Target mode: all classes';
            else
                txt{end+1} = ['Target class: ' num2str(targetClass)];
                txt{end+1} = ['Target (=' num2str(targetClass) '): ' num2str(sum(S.class==targetClass))];
                txt{end+1} = ['Non-target (~=' num2str(targetClass) '): ' num2str(sum(S.class~=targetClass))];
            end
        end
        if nargin >= 2 && ~isempty(msg)
            txt = [txt(:); {' '}; msg(:)];
        end
        if isempty(txt)
            txt = {'Load data to begin.'};
        end
        set(S.txtInfo,'String',txt);
    end

    function txt = buildPartitionSummary(S)
        txt = {};
        txt{end+1} = ['Mode: ' S.mode];
        txt{end+1} = ['Method: ' S.method];
        if isfield(S,'classSplit'), txt{end+1} = ['Class split: ' S.classSplit]; end
        if is_all_class_partition(S.classSplit)
            txt{end+1} = 'All-class ready: yes';
        end
        targetClass = getSelectedTargetClass(S);
        if ~is_all_class_partition(S.classSplit)
            txt{end+1} = ['Target class: ' num2str(targetClass)];
        end
        txt{end+1} = ['Train: ' num2str(length(S.idxTrain)) ' samples'];
        if ~is_all_class_partition(S.classSplit)
            txt{end+1} = ['  Target: ' num2str(sum(S.class(S.idxTrain)==targetClass)) ', Non-target: ' num2str(sum(S.class(S.idxTrain)~=targetClass))];
        end
        txt{end+1} = ['Validation: ' num2str(length(S.idxVal)) ' samples'];
        if ~is_all_class_partition(S.classSplit)
            txt{end+1} = ['  Target: ' num2str(sum(S.class(S.idxVal)==targetClass)) ', Non-target: ' num2str(sum(S.class(S.idxVal)~=targetClass))];
        end
        txt{end+1} = ['Test: ' num2str(length(S.idxTest)) ' samples'];
        if ~is_all_class_partition(S.classSplit)
            txt{end+1} = ['  Target: ' num2str(sum(S.class(S.idxTest)==targetClass)) ', Non-target: ' num2str(sum(S.class(S.idxTest)~=targetClass))];
        end
        if is_all_class_partition(S.classSplit)
            Ctab = buildClassCountsStruct(S.class,S.idxTrain,S.idxVal,S.idxTest);
            for ii = 1:length(Ctab.classes)
                txt{end+1} = ['  Class ' num2str(Ctab.classes(ii)) ': train ' num2str(Ctab.train(ii)) ...
                              ', val ' num2str(Ctab.val(ii)) ', test ' num2str(Ctab.test(ii))];
            end
        end
    end
end

% ================================================================
% All-class partition dialog and helpers
% ================================================================
function tf = is_all_class_partition(classSplit)
    tf = false;
    if isempty(classSplit)
        return;
    end
    tf = ~isempty(strfind(lower(classSplit),'all classes')) || ...
         ~isempty(strfind(lower(classSplit),'multiclass'));
end

function counts = buildClassCountsStruct(classv,idxTrain,idxVal,idxTest)
    classes = unique(classv(:));
    counts = struct();
    counts.classes = classes(:);
    counts.available = zeros(length(classes),1);
    counts.train = zeros(length(classes),1);
    counts.val = zeros(length(classes),1);
    counts.test = zeros(length(classes),1);
    for ii = 1:length(classes)
        c = classes(ii);
        counts.available(ii) = sum(classv == c);
        counts.train(ii) = sum(classv(idxTrain) == c);
        counts.val(ii) = sum(classv(idxVal) == c);
        counts.test(ii) = sum(classv(idxTest) == c);
    end
end

function [ok,req] = promptBinaryCounts(classv,targetClass,modeStr,useVal,useTest)
    ok = false;
    req = [];

    available = [sum(classv(:) == targetClass); sum(classv(:) ~= targetClass)];
    labels = {['Target (=' num2str(targetClass) ')']; ['Non-target (~=' num2str(targetClass) ')']};
    trainDefault = zeros(2,1);
    valDefault = zeros(2,1);
    testDefault = zeros(2,1);

    for ii = 1:2
        [trainDefault(ii),valDefault(ii),testDefault(ii)] = defaultAllClassCounts(available(ii),useVal,useTest);
    end
    if strcmpi(modeStr,'Rigorous')
        trainDefault(2) = 0;
        if useVal && ~useTest
            valDefault(2) = available(2);
            testDefault(2) = 0;
        elseif ~useVal && useTest
            valDefault(2) = 0;
            testDefault(2) = available(2);
        elseif useVal && useTest
            valDefault(2) = floor(0.50*available(2));
            testDefault(2) = available(2) - valDefault(2);
        end
    end

    f = figure('Name','Binary partition counts', ...
               'NumberTitle','off', ...
               'MenuBar','none', ...
               'Toolbar','none', ...
               'WindowStyle','modal', ...
               'Color',[0.96 0.94 0.90], ...
               'Units','normalized', ...
               'Position',[0.30 0.30 0.42 0.34]);

    uicontrol('Parent',f,'Style','text', ...
              'String',['Set sample counts for target class ' num2str(targetClass) ' and its non-target samples.'], ...
              'Units','normalized','Position',[0.06 0.83 0.88 0.08], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    yHead = 0.70;
    uicontrol('Parent',f,'Style','text','String','Group', ...
              'Units','normalized','Position',[0.06 yHead 0.22 0.06], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Available', ...
              'Units','normalized','Position',[0.30 yHead 0.16 0.06], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Train', ...
              'Units','normalized','Position',[0.49 yHead 0.12 0.06], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Validation', ...
              'Units','normalized','Position',[0.63 yHead 0.16 0.06], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Test', ...
              'Units','normalized','Position',[0.82 yHead 0.10 0.06], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');

    hTrain = zeros(2,1);
    hVal = zeros(2,1);
    hTest = zeros(2,1);
    for ii = 1:2
        y = 0.58 - (ii-1)*0.16;
        uicontrol('Parent',f,'Style','text','String',labels{ii}, ...
                  'Units','normalized','Position',[0.06 y 0.22 0.07], ...
                  'BackgroundColor',[0.96 0.94 0.90], ...
                  'HorizontalAlignment','left');
        uicontrol('Parent',f,'Style','text','String',num2str(available(ii)), ...
                  'Units','normalized','Position',[0.32 y 0.10 0.07], ...
                  'BackgroundColor',[0.96 0.94 0.90]);
        hTrain(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(trainDefault(ii)), ...
                  'Units','normalized','Position',[0.50 y 0.09 0.07], ...
                  'BackgroundColor',[1 1 1]);
        hVal(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(valDefault(ii)), ...
                  'Units','normalized','Position',[0.66 y 0.09 0.07], ...
                  'BackgroundColor',[1 1 1]);
        hTest(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(testDefault(ii)), ...
                  'Units','normalized','Position',[0.82 y 0.09 0.07], ...
                  'BackgroundColor',[1 1 1]);
    end

    if strcmpi(modeStr,'Rigorous')
        set(hTrain(2),'String','0','Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
    end
    if ~useVal
        for ii = 1:length(hVal)
            set(hVal(ii),'String','0','Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
        end
    end
    if ~useTest
        for ii = 1:length(hTest)
            set(hTest(ii),'String','0','Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
        end
    end

    uicontrol('Parent',f,'Style','pushbutton','String','OK', ...
              'Units','normalized','Position',[0.58 0.06 0.16 0.10], ...
              'FontWeight','bold','Callback',@onOK);
    uicontrol('Parent',f,'Style','pushbutton','String','Cancel', ...
              'Units','normalized','Position',[0.77 0.06 0.16 0.10], ...
              'Callback',@onCancel);

    uiwait(f);

    function onOK(hObj,ev)
        train = zeros(2,1);
        val = zeros(2,1);
        test = zeros(2,1);
        try
            for jj = 1:2
                train(jj) = parseNonnegativeInt(get(hTrain(jj),'String'),['Train ' labels{jj}]);
                val(jj) = parseNonnegativeInt(get(hVal(jj),'String'),['Validation ' labels{jj}]);
                test(jj) = parseNonnegativeInt(get(hTest(jj),'String'),['Test ' labels{jj}]);
                if ~useVal && val(jj) ~= 0
                    error('Validation counts must be zero when Validation is disabled.');
                end
                if ~useTest && test(jj) ~= 0
                    error('Test counts must be zero when Test is disabled.');
                end
                if (train(jj) + val(jj) + test(jj)) ~= available(jj)
                    error(['Counts for ' labels{jj} ' must sum to available samples (' num2str(available(jj)) ').']);
                end
            end
            if strcmpi(modeStr,'Rigorous') && train(2) ~= 0
                error('In Rigorous mode, Train cannot contain non-target samples.');
            end
        catch ME
            errordlg(ME.message,'Binary counts');
            return;
        end

        req = struct();
        req.trainTarget = train(1);
        req.trainNonTarget = train(2);
        req.valTarget = val(1);
        req.valNonTarget = val(2);
        req.testTarget = test(1);
        req.testNonTarget = test(2);
        ok = true;
        if ishandle(f)
            uiresume(f);
            delete(f);
        end
    end

    function onCancel(hObj,ev)
        ok = false;
        req = [];
        if ishandle(f)
            uiresume(f);
            delete(f);
        end
    end
end

function [ok,classReq] = promptAllClassCounts(classv,useVal,useTest)
    ok = false;
    classReq = [];

    classes = unique(classv(:));
    nClass = length(classes);
    available = zeros(nClass,1);
    trainDefault = zeros(nClass,1);
    valDefault = zeros(nClass,1);
    testDefault = zeros(nClass,1);

    for ii = 1:nClass
        available(ii) = sum(classv == classes(ii));
        [trainDefault(ii),valDefault(ii),testDefault(ii)] = defaultAllClassCounts(available(ii),useVal,useTest);
    end

    rowH = 0.075;
    figH = min(0.82,max(0.34,0.22 + rowH*nClass));
    f = figure('Name','All classes partition counts', ...
               'NumberTitle','off', ...
               'MenuBar','none', ...
               'Toolbar','none', ...
               'WindowStyle','modal', ...
               'Color',[0.96 0.94 0.90], ...
               'Units','normalized', ...
               'Position',[0.25 0.12 0.50 figH]);

    uicontrol('Parent',f,'Style','text', ...
              'String','Set the number of samples from each class assigned to Train, Validation and Test.', ...
              'Units','normalized','Position',[0.05 0.91 0.90 0.055], ...
              'BackgroundColor',[0.96 0.94 0.90], ...
              'HorizontalAlignment','left','FontWeight','bold');

    yHead = 0.84;
    uicontrol('Parent',f,'Style','text','String','Class', ...
              'Units','normalized','Position',[0.06 yHead 0.12 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Available', ...
              'Units','normalized','Position',[0.21 yHead 0.14 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Train', ...
              'Units','normalized','Position',[0.40 yHead 0.12 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Validation', ...
              'Units','normalized','Position',[0.57 yHead 0.14 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');
    uicontrol('Parent',f,'Style','text','String','Test', ...
              'Units','normalized','Position',[0.76 yHead 0.12 0.04], ...
              'BackgroundColor',[0.96 0.94 0.90],'FontWeight','bold');

    hTrain = zeros(nClass,1);
    hVal = zeros(nClass,1);
    hTest = zeros(nClass,1);
    rowTop = 0.78;
    for ii = 1:nClass
        y = rowTop - (ii-1)*rowH;
        uicontrol('Parent',f,'Style','text','String',num2str(classes(ii)), ...
                  'Units','normalized','Position',[0.06 y 0.12 0.045], ...
                  'BackgroundColor',[0.96 0.94 0.90]);
        uicontrol('Parent',f,'Style','text','String',num2str(available(ii)), ...
                  'Units','normalized','Position',[0.22 y 0.12 0.045], ...
                  'BackgroundColor',[0.96 0.94 0.90]);
        hTrain(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(trainDefault(ii)), ...
                  'Units','normalized','Position',[0.40 y 0.10 0.045], ...
                  'BackgroundColor',[1 1 1]);
        hVal(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(valDefault(ii)), ...
                  'Units','normalized','Position',[0.59 y 0.10 0.045], ...
                  'BackgroundColor',[1 1 1]);
        hTest(ii) = uicontrol('Parent',f,'Style','edit','String',num2str(testDefault(ii)), ...
                  'Units','normalized','Position',[0.76 y 0.10 0.045], ...
                  'BackgroundColor',[1 1 1]);
        if ~useVal
            set(hVal(ii),'String','0','Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
        end
        if ~useTest
            set(hTest(ii),'String','0','Enable','inactive','BackgroundColor',[0.92 0.92 0.92]);
        end
    end

    uicontrol('Parent',f,'Style','pushbutton','String','OK', ...
              'Units','normalized','Position',[0.58 0.035 0.16 0.07], ...
              'FontWeight','bold','Callback',@onOK);
    uicontrol('Parent',f,'Style','pushbutton','String','Cancel', ...
              'Units','normalized','Position',[0.77 0.035 0.16 0.07], ...
              'Callback',@onCancel);

    uiwait(f);

    function onOK(hObj,ev)
        train = zeros(nClass,1);
        val = zeros(nClass,1);
        test = zeros(nClass,1);
        try
            for jj = 1:nClass
                train(jj) = parseNonnegativeInt(get(hTrain(jj),'String'),['Train class ' num2str(classes(jj))]);
                val(jj) = parseNonnegativeInt(get(hVal(jj),'String'),['Validation class ' num2str(classes(jj))]);
                test(jj) = parseNonnegativeInt(get(hTest(jj),'String'),['Test class ' num2str(classes(jj))]);
                if ~useVal && val(jj) ~= 0
                    error('Validation counts must be zero when Validation is disabled.');
                end
                if ~useTest && test(jj) ~= 0
                    error('Test counts must be zero when Test is disabled.');
                end
                if train(jj) < 1
                    error(['Class ' num2str(classes(jj)) ' must have at least one training sample for All classes modelling.']);
                end
                if (train(jj) + val(jj) + test(jj)) ~= available(jj)
                    error(['Counts for class ' num2str(classes(jj)) ' must sum to available samples (' num2str(available(jj)) ').']);
                end
            end
        catch ME
            errordlg(ME.message,'All classes counts');
            return;
        end

        classReq = struct();
        classReq.classes = classes(:);
        classReq.available = available(:);
        classReq.train = train(:);
        classReq.val = val(:);
        classReq.test = test(:);
        ok = true;
        if ishandle(f)
            uiresume(f);
            delete(f);
        end
    end

    function onCancel(hObj,ev)
        ok = false;
        classReq = [];
        if ishandle(f)
            uiresume(f);
            delete(f);
        end
    end
end

function [nTrain,nVal,nTest] = defaultAllClassCounts(nAvailable,useVal,useTest)
    if useVal && useTest
        nTrain = floor(0.50*nAvailable);
        nVal = floor(0.25*nAvailable);
        nTest = nAvailable - nTrain - nVal;
    elseif useVal
        nTrain = floor(0.67*nAvailable);
        nVal = nAvailable - nTrain;
        nTest = 0;
    elseif useTest
        nTrain = floor(0.67*nAvailable);
        nVal = 0;
        nTest = nAvailable - nTrain;
    else
        nTrain = nAvailable;
        nVal = 0;
        nTest = 0;
    end
    if nAvailable > 0 && nTrain < 1
        nTrain = 1;
        if nTest > 0
            nTest = nTest - 1;
        elseif nVal > 0
            nVal = nVal - 1;
        end
    end
end

function part = selectAndSplitByExplicitClassCounts(X, classv, classReq, method)
    part = struct('train',[],'val',[],'test',[]);
    for ii = 1:length(classReq.classes)
        c = classReq.classes(ii);
        idxC = find(classv == c);
        nTrainC = classReq.train(ii);
        nValC = classReq.val(ii);
        nTestC = classReq.test(ii);
        if (nTrainC + nValC + nTestC) ~= length(idxC)
            error(['Counts for class ' num2str(c) ' do not match available samples.']);
        end
        partC = selectAndSplitIndicesImproved(X, idxC, nTrainC, nValC, nTestC, method);
        part.train = [part.train(:); partC.train(:)];
        part.val   = [part.val(:);   partC.val(:)];
        part.test  = [part.test(:);  partC.test(:)];
    end
end

% ================================================================
% Selection 
% ================================================================
function part = selectAndSplitByClassGroups(X, classv, req, method)
    part = struct('train',[],'val',[],'test',[]);
    classes = unique(classv(:));
    for ic = 1:length(classes)
        c = classes(ic);
        idxC = find(classv == c);
        nC = length(idxC);
        if c == 1
            nTrainC = req.trainTarget;
            nValC   = req.valTarget;
            nTestC  = req.testTarget;
        else
            nonTargetClasses = classes(classes ~= 1);
            nonTargetCounts = zeros(length(nonTargetClasses),1);
            for jj = 1:length(nonTargetClasses)
                nonTargetCounts(jj) = sum(classv == nonTargetClasses(jj));
            end
            pos = find(nonTargetClasses == c);
            [trainAlloc,valAlloc,testAlloc] = allocateThreeWayCountsByClass(nonTargetCounts, req.trainNonTarget, req.valNonTarget, req.testNonTarget);
            nTrainC = trainAlloc(pos);
            nValC   = valAlloc(pos);
            nTestC  = testAlloc(pos);
        end
        if (nTrainC + nValC + nTestC) ~= nC
            error(['Internal allocation error for class ' num2str(c) '.']);
        end
        partC = selectAndSplitIndicesImproved(X, idxC, nTrainC, nValC, nTestC, method);
        part.train = [part.train(:); partC.train(:)];
        part.val   = [part.val(:);   partC.val(:)];
        part.test  = [part.test(:);  partC.test(:)];
    end
end

function [trainAlloc,valAlloc,testAlloc] = allocateThreeWayCountsByClass(classCounts, nTrain, nVal, nTest)
    classCounts = classCounts(:);
    nClass = length(classCounts);
    trainAlloc = zeros(nClass,1);
    valAlloc   = zeros(nClass,1);
    testAlloc  = zeros(nClass,1);
    if nClass == 0
        if (nTrain+nVal+nTest) ~= 0
            error('Non-target counts were requested, but no non-target class exists.');
        end
        return;
    end
    if (nTrain+nVal+nTest) ~= sum(classCounts)
        error('Requested non-target counts do not match available non-target samples.');
    end
    trainAlloc = allocateCountsByClass(classCounts, nTrain);
    remainingCounts = classCounts - trainAlloc;
    valAlloc = allocateCountsByClass(remainingCounts, nVal);
    testAlloc = remainingCounts - valAlloc;
    if any(testAlloc < 0) || sum(testAlloc) ~= nTest
        error('Internal allocation error for multiclass-aware split.');
    end
end

function alloc = allocateCountsByClass(classCounts, totalRequested)
    classCounts = classCounts(:);
    nClass = length(classCounts);
    alloc = zeros(nClass,1);
    if nClass == 0
        if totalRequested ~= 0
            error('Counts were requested from an empty class subset.');
        end
        return;
    end
    if totalRequested < 0 || totalRequested > sum(classCounts)
        error('Requested count is inconsistent with available class counts.');
    end
    if totalRequested == 0
        return;
    end
    if totalRequested == sum(classCounts)
        alloc = classCounts;
        return;
    end
    raw = totalRequested * classCounts / sum(classCounts);
    alloc = floor(raw);
    remainder = totalRequested - sum(alloc);
    frac = raw - alloc;
    [~,ord] = sort(frac,'descend');
    k = 1;
    while remainder > 0
        ii = ord(k);
        if alloc(ii) < classCounts(ii)
            alloc(ii) = alloc(ii) + 1;
            remainder = remainder - 1;
        end
        k = k + 1;
        if k > length(ord), k = 1; end
    end
end

function part = selectAndSplitIndicesImproved(X, idxPool, nTrain, nVal, nTest, method)
    part = struct('train',[],'val',[],'test',[]);
    nPool = length(idxPool);
    if nPool == 0
        if (nTrain+nVal+nTest) ~= 0
            error('Requested samples from an empty class subset.');
        end
        return;
    end
    if (nTrain + nVal + nTest) ~= nPool
        error('Counts do not sum to the available subset size.');
    end

    Xsub = X(idxPool,:);

    % 1) choose train first
    trainLocal = selectSubsetPrimary(Xsub, nTrain, method);
    remLocal = setdiff(1:nPool, trainLocal);

    % 2) choose validation and test from remaining samples
    if isempty(remLocal)
        valLocal = [];
        testLocal = [];
    else
        Xrem = Xsub(remLocal,:);
        if nVal > 0 && nTest > 0
            switch lower(method)
                case 'duplex'
                    [valRem, testRem] = duplex_two_group_split(Xrem, nVal, nTest);
                case 'kennard-stone'
                    valRem = ks_original_subset(Xrem, nVal);
                    rem2 = setdiff(1:size(Xrem,1), valRem);
                    if nTest > 0
                        testRem = rem2;
                    else
                        testRem = [];
                    end
                otherwise
                    ord = randperm_compat(size(Xrem,1));
                    valRem = ord(1:nVal);
                    testRem = ord(nVal+1:nVal+nTest);
            end
        elseif nVal > 0
            switch lower(method)
                case 'kennard-stone'
                    valRem = ks_original_subset(Xrem, nVal);
                case 'duplex'
                    valRem = duplex_primary_subset(Xrem, nVal);
                otherwise
                    ord = randperm_compat(size(Xrem,1));
                    valRem = ord(1:nVal);
            end
            testRem = [];
        elseif nTest > 0
            switch lower(method)
                case 'kennard-stone'
                    testRem = ks_original_subset(Xrem, nTest);
                case 'duplex'
                    testRem = duplex_primary_subset(Xrem, nTest);
                otherwise
                    ord = randperm_compat(size(Xrem,1));
                    testRem = ord(1:nTest);
            end
            valRem = [];
        else
            valRem = [];
            testRem = [];
        end

        valLocal = remLocal(valRem(:));
        testLocal = remLocal(testRem(:));
    end

    part.train = idxPool(trainLocal(:));
    part.val   = idxPool(valLocal(:));
    part.test  = idxPool(testLocal(:));
end

function subset = ks_original_subset(Xsub, nSel)
    n = size(Xsub,1);
    if nSel <= 0
        subset = [];
        return;
    end
    if nSel >= n
        subset = 1:n;
        return;
    end
    if exist('ks_select','file') == 2
%          [obj,~,~,~,~] = kenston(Xsub, nSel, 1, 0, ones(size(Xsub,1),1));
         [obj,~,~,~,] = ks_select(Xsub, nSel, 1, 0, ones(size(Xsub,1),1));
    else
        obj = local_kenston_original_order(Xsub, nSel, 1);
    end
    subset = obj(:)';
end

function object = local_kenston_original_order(x, no_p, men)
    [n,m] = size(x); 
    t = x;
    meant = mean(t);
    t1 = t - ones(n,1)*meant;
    a = zeros(n,1);
    for i = 1:n
        a(i) = t1(i,:)*t1(i,:)';
    end
    if men == 1
        [~,c] = min(a);
    else
        [~,c] = max(a);
    end
    object(1) = c;

    if no_p >= 2
        t1 = t - ones(n,1)*t(object(1),:);
        a = zeros(n,1);
        for i = 1:n
            a(i) = t1(i,:)*t1(i,:)';
        end
        [~,c] = max(a);
        object(2) = c;
    end

    for pi = 3:no_p
        list = 1:n;
        tt = t;
        k = length(object);
        list(object) = [];
        tt(object,:) = [];
        nl = length(list);
        dmin = zeros(nl,1);
        for j = 1:nl
            a = zeros(k,1);
            for i = 1:k
                t1 = tt(j,:) - t(object(i),:);
                a(i) = t1*t1';
            end
            dmin(j) = min(a);
        end
        [~,c] = max(dmin);
        object(pi) = list(c);
    end
    object = object(1:no_p);
end

function subset = selectSubsetPrimary(Xsub, nSel, method)
    n = size(Xsub,1);
    if nSel == 0
        subset = [];
        return;
    end
    if nSel == n
        subset = 1:n;
        return;
    end
    switch lower(method)
        case 'random'
            ord = randperm_compat(n);
            subset = ord(1:nSel);
        case 'kennard-stone'
            subset = ks_original_subset(Xsub, nSel);
        case 'duplex'
            subset = duplex_primary_subset(Xsub, nSel);
        otherwise
            ord = 1:n;
            subset = ord(1:nSel);
    end
end

function order = selectOrderWithinSubset(Xsub, method)
    n = size(Xsub,1);
    switch lower(method)
        case 'random'
            order = randperm_compat(n);
        case 'kennard-stone'
            order = kennard_stone_order(Xsub);
        case 'duplex'
            order = duplex_order(Xsub);
        otherwise
            order = 1:n;
    end
end

function order = randperm_compat(n)
    [~,order] = sort(rand(n,1));
    order = order(:)';
end

function subset = kennard_stone_subset(X, nSel)
    n = size(X,1);
    if nSel <= 0
        subset = [];
        return;
    end
    if nSel >= n
        subset = 1:n;
        return;
    end
    D = local_distance_matrix(X);
    Dwork = D + diag(-inf*ones(n,1));
    [~,ind] = max(Dwork(:));
    [i1,i2] = ind2sub([n n],ind);

    selected = unique([i1 i2]);
    if length(selected) > nSel
        selected = selected(1:nSel);
        subset = selected;
        return;
    end
    remaining = setdiff(1:n,selected);
    while length(selected) < nSel
        minDist = zeros(length(remaining),1);
        for i = 1:length(remaining)
            r = remaining(i);
            minDist(i) = min(D(r,selected));
        end
        [~,imax] = max(minDist);
        selected = [selected remaining(imax)];
        remaining(imax) = [];
    end
    subset = selected(:)';
end

function subset = duplex_primary_subset(X, nSel)
    n = size(X,1);
    if nSel <= 0
        subset = [];
        return;
    end
    if nSel >= n
        subset = 1:n;
        return;
    end
    ord = duplex_order(X);
    subset = ord(1:nSel);
end

function [grp1, grp2] = duplex_two_group_split(X, n1, n2)
    n = size(X,1);
    if (n1+n2) ~= n
        error('duplex_two_group_split requires n1+n2 equal to the number of available remaining samples.');
    end
    if n == 0
        grp1 = [];
        grp2 = [];
        return;
    end
    D = local_distance_matrix(X);
    Dwork = D + diag(-inf*ones(n,1));
    [~,ind] = max(Dwork(:));
    [i1,i2] = ind2sub([n n],ind);

    grp1 = i1;
    grp2 = i2;
    remaining = setdiff(1:n,[i1 i2]);

    while ~isempty(remaining)
        canFill1 = length(grp1) < n1;
        canFill2 = length(grp2) < n2;

        if canFill1 && canFill2
            score1 = zeros(length(remaining),1);
            score2 = zeros(length(remaining),1);
            for i = 1:length(remaining)
                r = remaining(i);
                score1(i) = min(D(r,grp1));
                score2(i) = min(D(r,grp2));
            end
            [best1,idx1] = max(score1);
            [best2,idx2] = max(score2);
            if best1 >= best2
                grp1 = [grp1 remaining(idx1)];
                remaining(idx1) = [];
            else
                grp2 = [grp2 remaining(idx2)];
                remaining(idx2) = [];
            end
        elseif canFill1
            score1 = zeros(length(remaining),1);
            for i = 1:length(remaining)
                r = remaining(i);
                score1(i) = min(D(r,grp1));
            end
            [~,idx1] = max(score1);
            grp1 = [grp1 remaining(idx1)];
            remaining(idx1) = [];
        elseif canFill2
            score2 = zeros(length(remaining),1);
            for i = 1:length(remaining)
                r = remaining(i);
                score2(i) = min(D(r,grp2));
            end
            [~,idx2] = max(score2);
            grp2 = [grp2 remaining(idx2)];
            remaining(idx2) = [];
        else
            break;
        end
    end
end

function order = kennard_stone_order(X)
    n = size(X,1);
    if n <= 2
        order = 1:n;
        return;
    end
    D = local_distance_matrix(X);
    Dwork = D + diag(-inf*ones(n,1));
    [mx,ind] = max(Dwork(:)); 
    [i1,i2] = ind2sub([n n],ind);

    selected = [i1 i2];
    remaining = setdiff(1:n,selected);
    while ~isempty(remaining)
        minDist = zeros(length(remaining),1);
        for i = 1:length(remaining)
            r = remaining(i);
            minDist(i) = min(D(r,selected));
        end
        [~,imax] = max(minDist);
        selected = [selected remaining(imax)];
        remaining(imax) = [];
    end
    order = selected;
end

function order = duplex_order(X)
    n = size(X,1);
    if n <= 2
        order = 1:n;
        return;
    end
    D = local_distance_matrix(X);
    Dwork = D + diag(-inf*ones(n,1));
    [~,ind] = max(Dwork(:));
    [i1,i2] = ind2sub([n n],ind);

    A = [i1];
    B = [i2];
    remaining = setdiff(1:n,[i1 i2]);

    turnA = true;
    while ~isempty(remaining)
        if turnA
            grp = A;
        else
            grp = B;
        end
        minDist = zeros(length(remaining),1);
        for i = 1:length(remaining)
            r = remaining(i);
            minDist(i) = min(D(r,grp));
        end
        [~,imax] = max(minDist);
        if turnA
            A = [A remaining(imax)];
        else
            B = [B remaining(imax)];
        end
        remaining(imax) = [];
        turnA = ~turnA;
    end

    % 
    order = [];
    na = length(A); nb = length(B);
    m = max(na,nb);
    for k = 1:m
        if k <= na, order = [order A(k)]; end
        if k <= nb, order = [order B(k)]; end
    end
end

function D = local_distance_matrix(X)
    n = size(X,1);
    D = zeros(n,n);
    for i = 1:n
        xi = X(i,:);
        for j = i+1:n
            d = sqrt(sum((xi - X(j,:)).^2));
            D(i,j) = d;
            D(j,i) = d;
        end
    end
end

function v = parseNonnegativeInt(strValue,label)
    v = str2double(strValue);
    if isnan(v) || v < 0 || abs(v-round(v)) > 1e-12
        error([label ' must be a non-negative integer.']);
    end
    v = round(v);
end

function seed = localApplyRandomSeed(strValue)
    seed = str2double(strValue);
    if isnan(seed) || abs(seed-round(seed)) > 1e-12
        error('Random seed must be an integer.');
    end
    seed = round(seed);
    rand('twister',seed);
end

% ================================================================
% Example data
% ================================================================
function [X,classv,axisv,sampleNames] = createExampleData()
    nT = 24;
    nN1 = 16;
    nN2 = 10;
    p = 140;
    axisv = linspace(1100,2500,p);

    XT = zeros(nT,p);
    XN1 = zeros(nN1,p);
    XN2 = zeros(nN2,p);

    for i = 1:nT
        XT(i,:) = 0.50 + 0.04*randn(1,p) ...
                + 0.22*exp(-(axisv-1450).^2/(2*55^2)) ...
                + 0.16*exp(-(axisv-1930).^2/(2*70^2));
    end
    for i = 1:nN1
        XN1(i,:) = 0.58 + 0.05*randn(1,p) ...
                 + 0.14*exp(-(axisv-1500).^2/(2*65^2)) ...
                 + 0.24*exp(-(axisv-2080).^2/(2*75^2));
    end
    for i = 1:nN2
        XN2(i,:) = 0.46 + 0.05*randn(1,p) ...
                 + 0.10*exp(-(axisv-1360).^2/(2*60^2)) ...
                 + 0.28*exp(-(axisv-2210).^2/(2*85^2));
    end

    X = [XT; XN1; XN2];
    classv = [ones(nT,1); 2*ones(nN1,1); 3*ones(nN2,1)];
    sampleNames = buildSampleNames(size(X,1));
end

function names = buildSampleNames(n)
    names = cell(n,1);
    for i = 1:n
        names{i} = ['Sample_' num2str(i)];
    end
end
