%
function plsdm_gui_step_visualization_preprocessing()
% PLS-DM Toolbox GUI - Step: Data Visualization and Preprocessing
%   - loading X, classes and x-axis
%   - visualizing raw and preprocessed spectra
%   - applying common chemometric preprocessing methods
%   - comparing raw and preprocessed class spectra and means
%   - exporting plots to standalone figure windows
%
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    GUI_VERSION = 'PLS-DM Toolbox GUI v1.0';

    scr = get(0,'ScreenSize');
    fig = figure('Name',['PLS-DM Toolbox - Data Visualization and Preprocessing ', GUI_VERSION], ...
                 'NumberTitle','off', ...
                 'MenuBar','none', ...
                 'Toolbar','none', ...
                 'Color',[0.95 0.96 0.94], ...
                 'Units','pixels', ...
                 'Position',[50 40 min(1280,scr(3)-100) min(720,scr(4)-120)]);

    S = struct();
    S.Xraw = [];
    S.Xall = [];
    S.Xproc = [];
    S.class = [];
    S.classAll = [];
    S.axis = [];
    S.axisProc = [];
    S.axisProvided = 0;
    S.sampleNames = {};
    S.sampleNamesAll = {};
    S.sampleIncluded = [];
    S.originalRows = [];
    S.classNames = {};
    S.currentPreprocLabel = 'Raw';
    S.exportVarName = 'Xproc';
    S.preproSteps = struct('method',{},'label',{},'params',{});
    S.PreprocessingModel = [];
    S.msc_ref = [];
    S.msc_ref_class = [];
    S.xLabelText = 'Variable';
    S.yLabelText = 'Intensity';
    S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
    S.classColors = [0.00 0.45 0.35; ...
                     0.82 0.35 0.16; ...
                     0.58 0.24 0.70; ...
                     0.20 0.55 0.75; ...
                     0.62 0.58 0.20; ...
                     0.42 0.42 0.42; ...
                     0.70 0.18 0.28];

 
    % -----------------------------
    themeDark = [0.12 0.32 0.25];

    % -----------------------------
    % Header
    % -----------------------------
    S.pnlHeader = uipanel('Parent',fig, ...
                        'Units', 'normalized', 'Position',[0.01 0.88 0.98 0.10], ...
                        'BackgroundColor',themeDark, ...
                        'BorderType', 'none');

    uicontrol('Parent',S.pnlHeader,'Style','text','String','View and preprocessing', ...
              'Units', 'normalized', 'Position',[0.025 0.45 0.55 0.42], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[1 1 1], ...
              'HorizontalAlignment','left','FontSize',17,'FontWeight','bold');

    uicontrol('Parent',S.pnlHeader,'Style','text', ...
              'String','Inspect raw data, apply preprocessing and compare processed class profiles', ...
              'Units', 'normalized', 'Position',[0.025 0.12 0.75 0.26], ...
              'BackgroundColor',themeDark, ...
              'ForegroundColor',[0.86 0.94 0.90], ...
              'HorizontalAlignment','left','FontSize',10);

    uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Help', ...
              'Units','normalized','Position',[0.86 0.24 0.10 0.48], ...
              'BackgroundColor',[0.86 0.94 0.90], ...
              'ForegroundColor',themeDark, ...
              'FontWeight','bold', ...
              'TooltipString','Open the help window for this View and preprocessing module.', ...
              'Callback',@onHelp);

    S.btnDataInfo = uicontrol('Parent',S.pnlHeader,'Style','pushbutton','String','Add data info...', ...
              'Units','normalized','Position',[0.69 0.24 0.155 0.48], ...
              'BackgroundColor',[0.86 0.94 0.90],'ForegroundColor',themeDark,'FontWeight','bold', ...
              'Enable','off','TooltipString','Add optional axis, class, and sample display names.', ...
              'Callback',@onDataInfo);

    % -----------------------------
    % Control panel
    % -----------------------------
    S.pnlCtrl = uipanel('Parent',fig,'Title','Controls', ...
                        'Units','normalized','Position',[0.01 0.02 0.24 0.84], ...
                        'BackgroundColor',[0.95 0.96 0.94], ...
                        'FontWeight','bold');
    S.btnExclude = uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Exclude...', ...
              'Units','normalized','Position',[0.68 0.885 0.25 0.045], ...
              'FontWeight','bold','Enable','off', ...
              'TooltipString','Include or exclude samples without deleting the original data.', ...
              'Callback',@onExcludeSamples);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Data', ...
              'Units','normalized','Position',[0.05 0.93 0.40 0.035], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left','FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Load example', ...
              'Units','normalized','Position',[0.05 0.885 0.28 0.045], ...
              'TooltipString','Load simulated spectral data to test the visualization and preprocessing tools.', ...
              'Callback',@onLoadExample);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Import workspace', ...
              'Units','normalized','Position',[0.36 0.885 0.29 0.045], ...
              'TooltipString','Import X, optional class vector and optional x-axis vector from the MATLAB workspace.', ...
              'Callback',@onImportWorkspace);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Preprocessing', ...
              'Units','normalized','Position',[0.05 0.84 0.50 0.035], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.lstPre = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'String',{'Raw','Center','Autoscaling','SNV','MSC', ...
                        'Moving average smoothing','Savitzky-Golay smoothing','1st derivative', ...
                        'Savitzky-Golay derivative','2nd derivative', ...
                        'Baseline offset correction','Max normalization', ...
                        'L1 normalization','L2 normalization'}, ...
              'Units','normalized','Position',[0.05 0.60 0.88 0.24], ...
              'Max',1,'Min',0,'Value',1,'BackgroundColor',[1 1 1], ...
              'TooltipString','Select a preprocessing method to apply directly or add to the preprocessing chain.');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Moving average window', ...
              'Units','normalized','Position',[0.05 0.515 0.45 0.03], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left');

    S.edWin = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','5', ...
              'Units','normalized','Position',[0.56 0.515 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Window size for moving average smoothing. Even values are automatically converted to the next odd value.');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','SG derivative', ...
              'Units','normalized','Position',[0.05 0.47 0.45 0.03], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left');

    S.popupSGDer = uicontrol('Parent',S.pnlCtrl,'Style','popupmenu', ...
              'String',{'1','2'}, ...
              'Units','normalized','Position',[0.56 0.467 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Derivative order for Savitzky-Golay preprocessing: 1st or 2nd derivative.');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','SG window', ...
              'Units','normalized','Position',[0.05 0.425 0.45 0.03], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left');

    S.edSGWin = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','11', ...
              'Units','normalized','Position',[0.56 0.422 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Savitzky-Golay window size. It must be odd and larger than the polynomial order.');

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','SG polynomial order', ...
              'Units','normalized','Position',[0.05 0.38 0.45 0.03], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left');

    S.edSGPoly = uicontrol('Parent',S.pnlCtrl,'Style','edit','String','2', ...
              'Units','normalized','Position',[0.56 0.377 0.15 0.04], ...
              'BackgroundColor',[1 1 1], ...
              'TooltipString','Polynomial order used in Savitzky-Golay derivative preprocessing.');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Apply selected', ...
              'Units','normalized','Position',[0.05 0.322 0.40 0.050], ...
              'TooltipString','Apply only the selected preprocessing to Xraw and update the processed view.', ...
              'Callback',@onApplyPreproc,'FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Add step', ...
              'Units','normalized','Position',[0.52 0.322 0.40 0.050], ...
              'TooltipString','Add the selected preprocessing and current parameters to the chain without running it yet.', ...
              'Callback',@onAddStep);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Run chain', ...
              'Units','normalized','Position',[0.05 0.265 0.40 0.050], ...
              'TooltipString','Run all preprocessing steps in the chain from Xraw and update Xproc.', ...
              'Callback',@onRunChain,'FontWeight','bold');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Clear chain', ...
              'Units','normalized','Position',[0.52 0.265 0.40 0.050], ...
              'TooltipString','Remove all steps from the preprocessing chain.', ...
              'Callback',@onClearChain);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Preprocessing chain', ...
              'Units','normalized','Position',[0.05 0.227 0.60 0.030], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.lstChain = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'Units','normalized','Position',[0.05 0.150 0.88 0.075], ...
              'BackgroundColor',[1 1 1], ...
              'String',{'No preprocessing chain defined.'}, ...
              'Max',2,'Min',0, ...
              'TooltipString','Current preprocessing chain. Use Add step, Run chain and Clear chain.');

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Restore raw', ...
              'Units','normalized','Position',[0.52 0.092 0.40 0.045], ...
              'TooltipString','Reset Xproc to the original raw data and update the preprocessed plots.', ...
              'Callback',@onRestoreRaw);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export Xproc', ...
              'Units','normalized','Position',[0.05 0.092 0.40 0.045], ...
              'TooltipString','Export only the processed matrix and, when available, the processed x-axis.', ...
              'Callback',@onExportXproc);

    uicontrol('Parent',S.pnlCtrl,'Style','pushbutton','String','Export plots', ...
              'Units','normalized','Position',[0.52 0.040 0.40 0.045], ...
              'TooltipString','Open the four current plots in a standalone MATLAB figure for saving or editing.', ...
              'Callback',@onExportPlots);

    uicontrol('Parent',S.pnlCtrl,'Style','text','String','Summary', ...
              'Units','normalized','Position',[0.05 0.058 0.25 0.030], ...
              'BackgroundColor',[0.95 0.96 0.94], ...
              'HorizontalAlignment','left','FontWeight','bold');

    S.txtInfo = uicontrol('Parent',S.pnlCtrl,'Style','listbox', ...
              'Units','normalized','Position',[0.05 0.005 0.40 0.050], ...
              'BackgroundColor',[1 1 1], ...
              'String',{'Load data to begin.'}, ...
              'Max',2,'Min',0);

    % -----------------------------
    % Main plotting panel
    % -----------------------------
    S.pnlView = uipanel('Parent',fig,'Title','Spectral visualization', ...
                        'Units','normalized','Position',[0.26 0.02 0.73 0.84], ...
                        'BackgroundColor',[0.95 0.96 0.94], ...
                        'FontWeight','bold');

    S.ax1 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.07 0.56 0.40 0.34]);
    title(S.ax1,'Raw spectra');
    xlabel(S.ax1,'Variable'); ylabel(S.ax1,'Intensity'); box(S.ax1,'on');

    S.ax2 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.56 0.36 0.34]);
    title(S.ax2,'Raw class means');
    xlabel(S.ax2,'Variable'); ylabel(S.ax2,'Intensity'); box(S.ax2,'on');

    S.ax3 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.07 0.11 0.40 0.28]);
    title(S.ax3,'Preprocessed spectra');
    xlabel(S.ax3,'Variable'); ylabel(S.ax3,'Intensity'); box(S.ax3,'on');

    S.ax4 = axes('Parent',S.pnlView,'Units','normalized','Position',[0.56 0.11 0.36 0.28]);
    title(S.ax4,'Preprocessed class means');
    xlabel(S.ax4,'Variable'); ylabel(S.ax4,'Intensity'); box(S.ax4,'on');

    guidata(fig,S);

    % ============================================================
    % CALLBACKS
    % ============================================================
    function onHelp(hObj,ev)
        hf = figure('Name','Help - View and preprocessing', ...
                    'NumberTitle','off', ...
                    'MenuBar','none', ...
                    'Toolbar','none', ...
                    'Color',[1 1 1], ...
                    'Units','pixels', ...
                    'Position',[120 90 760 560]);

%         uicontrol('Parent',hf,'Style','text', ...
%                   'String','View and preprocessing - Help', ...
%                   'Units','normalized','Position',[0.03 0.91 0.94 0.06], ...
%                   'BackgroundColor',[1 1 1], ...
%                   'ForegroundColor',[0.12 0.32 0.25], ...
%                   'HorizontalAlignment','left', ...
%                   'FontName','Arial','FontSize',14,'FontWeight','bold');

        helpText = { ...
            'PURPOSE OF THIS MODULE'; ...
            ' '; ...
            'This interface is the first step of the PLS-DM workflow. It is used to inspect raw analytical signals, apply individual methods or ordered preprocessing chains, compare the original and processed profiles, and export the processed matrix to the next modules.'; ...
            ' '; ...
            'The module is intended mainly for spectral or signal-like data, such as NIR, MIR/FTIR, Raman, UV-Vis, fluorescence, voltammetric, chromatographic or other instrumental profiles. Rows must correspond to samples and columns must correspond to variables.'; ...
            ' '; ...
            'IMPORTANT CONCEPT'; ...
            ' '; ...
            'Preprocessing can change model performance, model complexity, robustness, variable importance and chemical interpretation. For this reason, the raw data are always preserved and the user should compare raw and preprocessed profiles before exporting the final matrix.'; ...
            ' '; ...
            'DATA INPUT'; ...
            ' '; ...
            'Load example:'; ...
            '  Loads a simulated spectral dataset. It is useful for testing the interface and understanding the plots before importing real data.'; ...
            ' '; ...
            'Import workspace:'; ...
            '  Imports variables already available in the MATLAB workspace.'; ...
            ' '; ...
            '  X matrix name:'; ...
            '    Name of the data matrix. X must be numeric with samples in rows and variables in columns.'; ...
            ' '; ...
            '  Class vector name (optional):'; ...
            '    Name of the class vector. It must contain one class label per sample.'; ...
            '    If this field is left empty, all samples are automatically treated as belonging to a single class.'; ...
            '    This is useful when the user only wants to inspect or preprocess one dataset without class information.'; ...
            ' '; ...
%             '  x-axis vector name (optional):'; ...
%             '    Name of the vector used on the x-axis, for example wavelength, wavenumber, energy, potential or time.'; ...
%             '    If this field is left empty, variables are numbered from 1 to the number of columns in X.'; ...
            ' '; ...
            '  X-axis label (optional):'; ...
            '    Text used as xlabel in all plots. Examples: Wavelength / nm, Wavenumber / cm^-1, Raman shift / cm^-1, Energy / keV, Potential / V, Variable.'; ...
            '    If this field is left empty, the default label is Variable.'; ...
            ' '; ...
%             '  Y-axis label (optional):'; ...
%             '    Text used as ylabel in all plots. Examples: Absorbance, Reflectance, Intensity, Fluorescence intensity, Current, Signal.'; ...
%             '    If this field is left empty, the default label is Intensity.'; ...
            ' '; ...
            'INPUT CHECKS'; ...
            ' '; ...
            'The number of rows in X must match the length of the class vector when a class vector is provided.'; ...
            'The x-axis vector should have the same number of elements as the number of columns in X.'; ...
            'The GUI is designed for numeric data. Missing values, Inf values or nonnumeric cells should be treated before using this module.'; ...
            ' '; ...
            'PLOTS DISPLAYED'; ...
            ' '; ...
            '1. Raw spectra:'; ...
            '  Shows the original data matrix Xraw. These curves never change after preprocessing.'; ...
            ' '; ...
            '2. Raw class means:'; ...
            '  Shows the mean raw profile of each class. If no class vector was supplied, a single mean profile is shown.'; ...
            ' '; ...
            '3. Preprocessed spectra:'; ...
            '  Shows the current processed matrix Xproc after the selected preprocessing step or sequence.'; ...
            ' '; ...
            '4. Preprocessed class means:'; ...
            '  Shows the class mean profiles after preprocessing.'; ...
            ' '; ...
            'INDIVIDUAL PREPROCESSING METHODS'; ...
            ' '; ...
            'Raw:'; ...
            '  Keeps Xproc equal to Xraw. Use this option to return to the unprocessed data without clicking Restore raw.'; ...
            ' '; ...
            'Center:'; ...
            '  Subtracts the column mean from each variable. It centers each variable around zero and is commonly used before PCA or PLS-based methods.'; ...
            ' '; ...
            'Autoscaling:'; ...
            '  Centers each variable and divides it by its standard deviation. It gives comparable weight to variables with different scales. Use with care for noisy variables, because noise can be amplified when the variable standard deviation is small.'; ...
            ' '; ...
            'SNV - Standard Normal Variate:'; ...
            '  Applies row-wise correction. For each sample, the sample mean is subtracted and the result is divided by the sample standard deviation.'; ...
            '  SNV is often useful for spectra affected by scatter, baseline offsets and global intensity differences.'; ...
            '  SNV can also modify the relative importance of variables, so interpretation of loadings or VIP should be done carefully.'; ...
            ' '; ...
            'MSC - Multiplicative Scatter Correction:'; ...
            '  Corrects each sample using the mean spectrum as reference. The method estimates additive and multiplicative effects and removes them from each profile.'; ...
            '  MSC is commonly used for NIR and other spectroscopic data affected by scattering or path length effects.'; ...
            '  It assumes that the reference spectrum is meaningful and that additive/multiplicative effects can be described by the fitted correction.'; ...
            ' '; ...
            'MSC reference and data partitioning:'; ...
            '  Partition the data before calculating a mean MSC reference. Calculating it from validation, test or unknown samples causes information leakage.'; ...
            '  For one-class classification (OCC), calculate the reference using only target-class training samples.'; ...
            '  Use that same target-training reference to correct training, validation, test, non-target and unknown samples evaluated by the model.'; ...
            '  Do not recalculate a separate mean reference for Xval, Xtest, non-target data or Xunknown.'; ...
            '  If several target classes are modelled by separate OCC models, calculate and store one independent MSC reference for each target-class model.'; ...
            '  Export msc_ref with the corrected matrix so the identical preprocessing can be reproduced for future samples.'; ...
            ' '; ...
            'Moving average smoothing:'; ...
            '  Reduces high-frequency noise by replacing each point by the average of neighboring points.'; ...
            '  The window size is defined by Moving average window. Even values are automatically converted to the next odd value.'; ...
            '  Excessive smoothing may remove narrow chemical features.'; ...
            ' '; ...
            '1st derivative:'; ...
            '  Computes a simple first derivative along the variable direction.'; ...
            '  First derivatives can reduce baseline offsets and emphasize changes in signal shape.'; ...
            '  They may amplify noise and strongly change the visual shape and interpretation of variables.'; ...
            ' '; ...
            'Savitzky-Golay derivative:'; ...
            '  Computes first or second derivative using a local polynomial fit.'; ...
            '  Parameters:'; ...
            '    SG derivative: derivative order, 1 or 2.'; ...
            '    SG window: number of points used in the local window. It must be odd.'; ...
            '    SG polynomial order: polynomial degree used in the local fit.'; ...
            '  SG derivatives combine smoothing and differentiation. The window and polynomial order strongly affect the final signal.'; ...
            ' '; ...
            'Savitzky-Golay smoothing:'; ...
            '  Applies polynomial smoothing without differentiation. It is useful when the aim is mainly noise reduction while preserving peak shape better than a simple moving average.'; ...
            ' '; ...
            '2nd derivative:'; ...
            '  Applies a second derivative treatment. Second derivatives can reduce baseline shifts and linear trends and may help resolve overlapping bands.'; ...
            '  Use with care because second derivatives can strongly amplify noise and complicate interpretation.'; ...
            ' '; ...
            'Baseline offset correction:'; ...
            '  Subtracts the minimum value of each sample profile from the entire profile. It is a simple row-wise offset correction.'; ...
            '  This is useful when spectra have positive vertical offsets. It is not a full polynomial or asymmetric baseline correction.'; ...
            ' '; ...
            'Max normalization:'; ...
            '  Divides each sample by its maximum absolute intensity. It makes profiles comparable in relative intensity.'; ...
            '  It should be used carefully with noisy data, because a single noisy maximum can control the whole normalization.'; ...
            ' '; ...
            'L1 normalization:'; ...
            '  Divides each sample by the sum of absolute intensities. It approximately normalizes the total absolute signal.'; ...
            ' '; ...
            'L2 normalization:'; ...
            '  Divides each sample by its Euclidean norm. It scales each sample vector to unit length.'; ...
            ' '; ...
            'PREPROCESSING CHAIN'; ...
            ' '; ...
            'Apply selected:'; ...
            '  Applies only the currently selected preprocessing method directly to Xraw.'; ...
            '  Use this for fast comparison of individual preprocessing methods.'; ...
            ' '; ...
            'Add step and Run chain:'; ...
            '  Add step stores the selected preprocessing method and parameters in the chain.'; ...
            '  Run chain applies all listed steps from Xraw, in the displayed order.'; ...
            '  Example: SNV followed by Savitzky-Golay derivative followed by Autoscaling generates:'; ...
            '    Xraw -> SNV -> SG derivative -> Autoscaling'; ...
            ' '; ...
            '  In a chain, the order of operations matters. SNV -> derivative is not necessarily equivalent to derivative -> SNV.'; ...
            '  Use short and chemically meaningful sequences. Very long sequences may overprocess the data.'; ...
            ' '; ...
            'NAMING AND EXPORTING'; ...
            ' '; ...
            'Export Xproc asks for one workspace name and exports only the current preprocessed matrix using that name.'; ...
            'If an x-axis vector was provided during import, the processed x-axis is also exported as xaxis_<matrix_name>.'; ...
            'When derivative preprocessing removes edge points, the exported x-axis is shortened in the same way as Xproc.'; ...
            ' '; ...
            'Export plots:'; ...
            '  Opens the four current plots in a standalone MATLAB figure. This is useful for saving figures, editing figure properties or preparing reports.'; ...
            ' '; ...
            'RESTORE RAW'; ...
            ' '; ...
            'Restore raw resets Xproc to Xraw, resets the processed x-axis and clears the preprocessing chain.'; ...
            'Use this button before starting a new preprocessing sequence.'; ...
            ' '; ...
            'PREPROCESSING CHAIN VS SPORT'; ...
            ' '; ...
            'The preprocessing chain in this GUI performs direct cumulative preprocessing on one matrix.'; ...
            'It is not the same as SPORT or other multiblock preprocessing fusion methods.'; ...
            ' '; ...
            'In this GUI:'; ...
            '  one processed matrix is generated after a sequence of operations.'; ...
            ' '; ...
            'In SPORT-like approaches:'; ...
            '  several differently preprocessed matrices are treated as separate blocks.'; ...
            '  PLS models and orthogonalization steps are used to extract complementary information from each block.'; ...
            ' '; ...
            'Therefore, this GUI provides a simple and practical preprocessing-chain tool, while SPORT is a more advanced multiblock modelling strategy.'; ...
            ' '; ...
            'BUTTON-BY-BUTTON REFERENCE'; ...
            ' '; ...
            'Help: opens this complete reference. It does not modify data or settings.'; ...
            'Load example: replaces the current GUI data with simulated spectra and classes for learning or testing.'; ...
            'Import workspace: selects X, optional Class, optional x-axis and axis labels. A new import replaces the data currently held by this GUI.'; ...
            'Exclude: opens the non-destructive sample-selection window. Excluded samples are removed from plots, preprocessing and MSC reference calculation without deleting Xraw.'; ...
            '  After changing inclusion, preprocessing is reset and must be applied again. Original row numbers remain linked to the imported matrix.'; ...
            'Apply selected: starts from Xraw, applies only the displayed method with its current parameters, stores Xproc and refreshes the processed plots.'; ...
            'Add step: records the selected method and current parameters at the end of the chain. It does not calculate Xproc.'; ...
            'Run chain: starts from Xraw and applies every stored step from top to bottom, replacing the current Xproc and processed axis.'; ...
            'Clear chain: deletes the stored sequence without deleting Xraw or changing the last calculated Xproc.'; ...
            'Restore raw: returns Xproc and the processed axis to their original state, clears the chain and refreshes the views.'; ...
            'Export Xproc: asks for a valid variable name and exports the current matrix; a compatible processed axis is also exported when available.'; ...
            'Export plots: creates an editable four-panel figure containing the two raw and two processed views.'; ...
            ' '; ...
            'RECOMMENDED WORKFLOW'; ...
            ' '; ...
            '1. Start with Raw and inspect the original profiles.'; ...
            '2. Check whether the main unwanted variation is noise, baseline offset, scatter, global intensity variation or class-related signal structure.'; ...
            '3. Test individual preprocessing methods first with Apply selected.'; ...
            '4. Compare raw and processed spectra visually.'; ...
            '5. If needed, build short combinations with Add step and Run chain.'; ...
            '6. Prefer simple preprocessing if performance is similar.'; ...
            '7. Export only the matrix that will be used in the following module.'; ...
            '8. In later PLS-DM optimization, evaluate not only SEN, SPEC and EFF, but also the number of latent variables and model stability.'; ...
            ' '; ...
            'PRACTICAL EXAMPLES'; ...
            ' '; ...
            'Possible sequence for scatter-dominated NIR data:'; ...
            '  SNV or MSC -> Center or Autoscaling'; ...
            ' '; ...
            'Possible sequence for noisy data with smooth bands:'; ...
            '  Savitzky-Golay smoothing -> Center'; ...
            ' '; ...
            'Possible sequence for baseline drift and overlapping bands:'; ...
            '  Savitzky-Golay derivative or 2nd derivative -> Autoscaling'; ...
            ' '; ...
            'Possible sequence for intensity-normalized visual comparison:'; ...
            '  Baseline offset correction -> Max normalization'; ...
            ' '; ...
            'These are starting points only. The best choice depends on the data, the analytical technique and the validation results.'; ...
            ' '; ...
            'WARNINGS AND LIMITATIONS'; ...
            ' '; ...
            'Preprocessing can improve model robustness and parsimony, but it can also remove useful chemical information.'; ...
            'Testing many preprocessing sequences can increase the risk of overfitting, especially with small datasets.'; ...
            'Derivatives and normalization can change the interpretation of loadings, VIP and spectral importance.'; ...
            'Always compare raw and processed data and, whenever possible, confirm the choice using independent validation.'; ...
            'Do not select preprocessing only because it gives the best value in one plot or one cross-validation run.'; ...
            ' '; ...
            'RELATION WITH PLS-DM'; ...
            ' '; ...
            'In PLS-DM, preprocessing affects the latent variable space, Q/f distances, acceptance boundaries, sensitivity, specificity and efficiency.'; ...
            'For rigorous modelling, the main effect is usually seen in sensitivity and acceptance of target samples.'; ...
            'For compliant modelling, preprocessing may also affect specificity because non-target samples are used to evaluate rejection ability.'; ...
            ' '; ...
            'INTERPRETATION GUIDELINES'; ...
            ' '; ...
            'If two preprocessing strategies give similar performance, prefer the one with fewer latent variables and clearer chemical interpretation.'; ...
            'If a preprocessing strongly changes the shape of the signal, interpret VIP/loadings with caution.'; ...
            'If derivatives are used, remember that peaks in the original signal may correspond to zero crossings or positive/negative lobes in derivative signals.'; ...
            'If SNV, MSC or normalization are used, remember that information can be redistributed along the signal profile.'
            };

        uicontrol('Parent',hf,'Style','edit', ...
                  'Units','normalized','Position',[0.03 0.04 0.94 0.86], ...
                  'Max',2,'Min',0, ...
                  'String',helpText, ...
                  'HorizontalAlignment','left', ...
                  'FontName','Courier New','FontSize',10, ...
                  'BackgroundColor',[1 1 1]);
    end

    function onLoadExample(hObj,ev)
        S = guidata(hObj);
        [X,cl,axv,names,clNames] = createExampleData();
        S.Xraw = X;
        S.Xall = X;
        S.Xproc = X;
        S.class = cl;
        S.classAll = cl(:);
        S.axis = axv;
        S.axisProc = axv;
        S.axisProvided = 1;
        S.xLabelText = 'Variable';
        S.yLabelText = 'Intensity';
        S.sampleNames = names;
        S.sampleNamesAll = names(:);
        S.sampleIncluded = true(size(X,1),1);
        S.originalRows = (1:size(X,1))';
        S.classNames = clNames;
        S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
        set(S.btnDataInfo,'Enable','on','String','Add data info...');
        set(S.btnExclude,'Enable','on');
        S.currentPreprocLabel = 'Raw';
        S.preproSteps = struct('method',{},'label',{},'params',{});
        S.msc_ref = [];
        S.msc_ref_class = [];
        S.PreprocessingModel = buildPreprocessingModel(S,'raw',S.Xraw,S.Xproc);
        updateChainList(S);
        S = refreshSubsetMenu(S);
        guidata(hObj,S);
        clearVisualizationObjects(hObj);
        refreshAll(hObj);
    end

    function onImportWorkspace(hObj,ev)
        S = guidata(hObj);
        [ok,names,vals] = plsdm_select_workspace_vars('Import workspace', ...
            {'X matrix','Class vector','x-axis vector'}, {'X','class','axis'}, {false,true,true});
        if ~ok, return; end
        try
            X = vals{1};
            if isempty(vals{2})
                cl = ones(size(X,1),1);
            else
                cl = vals{2};
                if size(cl,1)==1
                    cl = cl';
                end
            end
            if isempty(vals{3})
                axv = 1:size(X,2);
                axisProvided = 0;
            else
                axv = vals{3};
                axisProvided = 1;
            end
            if length(cl) ~= size(X,1)
                error('Class vector length must match the number of rows of X. Leave the class field empty to use a single class.');
            end
            if length(axv) ~= size(X,2)
                error('x-axis vector length must match the number of columns of X.');
            end
            S.Xraw = X;
            S.Xall = X;
            S.Xproc = X;
            S.class = cl;
            S.classAll = cl(:);
            S.axis = axv(:)';
            S.axisProc = S.axis;
            S.axisProvided = axisProvided;
            S.xLabelText = 'Variable';
            S.yLabelText = 'Intensity';
            S.sampleNames = buildSampleNames(size(X,1));
            S.sampleNamesAll = S.sampleNames(:);
            S.sampleIncluded = true(size(X,1),1);
            S.originalRows = (1:size(X,1))';
            S.classNames = buildClassNames(unique(cl));
            S.dataInfo = struct('xLabel','','yLabel','','classValues',[],'classNames',{{}},'sampleNames',{{}});
            set(S.btnDataInfo,'Enable','on','String','Add data info...');
            set(S.btnExclude,'Enable','on');
            S.currentPreprocLabel = 'Raw';
            S.exportVarName = 'Xproc';
            S.preproSteps = struct('method',{},'label',{},'params',{});
            S.msc_ref = [];
            S.msc_ref_class = [];
            S.PreprocessingModel = buildPreprocessingModel(S,'raw',S.Xraw,S.Xproc);
            updateChainList(S);
            S = refreshSubsetMenu(S);
            guidata(hObj,S);
            refreshAll(hObj);
        catch ME
            errordlg(['Error importing data: ' ME.message],'Import');
        end
    end

    function onDataInfo(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xraw), errordlg('Load data before adding data information.','Add data info'); return; end
        current = S.dataInfo;
        current.xLabel = S.xLabelText; current.yLabel = S.yLabelText;
        current.classValues = plsdm_unique_stable(S.class(:)); current.classNames = S.classNames;
        current.sampleNames = S.sampleNames;
        [info,applied] = plsdm_add_data_info(fig,S.class,size(S.Xraw,1),current);
        if ~applied, return; end
        S.dataInfo = info;
        if ~isempty(info.xLabel), S.xLabelText = info.xLabel; else, S.xLabelText = 'Variable'; end
        if ~isempty(info.yLabel), S.yLabelText = info.yLabel; else, S.yLabelText = 'Intensity'; end
        S.classNames = info.classNames;
        if ~isempty(info.sampleNames), S.sampleNames = info.sampleNames; else, S.sampleNames = buildSampleNames(size(S.Xraw,1)); end
        if ~isempty(S.sampleIncluded) && numel(S.sampleIncluded) == numel(S.sampleNamesAll)
            S.sampleNamesAll(S.sampleIncluded) = S.sampleNames(:);
        end
        set(S.btnDataInfo,'String','Edit data info...');
        guidata(fig,S); refreshAll(fig);
    end

    function onExcludeSamples(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xall), errordlg('Load data before editing sample inclusion.','Exclude samples'); return; end
        d = struct('label','Loaded data','X',S.Xall, ...
            'classDisplay',{num2cell(S.classAll(:))}, ...
            'sampleNames',{S.sampleNamesAll(:)}, ...
            'originalRows',S.originalRows(:),'included',S.sampleIncluded(:));
        [applied,d] = plsdm_exclude_samples_dialog(fig,d);
        if ~applied, return; end
        S.sampleIncluded = d.included;
        S.Xraw = S.Xall(S.sampleIncluded,:);
        S.Xproc = S.Xraw;
        S.class = S.classAll(S.sampleIncluded);
        S.sampleNames = S.sampleNamesAll(S.sampleIncluded);
        S.axisProc = S.axis;
        S.currentPreprocLabel = 'Raw';
        S.preproSteps = struct('method',{},'label',{},'params',{});
        S.msc_ref = [];
        S.msc_ref_class = [];
        S.PreprocessingModel = buildPreprocessingModel(S,'sample_selection_changed',S.Xraw,S.Xproc);
        updateChainList(S);
        guidata(hObj,S);
        clearVisualizationObjects(hObj);
        refreshAll(hObj);
        msgbox('Sample selection updated. Preprocessing was reset; apply it again to visualize the updated results.', ...
            'Sample selection updated');
    end

    function onApplyPreproc(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xraw)
            errordlg('No data loaded.','Preprocessing');
            return;
        end

        [S,step,ok] = captureSelectedPreprocStep(S);
        if ~ok, return; end
        [Xp,axisProc,mscRef,mscRefClass] = applyPreprocStep(S.Xraw,S.axis,step);
        S.Xproc = Xp;
        S.axisProc = axisProc;
        S.msc_ref = mscRef;
        S.msc_ref_class = mscRefClass;
        if strcmpi(step.method,'Raw')
            S.preproSteps = struct('method',{},'label',{},'params',{});
            S.currentPreprocLabel = 'Raw';
            S.PreprocessingModel = buildPreprocessingModel(S,'raw',S.Xraw,S.Xproc);
        else
            S.preproSteps = step;
            S.currentPreprocLabel = step.label;
            S.PreprocessingModel = buildPreprocessingModel(S,'single_apply',S.Xraw,S.Xproc);
        end
        updateChainList(S);
        guidata(hObj,S);
        clearVisualizationObjects(hObj);
        refreshAll(hObj);
    end

    function onAddStep(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xraw)
            errordlg('Load data before defining the preprocessing chain.','Preprocessing chain');
            return;
        end
        [S,step,ok] = captureSelectedPreprocStep(S);
        if ~ok, return; end
        if strcmpi(step.method,'Raw')
            S.preproSteps = struct('method',{},'label',{},'params',{});
        else
            S.preproSteps(end+1) = step;
        end
        S.PreprocessingModel = buildPreprocessingModel(S,'defined_not_run',S.Xraw,S.Xproc);
        updateChainList(S);
        guidata(hObj,S);
    end

    function onRunChain(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xraw)
            errordlg('No data loaded.','Preprocessing chain');
            return;
        end
        if isempty(S.preproSteps)
            S.Xproc = S.Xraw;
            S.axisProc = S.axis;
            S.currentPreprocLabel = 'Raw';
            S.msc_ref = [];
            S.msc_ref_class = [];
        else
            Xp = S.Xraw;
            axisProc = S.axis;
            mscRef = [];
            mscRefClass = [];
            for iStep = 1:length(S.preproSteps)
                [Xp,axisProc,stepMscRef,stepMscClass] = applyPreprocStep(Xp,axisProc,S.preproSteps(iStep));
                if ~isempty(stepMscRef)
                    mscRef = stepMscRef;
                    mscRefClass = stepMscClass;
                end
            end
            S.Xproc = Xp;
            S.axisProc = axisProc;
            S.msc_ref = mscRef;
            S.msc_ref_class = mscRefClass;
            S.currentPreprocLabel = buildChainLabel(S.preproSteps);
        end
        S.PreprocessingModel = buildPreprocessingModel(S,'chain',S.Xraw,S.Xproc);
        updateChainList(S);
        guidata(hObj,S);
        clearVisualizationObjects(hObj);
        refreshAll(hObj);
    end

    function onClearChain(hObj,ev)
        S = guidata(hObj);
        S.preproSteps = struct('method',{},'label',{},'params',{});
        S.PreprocessingModel = buildPreprocessingModel(S,'cleared',S.Xraw,S.Xproc);
        updateChainList(S);
        guidata(hObj,S);
    end

    function onRestoreRaw(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xraw), return; end
        S.Xproc = S.Xraw;
        S.axisProc = S.axis;
        S.currentPreprocLabel = 'Raw';
        S.msc_ref = [];
        S.msc_ref_class = [];
        S.preproSteps = struct('method',{},'label',{},'params',{});
        S.PreprocessingModel = buildPreprocessingModel(S,'raw',S.Xraw,S.Xproc);
        set(S.lstPre,'Value',1);
        updateChainList(S);
        guidata(hObj,S);
        clearVisualizationObjects(hObj);
        refreshAll(hObj);
    end

    function onExportXproc(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xproc)
            errordlg('Nothing to export.','Export');
            return;
        end
        ansVar = inputdlg({'Name for the preprocessed matrix in the workspace:'}, ...
                          'Export variable name',1,{S.exportVarName});
        if isempty(ansVar)
            return;
        end
        varName = strtrim(ansVar{1});
        if isempty(varName)
            varName = 'Xproc';
        end
        if ~isvarname(varName)
            errordlg('Invalid variable name. Use a valid MATLAB variable name.','Export variable name');
            return;
        end
        S.exportVarName = varName;
        if isempty(S.PreprocessingModel)
            S.PreprocessingModel = buildPreprocessingModel(S,'export',S.Xraw,S.Xproc);
        end
        guidata(hObj,S);
        assignin('base',S.exportVarName,S.Xproc);
        exportedNames = S.exportVarName;
        if isfield(S,'msc_ref') && ~isempty(S.msc_ref)
            exportMsc = questdlg( ...
                'Export the MSC reference spectrum used for this correction as msc_ref (1 x J)?', ...
                'Export MSC reference','Yes','No','Yes');
            if strcmp(exportMsc,'Yes')
                assignin('base','msc_ref',S.msc_ref(:)');
                exportedNames = [exportedNames ', msc_ref'];
                if isfield(S,'msc_ref_class') && ~isempty(S.msc_ref_class)
                    assignin('base','msc_ref_class',S.msc_ref_class);
                    exportedNames = [exportedNames ', msc_ref_class'];
                end
            end
        end
        if isfield(S,'axisProvided') && S.axisProvided == 1
            axisName = ['xaxis_' S.exportVarName];
            assignin('base',axisName,S.axisProc);
            exportedNames = [exportedNames ', ' axisName];
        end
        msgbox(['Variables exported to workspace: ' exportedNames], 'Export');
    end

    function onExportPlots(hObj,ev)
        S = guidata(hObj);
        if isempty(S.Xproc)
            errordlg('No plots available for export.','Export plots');
            return;
        end
        [Xsub,clsub] = getCurrentSubset(S);
        procYLabel = getProcessedYLabel(S);
        plotNames = {'Raw spectra','Raw class means', ...
            ['Preprocessed spectra - ' S.currentPreprocLabel],['Preprocessed class means - ' S.currentPreprocLabel]};
        selected = plsdm_select_plots_to_export(fig,plotNames);
        if isempty(selected), return; end
        f = figure('Name','Exported plots','NumberTitle','off','Color',[1 1 1]);
        [XrawSub,clrawSub] = getCurrentRawSubset(S);
        n = numel(selected); nr = ceil(sqrt(n)); nc = ceil(n/nr);
        for jj = 1:n
            ax = subplot(nr,nc,jj,'Parent',f);
            switch selected(jj)
                case 1, plotSpectraPanel(ax,XrawSub,clrawSub,S.axis,1,S.classColors,plotNames{1},S.xLabelText,S.yLabelText,S.classNames);
                case 2, plotMeanStdPanel(ax,XrawSub,clrawSub,S.axis,0,S.classColors,plotNames{2},S.xLabelText,S.yLabelText,S.classNames);
                case 3, plotSpectraPanel(ax,Xsub,clsub,S.axisProc,1,S.classColors,plotNames{3},S.xLabelText,procYLabel,S.classNames);
                case 4, plotMeanStdPanel(ax,Xsub,clsub,S.axisProc,0,S.classColors,plotNames{4},S.xLabelText,procYLabel,S.classNames);
            end
        end
    end

    function [S,step,ok] = captureSelectedPreprocStep(S)
        list = get(S.lstPre,'String');
        val = get(S.lstPre,'Value');
        choice = list{val};

        win = str2double(get(S.edWin,'String'));
        if isnan(win) || win < 3
            win = 5;
            set(S.edWin,'String','5');
        end
        if mod(win,2) == 0
            win = win + 1;
            set(S.edWin,'String',num2str(win));
        end

        sgDer = get(S.popupSGDer,'Value');
        sgWin = str2double(get(S.edSGWin,'String'));
        sgPoly = str2double(get(S.edSGPoly,'String'));

        if isnan(sgWin) || sgWin < 5
            sgWin = 11;
            set(S.edSGWin,'String','11');
        end
        if mod(sgWin,2) == 0
            sgWin = sgWin + 1;
            set(S.edSGWin,'String',num2str(sgWin));
        end
        if isnan(sgPoly) || sgPoly < 1
            sgPoly = 2;
            set(S.edSGPoly,'String','2');
        end
        if sgPoly >= sgWin
            sgPoly = sgWin - 1;
            set(S.edSGPoly,'String',num2str(sgPoly));
        end

        params = struct();
        params.movingWindow = win;
        params.sgDerivativeOrder = sgDer;
        params.sgWindow = sgWin;
        params.sgPolynomialOrder = sgPoly;

        step = struct();
        step.method = choice;
        step.label = buildStepLabel(choice,params);
        step.params = params;
        ok = true;
        if strcmpi(choice,'MSC')
            [mscOk,mscSource,mscReference,mscTargetClass] = configureMscReference(size(S.Xraw,2),S.class);
            if ~mscOk
                ok = false;
                return;
            end
            step.params.mscSource = mscSource;
            step.params.mscReference = mscReference;
            step.params.mscTargetClass = mscTargetClass;
            if strcmp(mscSource,'target_class')
                step.params.mscTargetMask = (S.class(:) == mscTargetClass);
            end
            if strcmp(mscSource,'external')
                step.label = 'MSC (external reference)';
            elseif strcmp(mscSource,'target_class')
                step.label = ['MSC (class ' num2str(mscTargetClass) ' mean)'];
            else
                step.label = 'MSC (mean reference)';
            end
        end
    end

    function [Xp,axisp,mscRef,mscRefClass] = applyPreprocStep(X,axisv,step)
        choice = step.method;
        p = step.params;
        axisp = axisv;
        mscRef = [];
        mscRefClass = [];
        switch lower(choice)
            case 'raw'
                Xp = X;
            case 'center'
                Xp = preprocess_mean_center(X);
            case 'autoscaling'
                Xp = preprocess_autoscale(X);
            case 'snv'
                Xp = preprocess_snv(X);
            case 'msc'
                if isfield(p,'mscSource') && strcmp(p.mscSource,'external')
                    mscRef = validateMscReference(p.mscReference,size(X,2));
                elseif isfield(p,'mscSource') && strcmp(p.mscSource,'target_class')
                    if ~isfield(p,'mscTargetMask') || numel(p.mscTargetMask) ~= size(X,1) || ~any(p.mscTargetMask)
                        error('No included samples are available for the selected MSC target class.');
                    end
                    mscRef = mean(X(logical(p.mscTargetMask),:),1);
                    mscRefClass = p.mscTargetClass;
                else
                    mscRef = mean(X,1);
                end
                Xp = preprocess_msc(X,mscRef);
            case 'moving average smoothing'
                Xp = preprocess_smooth_ma(X,p.movingWindow);
            case 'savitzky-golay smoothing'
                Xp = preprocess_sg_smoothing(X,p.sgWindow,p.sgPolynomialOrder);
            case '1st derivative'
                Xp = preprocess_first_derivative(X);
                axisp = derivative_axis(axisv,size(X,2),1);
            case 'savitzky-golay derivative'
                Xfull = preprocess_sg_derivative(X,p.sgWindow,p.sgPolynomialOrder,p.sgDerivativeOrder);
                [Xp,axisp] = trim_sg_edges(Xfull,axisv,p.sgWindow);
            case '2nd derivative'
                Xfull = preprocess_sg_derivative(X,p.sgWindow,p.sgPolynomialOrder,2);
                [Xp,axisp] = trim_sg_edges(Xfull,axisv,p.sgWindow);
            case 'baseline offset correction'
                Xp = preprocess_baseline_offset(X);
            case 'max normalization'
                Xp = preprocess_maxnorm(X);
            case 'l1 normalization'
                Xp = preprocess_l1(X);
            case 'l2 normalization'
                Xp = preprocess_l2(X);
            otherwise
                Xp = X;
        end
    end

    function axisp = derivative_axis(axisv,nvars,order)
        if nargin < 3
            order = 1;
        end
        if isempty(axisv) || length(axisv) ~= nvars
            axisp = 1:max(1,nvars-order);
            return;
        end
        if order == 1
            axisp = (axisv(1:end-1) + axisv(2:end)) / 2;
        else
            axisp = axisv(2:end-1);
        end
    end

    function [Xtrim,axistrim] = trim_sg_edges(X,axisv,win)
        halfw = floor(win/2);
        nvars = size(X,2);
        if nvars > 2*halfw
            keep = (halfw+1):(nvars-halfw);
        else
            keep = 1:nvars;
        end
        Xtrim = X(:,keep);
        if isempty(axisv) || length(axisv) ~= nvars
            axistrim = keep;
        else
            axistrim = axisv(keep);
        end
    end

    function label = buildStepLabel(choice,params)
        switch lower(choice)
            case 'moving average smoothing'
                label = ['Moving average smoothing (window=' num2str(params.movingWindow) ')'];
            case 'savitzky-golay smoothing'
                label = ['SG smoothing (window=' num2str(params.sgWindow) ', poly=' num2str(params.sgPolynomialOrder) ')'];
            case 'savitzky-golay derivative'
                if params.sgDerivativeOrder == 1
                    dlabel = '1st';
                else
                    dlabel = '2nd';
                end
                label = ['SG ' dlabel ' derivative (window=' num2str(params.sgWindow) ', poly=' num2str(params.sgPolynomialOrder) ')'];
            case '2nd derivative'
                label = ['SG 2nd derivative (window=' num2str(params.sgWindow) ', poly=' num2str(params.sgPolynomialOrder) ')'];
            otherwise
                label = choice;
        end
    end

    function label = buildChainLabel(steps)
        if isempty(steps)
            label = 'Raw';
            return;
        end
        label = 'Chain: ';
        for iStep = 1:length(steps)
            if iStep > 1
                label = [label ' -> ']; 
            end
            label = [label steps(iStep).label]; 
        end
    end

    function updateChainList(S)
        if ~isfield(S,'lstChain') || ~ishandle(S.lstChain)
            return;
        end
        if isempty(S.preproSteps)
            set(S.lstChain,'String',{'No preprocessing chain defined.'},'Value',1);
            return;
        end
        txt = cell(length(S.preproSteps),1);
        for iStep = 1:length(S.preproSteps)
            txt{iStep} = [num2str(iStep) '. ' S.preproSteps(iStep).label];
        end
        set(S.lstChain,'String',txt,'Value',1);
    end

    function model = buildPreprocessingModel(S,mode,Xraw,Xproc)
        model = struct();
        model.toolbox = 'PLS-DM Toolbox';
        model.module = 'View and preprocessing';
        model.mode = mode;
        model.created = datestr(now);
        model.currentLabel = S.currentPreprocLabel;
        model.steps = S.preproSteps;
        model.nSteps = length(S.preproSteps);
        if isempty(Xraw)
            model.rawSize = [0 0];
        else
            model.rawSize = size(Xraw);
        end
        if isempty(Xproc)
            model.processedSize = [0 0];
        else
            model.processedSize = size(Xproc);
        end
        model.xAxisRaw = S.axis;
        model.xAxisProcessed = S.axisProc;
        model.axisProvided = S.axisProvided;
        model.xLabel = S.xLabelText;
        model.yLabel = S.yLabelText;
        model.classVector = S.class;
        model.classNames = S.classNames;
        model.msc_ref = S.msc_ref;
        model.sampleIncluded = S.sampleIncluded;
        model.includedOriginalRows = S.originalRows(S.sampleIncluded);
        model.excludedOriginalRows = S.originalRows(~S.sampleIncluded);
        model.notes = ['Apply the listed steps in order to transform Xraw into ' ...
                       'the exported preprocessed matrix.'];
    end

    function [ok,source,reference,targetClass] = configureMscReference(nVars,classVector)
        ok = false;
        source = '';
        reference = [];
        targetClass = [];
        state.reference = [];
        classValues = unique(classVector(:));
        classLabels = arrayfun(@num2str,classValues,'UniformOutput',false);

        hDlg = dialog('Name','MSC reference','WindowStyle','modal', ...
            'Units','pixels','Position',[300 250 570 285], ...
            'Color',[0.95 0.96 0.94],'CloseRequestFcn',@onCancelMsc);
        uicontrol('Parent',hDlg,'Style','text', ...
            'String','Select the reference spectrum used for MSC correction:', ...
            'Units','normalized','Position',[0.06 0.82 0.88 0.09], ...
            'HorizontalAlignment','left','FontWeight','bold', ...
            'BackgroundColor',[0.95 0.96 0.94]);
        hSource = uicontrol('Parent',hDlg,'Style','popupmenu', ...
            'String',{'Use the mean spectrum of all current samples', ...
                      'Use the mean spectrum of a target class', ...
                      'Load a reference spectrum from the MATLAB workspace'}, ...
            'Units','normalized','Position',[0.06 0.68 0.88 0.10], ...
            'Callback',@onMscSourceChanged);
        uicontrol('Parent',hDlg,'Style','text','String','Reference class:', ...
            'Units','normalized','Position',[0.06 0.59 0.22 0.06], ...
            'HorizontalAlignment','left','BackgroundColor',[0.95 0.96 0.94]);
        hClass = uicontrol('Parent',hDlg,'Style','popupmenu','String',classLabels, ...
            'Units','normalized','Position',[0.28 0.59 0.18 0.07],'Enable','off');
        hLoad = uicontrol('Parent',hDlg,'Style','pushbutton', ...
            'String','Select reference from workspace...', ...
            'Units','normalized','Position',[0.06 0.47 0.48 0.10], ...
            'Enable','off','Callback',@onLoadMscReference);
        hStatus = uicontrol('Parent',hDlg,'Style','text', ...
            'String','The mean spectrum will be calculated when MSC is applied.', ...
            'Units','normalized','Position',[0.56 0.45 0.38 0.14], ...
            'HorizontalAlignment','left','BackgroundColor',[0.95 0.96 0.94]);
        uicontrol('Parent',hDlg,'Style','text', ...
            'String',['Important: partition data before using a mean MSC reference. ' ...
                      'For OCC, use only target-class training samples to calculate it. See Help for details.'], ...
            'Units','normalized','Position',[0.06 0.25 0.88 0.20], ...
            'HorizontalAlignment','left','ForegroundColor',[0.55 0.18 0.08], ...
            'BackgroundColor',[0.95 0.96 0.94]);
        uicontrol('Parent',hDlg,'Style','pushbutton','String','OK', ...
            'Units','normalized','Position',[0.55 0.07 0.18 0.12], ...
            'FontWeight','bold','Callback',@onAcceptMsc);
        uicontrol('Parent',hDlg,'Style','pushbutton','String','Cancel', ...
            'Units','normalized','Position',[0.76 0.07 0.18 0.12], ...
            'Callback',@onCancelMsc);

        uiwait(hDlg);
        if ishandle(hDlg)
            result = getappdata(hDlg,'MscResult');
            if ~isempty(result)
                ok = result.ok;
                source = result.source;
                reference = result.reference;
                targetClass = result.targetClass;
            end
            delete(hDlg);
        end

        function onMscSourceChanged(src,ev)
            value = get(hSource,'Value');
            set(hClass,'Enable','off');
            set(hLoad,'Enable','off');
            if value == 3
                set(hLoad,'Enable','on');
                if isempty(state.reference)
                    set(hStatus,'String','No external reference selected.');
                end
            elseif value == 2
                set(hClass,'Enable','on');
                set(hStatus,'String','The selected class mean will be applied to all samples.');
            else
                set(hStatus,'String','The mean spectrum will be calculated when MSC is applied.');
            end
        end

        function onLoadMscReference(src,ev)
            [selected,names,vals] = plsdm_select_workspace_vars('Load MSC reference', ...
                {'MSC reference spectrum (1 x J)'},{'msc_ref'},{false});
            if ~selected, return; end
            try
                state.reference = validateMscReference(vals{1},nVars);
                set(hStatus,'String',['Loaded: ' names{1} ' (1 x ' num2str(nVars) ')']);
            catch ME
                errordlg(ME.message,'MSC reference');
            end
        end

        function onAcceptMsc(src,ev)
            result.ok = true;
            result.targetClass = [];
            value = get(hSource,'Value');
            if value == 1
                result.source = 'mean';
                result.reference = [];
            elseif value == 2
                result.source = 'target_class';
                result.reference = [];
                result.targetClass = classValues(get(hClass,'Value'));
            else
                if isempty(state.reference)
                    errordlg('Select a reference spectrum from the MATLAB workspace before continuing.','MSC reference');
                    return;
                end
                result.source = 'external';
                result.reference = state.reference;
            end
            setappdata(hDlg,'MscResult',result);
            uiresume(hDlg);
        end

        function onCancelMsc(src,ev)
            result.ok = false;
            result.source = '';
            result.reference = [];
            result.targetClass = [];
            setappdata(hDlg,'MscResult',result);
            uiresume(hDlg);
        end
    end

    function ref = validateMscReference(ref,nVars)
        if ~isnumeric(ref) || ~isreal(ref) || ~isvector(ref)
            error('The MSC reference must be a real numeric vector.');
        end
        if numel(ref) ~= nVars
            error(['The MSC reference must contain exactly ' num2str(nVars) ' elements (one per variable).']);
        end
        if any(~isfinite(ref(:)))
            error('The MSC reference cannot contain NaN or Inf values.');
        end
        ref = double(ref(:)');
        if all(ref == ref(1))
            error('The MSC reference must contain variation; a constant vector cannot be used.');
        end
    end

    % ============================================================
    % GUI SUPPORT
    % ============================================================
    function clearVisualizationObjects(hObj)
        
        S = guidata(hObj);
        figLocal = ancestor(hObj,'figure');
        if isempty(figLocal) || ~ishandle(figLocal)
            figLocal = fig;
        end

        try, delete(findall(figLocal,'Tag','legend')); catch, end
        try, delete(findall(figLocal,'Tag','Colorbar')); catch, end

        hardClearAxis(S.ax1,'Raw spectra',S.xLabelText,S.yLabelText);
        hardClearAxis(S.ax2,'Raw class means',S.xLabelText,S.yLabelText);
        hardClearAxis(S.ax3,'Preprocessed spectra',S.xLabelText,getProcessedYLabel(S));
        hardClearAxis(S.ax4,'Preprocessed class means',S.xLabelText,getProcessedYLabel(S));
    end

    function hardClearAxis(ax,ttl,xlab,ylab)
        
        if isempty(ax) || ~ishandle(ax)
            return;
        end
        try, delete(allchild(ax)); catch, end
        try, cla(ax,'reset'); catch, cla(ax); end
        axes(ax);
        title(ttl,'FontWeight','bold');
        xlabel(xlab,'FontWeight','bold');
        ylabel(ylab,'FontWeight','bold');
        set(ax,'FontName','Arial','FontSize',10,'LineWidth',1.0);
        box on; grid on;
    end

    function refreshAll(hObj,ev)
        S = guidata(hObj);
       
        %
        clearVisualizationObjects(hObj);

        if isempty(S.Xproc)
            return;
        end

        [Xsub,clsub,idx] = getCurrentSubset(S);
        [XrawSub,clrawSub] = getCurrentRawSubset(S);
        procYLabel = getProcessedYLabel(S);
        plotSpectraPanel(S.ax1,XrawSub,clrawSub,S.axis,1,S.classColors,'Raw spectra',S.xLabelText,S.yLabelText,S.classNames);
        plotMeanStdPanel(S.ax2,XrawSub,clrawSub,S.axis,0,S.classColors,'Raw class means',S.xLabelText,S.yLabelText,S.classNames);
        plotSpectraPanel(S.ax3,Xsub,clsub,S.axisProc,1,S.classColors,['Preprocessed spectra - ' S.currentPreprocLabel],S.xLabelText,procYLabel,S.classNames);
        plotMeanStdPanel(S.ax4,Xsub,clsub,S.axisProc,0,S.classColors,['Preprocessed class means - ' S.currentPreprocLabel],S.xLabelText,procYLabel,S.classNames);
        updateInfoBox(S,Xsub,clsub,idx);
        drawnow;
    end

    function yLabel = getProcessedYLabel(S)
        yLabel = S.yLabelText;
        derivativeOrder = 0;
        for kk = 1:length(S.preproSteps)
            method = lower(S.preproSteps(kk).method);
            if strcmp(method,'1st derivative')
                derivativeOrder = derivativeOrder + 1;
            elseif strcmp(method,'2nd derivative')
                derivativeOrder = derivativeOrder + 2;
            elseif strcmp(method,'savitzky-golay derivative')
                derivativeOrder = derivativeOrder + S.preproSteps(kk).params.sgDerivativeOrder;
            end
        end
        if derivativeOrder == 1
            yLabel = [yLabel ' (1st der.)'];
        elseif derivativeOrder == 2
            yLabel = [yLabel ' (2nd der.)'];
        elseif derivativeOrder > 2
            yLabel = [yLabel ' (' num2str(derivativeOrder) 'th der.)'];
        end
    end

    function S = refreshSubsetMenu(S)
     
    end

    function [Xsub,clsub,idx] = getCurrentSubset(S)
        idx = 1:size(S.Xproc,1);
        Xsub = S.Xproc(idx,:);
        clsub = S.class(idx);
    end

    function [XrawSub,clrawSub,idx] = getCurrentRawSubset(S)
        idx = 1:size(S.Xraw,1);
        XrawSub = S.Xraw(idx,:);
        clrawSub = S.class(idx);
    end

    function updateInfoBox(S,Xsub,clsub,idx)
        txt = {};
        txt{end+1} = ['Total samples: ' num2str(size(S.Xraw,1))];
        txt{end+1} = ['Variables: ' num2str(size(S.Xraw,2))];
        txt{end+1} = ['Samples displayed: ' num2str(length(idx))];
        txt{end+1} = ['Preprocessing: ' S.currentPreprocLabel];
        u = unique(clsub(:)');
        for k = 1:length(u)
            txt{end+1} = ['Class ' num2str(u(k)) ': ' num2str(sum(clsub==u(k))) ' samples'];
        end
        txt{end+1} = ['Min(X): ' num2str(min(Xsub(:)),4)];
        txt{end+1} = ['Max(X): ' num2str(max(Xsub(:)),4)];
        txt{end+1} = ['Mean(X): ' num2str(mean(Xsub(:)),4)];
        set(S.txtInfo,'String',txt);
    end
end

% ================================================================
% PLOTS
% ================================================================
function plotSpectraPanel(ax,X,classv,axisv,showOverlay,classColors,plotTitle,xLabelText,yLabelText,classNames)
    axes(ax);
    try, delete(allchild(ax)); catch, end
    try, cla(ax,'reset'); catch, cla(ax); end
    hold on;
    if isempty(X), return; end
    if nargin < 4 || isempty(axisv)
        axisv = 1:size(X,2);
    end
    if nargin < 6 || isempty(classColors)
        classColors = lines(max(2,length(unique(classv))));
    end
    if nargin < 7 || isempty(plotTitle)
        plotTitle = 'Spectra';
    end
    if nargin < 8 || isempty(xLabelText), xLabelText = 'Variable'; end
    if nargin < 9 || isempty(yLabelText), yLabelText = 'Intensity'; end

    u = unique(classv(:)');
    legtxt = cell(length(u),1);
    hLeg = zeros(length(u),1);
    for k = 1:length(u)
        Xi = X(classv==u(k),:);
        c = classColors(1+mod(k-1,size(classColors,1)),:);
        if showOverlay
            cPlot = c + 0.55*(1-c);
        else
            cPlot = c;
        end
        for i = 1:size(Xi,1)
            if i == 1
                hLeg(k) = plot(axisv,Xi(i,:),'Color',cPlot,'LineWidth',0.7);
            else
                plot(axisv,Xi(i,:),'Color',cPlot,'LineWidth',0.7,'HandleVisibility','off');
            end
        end
        if k <= numel(classNames), legtxt{k} = classNames{k}; else, legtxt{k} = ['Class ' num2str(u(k))]; end
    end
    xlabel(xLabelText,'FontWeight','bold');
    ylabel(yLabelText,'FontWeight','bold');
    title(plotTitle,'FontWeight','bold');
    if ~isempty(hLeg)
        leg = legend(hLeg,legtxt,'Location','Best');
        set(leg,'Box','off');
    end
    set(ax,'FontName','Arial','FontSize',10,'LineWidth',1.0);
    box on; grid on;
    hold off;
end

function plotMeanStdPanel(ax,X,classv,axisv,showMeanStd,classColors,plotTitle,xLabelText,yLabelText,classNames)
    axes(ax); cla(ax); hold on;
    if isempty(X), return; end
    if nargin < 4 || isempty(axisv)
        axisv = 1:size(X,2);
    end
    if nargin < 6 || isempty(classColors)
        classColors = lines(max(2,length(unique(classv))));
    end
    if nargin < 7 || isempty(plotTitle)
        plotTitle = 'Class means';
    end
    if nargin < 8 || isempty(xLabelText), xLabelText = 'Variable'; end
    if nargin < 9 || isempty(yLabelText), yLabelText = 'Intensity'; end

    u = unique(classv(:)');
    legtxt = cell(length(u),1);
    hLeg = zeros(length(u),1);
    for k = 1:length(u)
        Xi = X(classv==u(k),:);
        mu = mean(Xi,1);
        sd = std(Xi,0,1);
        c = classColors(1+mod(k-1,size(classColors,1)),:);
        if showMeanStd
            plot(axisv,mu+sd,':','Color',c,'LineWidth',1.0,'HandleVisibility','off');
            plot(axisv,mu-sd,':','Color',c,'LineWidth',1.0,'HandleVisibility','off');
        end
        hLeg(k) = plot(axisv,mu,'Color',c,'LineWidth',2.4);
        if k <= numel(classNames), legtxt{k} = [classNames{k} ' mean']; else, legtxt{k} = ['Class ' num2str(u(k)) ' mean']; end
    end
    xlabel(xLabelText,'FontWeight','bold');
    ylabel(yLabelText,'FontWeight','bold');
    title(plotTitle,'FontWeight','bold');
    if ~isempty(hLeg)
        leg = legend(hLeg,legtxt,'Location','Best');
        set(leg,'Box','off');
    end
    set(ax,'FontName','Arial','FontSize',10,'LineWidth',1.0);
    box on; grid on;
    hold off;
end

function plotHeatmapPanel(ax,X)
    axes(ax); cla(ax);
    if isempty(X), return; end
    imagesc(X);
    xlabel('Variable'); ylabel('Sample');
    title('Heatmap','FontWeight','bold');
    set(ax,'FontName','Arial','FontSize',10,'LineWidth',1.0);
    colorbar;
end

function plotHistogramPanel(ax,X)
    axes(ax); cla(ax);
    if isempty(X), return; end
    vals = X(:);
    nb = max(10,round(sqrt(length(vals))));
    hist(vals,nb);
    xlabel('Value'); ylabel('Frequency');
    title('Overall histogram','FontWeight','bold');
    set(ax,'FontName','Arial','FontSize',10,'LineWidth',1.0);
    box on;
end

% ================================================================
% PREPROCESSING
% ================================================================
function Xc = preprocess_mean_center(X)
    mu = mean(X,1);
    Xc = X - repmat(mu,size(X,1),1);
end

function Xs = preprocess_autoscale(X)
    mu = mean(X,1);
    sd = std(X,0,1);
    sd(sd==0) = 1;
    Xs = (X - repmat(mu,size(X,1),1)) ./ repmat(sd,size(X,1),1);
end

function Xsnv = preprocess_snv(X)
    Xsnv = zeros(size(X));
    for i = 1:size(X,1)
        xi = X(i,:);
        s = std(xi);
        if s==0, s=1; end
        Xsnv(i,:) = (xi - mean(xi)) ./ s;
    end
end

function Xmsc = preprocess_msc(X,ref)
    ref = ref(:)';
    Xmsc = zeros(size(X));
    for i = 1:size(X,1)
        xi = X(i,:)';
        A = [ones(length(ref),1) ref(:)];
        b = A\xi;
        a = b(1);
        bb = b(2);
        if bb==0, bb=1; end
        Xmsc(i,:) = ((xi - a)./bb)';
    end
end

function Xsm = preprocess_smooth_ma(X,win)
    Xsm = zeros(size(X));
    h = ones(1,win)/win;
    for i = 1:size(X,1)
        xi = X(i,:);
        Xsm(i,:) = conv(xi,h,'same');
    end
end

function Xd = preprocess_first_derivative(X)
    if size(X,2) < 2
        Xd = X;
        return;
    end
    Xd = diff(X,1,2);
end

function Xsg = preprocess_sg_derivative(X,win,polyOrder,derOrder)
    if mod(win,2)==0
        win = win + 1;
    end
    if polyOrder >= win
        polyOrder = win - 1;
    end
    halfw = (win-1)/2;
    p = size(X,2);

    xloc = (-halfw:halfw)';
    A = zeros(win,polyOrder+1);
    for j = 0:polyOrder
        A(:,j+1) = xloc.^j;
    end
    G = inv(A'*A)*A';
    coeff = factorial(derOrder) * G(derOrder+1,:);

    Xsg = zeros(size(X));
    for i = 1:size(X,1)
        xi = X(i,:);
        yi = zeros(1,p);
        for k = 1:p
            idx = (k-halfw):(k+halfw);
            idx(idx<1) = 1;
            idx(idx>p) = p;
            segment = xi(idx);
            yi(k) = coeff * segment(:);
        end
        Xsg(i,:) = yi;
    end
end


function Xsg = preprocess_sg_smoothing(X,win,polyOrder)
    if mod(win,2)==0
        win = win + 1;
    end
    if polyOrder >= win
        polyOrder = win - 1;
    end
    halfw = (win-1)/2;
    p = size(X,2);

    xloc = (-halfw:halfw)';
    A = zeros(win,polyOrder+1);
    for j = 0:polyOrder
        A(:,j+1) = xloc.^j;
    end
    G = inv(A'*A)*A';
    coeff = G(1,:);

    Xsg = zeros(size(X));
    for i = 1:size(X,1)
        xi = X(i,:);
        yi = zeros(1,p);
        for k = 1:p
            idx = (k-halfw):(k+halfw);
            idx(idx<1) = 1;
            idx(idx>p) = p;
            segment = xi(idx);
            yi(k) = coeff * segment(:);
        end
        Xsg(i,:) = yi;
    end
end

function Xb = preprocess_baseline_offset(X)
    mn = min(X,[],2);
    Xb = X - repmat(mn,1,size(X,2));
end

function Xm = preprocess_maxnorm(X)
    Xm = zeros(size(X));
    for i = 1:size(X,1)
        nrm = max(abs(X(i,:)));
        if nrm==0, nrm=1; end
        Xm(i,:) = X(i,:) / nrm;
    end
end


function X1 = preprocess_l1(X)
    X1 = zeros(size(X));
    for i = 1:size(X,1)
        nrm = sum(abs(X(i,:)));
        if nrm==0, nrm=1; end
        X1(i,:) = X(i,:) / nrm;
    end
end

function X2 = preprocess_l2(X)
    X2 = zeros(size(X));
    for i = 1:size(X,1)
        nrm = sqrt(sum(X(i,:).^2));
        if nrm==0, nrm=1; end
        X2(i,:) = X(i,:) / nrm;
    end
end

% ================================================================
% EXAMPLE DATA
% ================================================================
function [X,classv,axisv,sampleNames,classNames] = createExampleData()
    n1 = 25;
    n2 = 20;
    p  = 180;
    axisv = linspace(1100,2500,p);
    X1 = zeros(n1,p);
    X2 = zeros(n2,p);
    for i = 1:n1
        X1(i,:) = 0.5 + 0.06*randn(1,p) ...
                + 0.25*exp(-(axisv-1450).^2/(2*60^2)) ...
                + 0.18*exp(-(axisv-1930).^2/(2*85^2));
    end
    for i = 1:n2
        X2(i,:) = 0.55 + 0.06*randn(1,p) ...
                + 0.18*exp(-(axisv-1450).^2/(2*65^2)) ...
                + 0.28*exp(-(axisv-2100).^2/(2*90^2));
    end
    X = [X1; X2];
    classv = [ones(n1,1); 2*ones(n2,1)];
    sampleNames = buildSampleNames(size(X,1));
    classNames = {'Class 1','Class 2'};
end

function names = buildSampleNames(n)
    names = cell(n,1);
    for i = 1:n
        names{i} = ['Sample_' num2str(i)];
    end
end

function names = buildClassNames(u)
    names = cell(length(u),1);
    for i = 1:length(u)
        names{i} = ['Class ' num2str(u(i))];
    end
end
