%
function PLSDMopt=plsdm_opt(Xtrain,ClassTrain,Kcv,maxLV,conflev,preprotype,option);
%% ========================================================================
%                                PLS-DM Optimization Routine
%
% Reference:
% Oliveri, P.; Lopez, M. I.; Casolino, M. C.; Ruisanchez, I.; Callao, M. P.;
% Medini, L.; Lanteri, S. Partial least squares density modeling (PLS-DM):
% A new class-modeling strategy applied to the authentication of olives in
% brine by near-infrared spectroscopy. Analytica Chimica Acta, 2014, 851,
% 30-36. https://doi.org/10.1016/j.aca.2014.09.013
%
%   Syntax:
%       PLSDMopt=plsdm_opt(Xtrain,ClassTrain,Kcv,maxLV,conflev,preprotype,option);
%
%   Description:
%       This function performs the optimization stage of the PLS-DM
%       (Partial Least Squares - Density Modeling) model. It evaluates
%       multiple combinations of preprocessing methods, smooth coefficients,
%       kappa values, and latent variables, using K-fold cross-validation.
%       Results are stored in the PLSDMopt structure, including compliance
%       rates and Pareto analysis,.
%
%   Inputs:
%       Xtrain      - Matrix of training data (samples x variables)
%       ClassTrain  - Vector of class labels (target = 1, (opitional) non-target positive ~= 1)
%       Kcv         - (Optional) Number of folds for cross-validation
%       maxLV       - (Optional) Maximum number of latent variables
%       conflev     - (Optional) Confidence level as a fraction (e.g., 0.95)
%       preprotype  - (Optional) A binary vector in which 0 disables and 1 enables each preprocessing option in the following order: raw data, centered, scaled, and autoscaled.
%                      Example: [0 1 0 0] means that only models using centered data will be evaluated.
%                      The default is [1 1 1 1]."
%       option      - (Optional advanced features), cell array (3x1)
%                     option{1} = smooth_coef
%                     Example: smooth_coef = [0.1 0.2 0.3]
%                     Default: smooth_coef = [0.3 0.4 0.5 0.6 0.7 0.8]
%
%                     option{2} = max_kappa
%                     Example: max_kappa = 5
%                     Default: max_kappa = 6
%                     
%                     option{3}= 0 PLS or 1 Robust PLS
%
%   Output:

%       PLSDMopt    - Structure containing all models, compliance analysis,
%                     Pareto charts, and optimization results.
%
%   Notes:
%       - Supports both one-class rigorous and compliant configurations.
%       - Preprocessing: raw, centered, scaled, autoscaled.
%       - The function calls external routines:
%         ClassDensity1, pls_kfold, classify_pls_dm and analyze_pls_dm_results.
%
%   Example:
%       PLSDMopt = plsdm_opt(Xtrain, ClassTrain);
%
% Count how many samples belong to the target class (label = 1)
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

PLSDMopt = struct();
PLSDMopt.WarningMessages = {};
nTarget = sum(ClassTrain == 1);
nNTarget=find(ClassTrain ~= 1);
%
if nTarget == 1
    error('It is not possible to build models with only 1 sample in the target class.');
    
elseif nTarget == 0
    error('There are no samples from the target class in the current dataset.');
    
elseif nTarget >= 2 && nTarget <= 10
    PLSDMopt.WarningMessages{end+1} = sprintf('Warning: only %d target samples were found. Models may be unreliable.', nTarget);
end
%
[Nsam Nvar]=size(Xtrain);
max_class=max(ClassTrain);
Ctrain=ClassTrain;
%
if max_class>1
    nt_samples = find(ClassTrain ~= 1);
    Ctrain(nt_samples)=2;
    Xtrain2=Xtrain(nt_samples,:);
    Nsam2=size(Xtrain2,1);
end
%
t_samples=find(ClassTrain==1);
Xtrain1=Xtrain(t_samples,:);
Nsam1=size(Xtrain1,1);
%% Initialization
PLSDMopt.model='Optimization step';
PLSDMopt.Xtrain=Xtrain;
PLSDMopt.ClassTrain=ClassTrain;
%
if nargin <5 || isempty(conflev)
    conflev=0.95;
end
%
PLSDMopt.conflev=conflev;
%
if nargin < 4 || isempty(maxLV)
    maxLV= 10;
end
PLSDMopt.maxLV = maxLV;
%
if nargin < 3 || isempty(Kcv)
    if Nsam1>19
        Kcv = 5;
    else
        Kcv=10;
    end
end
PLSDMopt.Kcv=Kcv;
%
targetFoldIndex = mod(t_samples-1,Kcv)+1;
%
if nargin<6 || isempty(preprotype)
    preprotype=[1 1 1 1];
end

if nargin<7
    smooth_coef = [0.3,0.4,0.5,0.6,0.7,0.8];
    kappa=1:6;
    rob=0;
    gama=0.01;
else
    %
    smooth_coef=option{1};
    %
    if isempty(smooth_coef)
        smooth_coef = [0.3,0.4,0.5,0.6,0.7,0.8];
    end
    
    kappa=option{2};
    %
    if isempty(kappa);
        kappa=1:6;
    end
    %
    rob=option{3};
    if isempty( rob);
        rob=0;;
    end
    if numel(option) >= 4
        gama = option{4};
    else
        gama = 0.01;
    end
    if isempty(gama)
        gama = 0.01;
    end
end

%
PLSDMopt.smooth_coef=smooth_coef;
PLSDMopt.SmoothValues=smooth_coef;
PLSDMopt.kappa=kappa;
PLSDMopt.kappa_values=kappa;
PLSDMopt.robust=rob;
PLSDMopt.gama=gama;
%
%% PLS models cv loop
RAWmodels={};
Centeredmodels={};
Scaledmodels={};
Autoscaledmodels={};
%
h = waitbar(0, 'Starting...', 'Name', 'PLS-DM: Optimization Run');
t0 = tic;                  % start the timer

for i=1:length(kappa); %Main loop PLS kfold cv
    % Progress
    p = i / length(kappa);
    kappa_i=kappa(i);
    
    if preprotype(1)==1 % 0  raw data
        for j=1:length(smooth_coef)
            
            %
            if max_class ==1
                if rob==0
                    Modelpls_kfold = pls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'raw', kappa_i, [], targetFoldIndex);
                    
                end
                
                if rob ==1
                    Modelpls_kfold = rpls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'raw', kappa_i, [], gama);
                end
            end
            %
            if  max_class>1
                if rob == 0
                    Modelpls_kfold = pls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'raw',  kappa_i,Xtrain2,targetFoldIndex);
                end
                if rob == 1
                    Modelpls_kfold = rpls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'raw',  kappa_i,Xtrain2,gama);
                end
            end
            
            RAWmodels{i,j}=Modelpls_kfold;
        end
    end
    
    if preprotype(2)==1 % 1  X_centered    - centered by mean of each column
        for j=1:length(smooth_coef)
            
            %
            if max_class ==1
                if rob==0
                    Modelpls_kfold = pls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'centered', kappa_i, [], targetFoldIndex);
                    
                end
                %
                if rob ==1
                    Modelpls_kfold = rpls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'centered', kappa_i, [], gama);
                end
            end
            %
            if  max_class>1
                if rob == 0
                    Modelpls_kfold = pls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'centered',  kappa_i,Xtrain2,targetFoldIndex);
                end
                %
                if rob == 1
                    Modelpls_kfold = rpls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'centered',  kappa_i,Xtrain2,gama);
                end
            end
            %
            Centeredmodels{i,j}=Modelpls_kfold;;
        end
    end
    
    if preprotype(3)==1 % 2  X_scaled - divided by std of each column (no centering)
        %
        for j=1:length(smooth_coef)
            if max_class ==1
                if rob==0
                    Modelpls_kfold = pls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'scaled', kappa_i, [], targetFoldIndex);
                    
                end
                
                if rob ==1
                    Modelpls_kfold = rpls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'scaled', kappa_i, [], gama);
                end
            end
            %
            if  max_class>1
                if rob == 0
                    Modelpls_kfold = pls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'scaled',  kappa_i,Xtrain2,targetFoldIndex);
                end
                if rob == 1
                    Modelpls_kfold = rpls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'scaled',  kappa_i,Xtrain2,gama);
                end
            end
            
            Scaledmodels{i,j}=Modelpls_kfold;
        end
    end
    
    if preprotype(4)==1 % 3  X_autoscaled  - centered and scaled
        %
        
        for j=1:length(smooth_coef)
            %
            if max_class ==1
                if rob==0
                    Modelpls_kfold = pls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'autoscaled', kappa_i, [], targetFoldIndex);
                    
                end
                
                if rob ==1
                    Modelpls_kfold = rpls_kfold(Xtrain1,Kcv, maxLV, conflev, smooth_coef(j), 'autoscaled', kappa_i, [], gama);
                end
            end
            %
            if  max_class>1
                if rob == 0
                    Modelpls_kfold = pls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'autoscaled',  kappa_i,Xtrain2,targetFoldIndex);
                end
                if rob == 1
                    Modelpls_kfold = rpls_kfold(Xtrain1, Kcv, maxLV, conflev, smooth_coef(j), 'autoscaled',  kappa_i,Xtrain2,gama);
                end
            end
            
            Autoscaledmodels{i,j}=Modelpls_kfold;
            
        end
    end
    elapsed = toc(t0);
    % ETA (estimated time remaining)
    if p > 0
        eta = elapsed / p - elapsed;
    else
        eta = Inf;
    end
    
    %
    waitbar(p, h, sprintf('Progress: %.0f%% | Elapsed time: %.2fs | ETA: %.1fs', ...
        100*p, elapsed, eta));
    drawnow;
    
end %Main loop PLS kfold cv end
%
close(h);
PLSDMopt.RAWmodels=RAWmodels;
PLSDMopt.Centeredmodels= Centeredmodels;
PLSDMopt.Scaledmodels=Scaledmodels;
PLSDMopt.Autoscaledmodels=Autoscaledmodels;
%
%% Samples Compliance
if preprotype(1)==1 % 0  raw data
    ComplianceRAWmodels={};
    %
    for i=1:length(kappa);
        %     i
        for j=1:length(smooth_coef)
            %         j
            RWAmodel_ij=RAWmodels{i,j};
            
            for k=1:maxLV
                
                Qresid=RWAmodel_ij.Qresid;
                Fdensity_cv=RWAmodel_ij.f_cv;
                Qlim=RWAmodel_ij.Qlims_perLV;
                qlimit=mean(Qlim{k});
                flimits_perLV=RWAmodel_ij.flimits_perLV;
                flimit= mean(flimits_perLV{k});
                qlimit_target=RWAmodel_ij.Qlimit_cv(:,k);
                flimit_target=RWAmodel_ij.flimit_cv(:,k);
                if  max_class>1
                    f_untarget_cv=RWAmodel_ij.f_untarget_cv;
                    Q_untarget_cv=RWAmodel_ij.Q_untarget_cv;
                    
                end
                %-----------------
                if  max_class == 1
                    Qstat=[Qresid(:,k)];
                    f_density=[Fdensity_cv(:,k)];
                    qlimit=qlimit_target; flimit=flimit_target;
                    Gtrue=ones(Nsam1,1);
                end
                %
                if  max_class> 1
                    Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
                    f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
                    qlimit=[qlimit_target;RWAmodel_ij.Qlimit_untarget_cv(:,k)];
                    flimit=[flimit_target;RWAmodel_ij.flimit_untarget_cv(:,k)];
                    Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
                end
                %------------------
                results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
                ComplianceRAWmodels{i,j,k}=results;
            end
            
        end
        %
    end
    %
    PLSDMopt.ComplianceRAWmodels=ComplianceRAWmodels;
end
%
if preprotype(2)==1 % 1  X_centered
    ComplianceCenteredmodel={};
    for i=1:length(kappa);
        %
        for j=1:length(smooth_coef)
            %
            Centeredmodel_ij=PLSDMopt.Centeredmodels{i,j};
            %
            for k=1:maxLV
                %
                Qresid=Centeredmodel_ij.Qresid;
                Fdensity_cv=Centeredmodel_ij.f_cv;
                Qlim=Centeredmodel_ij.Qlims_perLV;
                qlimit=mean(Qlim{k});
                flimits_perLV=Centeredmodel_ij.flimits_perLV;
                flimit= mean(flimits_perLV{k});
                qlimit_target=Centeredmodel_ij.Qlimit_cv(:,k);
                flimit_target=Centeredmodel_ij.flimit_cv(:,k);
                if  max_class>1
                    f_untarget_cv=Centeredmodel_ij.f_untarget_cv;
                    Q_untarget_cv=Centeredmodel_ij.Q_untarget_cv;
                    
                end
                %-----------------
                if  max_class == 1
                    Qstat=[Qresid(:,k)];
                    f_density=[Fdensity_cv(:,k)];
                    qlimit=qlimit_target; flimit=flimit_target;
                    Gtrue=ones(Nsam1,1);
                end
                %
                if  max_class> 1
                    Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
                    f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
                    qlimit=[qlimit_target;Centeredmodel_ij.Qlimit_untarget_cv(:,k)];
                    flimit=[flimit_target;Centeredmodel_ij.flimit_untarget_cv(:,k)];
                    Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
                end
                %------------------
                results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
                ComplianceCenteredmodel{i,j,k}=results;
            end
            
        end
        
        
    end
    PLSDMopt.ComplianceCenteredmodel=ComplianceCenteredmodel;
end

if preprotype(3)==1 % 2  X_scaled
    ComplianceScaledmodel={};
    for i=1:length(kappa);
        
        for j=1:length(smooth_coef)
            
            Scaledmodel_ij=PLSDMopt.Scaledmodels{i,j};
            
            for k=1:maxLV
                
                Qresid=Scaledmodel_ij.Qresid;
                Fdensity_cv=Scaledmodel_ij.f_cv;
                Qlim=Scaledmodel_ij.Qlims_perLV;
                qlimit=mean(Qlim{k});
                flimits_perLV=Scaledmodel_ij.flimits_perLV;
                flimit= mean(flimits_perLV{k});
                qlimit_target=Scaledmodel_ij.Qlimit_cv(:,k);
                flimit_target=Scaledmodel_ij.flimit_cv(:,k);
                if  max_class>1
                    f_untarget_cv=Scaledmodel_ij.f_untarget_cv;
                    Q_untarget_cv=Scaledmodel_ij.Q_untarget_cv;
                    
                end
                %-----------------
                if  max_class == 1
                    Qstat=[Qresid(:,k)];
                    f_density=[Fdensity_cv(:,k)];
                    qlimit=qlimit_target; flimit=flimit_target;
                    Gtrue=ones(Nsam1,1);
                end
                %
                if  max_class> 1
                    Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
                    f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
                    qlimit=[qlimit_target;Scaledmodel_ij.Qlimit_untarget_cv(:,k)];
                    flimit=[flimit_target;Scaledmodel_ij.flimit_untarget_cv(:,k)];
                    Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
                end
                %------------------
                results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
                ComplianceScaledmodel{i,j,k}=results;
            end
            
        end
        
        
    end
    PLSDMopt.ComplianceScaledmodel=ComplianceScaledmodel;
end

if preprotype(4)==1 % 3  X_autoscaled
    ComplianceAutoscaledmodel={};
    for i=1:length(kappa);
        
        for j=1:length(smooth_coef)
            
            Autoscaledmodel_ij=PLSDMopt.Autoscaledmodels{i,j};
            
            for k=1:maxLV
                
                Qresid=Autoscaledmodel_ij.Qresid;
                Fdensity_cv=Autoscaledmodel_ij.f_cv;
                Qlim=Autoscaledmodel_ij.Qlims_perLV;
                qlimit=mean(Qlim{k});
                flimits_perLV=Autoscaledmodel_ij.flimits_perLV;
                flimit= mean(flimits_perLV{k});
                qlimit_target=Autoscaledmodel_ij.Qlimit_cv(:,k);
                flimit_target=Autoscaledmodel_ij.flimit_cv(:,k);
                if  max_class>1
                    f_untarget_cv=Autoscaledmodel_ij.f_untarget_cv;
                    Q_untarget_cv=Autoscaledmodel_ij.Q_untarget_cv;
                    
                end
                %-----------------
                if  max_class == 1
                    Qstat=[Qresid(:,k)];
                    f_density=[Fdensity_cv(:,k)];
                    qlimit=qlimit_target; flimit=flimit_target;
                    Gtrue=ones(Nsam1,1);
                end
                %
                if  max_class> 1
                    Qstat=[Qresid(:,k);Q_untarget_cv(:,k)];
                    f_density=[Fdensity_cv(:,k);f_untarget_cv(:,k)];
                    qlimit=[qlimit_target;Autoscaledmodel_ij.Qlimit_untarget_cv(:,k)];
                    flimit=[flimit_target;Autoscaledmodel_ij.flimit_untarget_cv(:,k)];
                    Gtrue=[ones(Nsam1,1);2*ones(size(Q_untarget_cv,1),1)];
                end
                %------------------
                results = classify_pls_dm(Qstat, f_density, qlimit, flimit, Gtrue);
                ComplianceAutoscaledmodel{i,j,k}=results;
            end
            
        end
        
        
    end
    PLSDMopt.ComplianceAutoscaledmodel=ComplianceAutoscaledmodel;
end
%% Results of the optimization and graphical outputs
if preprotype(1)==1 % 0  raw data
    figs_before = findobj(0,'Type','figure');
    old_fig_visible = get(0,'DefaultFigureVisible');
    set(0,'DefaultFigureVisible','off');
    try
        evalc('[results_struct, pareto_struct, best_model] = analyze_pls_dm_results(ComplianceRAWmodels,kappa,smooth_coef,conflev,''raw'');');
    catch ME
        set(0,'DefaultFigureVisible',old_fig_visible);
        figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
        rethrow(ME);
    end
    set(0,'DefaultFigureVisible',old_fig_visible);
    figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
    
    PLSDMopt.results_structRaw=results_struct;
    PLSDMopt.pareto_structRaw=pareto_struct;
    %
end
%
if preprotype(2)==1 % 0  X centered
    figs_before = findobj(0,'Type','figure');
    old_fig_visible = get(0,'DefaultFigureVisible');
    set(0,'DefaultFigureVisible','off');
    try
        evalc('[results_struct, pareto_struct, best_model] = analyze_pls_dm_results(ComplianceCenteredmodel,kappa,smooth_coef,conflev,''centered'');');
    catch ME
        set(0,'DefaultFigureVisible',old_fig_visible);
        figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
        rethrow(ME);
    end
    set(0,'DefaultFigureVisible',old_fig_visible);
    figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
    
    PLSDMopt.results_structCentered=results_struct;
    PLSDMopt.pareto_structCentered=pareto_struct;
    %
end
%
if preprotype(3)==1 % X scaled
    figs_before = findobj(0,'Type','figure');
    old_fig_visible = get(0,'DefaultFigureVisible');
    set(0,'DefaultFigureVisible','off');
    try
        evalc('[results_struct, pareto_struct, best_model] = analyze_pls_dm_results(ComplianceScaledmodel,kappa,smooth_coef,conflev,''scale'');');
    catch ME
        set(0,'DefaultFigureVisible',old_fig_visible);
        figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
        rethrow(ME);
    end
    set(0,'DefaultFigureVisible',old_fig_visible);
    figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
    PLSDMopt.results_structScaled=results_struct;
    PLSDMopt.pareto_structScaled=pareto_struct;
    %
end

if preprotype(4)==1 % 3 X Autoscaled
    figs_before = findobj(0,'Type','figure');
    old_fig_visible = get(0,'DefaultFigureVisible');
    set(0,'DefaultFigureVisible','off');
    try
        evalc('[results_struct, pareto_struct, best_model] = analyze_pls_dm_results(ComplianceAutoscaledmodel,kappa,smooth_coef,conflev,''autoscale'');');
    catch ME
        set(0,'DefaultFigureVisible',old_fig_visible);
        figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
        rethrow(ME);
    end
    set(0,'DefaultFigureVisible',old_fig_visible);
    figs_after = findobj(0,'Type','figure'); close(setdiff(figs_after,figs_before));
    
    PLSDMopt.results_structAutoscaled=results_struct;
    PLSDMopt.pareto_structAutoscaled=pareto_struct;
    %
end
PLSDMopt.GUIOptimizationCompleted = true;
if rob==1
    PLSDMopt.RobustNotice = 'Robust PLS algorithm used during optimization.';
end
