%
function Qlim = plsdm_original_qlimit(E,conflev,varargin)
% PLS-DM Toolbox

%PLSDM_ORIGINAL_QLIMIT Jackson-Mudholkar limit from PLS residuals.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 2 || isempty(conflev), conflev = 0.95; end

[n,~] = size(E);
if n < 2
    Qlim = 0;
    return
end

[~,S,~] = svd(E,'econ');
eigv = diag(S).^2/(n-1);
tail = eigv;

if isempty(tail)
    Qlim = 0;
    return
end

theta1 = sum(tail);
theta2 = sum(tail.^2);
theta3 = sum(tail.^3);
h0 = 1 - (2*theta1*theta3)/(3*theta2^2);
if h0 < 0.001, h0 = 0.001; end

try
    z = norminv(conflev);
catch
    z = sqrt(2)*erfinv(2*conflev-1);
end
term = (z*sqrt(2*theta2*h0^2)/theta1) + 1 + (theta2*h0*(h0-1))/(theta1^2);
Qlim = theta1 * term^(1/h0);
if ~isfinite(Qlim) || Qlim < 0
    Qlim = 0;
end
end
