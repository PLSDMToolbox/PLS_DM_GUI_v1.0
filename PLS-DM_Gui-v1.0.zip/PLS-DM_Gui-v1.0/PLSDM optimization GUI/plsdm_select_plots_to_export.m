%
function selected = plsdm_select_plots_to_export(parent,plotNames)
% PLS-DM Toolbox
% Modal selection of named GUI panels to copy into one external figure.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    selected = [];
    n = numel(plotNames); h = 145 + 30*n;
    f = figure('Name','Select plots to export','NumberTitle','off','MenuBar','none', ...
        'ToolBar','none','WindowStyle','modal','Resize','off','Position',center(parent,430,h), ...
        'CloseRequestFcn',@cancelDialog);
    chkAll = uicontrol(f,'Style','checkbox','String','All plots','Value',1, ...
        'FontWeight','bold','Position',[25 h-55 370 25],'Callback',@toggleAll);
    chk = zeros(n,1);
    for k = 1:n
        chk(k) = uicontrol(f,'Style','checkbox','String',plotNames{k},'Value',1, ...
            'Position',[45 h-55-30*k 350 25],'Callback',@syncAll);
    end
    uicontrol(f,'Style','pushbutton','String','Export','FontWeight','bold', ...
        'Position',[215 20 90 32],'Callback',@acceptDialog);
    uicontrol(f,'Style','pushbutton','String','Cancel', ...
        'Position',[320 20 85 32],'Callback',@cancelDialog);
    uiwait(f);
    function toggleAll(~,~), set(chk,'Value',get(chkAll,'Value')); end
    function syncAll(~,~), set(chkAll,'Value',all(cell2mat(get(chk,'Value')))); end
    function acceptDialog(~,~)
        values = cell2mat(get(chk,'Value')); selected = find(values(:));
        if isempty(selected), errordlg('Select at least one plot.','Export plots'); return; end
        uiresume(f); delete(f);
    end
    function cancelDialog(~,~), selected = []; uiresume(f); delete(f); end
end
function p = center(parent,w,h)
    old = get(parent,'Units'); set(parent,'Units','pixels'); q = get(parent,'Position'); set(parent,'Units',old);
    p = [q(1)+(q(3)-w)/2 q(2)+(q(4)-h)/2 w h];
end
