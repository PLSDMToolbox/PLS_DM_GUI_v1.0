%
function values = plsdm_unique_stable(inputValues)
% PLS-DM Toolbox
%PLSDM_UNIQUE_STABLE Stable unique values for old and new MATLAB releases.
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

    inputValues = inputValues(:);
    values = inputValues([]);
    for k = 1:numel(inputValues)
        if isempty(values) || ~any(values == inputValues(k))
            values(end+1,1) = inputValues(k); 
        end
    end
end
