%
function Modelpls_kfold = rpls_kfold(X,K, maxLV, conflev, alpha, preprocessing, kappa,Xuntarget,gama)
% PLS with K-fold cross-validation (ROBUST NIPALS)
%  Syntax:
%   Modelpls_kfold = pls_kfold(X, K, maxLV, conflev, alpha, preprocessing, kappa, Xuntarget)
%
% Inputs:
%   X       - predictors (n x m), Model data (no centering/scaling)
%   K       - number of folds
%   maxLV   - maximum number of latent variables to evaluate
%   conflev - confidence level for Q-limits and f-limits (scalar in (0,1), default 0.95)
%   alpha   - smoothing coefficient for PFM (e.g., 0.3-0.8).
%   preprocessing - 'raw' | 'centered' | 'scaled' | 'autoscaled'
%   kappa   - number of nearest neighbours used to build ytrain (PFM input)
%   Xuntarget - (optional) additional predictors for potential function calculation
%==========================================================================
%   Authors:    Adriano de Araujo Gomes
%                araujo.gomes@ufrgs.br
%
%                  Cristina Malegori
%            cristina.malegori@unige.it
%
%                Mateus P. Schneider
%            mateuspschneider@gmail.com
%
%                   Paolo Oliveri
%               paolo.oliveri@unige.it
%
%   Date:      2025-08-08
%   Version:   1.0
%   Copyright: � 2025
%   Licensed under the PLS-DM Toolbox License.
%   See LICENSE.txt in the toolbox root for terms and attribution.
%==========================================================================

if nargin < 4 || isempty(conflev)
    conflev = 0.95;
end
if nargin < 5
    error('You must provide smoothing coefficient alpha as 6th argument.');
end
if conflev <= 0 || conflev >= 1
    error('conflev must be between 0 and 1 (exclusive).');
end
if nargin < 7
    error('All 7 arguments must be provided.');
end
if nargin < 8
    Xuntarget = [];
end
if nargin < 9 || isempty(gama)
    gama = 0.01;
end

[Nsam, Nvar] = size(X);

% Initialize output struct
Modelpls_kfold.type          = 'Model PLS k fold (robust core)';
Modelpls_kfold.K             = K;
Modelpls_kfold.maxLV         = maxLV;
Modelpls_kfold.conflev       = conflev;
Modelpls_kfold.alpha         = alpha;
Modelpls_kfold.preprocessing = preprocessing;

XModel = X;

% Venetian blinds assignment (model)
cvFolds = cell(1, K);
for k = 1:K
    cvFolds{k} = k:K:Nsam;
end

hasUntarget = (nargin > 7 && ~isempty(Xuntarget));
if hasUntarget
    N_unt = size(Xuntarget,1);
end

% 
Qresid      = nan(Nsam, maxLV);
f_cv        = nan(Nsam, maxLV);
QlimitO_cv  = nan(Nsam, maxLV);
flimitO_cv  = nan(Nsam, maxLV);
RMSEcv      = zeros(maxLV,1);           
y_pred_cv = nan(Nsam, maxLV);

Modelpls_kfold.Qtrain   = cell(maxLV, K);
Modelpls_kfold.Qtest    = cell(maxLV, K);
Modelpls_kfold.ftrain   = cell(maxLV, K);
Modelpls_kfold.ftest    = cell(maxLV, K);
Modelpls_kfold.Ytraincv = cell(maxLV, K);

Modelpls_kfold.Qlims_perLV    = cell(maxLV,1);
Modelpls_kfold.flimits_perLV  = cell(maxLV,1);
Modelpls_kfold.QlimsO_perLV   = cell(maxLV,1);
Modelpls_kfold.flimitsO_perLV = cell(maxLV,1);

if hasUntarget
    N_unt_cv = N_unt*K;
    Modelpls_kfold.f_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.Q_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.Qlimit_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.flimit_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.QlimitO_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.flimitO_untarget_cv = nan(N_unt_cv, maxLV);
    Modelpls_kfold.untarget_fold_index = kron((1:K)',ones(N_unt,1));
end

% z limit to Q-limit (Jackson)
try
    zq = norminv(conflev);
catch
    zq = sqrt(2) * erfinv(2*conflev - 1);
end

% ---------------- MAIN LOOP over LV --------------------
for a = 1:maxLV
    
    y_pred_all  = zeros(Nsam,1);
    qlim_fold   = nan(K,1);
    flimit_fold = nan(K,1);
    qlimO_fold   = nan(K,1);
    flimitO_fold = nan(K,1);
    fold_counter = 0;
    
    for fold = 1:K
        test_idx  = cvFolds{fold};
        train_idx = true(Nsam,1);
        train_idx(test_idx) = false;
        train_idx = find(train_idx);
        
        fold_counter = fold_counter + 1;
        
        % Train/test split
        Xtrain = XModel(train_idx,:);
        Xtest  = XModel(test_idx,:);
        
        %--------------------------------------------------------------
        % === Robust preprocessing: median, MAD, and scale factors ===
        [ntr, m] = size(Xtrain);
        nte      = size(Xtest,1);
        
        mu    = median(Xtrain, 1);
        sigma = mad(Xtrain, 0, 1) * 1.4826;
        sigma(sigma == 0) = 1;
        
        switch lower(preprocessing)
            case 'raw'
                mu    = zeros(1, m);
                sigma = ones(1, m);
                % Xtrain, Xtest 
            case 'centered'
                Xtrain = Xtrain - repmat(mu, ntr, 1);
                Xtest  = Xtest  - repmat(mu, nte, 1);
            case 'scaled'
                Xtrain = (Xtrain) ./ repmat(sigma, ntr, 1);
                Xtest  = (Xtest) ./ repmat(sigma, nte, 1);
            case 'autoscaled'
                Xtrain = (Xtrain - repmat(mu, ntr, 1)) ./ repmat(sigma, ntr, 1);
                Xtest  = (Xtest  - repmat(mu, nte, 1)) ./ repmat(sigma, nte, 1);
            otherwise
                error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
        end
        
        %--------------------------------------------------------------
        % === Class density by kNN ("ytrain") ===
        [D_sorted, ~, ~] = ClassDensity1(Xtrain,true);
        DENSITY_Train = D_sorted(:, 2:ntr);
        dist1         = DENSITY_Train(:, 1:kappa);
        ytrain        = sum(dist1, 2);     
        Modelpls_kfold.Ytraincv{a, fold} = ytrain;
        
        %--------------------------------------------------------------
        % === ROBUST PLS (PRM-like)  ===
        % Initial weights are equal for every sample.
        wSample   = ones(ntr,1);
        maxRobIter = 10;
        tolRob     = 1e-3;
        
        W  = zeros(m,a);
        P  = zeros(m,a);
        Qy = zeros(1,a);
        T  = zeros(ntr,a);
        
        for itRob = 1:maxRobIter
            
            % 1) Fit weighted PLS with a latent variables.
            [W, P, Qy, T] = wpls_nipals_multilv(Xtrain, ytrain, a, wSample);
            
            % 2) Regression coefficients.
            B_pls = W * ((P' * W) \ Qy');
            
            % 3) Training prediction.
            y_pred_train = Xtrain * B_pls;
            r_y          = ytrain - y_pred_train;
            
            % 4) Training X-residual Q statistics.
            Wcoeff      = W / (P' * W);
            Ttrain_proj = Xtrain * Wcoeff;
            Xhat_train  = Ttrain_proj * P';
            Resid_train = Xtrain - Xhat_train;
            Qtrain_tmp  = sum(Resid_train.^2, 2);
            
            % 5) Score-based leverage.
            h = sum(T.^2, 2) ./ (sum(sum(T.^2)) + eps);
            
            % 6) Robust median/MAD scales for r_y, Q, and h.
            med_ry = median(r_y);
            s_ry   = mad(r_y, 1) * 1.4826;  if s_ry == 0, s_ry = eps; end
            zY     = (r_y - med_ry) / s_ry;
            
            med_Q = median(Qtrain_tmp);
            s_Q   = mad(Qtrain_tmp, 1) * 1.4826; if s_Q == 0, s_Q = eps; end
            zQ    = (Qtrain_tmp - med_Q) / s_Q;
            
            med_h = median(h);
            s_h   = mad(h, 1) * 1.4826; if s_h == 0, s_h = eps; end
            zH    = (h - med_h) / s_h;
            
            % 7) Combine diagnostics into the global distance d.
            cY = 4.685; cQ = 4.685; cH = 3.0; % (Adriano 04/03/2026)
            alphaY = 1;  alphaQ = 1;   alphaH = 1;
            
            d = sqrt( ...
                (alphaY * (zY / cY)).^2 + ...
                (alphaQ * (zQ / cQ)).^2 + ...
                (alphaH * (zH / cH)).^2 );
            
            % 8) Tukey bisquare weights.
            w_new = bisquare_tukey(d);
            
            if all(w_new == 0)
                w_new = ones(ntr,1);
            end
            w_new = w_new / sum(w_new);
            
            % 9) Robust stopping criterion.
            if norm(w_new - wSample) < tolRob * norm(wSample)
                wSample = w_new;
                break;
            end
            
            wSample = w_new;
        end
        
        % Store robust Qtrain from the final iteration.
        Modelpls_kfold.Qtrain{a, fold} = Qtrain_tmp;
        
        %--------------------------------------------------------------
        % ===== TEST PREDICTION WITH THE SAME ROBUST MODEL =====
        y_pred_fold = Xtest * B_pls;
        y_pred_all(test_idx) = y_pred_fold;
        y_pred_cv(test_idx, a) = y_pred_fold;
        % Test-set Q residuals.
        Ttest      = Xtest * Wcoeff;
        Xhat_test  = Ttest * P';
        Resid_test = Xtest - Xhat_test;
        Qtest      = sum(Resid_test.^2, 2);
        Qresid(test_idx, a)          = Qtest;
        Modelpls_kfold.Qtest{a,fold} = Qtest;
        
        outlev = (1 - gama)^(1/max(size(Xtrain,1),1));
        Qlim=plsdm_original_qlimit(Resid_train,conflev);
        QlimO=plsdm_original_qlimit(Resid_train,outlev);
        qlim_fold(fold_counter) = Qlim;
        qlimO_fold(fold_counter) = QlimO;
        Qlimit_cv(test_idx,a)=Qlim;
        QlimitO_cv(test_idx,a)=QlimO;
        
        %--------------------------------------------------------------
        % === PFM (Potential Function Method) on scores T ===
        nt_train = size(T,1);
        [f_test,f_alpha_fold,f_train]=plsdm_original_pfm(T,Ttest,alpha,conflev);
        [~,f_alphaO_fold]=plsdm_original_pfm(T,Ttest,alpha,outlev);
        Modelpls_kfold.ftrain{a, fold} = f_train;
        f_cv(test_idx, a)        = f_test;
        Modelpls_kfold.ftest{a, fold} = f_test;
        flimit_fold(fold_counter) = f_alpha_fold;
        flimitO_fold(fold_counter) = f_alphaO_fold;
        flimit_cv(test_idx,a)=f_alpha_fold;
        flimitO_cv(test_idx,a)=f_alphaO_fold;
        
        %--------------------------------------------------------------
        % === Additional calculations for Xuntarget ===
        if hasUntarget
            ut_idx        = ((fold-1)*N_unt + 1):(fold*N_unt);
            Xuntargetcv   = Xuntarget;
            Nsam_untarget = N_unt;
            
            switch lower(preprocessing)
                case 'raw'
                    Xuntarget_processed = Xuntargetcv;
                case 'centered'
                    Xuntarget_processed = Xuntargetcv-repmat(mu,Nsam_untarget,1);
                case 'scaled'
                    Xuntarget_processed = Xuntargetcv./repmat(sigma,Nsam_untarget,1);
                case 'autoscaled'
                    Xuntarget_processed = (Xuntargetcv - repmat(mu, Nsam_untarget, 1)) ./ repmat(sigma, Nsam_untarget, 1);
                otherwise
                    error('Invalid preprocessing option. Choose: raw | centered | scaled | autoscaled');
            end
            
            % Scores  untarget
            T_untarget = Xuntarget_processed * Wcoeff;
            
            f_untarget=plsdm_original_pfm(T,T_untarget,alpha,conflev);
            Modelpls_kfold.f_untarget_cv(ut_idx, a) = f_untarget;
            Modelpls_kfold.Qlimit_untarget_cv(ut_idx,a)=Qlim;
            Modelpls_kfold.flimit_untarget_cv(ut_idx,a)=f_alpha_fold;
            Modelpls_kfold.QlimitO_untarget_cv(ut_idx,a)=QlimO;
            Modelpls_kfold.flimitO_untarget_cv(ut_idx,a)=f_alphaO_fold;
            
            % Q residual untarget
            Xhat_untarget   = T_untarget * P';
            Resid_untarget  = Xuntarget_processed - Xhat_untarget;
            Q_untarget      = sum(Resid_untarget.^2, 2);
            Modelpls_kfold.Q_untarget_cv(ut_idx, a) = Q_untarget;
        end
        
    end % folds
    
    % Store results for current LV
    Modelpls_kfold.Qlims_perLV{a}    = qlim_fold;
    Modelpls_kfold.flimits_perLV{a}  = flimit_fold;
    Modelpls_kfold.QlimsO_perLV{a}   = qlimO_fold;
    Modelpls_kfold.flimitsO_perLV{a} = flimitO_fold;
    % 
end

Modelpls_kfold.f_cv      = f_cv;
Modelpls_kfold.Qresid    = Qresid;
Modelpls_kfold.Qlimit_cv = Qlimit_cv;
Modelpls_kfold.flimit_cv = flimit_cv;
Modelpls_kfold.QlimitO_cv = QlimitO_cv;
Modelpls_kfold.flimitO_cv = flimitO_cv;
Modelpls_kfold.y_pred_cv = y_pred_cv;

end % <- End of the main fuction



% ==  LOCAL FUNCTIONS ==========================================

function [W, P, Qy, T] = wpls_nipals_multilv(X, y, a, wSample)
% WPLS_NIPALS_MULTILV - Multi-LV PLS with sample weights (NIPALS).
%
% X       : (n x m)
% y       : (n x 1)
% a       : number of latent variables
% wSample : n-by-1 sample weights; normalization is not required

y       = y(:);
wSample = wSample(:);
wSample = wSample / sum(wSample);

[n, m] = size(X);

W  = zeros(m,a);
P  = zeros(m,a);
Qy = zeros(1,a);
T  = zeros(n,a);

Xres = X;
yres = y;

maxIter = 100;
tol     = 1e-10;

for comp = 1:a
    % Initialize u from yres.
    u = yres;
    
    for it = 1:maxIter
        % Weighted regression Xres ~ u.
        Wu = wSample .* u;
        w  = Xres' * Wu;            % p x 1
        w  = w / max(norm(w), eps); % normaliza
        
        % score t
        t = Xres * w;               % n x 1
        
        % Weighted regression yres ~ t.
        Wt   = wSample .* t;
        numq = (yres' * Wt);
        denq = (t'    * Wt) + eps;
        q    = numq / denq;
        
        % novo u
        u_new = q * t;
        
        if norm(u_new - u) < tol * (norm(u) + eps)
            u = u_new;
            break;
        end
        u = u_new;
    end
    
    % X loading.
    Wt   = wSample .* t;
    nump = Xres' * Wt;
    denp = (t'   * Wt) + eps;
    p    = nump / denp;
    
    % salva
    W(:,comp)  = w;
    P(:,comp)  = p;
    Qy(:,comp) = q;
    T(:,comp)  = t;
    
    % Deflation.
    Xres = Xres - t * p';
    yres = yres - t * q;
end
end


function w = bisquare_tukey(d)
% BISQUARE_TUKEY Tukey's bisquare weights
%
% Input:
%   d : vector of combined distances (already scaled)
%
% Output:
%   w : vector of weights in [0,1]

w   = zeros(size(d));
idx = (d < 1);
di  = d(idx);
w(idx) = (1 - di.^2).^2;
end
