Licensed under the PLS-DM Toolbox License. 
Internal business use is permitted. 
Sale or incorporation into commercial products requires prior written authorization. See LICENSE.txt.